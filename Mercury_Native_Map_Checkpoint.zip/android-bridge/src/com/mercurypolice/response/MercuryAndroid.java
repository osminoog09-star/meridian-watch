package com.mercurypolice.response;
import android.app.Activity;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.*;
import android.webkit.*;
import android.widget.Toast;
import android.util.DisplayMetrics;
import org.json.*;
import org.godotengine.godot.Godot;
import org.godotengine.godot.plugin.*;
import java.util.*;
import java.io.ByteArrayInputStream;
public final class MercuryAndroid extends GodotPlugin implements ApkUpdater.Host {
 private final Handler main=new Handler(Looper.getMainLooper());
 private ApkUpdater updater;private boolean active=false,closed=false;private Runnable afterSave;private WebView legacy;private boolean migrating=false;
 private final Runnable poll=()->{if(!closed&&active){ensureUpdater();updater.check(false);main.postDelayed(this.pollAgain,300000);}};
 private final Runnable pollAgain=()->{if(!closed&&active){ensureUpdater();updater.check(false);main.postDelayed(this.pollAgain,300000);}};
 public MercuryAndroid(Godot godot){super(godot);}
 @Override public String getPluginName(){return "MercuryAndroid";}
 @Override public Set<SignalInfo> getPluginSignals(){Set<SignalInfo> signals=new HashSet<>();signals.add(new SignalInfo("legacy_storage_ready",String.class,String.class));signals.add(new SignalInfo("save_before_update"));return signals;}
 private void ensureUpdater(){if(updater==null)updater=new ApkUpdater(getActivity(),this);}
 @Override public boolean isActive(){return active&&!closed;}
 @Override public void saveForUpdate(Runnable continuation){afterSave=continuation;emitSignal("save_before_update");main.postDelayed(()->{if(afterSave!=null){afterSave=null;Toast.makeText(getActivity(),"Сохранение не подтверждено — установка отложена",Toast.LENGTH_LONG).show();}},10000);}
 @UsedByGodot public void savedForUpdate(boolean success){main.post(()->{Runnable next=afterSave;afterSave=null;if(success&&next!=null)next.run();});}
 @UsedByGodot public void checkUpdates(boolean manual){main.post(()->{ensureUpdater();updater.check(manual);});}
 @Override public void onMainResume(){active=true;ensureUpdater();updater.resume();main.removeCallbacks(poll);main.removeCallbacks(pollAgain);main.postDelayed(poll,10000);}
 @Override public void onMainPause(){active=false;main.removeCallbacks(poll);main.removeCallbacks(pollAgain);}
 @Override public void onMainDestroy(){closed=true;if(updater!=null)updater.close();main.removeCallbacksAndMessages(null);if(legacy!=null){legacy.destroy();legacy=null;}}
 @Override public void onMainActivityResult(int request,int result,Intent data){if(updater!=null)updater.activityResult(request);}
 @UsedByGodot public void readLegacyStorage(){main.post(()->{
  if(migrating||closed)return;migrating=true;
  legacy=new WebView(getActivity());WebSettings settings=legacy.getSettings();settings.setJavaScriptEnabled(true);settings.setDomStorageEnabled(true);settings.setAllowFileAccess(false);settings.setAllowContentAccess(false);
  legacy.setWebViewClient(new WebViewClient(){
   @Override public boolean shouldOverrideUrlLoading(WebView view,WebResourceRequest request){return true;}
   @Override public WebResourceResponse shouldInterceptRequest(WebView view,WebResourceRequest request){return new WebResourceResponse("text/plain","UTF-8",403,"Blocked",Collections.emptyMap(),new ByteArrayInputStream(new byte[0]));}
   @Override public void onPageFinished(WebView view,String url){
    if(!migrating)return;
    String script="(()=>{const out={};for(const key of ['meridian-watch-v1','meridian-watch-v1-backup','meridian-watch-audio-v1','meridian-watch-a11y-v1','meridian-watch-graphics-v1','meridian-watch-lighting-v1','mercury-frame-rate','mercury-world-rate','mercury-adaptive-resolution','mercury-diagnostics']){const value=localStorage.getItem(key);if(value!==null)out[key]=value;}return JSON.stringify(out);})()";
    view.evaluateJavascript(script,raw->{try{Object value=new JSONArray("["+raw+"]").get(0);if(!(value instanceof String)||((String)value).length()>2500000)throw new Exception("Storage size");String text=(String)value;new JSONObject(text);finishMigration(text,"");}catch(Exception e){finishMigration("{}","Не удалось прочитать старое сохранение");}});
   }
  });
  legacy.loadDataWithBaseURL("https://mercurypolice.com/game/","<!doctype html><html><body></body></html>","text/html","UTF-8",null);
  main.postDelayed(()->{if(migrating)finishMigration("{}","Истекло время чтения старого сохранения");},15000);
 });}
 private void finishMigration(String json,String error){if(!migrating)return;migrating=false;emitSignal("legacy_storage_ready",json,error);if(legacy!=null){legacy.stopLoading();legacy.destroy();legacy=null;}}
 @UsedByGodot public void vibratePattern(String json){main.post(()->{try{JSONArray input=new JSONArray(json);int count=Math.min(16,input.length());long[] pattern=new long[count+1];for(int k=0;k<count;k++)pattern[k+1]=Math.max(0,Math.min(1000,input.getLong(k)));Vibrator vibrator=(Vibrator)getActivity().getSystemService(Activity.VIBRATOR_SERVICE);if(Build.VERSION.SDK_INT>=26)vibrator.vibrate(VibrationEffect.createWaveform(pattern,-1));else vibrator.vibrate(pattern,-1);}catch(Exception e){}});}
 @UsedByGodot public String deviceDiagnostics(){try{JSONObject out=new JSONObject();Debug.MemoryInfo memory=new Debug.MemoryInfo();Debug.getMemoryInfo(memory);out.put("processPssBytes",memory.getTotalPss()*1024L);out.put("model",Build.MODEL);out.put("android",Build.VERSION.RELEASE);DisplayMetrics display=getActivity().getResources().getDisplayMetrics();out.put("width",display.widthPixels);out.put("height",display.heightPixels);out.put("densityDpi",display.densityDpi);Intent battery=getActivity().registerReceiver(null,new IntentFilter(Intent.ACTION_BATTERY_CHANGED));if(battery!=null)out.put("batteryTemperatureC",battery.getIntExtra(BatteryManager.EXTRA_TEMPERATURE,0)/10.0);if(Build.VERSION.SDK_INT>=29)out.put("thermalStatus",((PowerManager)getActivity().getSystemService(Activity.POWER_SERVICE)).getCurrentThermalStatus());return out.toString();}catch(Exception e){return "{}";}}
}
