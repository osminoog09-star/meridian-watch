#ifndef MERCURY_NATIVE_AUDIO_H
#define MERCURY_NATIVE_AUDIO_H
#include <godot_cpp/variant/dictionary.hpp>
#include <godot_cpp/variant/array.hpp>
#include <godot_cpp/variant/packed_vector2_array.hpp>
#include <cmath>
#include <vector>
#include <algorithm>
#include <cstdint>
namespace godot {
class MercuryNativeAudio {
 struct Voice {double age=0,phase=0,filter=0;Dictionary spec;};
 std::vector<Voice> voices;std::vector<Vector2> echo;size_t echo_index=0;int rate=0;
 uint32_t rng=7;double pink[3]={0,0,0},brown=0,filters[12]={0},phases[4]={0},gain[12]={0};
 double noise(){rng=rng*1664525u+1013904223u;return double(rng)/4294967296.0*2-1;}
 double low(double value,double hz,double &previous){double a=1-std::exp(-6.283185307179586*std::max(20.0,std::min(double(rate)*.45,hz))/rate);previous+=a*(value-previous);return previous;}
 double wave(double phase,const std::vector<double>& harmonics){double value=0,sum=0;for(int k=1;k<harmonics.size();k++){double amplitude=harmonics[k];value+=std::sin(phase*k)*amplitude;sum+=std::abs(amplitude);}return sum>0?value/sum:std::sin(phase);}
 double envelope(const Voice& voice){Array shape=voice.spec.get("shape",Array());if(shape.is_empty())return std::max(0.0,1-voice.age/double(voice.spec.get("length",.1)));double previous_time=0,previous_level=0;for(int k=0;k<shape.size();k++){Array point=shape[k];double t=point[0],level=point[1];if(voice.age<=t)return previous_level+(level-previous_level)*std::max(0.0,std::min(1.0,(voice.age-previous_time)/std::max(.000001,t-previous_time)));previous_time=t;previous_level=level;}double length=voice.spec.get("length",.1);return previous_level*std::max(0.0,(length-voice.age)/std::max(.001,length-previous_time));}
 public:
 PackedVector2Array render(const Dictionary &parameters,int frames,int sample_rate){
  sample_rate=std::max(8000,std::min(48000,sample_rate));frames=std::max(0,std::min(8192,frames));if(rate!=sample_rate){rate=sample_rate;echo.assign(rate*2,Vector2());echo_index=0;}
  Array shots=parameters.get("shots",Array());for(int k=0;k<shots.size()&&voices.size()<16;k++){Dictionary spec=shots[k];Voice voice;voice.spec=spec;voice.age=-double(spec.get("delay",0.0));voices.push_back(voice);}
  Array beds=parameters.get("beds",Array()),tones=parameters.get("tones",Array());Dictionary room=parameters.get("room",Dictionary());double wet=room.get("wet",0.0),decay=room.get("decay",.75),pre=room.get("pre",.02),master=parameters.get("master",0.0);bool active=parameters.get("active",false);
  struct Bed {double level=0,hz=700;bool brown=false;};Bed prepared_beds[8];
  struct Tone {double level=0,hz=0,cutoff=4200,pan=0;std::vector<double> wave;};Tone prepared_tones[4];
  for(int k=0;k<8;k++){Dictionary b=k<beds.size()?Dictionary(beds[k]):Dictionary();prepared_beds[k]={double(b.get("level",0.0)),double(b.get("hz",700.0)),bool(b.get("brown",false))};}
  for(int k=0;k<4;k++){Dictionary t=k<tones.size()?Dictionary(tones[k]):Dictionary();auto &p=prepared_tones[k];p.level=t.get("level",0.0);p.hz=t.get("hz",0.0);p.cutoff=t.get("cutoff",4200.0);p.pan=std::max(-.85,std::min(.85,double(t.get("pan",0.0))));Array h=t.get("wave",Array());for(int j=0;j<h.size();j++)p.wave.push_back(double(h[j]));}
  PackedVector2Array out;out.resize(frames);const double dt=1.0/rate,smoothing=1-std::exp(-dt/.045);
  for(int frame=0;frame<frames;frame++){
   double white=noise();pink[0]=.99765*pink[0]+white*.099046;pink[1]=.963*pink[1]+white*.2965164;pink[2]=.57*pink[2]+white*1.0526913;double p=(pink[0]+pink[1]+pink[2]+white*.1848)*.13;brown=brown*.995+noise()*.05;double l=0,r=0,reflection=0;
   for(int k=0;k<8;k++){const Bed &b=prepared_beds[k];double target=active?b.level:0;gain[k]+=(target-gain[k])*smoothing;double sample=low(b.brown?brown:p,b.hz,filters[k])*gain[k];l+=sample;r+=sample;}
   for(int k=0;k<4;k++){const Tone &tone=prepared_tones[k];double target=active?tone.level:0;gain[8+k]+=(target-gain[8+k])*smoothing;double hz=tone.hz;phases[k]=std::fmod(phases[k]+6.283185307179586*hz*dt,6.283185307179586);double sample=low(wave(phases[k],tone.wave),tone.cutoff,filters[8+k])*gain[8+k],pan=tone.pan;l+=sample*std::sqrt((1-pan)*.5);r+=sample*std::sqrt((1+pan)*.5);reflection+=sample*.5;}
   for(auto&voice:voices){if(voice.age>=0&&active){double length=voice.spec.get("length",.1),hz=voice.spec.get("hz",1000.0),to=voice.spec.get("to",hz);hz+=(to-hz)*std::min(1.0,voice.age/std::max(.001,length));voice.phase=std::fmod(voice.phase+6.283185307179586*hz*dt,6.283185307179586);double raw=bool(voice.spec.get("noise",false))?noise():std::sin(voice.phase);double sample=low(raw,hz,voice.filter)*envelope(voice)*double(voice.spec.get("level",0.0));l+=sample*.707;r+=sample*.707;reflection+=sample;}voice.age+=dt;}
   voices.erase(std::remove_if(voices.begin(),voices.end(),[](const Voice&v){return v.age>=double(v.spec.get("length",.1));}),voices.end());
   echo[echo_index]=Vector2(reflection,reflection*.97);for(int tap=0;tap<5;tap++){double delay=pre+decay*(tap+1)/7;size_t offset=std::min(echo.size()-1,size_t(delay*rate));Vector2 delayed=echo[(echo_index+echo.size()-offset)%echo.size()];double scale=wet*std::exp(-3.0*(tap+1)/7)/2.0;l+=delayed.x*scale;r+=delayed.y*scale;}
   echo_index=(echo_index+1)%echo.size();l*=master;r*=master;auto limit=[](double v){double a=std::abs(v);if(a>.2)a=.2+(a-.2)/4;return std::copysign(std::min(.95,a),v);};out.set(frame,Vector2(limit(l),limit(r)));
  }
  return out;
 }
};
}
#endif
