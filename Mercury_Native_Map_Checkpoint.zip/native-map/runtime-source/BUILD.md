# Native runtime build
Upstream sttts/godot-quickjs a99c40bcdf344182b22a0c31710a1abdc011e379; godot-cpp da26c1732ee8656ef9ccad587cbdd55acf8637c8. QuickJS sources and their MIT license are vendored; wrapper attribution and MIT declaration are in README.md; godot-cpp license is in extern/godot-cpp/LICENSE.md.

Local fixes: String::utf8 for text/keys/errors, clear errors before each call, memory limit256MiB and stack4MiB. RefCounted/FileAccess/OS build profile; OS is required by Android print_string.cpp.

Linux: cmake -S . -B build -DCMAKE_BUILD_TYPE=Release -DGODOTCPP_BUILD_PROFILE=$PWD/build-profile.json; cmake --build build -j4.
Android: official NDK r27c, Android API26, arm64-v8a; same commands adding -DCMAKE_TOOLCHAIN_FILE=$ANDROID_NDK/build/cmake/android.toolchain.cmake -DANDROID_ABI=arm64-v8a -DANDROID_PLATFORM=android-26. Install resulting kbounce_quickjs.so into addons/mercury_quickjs/bin under the platform name specified in mercury_quickjs.gdextension. Run-time mobile acceptance remains pending.

2026-10-12: bounded run_jobs(128) handles Promise callbacks for file imports; clamped0..1024 and surfaced exceptions. Linux rebuilt/tested; Android rebuild pending.
