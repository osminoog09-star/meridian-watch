export function sidewalkProfile(road,source={}){
 const tag=source.sidewalk??'unknown';
 const explicit=['both','left','right','yes'].includes(tag);
 const inferred=tag==='unknown'&&road.drive&&!road.bridge&&['primary','secondary','tertiary','residential'].includes(road.kind);
 return {left:explicit&&tag!=='right'||inferred,right:explicit&&tag!=='left'||inferred,width:1.6,source:explicit?'tag':inferred?'illustrative':tag};
}
