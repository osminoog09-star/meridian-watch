"""Derive continuous native elevations along the existing road graph; no routing edits."""
from pathlib import Path
import json,math,heapq,collections
ROOT=Path(__file__).resolve().parents[1]
LENGTH=40.0
HEIGHT=2.5
def point(p):return tuple(round(v,6) for v in p)
def key(r):return str(r['id'])+':'+':'.join(str(math.floor(v*1000+0.5)) for p in [r['a'],r['b']] for v in p)
city=json.loads((ROOT/'assets/city.json').read_text())
roads=[r for c in city['chunks'] for r in c['roads']]
assert len({key(r) for r in roads})==len(roads)
graph=collections.defaultdict(list);dist={}
for r in roads:
 a,b=point(r['a']),point(r['b']);length=math.dist(a,b)
 if r['bridge']:dist[a]=dist[b]=0.0
 else:graph[a].append((b,length));graph[b].append((a,length))
queue=[(d,p) for p,d in dist.items()];heapq.heapify(queue)
while queue:
 d,p=heapq.heappop(queue)
 if d!=dist[p]:continue
 for q,length in graph[p]:
  candidate=d+length
  if candidate<LENGTH and candidate<dist.get(q,math.inf):
   dist[q]=candidate;heapq.heappush(queue,(candidate,q))
profiles={};segments=[]
for r in roads:
 a,b=r['a'],r['b'];length=math.dist(a,b)
 da,db=dist.get(point(a),math.inf),dist.get(point(b),math.inf)
 if not r['bridge'] and min(da,db)>=LENGTH:continue
 ts={0.0,1.0}
 if not r['bridge'] and length>0:
  for t in [(LENGTH-da)/length,1-(LENGTH-db)/length,(db+length-da)/(2*length)]:
   if math.isfinite(t) and 0<t<1:ts.add(t)
 ts=sorted(ts);pieces=[]
 def at(t):return [a[k]+(b[k]-a[k])*t for k in range(2)]
 def height(t):return HEIGHT if r['bridge'] else HEIGHT*max(0,1-min(da+t*length,db+(1-t)*length)/LENGTH)
 for x,y in zip(ts,ts[1:]):
  piece={'a':at(x),'b':at(y),'ha':height(x),'hb':height(y),'edgeWidth':r['edgeWidth'],'road':key(r),'bridge':r['bridge']}
  pieces.append(piece)
  segments.append(piece)
 profiles[key(r)]=pieces
# Include nearby level roads so a road under/alongside a bridge stays at ground.
def cells(r):
 pad=r['edgeWidth']/2+.5
 return {(x,y) for x in range(math.floor((min(r['a'][0],r['b'][0])-pad)/64),math.floor((max(r['a'][0],r['b'][0])+pad)/64)+1) for y in range(math.floor((min(r['a'][1],r['b'][1])-pad)/64),math.floor((max(r['a'][1],r['b'][1])+pad)/64)+1)}
active=set().union(*(cells(p) for p in segments))
for r in roads:
 if key(r) not in profiles and cells(r)&active:
  segments.append({'a':r['a'],'b':r['b'],'ha':0.0,'hb':0.0,'edgeWidth':r['edgeWidth'],'road':key(r),'bridge':False})
out={'approachMetres':LENGTH,'deckHeight':HEIGHT,'profiles':profiles,'segments':segments}
(ROOT/'assets/bridge-profiles.json').write_text(json.dumps(out,separators=(',',':'))+'\n')
print(json.dumps({'bridge_segments':sum(r['bridge'] for r in roads),'profiled_roads':len(profiles),'elevated_pieces':len(segments)}))
