"""Pack source and native binaries, excluding build caches and APK artifacts."""
from pathlib import Path
import argparse,zipfile,os,shutil,tempfile
p=argparse.ArgumentParser();p.add_argument('destination',type=Path);a=p.parse_args();root=Path(__file__).resolve().parents[1];out=a.destination.resolve();out.mkdir(parents=True,exist_ok=True)
with tempfile.TemporaryDirectory() as temporary:
 archive=Path(temporary)/'checkpoint.zip'
 with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,6) as z:
  for f in root.rglob('*'):
   if not f.is_file() or any(part in f.relative_to(root).parts for part in ['node_modules','.godot','.git','build','__pycache__','private-runtime']) or f.suffix in ['.pyc','.apk']:continue
   z.write(f,Path('native-map')/f.relative_to(root))
 target=out/'Mercury_Native_Map_Checkpoint.zip';shutil.copyfile(archive,str(target)+'.pending');os.replace(str(target)+'.pending',target)
for name in ['COLLAB_LOG.md','native-cycle-release.json','native-scenes-release.json','native-vehicles-release.json','native-people-release.json','native-patrol-release.json']:
 shutil.copyfile(root/name,out/name)
print(target.stat().st_size)
