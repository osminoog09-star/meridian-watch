// Claude 17.10 (Release R2): every radio line the simulation says in long shifts of every service and mode, cut into
// voice fragments — the list tools/make_sounds.py voices.
import {createGame,tick,nextShift,hireOfficer,createPatrol} from '../simulation/source/sim.js';
import {radioFragments,radioVoice} from '../ui/radio-voice.js';
import {VARIANTS} from '../simulation/source/calls.js';
import {DISTRICTS} from '../simulation/source/fiction.js';
import {ARMED} from '../simulation/source/prefecture.js';
import {RADIO_KINDS,radioText} from '../simulation/source/radio.js';
const seen=new Map(),lines=new Set();
function collect(s){for(const r of s.radio??[]){const id=r.from+'|'+r.text;if(lines.has(id))continue;lines.add(id);const v=radioVoice(r.from);for(const f of radioFragments(r.text))if(!seen.has(v+'|'+f.key))seen.set(v+'|'+f.key,{voice:v,key:f.key,text:f.text});for(const f of radioFragments(r.from))if(!seen.has(v+'|'+f.key))seen.set(v+'|'+f.key,{voice:v,key:f.key,text:f.text});}}
const configs=[];for(const service of ['police','rescue','ems','dispatch'])for(const seed of [7182,4242,99,2026])configs.push(['career',seed,service]);for(const seed of [4242,7])configs.push(['chief',seed,'police']);
for(const [mode,seed,service] of configs){let s=createGame(mode,seed,{schedule:'ppa',service});if(mode==='chief'){for(const c of [...(s.candidates??[])].slice(0,4))hireOfficer(s,c.id);if(s.officers?.length>=4){createPatrol(s,s.officers[0].id,s.officers[1].id,1);createPatrol(s,s.officers[2].id,s.officers[3].id,2);}s.setupPending=false;}
 for(let shift=0;shift<3;shift++){for(let k=0;k<4000&&!s.ended;k++){tick(s,.5);if(k%5===0)collect(s);}collect(s);s.ended=true;s=nextShift(s);}}
const add=(v,text)=>{for(const f of radioFragments(text))if(!seen.has(v+'|'+f.key))seen.set(v+'|'+f.key,{voice:v,key:f.key,text:f.text});};
for(const x of VARIANTS){add('duty',x.name.toLowerCase());add('duty','Повторно: '+x.name.toLowerCase());}for(const d of Object.values(DISTRICTS))add('duty',d);for(const a of Object.values(ARMED))add('duty',a.prefix.toLowerCase());add('duty','Розыск, город');
for(const kind of RADIO_KINDS)for(let a=0;a<40;a++)for(const v of ['crewA','crewB','duty'])add(v,radioText(kind,a,a*7+3,'Меридиан-01',{call:'вызов',place:'город'}));
for(const v of ['duty','crewA','crewB']){for(let n=0;n<=99;n++)seen.set(v+'|n'+n,{voice:v,key:'n'+n,text:String(n)});for(let n=1;n<=9;n++){seen.set(v+'|n0'+n,{voice:v,key:'n0'+n,text:'0'+n});seen.set(v+'|n'+n*100,{voice:v,key:'n'+n*100,text:String(n*100)});}seen.set(v+'|n00',{voice:v,key:'n00',text:'00'});}
console.log(JSON.stringify({lines:lines.size,fragments:[...seen.values()]}));
