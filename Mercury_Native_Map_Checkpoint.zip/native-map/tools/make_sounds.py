#!/usr/bin/env python3
"""Claude 17.10.2026 (Release R2 «Звук»): builds the game's sound bank in audio/.

Owner 17.10: «звук надо доработать полноценно». The old sound was a 22 kHz generator of beeps and noise. The bank is:
  * recorded sounds from free libraries (CC BY-SA 0 A.D., CC BY / CC BY-SA / CC0 Minetest Game) — rain, wind,
    storm, snow, thunder, sea, river, harbour, crowd, birds, fire, footsteps on five surfaces, interface clicks;
  * sounds synthesised here at 44.1 kHz where a recording with a free licence was not available: police, ambulance and
    rescue sirens (wail, yelp, hi-lo) as seamless loops, petrol and diesel engines (idle and drive), tyres on the
    road, passing cars, city traffic, horn, car doors, TETRA radio tones (VIRVE: the Estonian police radio is digital,
    no squelch hiss), the dispatcher console alert;
  * the radio voice: every fragment the simulation says (tools/radio_corpus.mjs) spoken by eSpeak NG in Russian with
    three voices (duty officer, crew A, crew B), then made to sound like a TETRA handset (8 kHz band, codec grit).

Usage: python3 tools/make_sounds.py SOURCES TTS_SITE CORPUS.json
  SOURCES  — a folder with checkouts of github.com/0ad/0ad, luanti-org/minetest_game, (blobs of the audio folders only)
  TTS_SITE — a folder with the espeakng_loader wheel installed (pip install --target)
The output is deterministic (fixed seeds). audio/CREDITS.md lists every recorded file and its licence.
"""
import json, os, subprocess, sys, wave, ctypes, shutil
import numpy as np
from scipy import signal

SR = 44100
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = os.path.join(ROOT, 'audio')
rng = np.random.default_rng(1707)


def ffmpeg(args):
    subprocess.run(['ffmpeg', '-v', 'error', '-y', *args], check=True)


def write_ogg(path, x, sr=SR, q=4):
    """x: float array (n,) or (n,2) in -1..1 → OGG Vorbis."""
    os.makedirs(os.path.dirname(path), exist_ok=True)
    x = np.clip(np.asarray(x, dtype=np.float64), -1, 1)
    tmp = path + '.wav'
    with wave.open(tmp, 'wb') as f:
        f.setnchannels(1 if x.ndim == 1 else x.shape[1]); f.setsampwidth(2); f.setframerate(sr)
        f.writeframes((x * 32767).astype('<i2').tobytes())
    ffmpeg(['-i', tmp, '-c:a', 'libvorbis', '-q:a', str(q), path])
    os.remove(tmp)


def read_audio(path, sr=SR, mono=False):
    ch = 1 if mono else 2
    raw = subprocess.run(['ffmpeg', '-v', 'error', '-i', path, '-f', 's16le', '-ac', str(ch), '-ar', str(sr), '-'],
                         check=True, capture_output=True).stdout
    a = np.frombuffer(raw, '<i2').astype(np.float64) / 32768
    return a if mono else a.reshape(-1, 2)


def norm(x, peak=0.9):
    m = np.max(np.abs(x)) or 1
    return x * (peak / m)


def rms_norm(x, target=0.12):
    r = np.sqrt(np.mean(x ** 2)) or 1
    return np.clip(x * (target / r), -1, 1)


def loop_crossfade(x, seconds, fade=1.5, sr=SR):
    """Cut `seconds` of x and fold the next `fade` seconds over the start: a seamless loop."""
    n, f = int(seconds * sr), int(fade * sr)
    x = x[: n + f]
    head, tail = x[:f], x[n:n + f]
    w = np.linspace(0, 1, f)
    if x.ndim == 2:
        w = w[:, None]
    out = x[:n].copy()
    out[:f] = head * np.sqrt(w) + tail * np.sqrt(1 - w)
    return out


def bandpass(x, lo, hi, sr=SR, order=2):
    sos = signal.butter(order, [lo, hi], 'bandpass', fs=sr, output='sos')
    return signal.sosfilt(sos, x, axis=0)


def lowpass(x, hz, sr=SR, order=2):
    return signal.sosfilt(signal.butter(order, hz, 'lowpass', fs=sr, output='sos'), x, axis=0)


def highpass(x, hz, sr=SR, order=2):
    return signal.sosfilt(signal.butter(order, hz, 'highpass', fs=sr, output='sos'), x, axis=0)


def looped_filter(fn, x, sr=SR):
    """Filter a loop without a click at the seam: run over two copies, keep the second."""
    y = fn(np.concatenate([x, x]))
    return y[len(x):]


def env(n, a=0.005, r=0.05, sr=SR):
    e = np.ones(n)
    na, nr = max(1, int(a * sr)), max(1, int(r * sr))
    e[:na] = np.linspace(0, 1, na)
    e[-nr:] *= np.linspace(1, 0, nr)
    return e


def osc(freq, kind='square', sr=SR, harmonics=40):
    """Band-limited oscillator from an instantaneous frequency array."""
    phase = 2 * np.pi * np.cumsum(freq) / sr
    out = np.zeros_like(phase)
    for k in range(1, harmonics + 1):
        if kind == 'square' and k % 2 == 0:
            continue
        amp = 1 / k
        mask = (freq * k) < sr * 0.45
        out += amp * np.sin(k * phase) * mask
    return out


def loop_freq(curve, sr=SR):
    """Scale a frequency curve slightly so the loop holds a whole number of cycles (no phase jump)."""
    cycles = np.sum(curve) / sr
    return curve * (round(cycles) / cycles)


# ── Sirens ────────────────────────────────────────────────────────────────────────────────────────────────────
def siren_voice(freq, bright=1.0):
    x = 0.65 * osc(freq, 'square', harmonics=25) + 0.35 * osc(freq, 'saw', harmonics=25) * bright
    x = looped_filter(lambda y: bandpass(y, 420, 4200, order=2), x)       # the horn speaker
    x = np.tanh(2.2 * x)                                                    # the driver clipping
    x = looped_filter(lambda y: lowpass(y, 6500), x)
    return norm(x, 0.85)


def sirens():
    t_w = np.arange(int(4.2 * SR)) / SR
    rise = 1.7
    f = np.where(t_w < rise, 620 + (1380 - 620) * (1 - np.exp(-3 * t_w / rise)) / (1 - np.exp(-3)),
                 1380 - (1380 - 620) * (np.clip(t_w - rise, 0, None) / (4.2 - rise)) ** 0.8)
    write_ogg(f'{OUT}/siren/police_wail.ogg', siren_voice(loop_freq(f)))
    t_y = np.arange(int(0.34 * SR)) / SR
    fy = 680 + 860 * (0.5 - 0.5 * np.cos(2 * np.pi * t_y / 0.34)) ** 0.7
    write_ogg(f'{OUT}/siren/police_yelp.ogg', siren_voice(loop_freq(np.tile(fy, 6))))
    # Ambulance: a softer, higher wail and yelp; rescue (fire engine): the European hi-lo two-tone.
    fa = loop_freq(np.interp(t_w, [0, 1.9, 4.2], [700, 1500, 700]))
    write_ogg(f'{OUT}/siren/ambulance_wail.ogg', siren_voice(fa, bright=0.6))
    write_ogg(f'{OUT}/siren/ambulance_yelp.ogg', siren_voice(loop_freq(np.tile(fy * 1.08, 6)), bright=0.6))
    seg = int(0.62 * SR)
    hilo = np.concatenate([np.full(seg, 435.0), np.full(seg, 580.0)])
    hilo = signal.lfilter([0.01], [1, -0.99], np.concatenate([hilo, hilo]))[len(hilo):]  # glide between tones
    write_ogg(f'{OUT}/siren/rescue_hilo.ogg', siren_voice(loop_freq(np.tile(hilo, 2)), bright=1.2))
    # The air horn of a fire engine and the short «whoop» police use at junctions.
    th = np.arange(int(0.9 * SR)) / SR
    horn = osc(np.full(len(th), 233.0), 'saw', harmonics=60) + 0.7 * osc(np.full(len(th), 311.0), 'saw', harmonics=60)
    write_ogg(f'{OUT}/siren/air_horn.ogg', norm(np.tanh(1.8 * lowpass(horn, 3000)) * env(len(th), 0.03, 0.2), 0.8))
    tw = np.arange(int(0.55 * SR)) / SR
    whoop = siren_voice(np.interp(tw, [0, 0.35, 0.55], [500, 1300, 900])) * env(len(tw), 0.01, 0.15)
    write_ogg(f'{OUT}/siren/police_whoop.ogg', whoop)


# ── Engines and road ─────────────────────────────────────────────────────────────────────────────────────────
def engine_loop(rpm, cylinders, seconds, diesel=False, seed=0):
    r = np.random.default_rng(seed)
    firing = rpm / 60 * cylinders / 2
    n = int(seconds * SR)
    cycles = round(seconds * firing)
    firing = cycles / seconds
    # One firing pulse per cycle with a little difference between cylinders, through exhaust resonances.
    pulse_len = int(SR / firing)
    out = np.zeros(n + pulse_len * 2)
    shape = np.exp(-np.arange(pulse_len) / (pulse_len * (0.22 if diesel else 0.15)))
    shape *= np.sin(np.pi * np.arange(pulse_len) / pulse_len) ** 0.3
    amps = 0.75 + 0.25 * r.random(cylinders)
    for c in range(cycles):
        start = int(c * SR / firing)
        out[start:start + pulse_len] += shape * amps[c % cylinders] * (1 + 0.04 * r.standard_normal())
    out[:pulse_len * 2] += out[n:n + pulse_len * 2]
    out = out[:n]
    body = looped_filter(lambda y: lowpass(y, 900 if diesel else 650, order=3), out - out.mean())
    res = looped_filter(lambda y: bandpass(y, firing * 2.9, firing * 3.4), out - out.mean())
    noise = r.standard_normal(n)
    clatter = looped_filter(lambda y: bandpass(y, 1800, 5000), noise) * (np.abs(body) / (np.abs(body).max() or 1))
    intake = looped_filter(lambda y: bandpass(y, 300, 1200), noise) * 0.15
    x = body + 0.5 * res + (0.35 if diesel else 0.12) * clatter * 3 + intake * (rpm / 3000)
    return norm(np.tanh(1.5 * norm(x)), 0.8)


def roads():
    write_ogg(f'{OUT}/vehicle/petrol_idle.ogg', engine_loop(820, 4, 2.0, seed=1))
    write_ogg(f'{OUT}/vehicle/petrol_drive.ogg', engine_loop(2600, 4, 2.0, seed=2))
    write_ogg(f'{OUT}/vehicle/diesel_idle.ogg', engine_loop(760, 4, 2.0, diesel=True, seed=3))
    write_ogg(f'{OUT}/vehicle/diesel_drive.ogg', engine_loop(2100, 4, 2.0, diesel=True, seed=4))
    write_ogg(f'{OUT}/vehicle/truck_idle.ogg', engine_loop(650, 6, 2.0, diesel=True, seed=5))
    write_ogg(f'{OUT}/vehicle/truck_drive.ogg', engine_loop(1700, 6, 2.0, diesel=True, seed=6))
    n = int(6 * SR)
    noise = rng.standard_normal(n)
    tyres = looped_filter(lambda y: bandpass(y, 120, 900, order=2), noise) + 0.25 * looped_filter(lambda y: bandpass(y, 1500, 4000), noise)
    write_ogg(f'{OUT}/vehicle/tyres.ogg', rms_norm(tyres, 0.18))
    wet = looped_filter(lambda y: bandpass(y, 1200, 8000), rng.standard_normal(n)) * 0.6 + tyres * 0.4
    write_ogg(f'{OUT}/vehicle/tyres_wet.ogg', rms_norm(wet, 0.18))
    # Distant city traffic: low rumble with slow swells (cars coming and going a few streets away).
    m = int(30 * SR)
    rumble = lowpass(np.cumsum(rng.standard_normal(m + SR)) * 0.02, 380)[SR:]
    rumble = highpass(rumble, 30)
    swell = np.interp(np.arange(m), np.linspace(0, m, 16), 0.6 + 0.4 * rng.random(16))
    hiss = bandpass(rng.standard_normal(m), 800, 2500) * 0.08
    bed = (rumble / (np.std(rumble) or 1) * 0.6 + hiss) * swell
    write_ogg(f'{OUT}/city/traffic.ogg', rms_norm(loop_crossfade(np.concatenate([bed, bed[:3 * SR]]), 30, 3), 0.12))
    # Two passing cars: an engine and tyres with Doppler and distance.
    for k, (speed, base) in enumerate([(14.0, 95.0), (19.0, 120.0)]):
        d = int(4.0 * SR)
        t = (np.arange(d) / SR) - 2.0
        dist = np.sqrt((speed * t) ** 2 + 6 ** 2)
        radial = (speed ** 2 * t) / dist
        dop = 343 / (343 + radial)
        gain = 1 / (1 + (dist / 6) ** 1.6)
        eng = osc(base * dop, 'saw', harmonics=30)
        tyre = bandpass(rng.standard_normal(d), 200, 2500)
        x = (lowpass(eng, 1500) * 0.5 + tyre * 0.6) * gain
        write_ogg(f'{OUT}/vehicle/pass_{k + 1}.ogg', norm(x * env(d, 0.3, 0.6), 0.7))
    th = np.arange(int(0.45 * SR)) / SR
    horn = osc(np.full(len(th), 415.0), 'square', 30) + osc(np.full(len(th), 520.0), 'square', 30)
    write_ogg(f'{OUT}/vehicle/horn.ogg', norm(lowpass(bandpass(horn, 300, 3500), 2800) * env(len(th), 0.01, 0.06), 0.7))
    # Car doors: latch, thump of the closing door and a little rattle of the body.
    for name, thump in (('door_open', 0.0), ('door_close', 1.0)):
        d = int(0.5 * SR)
        t = np.arange(d) / SR
        latch = bandpass(rng.standard_normal(d), 2500, 7000) * np.exp(-t / 0.008)
        body = np.sin(2 * np.pi * 68 * t) * np.exp(-t / 0.07) * thump
        rattle = bandpass(rng.standard_normal(d), 600, 2000) * np.exp(-t / 0.05) * (0.5 * thump + 0.15)
        late = np.zeros(d)
        if not thump:
            late[int(0.12 * SR):] = bandpass(rng.standard_normal(d - int(0.12 * SR)), 1500, 5000) * np.exp(-np.arange(d - int(0.12 * SR)) / SR / 0.01) * 0.6
        write_ogg(f'{OUT}/vehicle/{name}.ogg', norm(latch * 0.7 + body + rattle * 0.6 + late, 0.8))


# ── Radio (TETRA / VIRVE) and console ─────────────────────────────────────────────────────────────────────────
def tetra(x, sr):
    """A digital handset: 300–3400 Hz, an 8 kHz codec with a little grit, a compressed level."""
    x = bandpass(x, 320, 3300, sr, order=3)
    if sr != 8000:
        x = signal.resample_poly(x, 8000, sr)
    q = np.round(x * 90) / 90                                                  # codec grit
    x = 0.85 * x + 0.15 * q
    x = np.tanh(3.0 * norm(x, 1.0)) * 0.8
    x = signal.resample_poly(x, 16000, 8000)
    return bandpass(x, 300, 3400, 16000, order=2)


def console():
    def tone(hz, length, level=0.5):
        t = np.arange(int(length * SR)) / SR
        return np.sin(2 * np.pi * hz * t) * env(len(t), 0.003, 0.02) * level
    gap = lambda s: np.zeros(int(s * SR))
    # TETRA «talk permit»: a short high beep before a voice; the end of a call: a lower double tick.
    write_ogg(f'{OUT}/radio/permit.ogg', np.concatenate([tone(1400, 0.05, 0.35), gap(0.03), tone(1400, 0.05, 0.35)]))
    write_ogg(f'{OUT}/radio/end.ogg', np.concatenate([tone(900, 0.03, 0.25), gap(0.04), tone(700, 0.03, 0.25)]))
    burst = bandpass(rng.standard_normal(int(0.18 * SR)), 400, 3000) * env(int(0.18 * SR), 0.005, 0.05) * 0.25
    write_ogg(f'{OUT}/radio/data.ogg', burst)
    # The dispatcher console: a new call (three rising tones) and an urgent one (five fast tones).
    write_ogg(f'{OUT}/ui/new_call.ogg', np.concatenate([tone(880, 0.09), gap(0.04), tone(1108, 0.09), gap(0.04), tone(1318, 0.14)]))
    write_ogg(f'{OUT}/ui/urgent_call.ogg', np.concatenate(sum([[tone(1250, 0.07, 0.6), gap(0.035)] for _ in range(5)], [])))
    chord = lambda hzs, length, level: sum(tone(h, length, level / len(hzs)) * np.exp(-np.arange(int(length * SR)) / SR / (length / 3)) for h in hzs)
    write_ogg(f'{OUT}/ui/resolved.ogg', np.concatenate([chord([523, 659], 0.18, 0.5), chord([659, 784, 1046], 0.45, 0.55)]))
    write_ogg(f'{OUT}/ui/missed.ogg', np.concatenate([chord([392, 466], 0.25, 0.5), chord([311, 370], 0.5, 0.5)]))
    write_ogg(f'{OUT}/ui/notice.ogg', chord([988, 1318], 0.35, 0.45))


# ── Radio voice ──────────────────────────────────────────────────────────────────────────────────────────────
ONES = ['ноль', 'один', 'два', 'три', 'четыре', 'пять', 'шесть', 'семь', 'восемь', 'девять', 'десять', 'одиннадцать',
        'двенадцать', 'тринадцать', 'четырнадцать', 'пятнадцать', 'шестнадцать', 'семнадцать', 'восемнадцать', 'девятнадцать']
TENS = ['', '', 'двадцать', 'тридцать', 'сорок', 'пятьдесят', 'шестьдесят', 'семьдесят', 'восемьдесят', 'девяносто']
HUNDREDS = ['', 'сто', 'двести', 'триста', 'четыреста', 'пятьсот', 'шестьсот', 'семьсот', 'восемьсот', 'девятьсот']


def number_words(s):
    if len(s) == 2 and s[0] == '0':
        return 'ноль ' + ONES[int(s[1])]
    n = int(s)
    if n >= 100 and n % 100 == 0:
        return HUNDREDS[n // 100]
    words = []
    if n >= 100:
        words.append(HUNDREDS[n // 100]); n %= 100
    if n < 20:
        words.append(ONES[n])
    else:
        words.append(TENS[n // 10])
        if n % 10:
            words.append(ONES[n % 10])
    return ' '.join(words)


SPOKEN = {'ГБР': 'гэ бэ эр', 'K-Komando': 'ка командо', 'АЗС': 'а зэ эс', 'ДТП': 'дэ тэ пэ', 'ППА': 'пэ пэ а', '112': 'сто двенадцать'}


def spoken(text):
    for a, b in SPOKEN.items():
        text = text.replace(a, b)
    return text


VOICE_SETTINGS = {'duty': ('ru+f3', 168, 52), 'crewA': ('ru+m3', 175, 38), 'crewB': ('ru+m7', 182, 46)}


class Speaker:
    def __init__(self, site):
        sys.path.insert(0, site)
        import espeakng_loader as loader
        self.lib = ctypes.CDLL(loader.get_library_path())
        self.buf = []
        CB = ctypes.CFUNCTYPE(ctypes.c_int, ctypes.POINTER(ctypes.c_short), ctypes.c_int, ctypes.c_void_p)

        def cb(w, n, e):
            if n > 0:
                self.buf.append(np.ctypeslib.as_array(w, shape=(n,)).copy())
            return 0
        self.cb = CB(cb)
        self.rate = self.lib.espeak_Initialize(1, 0, loader.get_data_path().encode(), 0)
        self.lib.espeak_SetSynthCallback(self.cb)

    def say(self, text, voice):
        name, speed, pitch = VOICE_SETTINGS[voice]
        self.buf.clear()
        self.lib.espeak_SetVoiceByName(name.encode())
        self.lib.espeak_SetParameter(1, speed, 0)
        self.lib.espeak_SetParameter(3, pitch, 0)
        b = text.encode('utf-8')
        self.lib.espeak_Synth(b, len(b) + 1, 0, 0, 0, 0x10, None, None)
        self.lib.espeak_Synchronize()
        a = np.concatenate(self.buf).astype(np.float64) / 32768 if self.buf else np.zeros(10)
        nz = np.nonzero(np.abs(a) > 0.01)[0]
        return a[max(0, nz[0] - 200): nz[-1] + 400] if len(nz) else a, self.rate


def voices(site, corpus_path):
    corpus = json.load(open(corpus_path))['fragments']
    sp = Speaker(site)
    os.makedirs(f'{OUT}/voice', exist_ok=True)
    for f in os.listdir(f'{OUT}/voice'):
        os.remove(f'{OUT}/voice/{f}')
    # One sprite per voice (a clip per file would cost 4 KB of Vorbis headers each): the bank keeps start and length.
    parts, bank, pos = {}, {}, {}
    gap = np.zeros(int(0.08 * 16000))
    for item in corpus:
        text = number_words(item['text']) if item['key'].startswith('n') else spoken(item['text'])
        a, rate = sp.say(text, item['voice'])
        x = norm(tetra(a, rate), 0.8)
        v = item['voice']
        start = pos.get(v, 0)
        parts.setdefault(v, []).extend([x, gap])
        bank.setdefault(v, {})[item['key']] = [round(start / 16000, 4), round(len(x) / 16000, 4)]
        pos[v] = start + len(x) + len(gap)
    for v, xs in parts.items():
        write_ogg(f'{OUT}/voice/{v}.ogg', np.concatenate(xs), sr=16000, q=1)
    json.dump(bank, open(f'{OUT}/voice/bank.json', 'w'), ensure_ascii=False, separators=(',', ':'), sort_keys=True)
    return len(corpus)


def fnv(s):
    h = 2166136261
    for c in s:
        h ^= ord(c)
        h = (h * 16777619) & 0xffffffff
    digits = '0123456789abcdefghijklmnopqrstuvwxyz'
    out = ''
    while True:
        h, r = divmod(h, 36)
        out = digits[r] + out
        if not h:
            return out


# ── Recordings ───────────────────────────────────────────────────────────────────────────────────────────────
CREDITS = []


def recorded(src, dst, seconds=None, fade=2.0, mono=False, gain=None, credit=None, start=0.0, q=3):
    a = read_audio(src, mono=mono)
    a = a[int(start * SR):]
    if seconds:
        a = loop_crossfade(a, min(seconds, len(a) / SR - fade - 0.1), fade)
    a = rms_norm(a, gain) if gain else norm(a, 0.9)
    write_ogg(f'{OUT}/{dst}', a, q=q)
    CREDITS.append((dst, credit))


def recordings(src):
    oad = f'{src}/0ad/binaries/data/mods/public/audio/ambient'
    O = '0 A.D., © Wildfire Games, CC BY-SA 3.0 (https://creativecommons.org/licenses/by-sa/3.0/, https://play0ad.com)'
    recorded(f'{oad}/weather/rain_11.ogg', 'weather/rain.ogg', 40, gain=0.16, credit=O)
    recorded(f'{oad}/weather/rain_12.ogg', 'weather/rain_heavy.ogg', 40, gain=0.2, credit=O)
    recorded(f'{oad}/weather/wind_11.ogg', 'weather/wind.ogg', 45, gain=0.12, credit=O)
    recorded(f'{oad}/weather/windstorm_11.ogg', 'weather/storm.ogg', 40, gain=0.18, credit=O)
    recorded(f'{oad}/weather/snowstorm_11.ogg', 'weather/snow.ogg', 40, gain=0.12, credit=O)
    recorded(f'{oad}/weather/thunder_10.ogg', 'weather/thunder_1.ogg', credit=O)
    recorded(f'{oad}/weather/thunder_11.ogg', 'weather/thunder_2.ogg', credit=O)
    recorded(f'{oad}/weather/windgust_11.ogg', 'weather/gust.ogg', credit=O)
    recorded(f'{oad}/water/wave_21.ogg', 'city/sea.ogg', 26, mono=True, gain=0.15, credit=O)
    recorded(f'{oad}/water/wavecrash_21.ogg', 'city/sea_storm.ogg', 22, gain=0.18, credit=O)
    recorded(f'{oad}/water/river_slow_21.ogg', 'city/river.ogg', 21, mono=True, gain=0.1, credit=O)
    recorded(f'{oad}/building/amb_port_10.ogg', 'city/harbour.ogg', 17, mono=True, gain=0.1, credit=O)
    recorded(f'{oad}/building/amb_trade_10.ogg', 'city/crowd.ogg', 20, mono=True, gain=0.1, credit=O)
    recorded(f'{oad}/building/amb_trade_11.ogg', 'city/crowd_2.ogg', 17, mono=True, gain=0.1, credit=O)
    recorded(f'{oad}/dayscape/day_temperate_gen_01.ogg', 'city/birds.ogg', 60, gain=0.08, credit=O)
    mt = f'{src}/luanti-org_minetest_game/mods'
    M = 'Minetest Game, © Perttu Ahola and contributors, CC BY-SA 3.0 / CC BY 3.0 / CC0 (mods/{mod}/license.txt)'
    recorded(f'{mt}/fire/sounds/fire_large.ogg', 'city/fire.ogg', 6, fade=1.0, mono=True, gain=0.18, credit=M.format(mod='fire'))
    for k in (1, 2, 3):
        recorded(f'{mt}/default/sounds/default_snow_footstep.{k}.ogg', f'steps/snow_{k}.ogg', mono=True, credit=M.format(mod='default'))
        recorded(f'{mt}/default/sounds/default_gravel_footstep.{k}.ogg', f'steps/gravel_{k}.ogg', mono=True, credit=M.format(mod='default'))
        recorded(f'{mt}/default/sounds/default_water_footstep.{k}.ogg', f'steps/wet_{k}.ogg', mono=True, credit=M.format(mod='default'))
    recorded(f'{mt}/default/sounds/default_break_glass.1.ogg', 'city/glass.ogg', mono=True, credit=M.format(mod='default'))
    for k in (1, 2, 3):
        recorded(f'{mt}/default/sounds/default_hard_footstep.{k}.ogg', f'steps/concrete_{k}.ogg', mono=True, credit=M.format(mod='default'))
        recorded(f'{mt}/default/sounds/default_grass_footstep.{k}.ogg', f'steps/grass_{k}.ogg', mono=True, credit=M.format(mod='default'))
    recorded(f'{mt}/default/sounds/default_wood_footstep.1.ogg', 'steps/wood_1.ogg', mono=True, credit=M.format(mod='default'))
    ui = f'{src}/0ad/binaries/data/mods/mod/audio/interface/ui'
    recorded(f'{ui}/ui_button_click.ogg', 'ui/click.ogg', mono=True, credit=O)
    recorded(f'{ui}/ui_button_longclick.ogg', 'ui/click_long.ogg', mono=True, credit=O)
    licences = f'{OUT}/licenses'
    os.makedirs(licences, exist_ok=True)
    shutil.copy(f'{src}/0ad/binaries/data/mods/public/audio/LICENSE.txt', f'{licences}/0ad-audio-LICENSE.txt')
    for mod in ('default', 'fire'):
        shutil.copy(f'{mt}/{mod}/license.txt', f'{licences}/minetest-{mod}-license.txt')


def credits():
    lines = ['# Звуки Mercury Response — источники и лицензии', '',
             'Собрано `tools/make_sounds.py` (Claude, 17.10.2026). Записи обрезаны в бесшовные петли, нормализованы и',
             'пережаты в OGG Vorbis — это изменения в смысле CC BY / CC BY-SA; изменённые файлы распространяются на тех же условиях.', '',
             '## Записи', '']
    for dst, credit in CREDITS:
        lines.append(f'- `audio/{dst}` — {credit}')
    lines += ['', '## Синтез (Claude, CC0)', '',
              'Сирены (`siren/*`), двигатели, шины, проезжающие машины, сигнал, двери (`vehicle/*`), городской шум `city/traffic.ogg`,',
              'тоны рации TETRA (`radio/*`), сигналы пульта и интерфейса `ui/new_call|urgent_call|resolved|missed|notice.ogg`.', '',
              '## Голос рации', '',
              '`voice/*` — eSpeak NG (GPL-3.0, использован как инструмент; озвученные фразы — данные игры), голоса ru+f3, ru+m3, ru+m7,',
              'обработка под цифровую рацию TETRA.', '']
    open(f'{OUT}/CREDITS.md', 'w').write('\n'.join(lines))


if __name__ == '__main__':
    src, site, corpus = sys.argv[1:4]
    for sub in ('siren', 'vehicle', 'city', 'weather', 'steps', 'ui', 'radio'):
        os.makedirs(f'{OUT}/{sub}', exist_ok=True)
    sirens(); roads(); console(); recordings(src); credits()
    print('voice fragments', voices(site, corpus))
