import fs from 'node:fs';
import {dispatch} from '../simulation/core-entry.js';
const fixtures=JSON.parse(fs.readFileSync(new URL('../simulation/service-save-fixtures.json',import.meta.url)));
const out=[];
for (const f of fixtures){
 const requests=[{op:'load',save:f.save}];dispatch(requests[0]);
 for(let shift=0;shift<2;shift++){
  let ended=false;
  for(let k=0;k<4000;k++){
   const req={op:'tick',dt:.5};requests.push(req);
   if(JSON.parse(dispatch(req)).ended){ended=true;break;}
  }
  if(!ended)throw Error('Shift did not end: '+f.service);
  if(shift===0){const req={op:'nextShift'};requests.push(req);dispatch(req);}
 }
 const state=JSON.parse(dispatch({op:'state'}));
 if((state.agency??'police')!==f.service)throw Error('Agency lost');
 out.push({mode:f.mode,service:f.service,requests,state});
 console.log(f.mode,f.service,requests.length,'requests, ended',state.ended);
}
fs.writeFileSync(new URL('../audit/service-long-fixtures.json',import.meta.url),JSON.stringify(out));
