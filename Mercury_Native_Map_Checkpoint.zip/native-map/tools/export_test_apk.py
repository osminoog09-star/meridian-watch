"""Export a native test APK using a previously verified Android host APK.
No signing credentials enter the source tree. Invoke with --help for paths.
"""
from pathlib import Path
import argparse,zipfile,shutil,os,subprocess
p=argparse.ArgumentParser();p.add_argument('--template',type=Path,required=True);p.add_argument('--cache',type=Path,required=True);p.add_argument('--godot',type=Path,required=True);p.add_argument('--work',type=Path,required=True);p.add_argument('--version-name',default='0.3.0-native-cycle-test');p.add_argument('--version-code',type=int,required=True);a=p.parse_args()
if a.version_code<1:p.error('--version-code must be positive')
root=Path(__file__).resolve().parents[1];build=a.work.resolve();sdk=build/'sdk';sdk.mkdir(parents=True,exist_ok=True)
with zipfile.ZipFile(a.cache/'tools.zip') as z:z.extractall(build/'tools')
shutil.copytree(build/'tools/android-16',sdk/'build-tools/36.1.0',dirs_exist_ok=True)
with zipfile.ZipFile(a.cache/'adb.zip') as z:z.extractall(sdk)
for f in sdk.rglob('*'):
 if f.is_file():f.chmod(0o755)
stage=build/'stage';shutil.copytree(root,stage,dirs_exist_ok=True,ignore=shutil.ignore_patterns('.godot','node_modules','build','__pycache__'))
template=build/'clean-template.apk'
with zipfile.ZipFile(a.template) as source,zipfile.ZipFile(template,'w',zipfile.ZIP_DEFLATED) as dest:
 for i in source.infolist():
  if i.filename.startswith(('assets/','META-INF/')) or 'mercury_quickjs' in i.filename:continue
  dest.writestr(i,source.read(i.filename))
jdk=Path('/usr/lib/jvm/java-17-openjdk-amd64')
for name,main in {'javac':'jdk.compiler/com.sun.tools.javac.Main','jar':'jdk.jartool/sun.tools.jar.Main','jarsigner':'jdk.jartool/sun.security.tools.jarsigner.Main'}.items():
 f=jdk/'bin'/name
 if not f.exists():f.write_text('#!/bin/sh\nexec "'+str(jdk/'bin/java')+'" -m '+main+' "$@"\n');f.chmod(0o755)
config=build/'config/godot';config.mkdir(parents=True,exist_ok=True)
(config/'editor_settings-4.7.tres').write_text('[gd_resource type="EditorSettings" format=3]\n[resource]\nexport/android/android_sdk_path = "'+str(sdk)+'"\nexport/android/java_sdk_path = "'+str(jdk)+'"\n')
(stage/'export_presets.cfg').write_text('''[preset.0]
name="Android Cycle"
platform="Android"
runnable=true
export_filter="all_resources"
include_filter="*.js,*.json"
exclude_filter="runtime-source/*,android-bridge/*,tools/*,audit/*,ui/source/*,ui/index.html,ui/package*,ui/test*,ui/*traces.json,ui/manual-call-trace.json,simulation/source/*,simulation/*fixtures.json,scripts/verify*,scripts/render_*"
export_path="'''+str(build/'unsigned.apk')+'''"
[preset.0.options]
custom_template/release="'''+str(template)+'''"
gradle_build/use_gradle_build=false
architectures/armeabi-v7a=false
architectures/arm64-v8a=true
architectures/x86=false
architectures/x86_64=false
version/code='''+str(a.version_code)+'''
version/name="'''+a.version_name+'''"
package/unique_name="com.mercurypolice.response"
package/name="Mercury Response"
package/signed=false
permissions/internet=true
permissions/vibrate=true
screen/immersive_mode=true
''')
env=os.environ.copy();env['XDG_CONFIG_HOME']=str(build/'config')
with (build/'export.log').open('w') as log:
 subprocess.run([str(a.godot.resolve()),'--headless','--path',str(stage),'--export-release','Android Cycle'],env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
print(build/'unsigned.apk')
