"""Run the native transfer checks in isolated save directories and retain results."""
from pathlib import Path
import subprocess,os,json,time,concurrent.futures,argparse
p=argparse.ArgumentParser();p.add_argument('--godot',required=True);p.add_argument('--jobs',type=int,default=1);a=p.parse_args()
if a.jobs<1:p.error('--jobs must be positive')
root=Path(__file__).resolve().parents[1];out=root/'audit';out.mkdir(exist_ok=True);engine=str(Path(a.godot).resolve())
def run(name,cmd):
 start=time.monotonic();env=os.environ.copy();env['XDG_DATA_HOME']=str(out/'private-runtime'/name)
 try:
  r=subprocess.run(cmd,cwd=root,env=env,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=360)
  text=r.stdout;code=r.returncode
 except subprocess.TimeoutExpired as e:
  text=(e.stdout or b'').decode() if isinstance(e.stdout,bytes) else (e.stdout or '')
  text+='\nAUDIT TIMEOUT';code=124
 (out/(name+'.log')).write_text(text)
 ok=code==0 and not any(x in text for x in ['SCRIPT ERROR:','ERROR:','FAILED','AUDIT TIMEOUT'])
 result={'name':name,'passed':ok,'exit_code':code,'seconds':round(time.monotonic()-start,2)}
 print(json.dumps(result),flush=True);return result
results=[]
for script in sorted((root/'ui').glob('test-*.mjs')):
 results.append(run(script.stem,['node',str(script)]))
# Node traces/fixtures above must finish before their native consumers.
with concurrent.futures.ThreadPoolExecutor(max_workers=a.jobs) as pool:
 futures=[pool.submit(run,f.stem,[engine,'--headless','--path',str(root),'--script','scripts/'+f.name,'--','--native-ui']) for f in sorted((root/'scripts').glob('verify_*.gd'))]
 for future in futures:results.append(future.result())
report={'passed':all(r['passed'] for r in results),'checks':results,'device_acceptance':False,'gpu_visual_acceptance':False}
(out/'migration-audit.json').write_text(json.dumps(report,indent=2)+'\n')
raise SystemExit(0 if report['passed'] else 1)
