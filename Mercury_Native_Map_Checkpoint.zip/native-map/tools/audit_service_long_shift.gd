extends SceneTree
const Core=preload("res://scripts/simulation_core.gd")
func eq(a,b)->bool:
 if (typeof(a)==TYPE_FLOAT or typeof(a)==TYPE_INT) and (typeof(b)==TYPE_FLOAT or typeof(b)==TYPE_INT):
  return abs(float(a)-float(b))<=0.00000001
 if typeof(a)!=typeof(b):return false
 if a is Dictionary:
  if a.size()!=b.size():return false
  for k in a:
   if not b.has(k) or not eq(a[k],b[k]):return false
  return true
 if a is Array:
  if a.size()!=b.size():return false
  for i in range(a.size()):
   if not eq(a[i],b[i]):return false
  return true
 return a==b
func _initialize():
 var core=Core.new()
 if not core.initialize():quit(1);return
 var fixtures=JSON.parse_string(FileAccess.get_file_as_string("res://audit/service-long-fixtures.json"))
 for f in fixtures:
  for req in f.requests:core.invoke(req)
  if not eq(core.state(),f.state):
   FileAccess.open("res://audit/long-diff-"+f.mode+"-"+f.service+".json",FileAccess.WRITE).store_string(JSON.stringify({"actual":core.state(),"expected":f.state}))
   push_error("Two-shift parity failed: "+f.mode+" / "+f.service)
   quit(2);return
  print("PASS two complete shifts: ",f.mode," / ",f.service)
 quit(0)
