# Звуки Mercury Response — источники и лицензии

Собрано `tools/make_sounds.py` (Claude, 17.10.2026). Записи обрезаны в бесшовные петли, нормализованы и
пережаты в OGG Vorbis — это изменения в смысле CC BY / CC BY-SA; изменённые файлы распространяются на тех же условиях.

## Записи

- `audio/weather/rain.ogg` — 0 A.D., © Wildfire Games, CC BY-SA 3.0 (https://creativecommons.org/licenses/by-sa/3.0/, https://play0ad.com)
- `audio/weather/rain_heavy.ogg` — 0 A.D., © Wildfire Games, CC BY-SA 3.0 (https://creativecommons.org/licenses/by-sa/3.0/, https://play0ad.com)
- `audio/weather/wind.ogg` — 0 A.D., © Wildfire Games, CC BY-SA 3.0 (https://creativecommons.org/licenses/by-sa/3.0/, https://play0ad.com)
- `audio/weather/storm.ogg` — 0 A.D., © Wildfire Games, CC BY-SA 3.0 (https://creativecommons.org/licenses/by-sa/3.0/, https://play0ad.com)
- `audio/weather/snow.ogg` — 0 A.D., © Wildfire Games, CC BY-SA 3.0 (https://creativecommons.org/licenses/by-sa/3.0/, https://play0ad.com)
- `audio/weather/thunder_1.ogg` — 0 A.D., © Wildfire Games, CC BY-SA 3.0 (https://creativecommons.org/licenses/by-sa/3.0/, https://play0ad.com)
- `audio/weather/thunder_2.ogg` — 0 A.D., © Wildfire Games, CC BY-SA 3.0 (https://creativecommons.org/licenses/by-sa/3.0/, https://play0ad.com)
- `audio/weather/gust.ogg` — 0 A.D., © Wildfire Games, CC BY-SA 3.0 (https://creativecommons.org/licenses/by-sa/3.0/, https://play0ad.com)
- `audio/city/sea.ogg` — 0 A.D., © Wildfire Games, CC BY-SA 3.0 (https://creativecommons.org/licenses/by-sa/3.0/, https://play0ad.com)
- `audio/city/sea_storm.ogg` — 0 A.D., © Wildfire Games, CC BY-SA 3.0 (https://creativecommons.org/licenses/by-sa/3.0/, https://play0ad.com)
- `audio/city/river.ogg` — 0 A.D., © Wildfire Games, CC BY-SA 3.0 (https://creativecommons.org/licenses/by-sa/3.0/, https://play0ad.com)
- `audio/city/harbour.ogg` — 0 A.D., © Wildfire Games, CC BY-SA 3.0 (https://creativecommons.org/licenses/by-sa/3.0/, https://play0ad.com)
- `audio/city/crowd.ogg` — 0 A.D., © Wildfire Games, CC BY-SA 3.0 (https://creativecommons.org/licenses/by-sa/3.0/, https://play0ad.com)
- `audio/city/crowd_2.ogg` — 0 A.D., © Wildfire Games, CC BY-SA 3.0 (https://creativecommons.org/licenses/by-sa/3.0/, https://play0ad.com)
- `audio/city/birds.ogg` — 0 A.D., © Wildfire Games, CC BY-SA 3.0 (https://creativecommons.org/licenses/by-sa/3.0/, https://play0ad.com)
- `audio/city/fire.ogg` — Minetest Game, © Perttu Ahola and contributors, CC BY-SA 3.0 / CC BY 3.0 / CC0 (mods/fire/license.txt)
- `audio/steps/snow_1.ogg` — Minetest Game, © Perttu Ahola and contributors, CC BY-SA 3.0 / CC BY 3.0 / CC0 (mods/default/license.txt)
- `audio/steps/gravel_1.ogg` — Minetest Game, © Perttu Ahola and contributors, CC BY-SA 3.0 / CC BY 3.0 / CC0 (mods/default/license.txt)
- `audio/steps/wet_1.ogg` — Minetest Game, © Perttu Ahola and contributors, CC BY-SA 3.0 / CC BY 3.0 / CC0 (mods/default/license.txt)
- `audio/steps/snow_2.ogg` — Minetest Game, © Perttu Ahola and contributors, CC BY-SA 3.0 / CC BY 3.0 / CC0 (mods/default/license.txt)
- `audio/steps/gravel_2.ogg` — Minetest Game, © Perttu Ahola and contributors, CC BY-SA 3.0 / CC BY 3.0 / CC0 (mods/default/license.txt)
- `audio/steps/wet_2.ogg` — Minetest Game, © Perttu Ahola and contributors, CC BY-SA 3.0 / CC BY 3.0 / CC0 (mods/default/license.txt)
- `audio/steps/snow_3.ogg` — Minetest Game, © Perttu Ahola and contributors, CC BY-SA 3.0 / CC BY 3.0 / CC0 (mods/default/license.txt)
- `audio/steps/gravel_3.ogg` — Minetest Game, © Perttu Ahola and contributors, CC BY-SA 3.0 / CC BY 3.0 / CC0 (mods/default/license.txt)
- `audio/steps/wet_3.ogg` — Minetest Game, © Perttu Ahola and contributors, CC BY-SA 3.0 / CC BY 3.0 / CC0 (mods/default/license.txt)
- `audio/city/glass.ogg` — Minetest Game, © Perttu Ahola and contributors, CC BY-SA 3.0 / CC BY 3.0 / CC0 (mods/default/license.txt)
- `audio/steps/concrete_1.ogg` — Minetest Game, © Perttu Ahola and contributors, CC BY-SA 3.0 / CC BY 3.0 / CC0 (mods/default/license.txt)
- `audio/steps/grass_1.ogg` — Minetest Game, © Perttu Ahola and contributors, CC BY-SA 3.0 / CC BY 3.0 / CC0 (mods/default/license.txt)
- `audio/steps/concrete_2.ogg` — Minetest Game, © Perttu Ahola and contributors, CC BY-SA 3.0 / CC BY 3.0 / CC0 (mods/default/license.txt)
- `audio/steps/grass_2.ogg` — Minetest Game, © Perttu Ahola and contributors, CC BY-SA 3.0 / CC BY 3.0 / CC0 (mods/default/license.txt)
- `audio/steps/concrete_3.ogg` — Minetest Game, © Perttu Ahola and contributors, CC BY-SA 3.0 / CC BY 3.0 / CC0 (mods/default/license.txt)
- `audio/steps/grass_3.ogg` — Minetest Game, © Perttu Ahola and contributors, CC BY-SA 3.0 / CC BY 3.0 / CC0 (mods/default/license.txt)
- `audio/steps/wood_1.ogg` — Minetest Game, © Perttu Ahola and contributors, CC BY-SA 3.0 / CC BY 3.0 / CC0 (mods/default/license.txt)
- `audio/ui/click.ogg` — 0 A.D., © Wildfire Games, CC BY-SA 3.0 (https://creativecommons.org/licenses/by-sa/3.0/, https://play0ad.com)
- `audio/ui/click_long.ogg` — 0 A.D., © Wildfire Games, CC BY-SA 3.0 (https://creativecommons.org/licenses/by-sa/3.0/, https://play0ad.com)

## Синтез (Claude, CC0)

Сирены (`siren/*`), двигатели, шины, проезжающие машины, сигнал, двери (`vehicle/*`), городской шум `city/traffic.ogg`,
тоны рации TETRA (`radio/*`), сигналы пульта и интерфейса `ui/new_call|urgent_call|resolved|missed|notice.ogg`.

## Голос рации

`voice/*` — eSpeak NG (GPL-3.0, использован как инструмент; озвученные фразы — данные игры), голоса ru+f3, ru+m3, ru+m7,
обработка под цифровую рацию TETRA.
