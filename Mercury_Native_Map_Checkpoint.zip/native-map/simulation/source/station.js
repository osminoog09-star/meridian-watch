// Claude 22.10.2026 (City 2.0 «Участок»). Owner: «небольшой полицейский участок: патрульные, задержанные, участковые и
// следователь». The detention block (ИВС) behind the station has six places; a detainee handed to the duty officer goes
// into a cell for the rest of the shift (the case goes to the investigator, the court takes him next day). When the cells
// are full the crew draws up a transfer to the prefecture's ИВС — a longer handover. The block is emptied every shift.
export const IVS=Object.freeze({capacity:6,transferTime:2.5});
export const ivsCount=s=>s?.ivs?.held?.length??0;
export const ivsFull=s=>ivsCount(s)>=IVS.capacity;
export function ivsPlace(s,label){if(!s.ivs||!Array.isArray(s.ivs.held))s.ivs={held:[]};if(ivsFull(s))return false;s.ivs.held.push({label:String(label??'').slice(0,100),at:Math.max(0,Math.round(s.time??0))});return true;}
export const validIvs=s=>s?.ivs===undefined||!!s.ivs&&typeof s.ivs==='object'&&Array.isArray(s.ivs.held)&&s.ivs.held.length<=IVS.capacity&&s.ivs.held.every(h=>h&&typeof h.label==='string'&&h.label.length<=100&&Number.isInteger(h.at)&&h.at>=0&&h.at<=100000);
// The district officer (участковый): his own district is the one he lives in.
export const DISTRICT_OFFICER=Object.freeze({trust:1});
