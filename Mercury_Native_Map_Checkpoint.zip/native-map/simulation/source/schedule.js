// R1 «Смена и календарь» (Claude, 11.10.2026). Realistic Estonian patrol roster (PPA):
// 12-hour shifts, two day shifts (08:00–20:00), two night shifts (20:00–08:00), then four days off.
// Sources: docs/REALISM_RESEARCH_CLAUDE_20261011.md (Postimees 2020, karjaar.politsei.ee).
// Pure calendar maths; sim.js moves the city clock between shifts. Legacy campaigns (no
// `schedule`) keep the old back-to-back 6-hour shifts unchanged.
import {WORLD_SECONDS_PER_TICK_SECOND} from './transport.js';
export const SCHEDULE_ID='ppa';
export const SHIFT_HOURS=12;
export const SHIFT_TICKS=SHIFT_HOURS*60*60/WORLD_SECONDS_PER_TICK_SECOND;// 960
export const LEGACY_SHIFT_TICKS=480;
export const ROTA=Object.freeze(['day','day','night','night']);
export const OFF_DAYS=4,CYCLE_DAYS=ROTA.length+OFF_DAYS;
export const SHIFT_START=Object.freeze({day:8*60,night:20*60});
export const SHIFT_LABEL=Object.freeze({day:'дневная',night:'ночная'});
const ticks=minutes=>minutes*60/WORLD_SECONDS_PER_TICK_SECOND;
// Absolute world minute (campaign starts on day 2, after the legacy clock origin 17:00 of day 1) when shift #index (0-based) starts.
export function shiftStartMinute(index){const cycle=Math.floor(index/ROTA.length),slot=index%ROTA.length,kind=ROTA[slot];return (2+cycle*CYCLE_DAYS+slot)*1440+SHIFT_START[kind];}
export const shiftKind=index=>ROTA[index%ROTA.length];
// population.elapsed for that moment (cityMinute(0) is 17:00 of day 1 in the legacy clock).
export const elapsedAt=minute=>ticks(minute-(1440+17*60));
export const shiftStartElapsed=index=>elapsedAt(shiftStartMinute(index));
export function restBefore(index){if(index<=0)return null;return shiftStartMinute(index)-(shiftStartMinute(index-1)+SHIFT_HOURS*60);}
// What the player sees after a shift: next shift kind, start, rest time and days off.
export function nextShiftInfo(shift){const index=shift;// 0-based index of the shift after shift number `shift`
 const start=shiftStartMinute(index),prevEnd=shiftStartMinute(index-1)+SHIFT_HOURS*60,rest=start-prevEnd,kind=shiftKind(index),day=Math.floor(start/1440),endDay=Math.floor(prevEnd/1440);
 const when=day===endDay?'сегодня':day===endDay+1?'завтра':`через ${day-endDay} дн.`;
 return {kind,label:SHIFT_LABEL[kind],startMinute:start%1440,restHours:rest/60,daysOff:rest>=72*60?OFF_DAYS:0,when};}
// Night duty fatigue: rises from 22:00, peaks 04:00–05:00, gone by 08:00 (Postimees 2020 survey).
export function nightFatigueFactor(minuteOfDay){const m=((minuteOfDay%1440)+1440)%1440;
 if(m>=8*60&&m<22*60)return 1;const t=m>=22*60?m-22*60:m+120;// minutes since 22:00, 0..600
 const peak=6.5*60;return t<=peak?1+.6*(t/peak):1+.6*Math.max(0,(600-t)/(600-peak));}
export const isScheduled=s=>s?.schedule===SCHEDULE_ID;
export const validSchedule=s=>s.schedule===undefined?s.shiftLength===LEGACY_SHIFT_TICKS:s.schedule===SCHEDULE_ID&&s.shiftLength===SHIFT_TICKS;
