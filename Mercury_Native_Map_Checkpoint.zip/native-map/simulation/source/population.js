import {ensureLife,tickLife,recordLife,validLife} from './resident-life.js';
import {worldMinutes,advanceVehicle,SPEED_KMH} from './transport.js';
import {visitDefaults,ensureVisit,beginVisit,tickVisit,validateVisit,VISIT_STATUSES} from './visits.js';
// A small, persistent population. People and building uses are fictional;
// footprints and the directed road network come from the bundled OSM dataset.
import data from './city-data.js';
import {byId,nearestRoad,point,roadRoute,ROAD_NODES,onRoad} from './geography.js';
import {containsWorldPoint} from './city-coverage.js';

export const POPULATION_SIZE=16;
export const RESIDENT_STATUS={home:'Дома',work:'На работе',toHome:'Едет домой',toWork:'Едет на работу',incident:'Участвует в происшествии',recovering:'Приходит в себя',toVisit:'Едет к месту отдыха',walkVisit:'Идёт к месту',visiting:'Отдыхает на прогулке',walkBack:'Идёт к машине',fromVisit:'Возвращается после прогулки'};
const names=['Кайса Тамм','Мартин Саар','Лийс Каск','Расмус Лепп','Анна Мяги','Карл Сепп','Эва Рейн','Оскар Лаас','Мария Пярн','Хенри Киви','Лаура Оя','Роберт Роос','София Илвес','Эрик Куус','Марта Сальм','Андрес Аас'];
const centre=byId('centre');
const nearby=data.buildings.map(b=>{
 const points=b.p.slice(0,-1),x=points.reduce((n,p)=>n+p[0],0)/points.length,y=points.reduce((n,p)=>n+p[1],0)/points.length;
 return {id:b.id,kind:b.kind,x,y,d:Math.hypot(x-centre.x,y-centre.y)};
}).filter(b=>b.d<.6).sort((a,b)=>a.d-b.d||a.id.localeCompare(b.id));
const homes=nearby.filter(b=>['house','apartments','residential','detached'].includes(b.kind)).slice(0,POPULATION_SIZE);
const workplaces=nearby.filter(b=>['retail','commercial','office','hotel','restaurant'].includes(b.kind)).slice(0,8);
const place=b=>({...b,access:point(nearestRoad(b)),street:nearestRoad(b).name});
export const PLACES=new Map([...homes,...workplaces].map(b=>[b.id,place(b)]));
export const RESIDENTS=homes.map((home,k)=>({id:k+1,name:names[k],home:home.id,work:workplaces[k%workplaces.length].id,start:8*60+(k%4)*10,end:17*60+k*2,color:['#c6a7e9','#ddcfa6','#9bbade','#ccaaa7'][k%4]}));
export const residentProfile=id=>RESIDENTS.find(r=>r.id===id);
export const cityMinute=elapsed=>(17*60+worldMinutes(elapsed))%1440;
export const formatMinute=m=>`${String(Math.floor(m/60)%24).padStart(2,'0')}:${String(Math.floor(m)%60).padStart(2,'0')}`;
const wanted=(profile,elapsed)=>{const m=cityMinute(elapsed);return m>=profile.start&&m<profile.end?'work':'home';};
export function ensurePopulation(s){
 if(s.population!==undefined){
  // Version 0.4.0 residents have no event fields. Only fill absent fields.
  for(const r of s.population.residents)for(const [k,v] of Object.entries({...eventDefaults(),...visitDefaults()}))if(r[k]===undefined)r[k]=v;
  for(const r of s.population.residents)ensureVisit(r);
  for(const r of s.population.residents)ensureLife(r);
  return s.population;
 }
 const elapsed=(s.shift-1)*s.shiftLength+s.time;
 s.population={version:1,elapsed,residents:RESIDENTS.map(profile=>{
  // A new 17:00 campaign begins at work, ready for the staggered evening commute.
  const status=elapsed===0?'work':wanted(profile,elapsed);
  return {id:profile.id,...PLACES.get(profile[status]).access,status,route:[],heading:0,journeys:0,...eventDefaults(),...visitDefaults()};
 })};for(const r of s.population.residents)ensureLife(r);return s.population;
}
const eventDefaults=()=>({incidentId:null,resumeStatus:null,recoveryUntil:0,stress:0,lastEvent:null});
const routes=new Map();
// Link only stationary residents to nearby, stationary calls. Moving drivers and
// missing people remain scene actors until their transport/search lifecycle exists.
export function linkResident(s,i){
 if(![0,3,4].includes(i.type))return null;
 const candidates=ensurePopulation(s).residents.filter(r=>['home','work'].includes(r.status)&&r.incidentId===null);
 if(!candidates.length)return null;
 const r=candidates[(i.id-1)%candidates.length],a=i.scene.participants[0];
 r.resumeStatus=r.status;r.status='incident';r.incidentId=i.id;recordLife(r,r.resumeStatus,s.population.elapsed);
 Object.assign(i,point(r));
 for(const actor of i.scene.participants)Object.assign(actor,point(r));
 a.residentId=r.id;a.name=residentProfile(r.id).name;
 if(i.type===3)a.role='Заявитель';
 return r;
}
export function releaseResidents(s,i,success,outcome){
 for(const r of ensurePopulation(s).residents){if(r.incidentId!==i.id)continue;
  const calm=success&&i.scene.tension<35;
  r.stress=Math.min(100,r.stress+(success?(calm?5:15):35));
  r.recoveryUntil=s.population.elapsed+(success?(calm?8:20):45);
  r.lastEvent={incidentId:i.id,outcome,success,elapsed:s.population.elapsed};
  r.incidentId=null;r.status='recovering';recordLife(r,'incident',s.population.elapsed);
 }
}
export function validateResidentLinks(s){
 const claimed=new Set();
 for(const i of s.incidents)for(const a of i.scene.participants){
  if(a.residentId===undefined)continue;
  const r=s.population.residents.find(r=>r.id===a.residentId);
  if(!r||a.name!==residentProfile(r.id).name||![0,3,4].includes(i.type)||a!==i.scene.participants[0])return false;
  if(['resolved','missed'].includes(i.state))continue;
  if(claimed.has(r.id)||r.status!=='incident'||r.incidentId!==i.id||a.route.length||Math.hypot(a.x-r.x,a.y-r.y)>1e-7||Math.hypot(i.x-r.x,i.y-r.y)>1e-7)return false;
  claimed.add(r.id);
 }
 return s.population.residents.every(r=>(r.status==='incident')===claimed.has(r.id));
}
function commute(profile,from,to){
 const key=profile.id+':'+to;
 if(!routes.has(key))routes.set(key,roadRoute(PLACES.get(profile[from]).access,PLACES.get(profile[to]).access));
 return routes.get(key).map(p=>({...p}));
}
// R1 calendar (Claude): time jumps between realistic shifts (12 h to 4 days). Residents are put
// where the clock says they should be (home or work), with no route, visit or incident link;
// needs (life) keep their values. Only scheduled campaigns call this.
export function resyncPopulation(s,elapsed){const population=ensurePopulation(s);population.elapsed=elapsed;
 for(const r of population.residents){const profile=residentProfile(r.id),status=wanted(profile,elapsed);Object.assign(r,PLACES.get(profile[status]).access,{status,route:[],heading:0,...eventDefaults(),...visitDefaults()});ensureVisit(r);ensureLife(r);}
 return population;}
export function tickPopulation(s,dt){
 const population=ensurePopulation(s);population.elapsed+=dt;
 for(const r of population.residents){
  const previous=r.status;tickLife(r,dt);
  try {
  const profile=residentProfile(r.id);
  if(r.status==='incident')continue;
  r.stress=Math.max(0,r.stress-dt*.12);
  if(r.status==='recovering'){
   if(population.elapsed<r.recoveryUntil)continue;
   r.status=r.resumeStatus;r.resumeStatus=null;r.recoveryUntil=0;
  }
  if(VISIT_STATUSES.includes(r.status)){tickVisit(r,population.elapsed,dt,PLACES.get(profile[r.visit.origin]).access);continue;}
  if(!r.route.length&&['home','work'].includes(r.status)){
   const to=wanted(profile,population.elapsed);
   if(to!==r.status){r.route=commute(profile,r.status,to);r.status=to==='home'?'toHome':'toWork';}
   else if(beginVisit(r,population.elapsed,r.status)){tickVisit(r,population.elapsed,dt,PLACES.get(profile[r.visit.origin]).access);continue;}
  }
  advanceVehicle(r,dt,Math.min(SPEED_KMH.civilian,r.trafficTargetKmh??Infinity));
  if(!r.route.length&&['toHome','toWork'].includes(r.status)){r.status=r.status==='toHome'?'home':'work';r.journeys++;}
  } finally {recordLife(r,previous,population.elapsed);}
 }
}
export function residentPosition(r){const profile=residentProfile(r.id);return ['home','work'].includes(r.status)?PLACES.get(profile[r.status]):r;}
export function populationSummary(s){const residents=ensurePopulation(s).residents;return {total:residents.length,home:residents.filter(r=>r.status==='home').length,work:residents.filter(r=>r.status==='work').length,travelling:residents.filter(r=>r.route.length).length,involved:residents.filter(r=>r.status==='incident').length,recovering:residents.filter(r=>r.status==='recovering').length,visiting:residents.filter(r=>VISIT_STATUSES.includes(r.status)).length};}
const coord=p=>`${p.x},${p.y}`,nodes=new Map(ROAD_NODES.map(n=>[coord(n),n]));
const number=(v,max=1e9)=>Number.isFinite(v)&&v>=0&&v<=max;
export function validatePopulation(p){
 if(!p||p.version!==1||!number(p.elapsed)||!Array.isArray(p.residents)||p.residents.length!==POPULATION_SIZE||new Set(p.residents.map(r=>r?.id)).size!==POPULATION_SIZE)return false;
 return p.residents.every(r=>{
  const profile=residentProfile(r?.id);
  if(!profile||!containsWorldPoint(r)||!Number.isFinite(r.heading)||Math.abs(r.heading)>Math.PI||!Number.isInteger(r.journeys)||!number(r.journeys)||!Object.hasOwn(RESIDENT_STATUS,r.status)||!Array.isArray(r.route)||r.route.length>1000)return false;
  const eventKeys=Object.keys(eventDefaults()),hasEvents=eventKeys.some(k=>r[k]!==undefined);
  if(hasEvents){
   if(!eventKeys.every(k=>r[k]!==undefined)||!number(r.stress,100)||!number(r.recoveryUntil))return false;
   if(r.incidentId!==null&&(!Number.isInteger(r.incidentId)||r.incidentId<1))return false;
   const busy=['incident','recovering'].includes(r.status);
   if(busy?!['home','work'].includes(r.resumeStatus):r.resumeStatus!==null)return false;
   if((r.status==='incident')!==(r.incidentId!==null)||r.status!=='recovering'&&r.recoveryUntil!==0)return false;
   if(r.lastEvent!==null){const e=r.lastEvent;if(!e||!Number.isInteger(e.incidentId)||e.incidentId<1||typeof e.outcome!=='string'||e.outcome.length>500||typeof e.success!=='boolean'||!number(e.elapsed)||e.elapsed>p.elapsed)return false;}
  }else if(['incident','recovering'].includes(r.status))return false;
  if(!validLife(r,p.elapsed,RESIDENT_STATUS)||!validateVisit(r,p.elapsed,PLACES,profile))return false;
  if(VISIT_STATUSES.includes(r.status))return true;
  if(['incident','recovering'].includes(r.status)){
   const access=PLACES.get(profile[r.resumeStatus]).access;
   return r.route.length===0&&Math.hypot(r.x-access.x,r.y-access.y)<1e-7;
  }
  if(!r.route.every((p,k)=>p&&nodes.has(coord(p))&&(!k||nodes.get(coord(r.route[k-1])).edges.some(e=>e.id===nodes.get(coord(p)).id))))return false;
  const to=r.status==='home'||r.status==='toHome'?'home':'work',destination=PLACES.get(profile[to]).access;
  if(['home','work'].includes(r.status))return r.route.length===0&&Math.hypot(r.x-destination.x,r.y-destination.y)<1e-7;
  if(!r.route.length||Math.hypot(r.route.at(-1).x-destination.x,r.route.at(-1).y-destination.y)>1e-7||!onRoad(r))return false;
  // The remaining first segment must be a real incoming directed edge.
  const first=nodes.get(coord(r.route[0]));
  if(Math.hypot(r.x-first.x,r.y-first.y)<1e-7)return true;
  return ROAD_NODES.some(a=>a.edges.some(e=>e.id===first.id&&Math.abs(Math.hypot(a.x-r.x,a.y-r.y)+Math.hypot(r.x-first.x,r.y-first.y)-e.d)<1e-7));
 });
}
