import {segmentSpeed} from './geography.js';
import {MAP_METRES} from './world-scale.js';
// Internal campaign units are retained for save compatibility. The presentation
// clock explicitly selects real-time (1) or the legacy compressed pace (45).
export const WORLD_SECONDS_PER_TICK_SECOND=45;
export const worldMinutes=elapsed=>elapsed*WORLD_SECONDS_PER_TICK_SECOND/60;
export const SPEED_KMH=Object.freeze({patrol:30,response:60,pursuit:75,civilian:30,fleeing:40,stopping:15,walking:4.8});
export const VEHICLE_DYNAMICS=Object.freeze({acceleration:2.2,braking:4.5,emergencyBraking:6,turning:25,sharpTurn:15});
const motionTraces=new WeakMap();
export function motionTrace(entity,since=0){const record=motionTraces.get(entity);if(!record||record.revision<=since)return null;return {revision:record.revision,points:record.segments.filter(s=>s.revision>since).flatMap(s=>s.points)};}
function recordMotion(entity,trace){if(!trace.length||Math.hypot(trace.at(-1).x-entity.x,trace.at(-1).y-entity.y)>1e-12)trace.push({x:entity.x,y:entity.y});const previous=motionTraces.get(entity),revision=(previous?.revision??0)+1,segments=[...(previous?.segments??[]),{revision,points:trace}].slice(-12);motionTraces.set(entity,{revision,segments});}
export const travelDistance=(kmh,dt)=>Math.max(0,kmh)/3.6*Math.max(0,dt)*WORLD_SECONDS_PER_TICK_SECOND/MAP_METRES;
export const patrolSpeed=u=>u.pursuing?SPEED_KMH.pursuit:u.status==='responding'?SPEED_KMH.response:SPEED_KMH.patrol;
const angle=(a,b)=>Math.abs(Math.atan2(Math.sin(a-b),Math.cos(a-b)));
const turnLimit=(from,at,to,dynamics)=>{
 if(!to)return 0;
 const bend=angle(Math.atan2(at.y-from.y,at.x-from.x),Math.atan2(to.y-at.y,to.x-at.x));
 return bend>=1.15?dynamics.sharpTurn:bend>=.55?dynamics.turning:Infinity;
};
const segmentProfile=(from,to)=>to.roadSpeed??segmentSpeed(from,to);
function speedPlan(entity,requested,obeyLimits,dynamics,currentSpeed){
 if(!entity.route.length)return {target:0,limit:null,source:null};
 const first=entity.route[0],profile=segmentProfile(entity,first),valid=Number.isFinite(profile?.kmh)&&profile.kmh>0&&profile.kmh<=130;
 const base=Math.max(0,Math.min(requested,obeyLimits&&valid?profile.kmh:Infinity));
 let target=base,distance=0,from=entity;
 for(let k=0;k<Math.min(18,entity.route.length);k++){
  const at=entity.route[k],to=entity.route[k+1],segment=Math.hypot(at.x-from.x,at.y-from.y)*MAP_METRES;
  distance+=segment;
  let future=turnLimit(from,at,to,dynamics);
  if(to){const next=segmentProfile(at,to);if(obeyLimits&&Number.isFinite(next?.kmh)&&next.kmh>0)future=Math.min(future,next.kmh);}
  else future=0;
  // Reserve one second of travel so a fixed simulation step cannot carry
  // excess speed across the sign, bend or final parking point.
  const brakingDistance=Math.max(0,distance-currentSpeed/3.6);
  if(Number.isFinite(future))target=Math.min(target,Math.sqrt((future/3.6)**2+2*dynamics.braking*brakingDistance)*3.6);
  if(distance>450)break;
  from=at;
 }
 return {target,limit:valid?profile.kmh:null,source:valid?profile.source:null};
}
function moveAtSpeed(entity,seconds,kmh,trace=null){
 let left=kmh/3.6*seconds/MAP_METRES,distance=0;
 while(left>1e-12&&entity.route.length){const p=entity.route[0],dx=p.x-entity.x,dy=p.y-entity.y,d=Math.hypot(dx,dy);if(d<=1e-12){entity.x=p.x;entity.y=p.y;entity.route.shift();continue;}entity.heading=Math.atan2(dy,dx);const step=Math.min(left,d);if(step>=d){entity.x=p.x;entity.y=p.y;entity.route.shift();trace?.push({x:entity.x,y:entity.y});}else{entity.x+=dx*step/d;entity.y+=dy*step/d;}left-=step;distance+=step;}
 return distance;
}
export function advanceRoute(entity,dt,kmh,{obeyLimits=true,kinematics=false,dynamics=VEHICLE_DYNAMICS}={}){
 if(kinematics)return advanceVehicle(entity,dt,kmh,{obeyLimits,dynamics});
 let seconds=Math.max(0,Number.isFinite(dt)?dt:0)*WORLD_SECONDS_PER_TICK_SECOND,distance=0,trace=[];
 while(seconds>1e-10&&entity.route.length){
  const p=entity.route[0],dx=p.x-entity.x,dy=p.y-entity.y,d=Math.hypot(dx,dy);
  const profile=p.roadSpeed??segmentSpeed(entity,p),limit=profile?.kmh,valid=Number.isFinite(limit)&&limit>0&&limit<=130;
  const speed=Math.max(0,Math.min(Number.isFinite(kmh)?kmh:0,obeyLimits&&valid?limit:Infinity));
  entity.roadLimitKmh=valid?limit:null;entity.roadLimitSource=valid?profile.source:null;
  if(d<=1e-12){entity.x=p.x;entity.y=p.y;entity.route.shift();continue;}
  if(speed<=0)break;
  entity.heading=Math.atan2(dy,dx);
  const rate=speed/3.6/MAP_METRES,step=Math.min(d,rate*seconds);
  if(step>=d){entity.x=p.x;entity.y=p.y;trace.push({x:p.x,y:p.y});entity.route.shift();}else{entity.x+=dx*step/d;entity.y+=dy*step/d;}
  seconds=Math.max(0,seconds-step/rate);distance+=step;
 }
 entity.currentSpeedKmh=dt>0?distance*MAP_METRES*3.6/(dt*WORLD_SECONDS_PER_TICK_SECOND):0;if(distance>0)recordMotion(entity,trace);return distance;
}
export function advanceVehicle(entity,dt,kmh,{obeyLimits=true,dynamics=VEHICLE_DYNAMICS}={}){
 const total=Math.max(0,Number.isFinite(dt)?dt:0)*WORLD_SECONDS_PER_TICK_SECOND,requested=Math.max(0,Number.isFinite(kmh)?kmh:0);
 let seconds=total,distance=0,speed=Number.isFinite(entity.motionSpeedKmh)?Math.max(0,entity.motionSpeedKmh):0,trace=[];
 while(seconds>1e-10&&entity.route.length){
  // Half-second world slices keep braking continuous without excessive mobile CPU work.
  const slice=Math.min(.5,seconds),plan=speedPlan(entity,requested,obeyLimits,dynamics,speed),rate=plan.target>=speed?dynamics.acceleration:dynamics.braking;
  const next=Math.max(0,plan.target>=speed?Math.min(plan.target,speed+rate*slice*3.6):Math.max(plan.target,speed-rate*slice*3.6));
  entity.roadLimitKmh=plan.limit;entity.roadLimitSource=plan.source;
  distance+=moveAtSpeed(entity,slice,(speed+next)/2,trace);speed=entity.route.length?next:0;seconds-=slice;
 }
 if(!entity.route.length)speed=0;
 if(entity.route.length){const active=segmentProfile(entity,entity.route[0]);if(Number.isFinite(active?.kmh)&&active.kmh>0&&active.kmh<=130){entity.roadLimitKmh=active.kmh;entity.roadLimitSource=active.source;}}
 entity.motionSpeedKmh=speed;entity.currentSpeedKmh=total>0?distance*MAP_METRES*3.6/total:0;
 if(distance>0)recordMotion(entity,trace);
 return distance;
}
// Bounded catch-up: normal 15/30/60 FPS and stalls up to 0.5 s lose no time.
// Longer foreground gaps are explicitly dropped, never replayed as minutes of work.
// R24 (Claude, 11.10.2026): more acceleration — ×10/×30/×60 on top of ×1/×2/×4. Up to ×4 the step stays
// 0.1 world-tick-second (identical results at any FPS, as before); faster speeds take proportionally
// longer steps, capped at 0.5 (the step every long-run audit uses), and at most 40 steps per frame.
export const GAME_SPEEDS=Object.freeze([1,2,4,10,30,60]);
export const MAX_STEP=.5,MAX_STEPS_PER_FRAME=40;
export const stepFor=(rate,speed)=>Math.min(MAX_STEP,.1*rate/WORLD_SECONDS_PER_TICK_SECOND*Math.max(1,speed/4));
export function createSimulationClock({worldRate=WORLD_SECONDS_PER_TICK_SECOND}={}){let remainder=0,rate=worldRate===1?1:45;return {
 reset(){remainder=0;},rate(value){rate=value===1?1:45;remainder=0;},worldRate:()=>rate,
 visualScale:speed=>rate/WORLD_SECONDS_PER_TICK_SECOND*(speed===0||GAME_SPEEDS.includes(speed)?speed:1),
 advance(realSeconds,speed,step){if(!Number.isFinite(realSeconds)||realSeconds<=0)return {steps:0,dropped:0};const accepted=Math.min(.5,realSeconds),factor=GAME_SPEEDS.includes(speed)?speed:1,quantum=stepFor(rate,factor);remainder+=accepted*factor*rate/WORLD_SECONDS_PER_TICK_SECOND;const count=Math.min(factor>4?MAX_STEPS_PER_FRAME:20,Math.floor((remainder+1e-9)/quantum));for(let i=0;i<count;i++)step(quantum);remainder=Math.max(0,remainder-count*quantum);if(factor>4)remainder=Math.min(remainder,quantum*MAX_STEPS_PER_FRAME);return {steps:count,dropped:Math.max(0,realSeconds-accepted)};}
};}

export function formatWorldDuration(internalSeconds){const seconds=Math.ceil(Math.max(0,Number.isFinite(internalSeconds)?internalSeconds:0)*WORLD_SECONDS_PER_TICK_SECOND),hours=Math.floor(seconds/3600),minutes=Math.floor(seconds%3600/60),rest=seconds%60;return hours?`${hours} ч ${minutes} мин города`:minutes?`${minutes} мин ${rest} с города`:`${rest} с города`;}
