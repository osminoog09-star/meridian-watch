// Seasons and daylight for roster campaigns (Claude, 11.10.2026). The PPA calendar (schedule.js)
// gives every shift a real date; a new campaign starts on 12 October. Pärnu climate and daylight:
// January ≈ −4 °C and 7 h of daylight, July ≈ +17 °C and 18 h. Snow and black ice slow every car
// and multiply crashes; summer heat brings yards, bars and the beach to life.
import {shiftStartMinute} from './schedule.js';
export const CAMPAIGN_EPOCH=Date.UTC(2026,9,12);// day 2 of the roster clock = 12.10.2026
export function dateOf(minute){const day=Math.floor(minute/1440)-2,d=new Date(CAMPAIGN_EPOCH+day*86400000);return {month:d.getUTCMonth(),dayOfMonth:d.getUTCDate(),year:d.getUTCFullYear(),label:`${String(d.getUTCDate()).padStart(2,'0')}.${String(d.getUTCMonth()+1).padStart(2,'0')}`};}
export const shiftDate=index=>dateOf(shiftStartMinute(index));
export const SEASONS=Object.freeze({winter:'Зима',spring:'Весна',summer:'Лето',autumn:'Осень'});
export const seasonOf=month=>month<=1||month===11?'winter':month<=4?'spring':month<=7?'summer':'autumn';
// Local sunrise/sunset (minutes) per month, Pärnu, rounded; DST included.
export const SUN=Object.freeze([[540,960],[480,1035],[420,1110],[390,1230],[315,1290],[255,1365],[270,1350],[345,1275],[420,1185],[480,1095],[495,975],[550,945]]);
export const SEASON_WEATHER=Object.freeze({
 winter:{order:['snow','clear','ice','snow','fog','clear','snow','wind'],temps:{snow:[-9,-1],clear:[-14,-3],ice:[-3,1],fog:[-4,2],wind:[-8,0]}},
 spring:{order:['clear','rain','clear','wind','rain','clear','fog','clear'],temps:{clear:[6,16],rain:[3,10],wind:[4,11],fog:[1,7]}},
 summer:{order:['clear','heat','clear','rain','clear','heat','wind','clear'],temps:{clear:[17,24],heat:[25,31],rain:[13,19],wind:[15,20]}},
 autumn:{order:['rain','clear','fog','rain','wind','clear','rain','fog'],temps:{rain:[4,11],clear:[5,13],fog:[2,8],wind:[3,10]}}
});
// Speed of all traffic in the weather (black ice is the worst).
export const WEATHER_SPEED=Object.freeze({snow:.8,ice:.7,fog:.9});
export const weatherSpeed=kind=>WEATHER_SPEED[kind]??1;

// Holidays and events of the Estonian calendar (fictional city, real dates). Night shifts that
// cross midnight count the next day too (New Year's night, Midsummer night).
export const HOLIDAYS=Object.freeze([
 {month:0,day:1,label:'Новый год',intensity:1.4,mods:{'noise-flat':2,'yard-company':2,'street-fight':1.8,'drunk-person':2,'fire-smoke':2.5,'drunk-driver':1.5}},
 {month:1,day:24,label:'День независимости',intensity:1.15,mods:{'noise-venue':1.5,'yard-company':1.4,'drunk-person':1.4}},
 {month:5,day:23,label:'Яанипяэв (Иванов день)',intensity:1.5,mods:{'drunk-person':2.5,'yard-company':2,'street-fight':1.8,'drunk-driver':2.2,'fire-smoke':2,'domestic':1.4,'noise-flat':1.5}},
 {month:5,day:24,label:'Яанипяэв (Иванов день)',intensity:1.4,mods:{'drunk-person':2.2,'drunk-driver':2,'street-fight':1.5,'crash':1.4}},
 {month:6,day:10,label:'Летний фестиваль на пляже',intensity:1.35,mods:{'noise-venue':2.2,'drunk-person':2,'street-fight':1.6,'bike-theft':1.5,'shoplift':1.3}},
 {month:6,day:11,label:'Летний фестиваль на пляже',intensity:1.35,mods:{'noise-venue':2.2,'drunk-person':2,'street-fight':1.6,'bike-theft':1.5,'shoplift':1.3}},
 {month:8,day:1,label:'День знаний',intensity:1.1,mods:{'missing-child':2,'crash':1.2}},
 {month:11,day:24,label:'Сочельник',intensity:1.1,mods:{domestic:1.6,'drunk-person':1.3}},
 {month:11,day:31,label:'Новогодняя ночь',intensity:1.5,mods:{'noise-flat':2.2,'yard-company':2,'street-fight':1.8,'drunk-person':2,'fire-smoke':2.5,'drunk-driver':1.6}}
]);
const holidayOn=(month,day)=>HOLIDAYS.find(h=>h.month===month&&h.day===day)??null;
export function shiftEvent(index,night){const start=dateOf(shiftStartMinute(index));let h=holidayOn(start.month,start.dayOfMonth);if(!h&&night){const next=dateOf(shiftStartMinute(index)+720);h=holidayOn(next.month,next.dayOfMonth);}return h;}

// Call load by hour and weekday (roster campaigns): busy evenings and the first half of the night,
// quiet early mornings, Friday and Saturday nights at their peak, calm Sunday mornings.
// Multiplies the rate of new calls; together with holidays it decides how hard a shift is.
const HOURLY=[1.35,1.25,1.05,.8,.6,.55,.6,.75,.9,.95,1,1,1.05,1,1,1.05,1.1,1.2,1.25,1.3,1.3,1.3,1.35,1.4];
export const WEEKDAY_LABEL=Object.freeze(['воскресенье','понедельник','вторник','среда','четверг','пятница','суббота']);
export const weekdayOf=absMinute=>new Date(CAMPAIGN_EPOCH+(Math.floor(absMinute/1440)-2)*86400000).getUTCDay();
export function loadFactor(absMinute){const m=((absMinute%1440)+1440)%1440,h=Math.floor(m/60),wd=weekdayOf(absMinute);let f=HOURLY[h];
 // Friday/Saturday evening and the night after them; Sunday morning is calm.
 const nightOf=h<6?(wd+6)%7:wd;if((nightOf===5||nightOf===6)&&(h>=18||h<6))f*=1.45;else if(wd===0&&h>=6&&h<14)f*=.75;return f;}
export const absoluteMinute=elapsedMinutes=>1440+17*60+elapsedMinutes;
