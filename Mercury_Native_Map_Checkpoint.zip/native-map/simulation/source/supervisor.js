// Release R1 «Служба как в ППА» (Claude, 17.10.2026). Owner 17.10: «встречи с моим руководителем; он же тоже должен приезжать
// иногда на вызовы — välijuht». A patrol officer's shift has a field supervisor (välijuht, usually an ülemkonstaabel or a
// komissar): he comes to the serious calls of his crews (a weapon, a joint scene, a fight with backup) and takes the lead,
// and every few shifts he talks with the officer — feedback, courses, extra shifts, the next rank.
export const SUPERVISOR=Object.freeze({kmh:70,pace:1.1,xp:5,talkEvery:8});
const NAMES=['Тармо Ребане','Кристина Лепп','Андрес Кукк','Марина Волкова','Райво Саар','Ирина Петрова'];
export const supervisorName=seed=>NAMES[Math.abs(seed|0)%NAMES.length];
export const supervisorTitle=seed=>`руководитель смены, комиссар ${supervisorName(seed)}`;
export function leadNeeded(i,{armed=false,joint=false,severity=0}={}){return !!i&&i.lead==null&&i.units?.includes(1)&&(armed||joint||(severity>=3&&!!i.backupRequested));}
export const validLead=i=>i.lead===undefined||i.lead===null||['called','onscene'].includes(i.lead);
