// Release F «Истории города» (Claude, 12.10.2026). Single calls are forgotten the next day; a city also
// has stories that run for days: a bicycle thief working one district, a night racer, phone scammers
// sending couriers to pensioners, a bar by the port that keeps the street awake, break-ins at the garage
// cooperative. Each story has three chapters on separate shifts. A chapter is one call in the story's
// district with its own briefing line and lookout; when the crew closes it the story moves on, a missed
// chapter is given one more chance, two misses and the story ends badly. The city press follows every
// chapter. Works in the career (the player's crew gets the call when free) and for the chief.
// Deterministic: order and timing come from hashes of the seed and the shift (no rng).
import {NODES,ROAD_NODES} from './geography.js';
import {MAP_METRES} from './world-scale.js';
const hash=(a,b)=>{let h=Math.imul((a|0)+389,2654435761)^Math.imul((b|0)+71,1597334677);h^=h>>>15;h=Math.imul(h,2246822519);return ((h^h>>>13)>>>0)/4294967296;};
export const ARCS=Object.freeze({
 bikes:{title:'Велосипеды Заречья',district:'ulejoe',intro:'В Заречье за неделю пропало шесть велосипедов — жители просят полицию разобраться.',chapters:[
  {variant:'bike-theft',brief:'Новая кража велосипеда у школы в Заречье. Опросите владельца и посмотрите камеры — нужен почерк вора.',lookout:'подросток с болторезом в рюкзаке, Заречье',news:'Полиция нашла запись кражи велосипедов в Заречье'},
  {variant:'bike-theft',brief:'Ещё один велосипед — у вокзала. По камерам тот же подросток. Ищем, куда он их свозит.',lookout:'подросток на чужом велосипеде, едет к гаражам Заречья',news:'Кражи велосипедов в Заречье: у полиции есть приметы'},
  {variant:'suspect-found',brief:'Соседи видят у гаражей Заречья парня с велосипедами. Задержите и соберите доказательства.',lookout:'гаражи у реки: склад краденых велосипедов',news:'В Заречье задержан серийный похититель велосипедов, владельцам вернут 11 велосипедов'}],
  good:'Серия краж велосипедов в Заречье раскрыта.',bad:'Вор из Заречья ушёл: велосипеды так и не нашли.'},
 racer:{title:'Ночной гонщик',district:'mai',intro:'По ночам в Майском гоняет тёмный седан: жители не спят, на перекрёстках опасно.',chapters:[
  {variant:'dangerous-driving',brief:'Тёмный седан снова гоняет по Майскому. Остановите безопасно и проверьте водителя.',lookout:'тёмный седан без глушителя, Майский',news:'Гонки по ночному Майскому: полиция усилила контроль'},
  {variant:'school-speeding',brief:'Тот же седан пролетел у школы на 70 км/ч. Нужна радарная проверка и протокол.',lookout:'тёмный седан, номер частично известен',news:'Гонщик у школы: полиция знает номер машины'},
  {variant:'vehicle-alert',brief:'Седан замечен камерами — водитель не остановится. Будьте готовы к преследованию.',lookout:'тёмный седан, водитель лишён прав',news:'Ночной гонщик Майского задержан после преследования'}],
  good:'Ночной гонщик задержан, в Майском снова тихо.',bad:'Гонщик ушёл. Жители Майского пишут жалобы в мэрию.'},
 scam:{title:'Звонок от «внука»',district:'vana',intro:'Пенсионерам Старого посада звонят «внуки» и «полицейские» и присылают курьеров за деньгами.',chapters:[
  {variant:'phone-scam',brief:'Пенсионерке звонят прямо сейчас: «внук попал в аварию». Успейте до курьера.',lookout:'курьер мошенников: молодой мужчина в кепке, Старый посад',news:'Мошенники звонят пенсионерам Старого посада: полиция предупреждает'},
  {variant:'phone-scam',brief:'Новый звонок, курьер уже едет. Попробуйте задержать его при передаче денег.',lookout:'курьер на такси, ждёт у подъезда',news:'Полиция ловит курьеров телефонных мошенников'},
  {variant:'suspect-found',brief:'Курьер приметен в Старом посаде с пакетом денег. Задержите — он выведет на организаторов.',lookout:'мужчина в кепке с пакетом, ждёт машину',news:'Задержан курьер телефонных мошенников: пенсионерам вернут деньги'}],
  good:'Курьер мошенников задержан, деньги пенсионерам вернут.',bad:'Мошенники сменили номера: пенсионеры Старого посада остались без денег.'},
 bar:{title:'Бар у порта',district:'beach',intro:'Бар у порта в Курортном работает до утра: шум, драки, жалобы соседей.',chapters:[
  {variant:'noise-venue',brief:'Опять шум у бара в Курортном. Спокойно поговорите с администратором и соберите показания соседей.',lookout:'бар у порта: громкая музыка после 23:00',news:'Жители Курортного жалуются на ночной бар у порта'},
  {variant:'street-fight',brief:'У того же бара драка. Разведите участников, найдите зачинщика.',lookout:'компания у бара у порта, конфликты на выходе',news:'Драка у бара в Курортном: полиция опросила свидетелей'},
  {variant:'noise-venue',brief:'Третья ночь подряд. Оформите нарушение — материалы уйдут в мэрию для решения о часах работы.',lookout:'бар у порта: проверка после полуночи',news:'Мэрия ограничила часы работы бара у порта после материалов полиции'}],
  good:'Бару у порта ограничили часы работы: в Курортном тише.',bad:'Бар у порта работает как прежде, соседи разочарованы.'},
 garages:{title:'Гаражный кооператив',district:'raama',intro:'В Северной слободе вскрывают гаражи и машины во дворах.',chapters:[
  {variant:'car-break',brief:'Вскрыта машина во дворе Северной слободы. Камеры подъезда могли что-то записать.',lookout:'двое в тёмной одежде, машины во дворах Северной слободы',news:'В Северной слободе вскрывают машины: полиция просит записи камер'},
  {variant:'alarm-burglary',brief:'Сработала сигнализация гаража в кооперативе. Те же двое?',lookout:'белый фургон у гаражного кооператива ночью',news:'Взлом в гаражном кооперативе: полиция изучает записи'},
  {variant:'suspect-found',brief:'Белый фургон с инструментами стоит у кооператива. Задержите и проверьте содержимое.',lookout:'белый фургон с инструментами, Северная слобода',news:'Задержаны взломщики гаражей Северной слободы'}],
  good:'Взломщики гаражей задержаны, часть вещей вернули владельцам.',bad:'Взломы в Северной слободе продолжаются: полиция не успела.'}
});
export const ARC_IDS=Object.freeze(Object.keys(ARCS));
export const CITY=Object.freeze({firstShift:9,gap:3,misses:2,window:[.25,.65],end:.85,reward:{trust:2,district:5,xp:150,budget:600},penalty:{trust:-2,district:-4}});
// The order of stories is fixed per campaign seed.
export const arcOrder=seed=>[...ARC_IDS].sort((a,b)=>hash(seed,a.length*7+a.charCodeAt(0))-hash(seed,b.length*7+b.charCodeAt(0)));
// After every story has been told the city's troubles come back (a new series), never the last one again.
export const DONE_LIMIT=10;
export function nextArc(seed,done,total=done.length){const order=arcOrder(seed),fresh=order.find(id=>!done.some(d=>d.id===id));if(fresh&&total<ARC_IDS.length)return fresh;const last=done.at(-1)?.id;const k=total%order.length;return order[k]===last?order[(k+1)%order.length]:order[k];}
export const chapterOf=a=>a?ARCS[a.id]?.chapters[a.chapter]??null:null;
export const spawnAt=(seed,shift,len)=>len*(CITY.window[0]+hash(seed,shift*3)*(CITY.window[1]-CITY.window[0]));
// Where the chapter happens: a road node 150–700 m from the district centre, different every chapter.
export function arcPoint(id,chapter){const d=NODES.find(n=>n.id===ARCS[id]?.district)??NODES[0],ring=ROAD_NODES.filter(n=>{const m=Math.hypot(n.x-d.x,n.y-d.y)*MAP_METRES;return m>=150&&m<=700;}).sort((a,b)=>String(a.id).localeCompare(String(b.id)));return ring.length?{x:ring[(chapter*13+id.length*5)%ring.length].x,y:ring[(chapter*13+id.length*5)%ring.length].y}:{x:d.x,y:d.y};}
// After the ending the story's kind of calls changes for a while: solved — fewer (×0.6), failed — more (×1.4).
export const EFFECT=Object.freeze({solved:.6,failed:1.4,shifts:12,limit:3});
export function cityMods(c,shift){const out={};for(const e of c?.effects??[]){if(e.until<shift||!ARCS[e.id])continue;for(const v of new Set(ARCS[e.id].chapters.map(ch=>ch.variant)))out[v]=(out[v]??1)*e.factor;}return out;}
export function validCity(c){if(c===undefined)return true;const int=(x,a,b)=>Number.isInteger(x)&&x>=a&&x<=b;if(!c||typeof c!=='object'||!Array.isArray(c.done)||c.done.length>DONE_LIMIT||(c.total!==undefined&&!int(c.total,0,1e6))||(c.effects!==undefined&&!(Array.isArray(c.effects)&&c.effects.length<=EFFECT.limit&&c.effects.every(e=>e&&Object.hasOwn(ARCS,e.id)&&[EFFECT.solved,EFFECT.failed].includes(e.factor)&&int(e.until,0,1e6))))||!c.done.every(d=>d&&Object.hasOwn(ARCS,d.id)&&typeof d.ok==='boolean'&&int(d.shift,0,1e6))||!int(c.next,0,1e6))return false;
 const a=c.arc;if(a===null||a===undefined)return true;return Object.hasOwn(ARCS,a.id)&&int(a.chapter,0,ARCS[a.id].chapters.length-1)&&int(a.miss,0,CITY.misses)&&(a.spawned===undefined||int(a.spawned,0,1e6))&&(a.incident===undefined||int(a.incident,0,1e9))&&(a.outcome===undefined||['ok','miss'].includes(a.outcome));}
