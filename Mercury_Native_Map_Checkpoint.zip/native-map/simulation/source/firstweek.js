// Release E (Claude's part) «Первая неделя службы» (Claude, 12.10.2026). A new roster career no longer
// starts with a wall of buttons: the first seven shifts are a guided week with the mentor. Every shift has
// one story call that comes to the player's crew (a noise complaint, a shoplifter, a drunk driver, a family
// conflict, a crash, a missing child, a confused elderly man). The mentor explains at the briefing what
// matters on that call; after the shift the debrief says what went well. At the end of the week the
// mentor gives a short evaluation. The week can be skipped at any time. Pure rules; sim.js drives it.
import {ROAD_NODES} from './geography.js';
import {MAP_METRES} from './world-scale.js';
export const WEEK=Object.freeze([
 {day:1,variant:'noise-flat',title:'Знакомство с районом',key:'polite',
  brief:'Первый день. Сегодня покажу район и как разговаривать с людьми. На шум в квартире не начинай с угроз: вежливая просьба работает чаще, а протокол — когда знаешь историю адреса.',
  good:'Спокойный разговор — половина работы. Видел, как человек сам убавил музыку?',bad:'Ничего, бывает. В следующий раз начни с вежливой просьбы, угрозы только злят.'},
 {day:2,variant:'shoplift',title:'Факты решают',key:'camera',
  brief:'Кража в магазине. Не верь ни охране, ни задержанному на слово — посмотри видео. От суммы и прежних краж зависит, проступок это или нечто серьёзнее.',
  good:'Видео — лучший свидетель. С ним протокол не оспорят.',bad:'Без видео мы гадали. Запомни: сначала факты, потом решение.'},
 {day:3,variant:'drunk-driver',title:'Первая ночь: пьяный водитель',key:'breath',
  brief:'Ночью главное — пьяные за рулём. Останавливай в безопасном месте и всегда — алкометр. От 0,2 промилле — проступок, от 1,5 — уже уголовное дело.',
  good:'Алкометр не врёт. Ты, может, сегодня кому-то жизнь спас.',bad:'Поверить на слово ночью — самая дорогая ошибка. Только алкометр.'},
 {day:4,variant:'domestic',title:'Семейный конфликт',key:'risk',
  brief:'Самые опасные вызовы — семейные. Разведи людей по комнатам, пострадавшую опроси отдельно по листу оценки риска. Мы можем запретить агрессору подходить к дому на 72 часа.',
  good:'Ты выслушал её отдельно — так она смогла сказать правду. Запрет защитит её до суда.',bad:'Когда опрашиваешь при агрессоре, правды не услышишь. В следующий раз — отдельно.'},
 {day:5,variant:'crash',title:'ДТП',key:'secure',
  brief:'После выходных — ДТП. Сначала огни и конусы: второй аварии на нашем месте быть не должно. Потом люди и скорая, потом алкометр обоим водителям.',
  good:'Место было в безопасности, и никто не пострадал второй раз. Так и работаем.',bad:'Без ограждения в нас могли въехать. Безопасность места — первым делом.'},
 {day:6,variant:'missing-child',title:'Пропал ребёнок',key:'calm',
  brief:'Если пропал ребёнок, мать в панике. Успокой, возьми приметы и фото — без них все экипажи ищут вслепую. Потом друзья и тренер: дети чаще всего у них.',
  good:'Приметы и звонок друзьям — и нашли быстро. Мать запомнит, как ты с ней говорил.',bad:'Мы поехали, не зная, кого ищем. Приметы — первым делом.'},
 {day:7,variant:'confused-person',title:'Человек в беде',key:'bracelet',
  brief:'Последняя смена недели. Не каждый, кто шатается, пьян: у пожилых бывают диабет и деменция. Подходи спереди и спокойно, ищи браслет или записку с адресом.',
  good:'Ты увидел, что ему нужна помощь, а не протокол. Это и есть полицейская работа.',bad:'Его состояние было медицинским. Сначала проверь, не нужна ли скорая.'}
]);
export const WEEK_DAYS=WEEK.length;
export const STORY=Object.freeze({startShare:.08,reward:{xp:120,bond:10},passPoints:10,radius:[350,900]});
export const weekActive=s=>s?.mode==='career'&&s.schedule==='ppa'&&!!s.life?.week&&!s.life.week.done;
export const storyDay=s=>weekActive(s)?WEEK.find(d=>d.day===s.life.week.day)??null:null;
// The story call comes 350–900 m from the station, chosen by the day (no rng).
export function storyPoint(hq,day){const ring=ROAD_NODES.filter(n=>{const m=Math.hypot(n.x-hq.x,n.y-hq.y)*MAP_METRES;return m>=STORY.radius[0]&&m<=STORY.radius[1];});if(!ring.length)return {x:hq.x,y:hq.y};const n=ring.sort((a,b)=>String(a.id).localeCompare(String(b.id)))[(day*37)%ring.length];return {x:n.x,y:n.y};}
// Points for the day: 1 for a closed call, 1 more for the key decision the mentor asked for.
export function dayResult(day,incident){const d=WEEK.find(x=>x.day===day);if(!d||!incident)return {day,points:0,resolved:false,key:false};const resolved=incident.state==='resolved',key=!!incident.talk?.choices?.some(c=>c.id===d.key);return {day,points:(resolved?1:0)+(resolved&&key?1:0),resolved,key};}
export function weekVerdict(results){const points=results.reduce((n,r)=>n+r.points,0),max=WEEK_DAYS*2;return {points,max,passed:points>=STORY.passPoints,text:points>=STORY.passPoints?`Испытательная неделя пройдена: ${points} из ${max}. Наставник: «Можешь работать самостоятельно — я рядом, если что».`:`Неделя закончена: ${points} из ${max}. Наставник: «Не всё вышло, но это нормально. Учимся дальше — на настоящих вызовах».`};}
export function validWeek(w){if(w===undefined)return true;if(!w||typeof w!=='object')return false;const int=(x,a,b)=>Number.isInteger(x)&&x>=a&&x<=b;
 return int(w.day,1,WEEK_DAYS+1)&&(w.spawned===undefined||int(w.spawned,0,1e6))&&(w.incident===undefined||int(w.incident,0,1e9))&&Array.isArray(w.results)&&w.results.length<=WEEK_DAYS&&w.results.every(r=>r&&int(r.day,1,WEEK_DAYS)&&int(r.points,0,2))&&(w.done===undefined||typeof w.done==='boolean')&&(w.outcome===undefined||int(w.outcome,0,2))&&(w.last===undefined||typeof w.last==='string'&&w.last.length<=400);}
