// Release J «Диспетчер 112» (Claude, 12.10.2026). The player works at the emergency centre of Meridian:
// calls ring in, the caller says what they see (often not what it is), the dispatcher asks questions,
// gives instructions on the phone and sends one service with a priority. Police, rescue and ambulance
// crews of the city work on their own; their result depends on how fast and how right they were sent.
// Facts behind the rules (Häirekeskus / 112 practice, general dispatch protocols):
//  · one number for police, rescue and ambulance; the operator decides who goes and how urgently;
//  · structured questions first: is the person breathing normally? is anyone trapped? is there a weapon?
//  · «agonal» gasping is not breathing — the dispatcher starts CPR instructions over the phone;
//  · priorities A (life threatening, lights and siren) … D (can wait); under-triage costs lives,
//    over-triage takes crews away from others;
//  · a crew sent to the wrong kind of call reports back and the call is passed on — minutes lost.
// Pure rules: sim.js keeps the desk state and calls these; nothing here touches other campaigns.
import {WORLD_SECONDS_PER_TICK_SECOND} from './transport.js';
export const DISPATCH_SERVICE='dispatch';
export const isDispatch=s=>s?.agency===DISPATCH_SERVICE;
const hash=(a,b)=>{let h=Math.imul((a|0)+557,2654435761)^Math.imul((b|0)+29,1597334677);h^=h>>>15;h=Math.imul(h,2246822519);return ((h^h>>>13)>>>0)/4294967296;};
export const ticksOf=minutes=>minutes*60/WORLD_SECONDS_PER_TICK_SECOND;
export const SERVICES=Object.freeze({police:'Полиция',rescue:'Спасатели',ems:'Скорая'});
export const PRIORITIES=Object.freeze({A:'A · угроза жизни',B:'B · срочно',C:'C · без угрозы жизни',D:'D · может подождать'});
const ORDER='ABCD';
// How long the system waits before a crew is sent, by priority (world minutes).
export const RELEASE=Object.freeze({A:0,B:.5,C:3,D:8});
// The mix of calls at the centre (weights by service).
export const MIX=Object.freeze({police:1,rescue:.45,ems:1.15});
export const DESK=Object.freeze({question:15,instruction:25,instructionTrained:12,pickup:1,colleagueMinutes:[1.4,2.6],gap:.55,stress:{call:.5,heavy:2.5,trained:.5}});
// The right answer for a call: the service and the priority.
const PRIORITY_OVERRIDE=Object.freeze({'fire-smoke':'A','gas-smell':'A','missing-child':'A','lost-child-mall':'B','restraining-order':'B','power-lines':'B','alarm-burglary':'B'});
export const typeAgency=t=>t>=10&&t<=13?'ems':t>=6&&t<=9?'rescue':'police';/* same as agency.js (no import: agency.js imports this module) */
export const rightService=i=>typeAgency(i?.type);
export function rightPriority(i,types){return PRIORITY_OVERRIDE[i?.variant]??(['C','B','A'][(types[i?.type]?.severity??1)-1]??'C');}
// ── What the caller says ─────────────────────────────────────────────────────────────────────────
// Groups of calls that sound alike on the phone. The opening line does not tell which it is; the
// questions do.
export const GROUPS=Object.freeze({
 down:{title:'Человек лежит, не отвечает',opening:'Тут человек лежит на земле и не отвечает! Что делать?',variants:['drunk-person','confused-person','ems-drunk','ems-unconscious','ems-arrest','ems-diabetic','ems-seizure'],
  questions:{
   breath:{q:'Он дышит нормально?',a:{'ems-arrest':'Э-э… иногда как будто всхлипывает, редко. Глаза открыты.','ems-unconscious':'Дышит, но хрипло и редко.','drunk-person':'Дышит, храпит даже.','ems-drunk':'Дышит, храпит.','ems-diabetic':'Дышит часто, весь мокрый от пота.','ems-seizure':'Дышит, его только что трясло, теперь лежит.','confused-person':'Дышит, он сидит, бормочет что-то.'}},
   alcohol:{q:'Пахнет алкоголем?',a:{'drunk-person':'Да, сильно, и бутылка рядом.','ems-drunk':'Да, пахнет. На улице холодно, он без шапки.','ems-diabetic':'Нет. Жена говорит, он диабетик.','confused-person':'Нет. Пожилой, в домашних тапках.'},other:'Не чувствую, не знаю.'},
   danger:{q:'Он агрессивен? Вам что-то угрожает?',a:{'drunk-person':'Пристаёт к людям, ругается, толкнул женщину.','confused-person':'Нет, он растерян, спрашивает, где его дом.'},other:'Нет, он не двигается.'}}},
 smoke:{title:'Пахнет дымом',opening:'В доме пахнет дымом, кажется, у соседей! Что делать?',variants:['fire-smoke','fire-flat','fire-stairs','alarm-auto','fire-rubbish'],
  questions:{
   see:{q:'Вы видите огонь или дым?',a:{'fire-flat':'Из окна третьего этажа идёт чёрный дым!','fire-smoke':'Из окна соседей идёт дым, немного.','fire-stairs':'Весь подъезд в дыму, мы не можем выйти!','alarm-auto':'Нет, только сирена сигнализации воет в торговом центре.','fire-rubbish':'Во дворе горит мусорный бак, дым в окна.'}},
   people:{q:'Внутри есть люди?',a:{'fire-flat':'Там живёт пожилой мужчина, не открывает.','fire-stairs':'На верхних этажах люди на балконах кричат.','fire-smoke':'Соседи вроде дома, не знаю.','alarm-auto':'Охрана выводит покупателей.','fire-rubbish':'Нет, это во дворе.'}}}},
 crash:{title:'Авария',opening:'Авария на перекрёстке, две машины столкнулись!',variants:['crash','rescue-crash'],
  questions:{
   trapped:{q:'Кто-то зажат в машине, не может выйти?',a:{'rescue-crash':'Да, водитель зажат, дверь смята, он стонет!','crash':'Нет, все вышли, ругаются.'}},
   injured:{q:'Есть пострадавшие?',a:{'rescue-crash':'Водитель в крови, не может пошевелить ногой.','crash':'У одной женщины болит шея, она сидит на обочине.'}}}},
 tree:{title:'Дерево упало',opening:'Ветром повалило дерево у дороги!',variants:['tree-down','storm-tree','power-lines'],
  questions:{
   wires:{q:'Дерево на проводах? Видите оборванные провода?',a:{'storm-tree':'Да, лежит на проводах, искрит!','power-lines':'Провод висит до земли, дерево рядом.','tree-down':'Нет, проводов нет, просто перегородило дорогу.'}}}},
 ice:{title:'Люди на льду',opening:'На заливе люди на льду, лёд трещит!',variants:['thin-ice','water-ice'],
  questions:{
   fell:{q:'Кто-то провалился под лёд?',a:{'water-ice':'Да! Один провалился, держится за край!','thin-ice':'Нет, но они далеко от берега и лёд тонкий.'}}}}
});
const groupOf=v=>Object.keys(GROUPS).find(g=>GROUPS[g].variants.includes(v))??null;
export const callGroup=i=>groupOf(i?.variant);
// Questions available for a call: its group's, or two general ones.
export const GENERAL=Object.freeze({injured:{q:'Есть пострадавшие?'},danger:{q:'Вам или кому-то угрожает опасность?'}});
export function questionsFor(i){const g=GROUPS[callGroup(i)];if(g)return Object.entries(g.questions).map(([id,x])=>({id,q:x.q}));return Object.entries(GENERAL).map(([id,x])=>({id,q:x.q}));}
export function answerFor(i,qid,ctx={}){const g=GROUPS[callGroup(i)];if(g){const x=g.questions[qid];return x?.a?.[i.variant]??x?.other??'Не знаю.';}
 const ag=rightService(i);if(qid==='injured')return ag==='ems'||ctx.injured?'Да, человеку плохо, нужна помощь врача.':ag==='rescue'?'Пока нет, но может быть опасно.':'Нет, вроде никто не ранен.';
 if(qid==='danger')return ['street-fight','fan-fight','domestic','restraining-order'].includes(i.variant)?'Да! Они дерутся, один с бутылкой.':ag==='rescue'?'Да, тут опасно подходить.':'Нет, сейчас нет.';return 'Не знаю.';}
export const openingFor=i=>GROUPS[callGroup(i)]?.opening??null;
export const callTitle=i=>GROUPS[callGroup(i)]?.title??'Входящий вызов 112';
// ── Instructions on the phone ────────────────────────────────────────────────────────────────────
export const INSTRUCTIONS=Object.freeze({
 cpr:{label:'Начните массаж сердца — я буду считать',useful:['ems-arrest'],line:'«Положите ладони на центр груди, давите сильно и часто — раз, два, три…»'},
 side:{label:'Положите на бок, следите за дыханием',useful:['ems-unconscious','ems-seizure','ems-drunk','drunk-person','ems-diabetic'],line:'«Поверните его на бок, голову чуть назад. Если перестанет дышать — сразу скажите».'},
 leave:{label:'Выйдите из квартиры, закройте дверь',useful:['fire-flat','fire-stairs','fire-smoke'],line:'«Не открывайте окна, выходите, закройте за собой дверь, ждите спасателей на улице».'},
 gas:{label:'Не включайте свет, откройте окна, выйдите',useful:['gas-smell'],line:'«Ничего не включайте и не выключайте, звонками не пользуйтесь, выходите на улицу».'},
 away:{label:'Отойдите в безопасное место, не вмешивайтесь',useful:['street-fight','fan-fight','domestic','restraining-order','alarm-burglary','phone-scam'],line:'«Не вмешивайтесь, отойдите, закройте дверь. Полиция едет».'},
 still:{label:'Не двигайте пострадавшего, держите тепло',useful:['crash','rescue-crash','ems-trauma','ems-fall','ems-ice-fall','ems-sport'],line:'«Не поднимайте его и не снимайте шлем, укройте курткой, мы уже едем».'}
});
export const usefulInstruction=i=>Object.keys(INSTRUCTIONS).find(k=>INSTRUCTIONS[k].useful.includes(i?.variant))??null;
// ── The desk ─────────────────────────────────────────────────────────────────────────────────────
export const DISPATCH_RANKS=Object.freeze(['Стажёр 112','Оператор 112','Старший оператор','Руководитель смены 112','Начальник центра']);
export const DISPATCH_PERMISSIONS=Object.freeze([
 {rank:0,title:'Стажёр 112',duty:'Принимает вызовы рядом с наставником'},
 {rank:1,title:'Оператор 112',duty:'Самостоятельно принимает вызовы и направляет службы'},
 {rank:2,title:'Старший оператор',duty:'Сложные вызовы и инструкции по телефону'},
 {rank:3,title:'Руководитель смены 112',duty:'Распределяет вызовы между операторами'},
 {rank:4,title:'Начальник центра',duty:'Все полномочия центра'}]);
export const COLLEAGUES=Object.freeze([{id:1,name:'Анна Сепп',skill:.9,f:true},{id:2,name:'Рауль Ойт',skill:.8}]);
// The city's crews the centre sends (ids from 2: there is no player crew in this campaign).
export const DISPATCH_FLEET=Object.freeze([
 {id:2,agency:'police',name:'Патруль 02',people:['Ирина Сокол','Март Кукк'],vehicle:'sedan',at:'centre'},
 {id:3,agency:'police',name:'Патруль 03',people:['Олег Ваганов','Кадри Мянд'],vehicle:'sedan',at:'ulejoe'},
 {id:4,agency:'police',name:'Патруль 04',people:['Пеэтер Лаас','Юлия Орлова'],vehicle:'suv',at:'papiniidu'},
 {id:5,agency:'rescue',name:'Спасатели 05',people:['Тарас Кульбок','Марек Таммик','Лийна Сепп','Андрес Пихл'],vehicle:'engine',at:'hq'},
 {id:6,agency:'rescue',name:'Цистерна 06',people:['Олег Савин','Кристо Ыун'],vehicle:'tanker',at:'hq'},
 {id:7,agency:'ems',name:'Скорая 07',people:['Мерле Таль','Андрей Кузнецов'],vehicle:'ambulance',at:'hospital'},
 {id:8,agency:'ems',name:'Скорая 08',people:['Ольга Лаур','Мартин Кесккюла'],vehicle:'ambulance',at:'hospital'},
 {id:9,agency:'ems',name:'Реанимобиль 09',people:['Хельги Рооп','Сергей Мельник','Кайди Пыдер'],vehicle:'resus',at:'hospital'}]);
export const FLEET_LOOK=Object.freeze({police:{paint:'white',lights:'redblue'},rescue:{paint:'red',lights:'blue'},ems:{paint:'ems',lights:'blue'}});
export function newDesk(){return {colleagues:COLLEAGUES.map(c=>({...c,call:null,until:0})),player:null,stats:{handled:0,service:0,priority:0,instructions:0,wrong:0,under:0,colleague:0},last:[]};}
// What a colleague decides (deterministic per call): skill decides service and priority; ambiguous calls are harder.
export function colleagueDecision(i,skill,types){const g=callGroup(i),right=rightService(i),pr=rightPriority(i,types),ok=hash(i.id,1)<skill-(g?.08:0);
 let service=right;if(!ok){const alts=g?[...new Set(GROUPS[g].variants.map(v=>v.startsWith('ems-')?'ems':['fire-flat','fire-stairs','alarm-auto','fire-rubbish','rescue-crash','storm-tree','water-ice'].includes(v)?'rescue':'police'))].filter(a=>a!==right):['police','rescue','ems'].filter(a=>a!==right);service=alts[Math.floor(hash(i.id,4)*alts.length)]??right;}
 const priority=hash(i.id,2)<skill?pr:ORDER[Math.min(3,ORDER.indexOf(pr)+1)];const instr=usefulInstruction(i)&&hash(i.id,3)<skill*.8?[usefulInstruction(i)]:[];return {service,priority,instr};}
export const colleagueMinutes=i=>DESK.colleagueMinutes[0]+hash(i.id,5)*(DESK.colleagueMinutes[1]-DESK.colleagueMinutes[0]);
// Grade of a routing decision (shown after the call).
export function gradeRoute(i,types){const c=i.call,right=rightService(i),pr=rightPriority(i,types),useful=usefulInstruction(i);
 const service=c.sent0===right,under=ORDER.indexOf(c.priority)>ORDER.indexOf(pr),exact=c.priority===pr,instr=!!useful&&c.instr.includes(useful);
 const xp=(service?12:0)+(exact?6:0)+(instr?8:0);
 const text=`${service?'Служба верная':'Не та служба: нужна '+SERVICES[right].toLowerCase()}, ${exact?'приоритет верный':under?`приоритет занижен (нужен ${pr})`:`приоритет завышен (хватило бы ${pr})`}${useful?(instr?', инструкция по телефону дана':', не хватило инструкции: «'+INSTRUCTIONS[useful].label+'»'):''}.`;
 return {service,under,exact,instr,xp,text};}
export function validCall(c){if(c===undefined)return true;const n=(x,a,b)=>Number.isFinite(x)&&x>=a&&x<=b;
 return !!c&&['ringing','talking','routed'].includes(c.status)&&n(c.at,0,1e6)&&(c.handler===undefined||['player','colleague'].includes(c.handler))&&Array.isArray(c.asked)&&c.asked.length<=6&&c.asked.every(q=>typeof q==='string'&&q.length<=20)&&Array.isArray(c.instr)&&c.instr.length<=3&&c.instr.every(k=>Object.hasOwn(INSTRUCTIONS,k))&&n(c.cost,0,600)
  &&(c.sent===undefined||Object.hasOwn(SERVICES,c.sent))&&(c.sent0===undefined||Object.hasOwn(SERVICES,c.sent0))&&(c.priority===undefined||ORDER.includes(c.priority))&&(c.release===undefined||n(c.release,0,1e6))&&(c.pick===undefined||!!c.pick&&typeof c.pick==='object'&&(c.pick.service===undefined||Object.hasOwn(SERVICES,c.pick.service))&&(c.pick.priority===undefined||ORDER.includes(c.pick.priority)))
  &&(c.grade===undefined||!!c.grade&&typeof c.grade.text==='string'&&c.grade.text.length<=300)&&(c.wrongTrip===undefined||c.wrongTrip===true)&&(c.colleague===undefined||Number.isInteger(c.colleague));}
export function validDesk(d){if(d===undefined)return true;const n=(x,a,b)=>Number.isFinite(x)&&x>=a&&x<=b;
 return !!d&&Array.isArray(d.colleagues)&&d.colleagues.length<=4&&d.colleagues.every(c=>c&&Number.isInteger(c.id)&&typeof c.name==='string'&&n(c.skill,0,1)&&(c.call===null||Number.isInteger(c.call))&&n(c.until,0,1e6))&&(d.player===null||Number.isInteger(d.player))
  &&!!d.stats&&['handled','service','priority','instructions','wrong','under','colleague'].every(k=>Number.isInteger(d.stats[k])&&d.stats[k]>=0)&&Array.isArray(d.last)&&d.last.length<=8&&d.last.every(x=>x&&Number.isInteger(x.id)&&typeof x.text==='string'&&x.text.length<=300);}
