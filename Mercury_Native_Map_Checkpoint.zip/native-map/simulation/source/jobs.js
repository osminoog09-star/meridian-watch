// Release Q1 «Профессии» (Claude, 17.10.2026). Owner 16.10: «быть полицейским, спасателем, водителем скорой; сменить
// работу». In real life an officer can leave for another emergency service: an application to the other employer,
// an interview and checks (fitness for rescuers, first aid for the ambulance, a calm head for the 112 centre), then the
// last shift at the old place and the first at the new one — from the bottom of the new ladder. The life stays the
// same: the person, the home, the money, the family, the skills; the experience counts toward skills, not a rank.
export const JOBS=Object.freeze({
 police:Object.freeze({label:'Полиция — патрульный',start:'младший констебль',needs:[{id:'fitness',min:55,text:'физподготовка от 55'},{id:'clean',text:'без дисциплинарных нарушений'}],about:'Патрульная служба префектуры: вызовы, задержания, ГБР и криминальная полиция дальше по карьере.'}),
 rescue:Object.freeze({label:'Спасательный департамент — спасатель',start:'спасатель',needs:[{id:'fitness',min:62,text:'физподготовка от 62'},{id:'stress',max:75,text:'стресс ниже 75'}],about:'Пожарная часть: пожары, ДТП с зажатыми, вода и лёд. Тяжёлая физическая работа.'}),
 ems:Object.freeze({label:'Скорая помощь — водитель / медтехник',start:'медтехник',needs:[{id:'course',course:'firstaid',text:'курс первой помощи'},{id:'stress',max:80,text:'стресс ниже 80'}],about:'Бригада скорой: водитель и помощь бригаде, дальше — медсестра и руководитель бригады.'}),
 taxi:Object.freeze({label:'Такси — водитель',start:'водитель такси',needs:[{id:'money',min:30,text:'карта обслуживающего лица из горуправы (30 €)'},{id:'stress',max:85,text:'стресс ниже 85'}],about:'Своя смена за рулём: заказы в приложении, пассажиры города, тариф и чаевые, рейтинг вместо званий. Без зарплаты — живёте с поездок.'}),
 dispatch:Object.freeze({label:'Центр 112 — оператор',start:'оператор',needs:[{id:'stress',max:65,text:'стресс ниже 65'},{id:'clean',text:'без дисциплинарных нарушений'}],about:'Пульт 112: опрос звонящих, инструкции до приезда, отправка служб.'})
});
export const JOB_IDS=Object.freeze(Object.keys(JOBS));
export const TRANSFER=Object.freeze({answer:2,cleanMonths:6});
// What is missing for the job (empty = the application can go).
export function jobChecks(s,id){const j=JOBS[id],l=s.life??{};if(!j)return [{ok:false,text:'Нет такой работы.'}];
 return j.needs.map(n=>{if(n.id==='fitness')return {ok:(l.fitness??0)>=n.min,text:`${n.text} (сейчас ${Math.round(l.fitness??0)})`};
  if(n.id==='stress')return {ok:(l.stress??0)<n.max,text:`${n.text} (сейчас ${Math.round(l.stress??0)})`};
  if(n.id==='course')return {ok:Number.isInteger(l.courses?.[n.course]),text:n.text};
  if(n.id==='money')return {ok:(l.money??0)>=n.min,text:`${n.text} (на счёте ${Math.round(l.money??0)} €)`};
  if(n.id==='clean')return {ok:l.breachMonth===undefined||(l.months??0)-l.breachMonth>=TRANSFER.cleanMonths,text:n.text};return {ok:true,text:n.text};});}
export function applyForJob(s,id){const l=s.life;if(s.mode!=='career'||!l)return {ok:false,message:'Сменить работу можно в карьере.'};const current=s.agency??'police';
 if(id===current)return {ok:false,message:'Вы уже здесь работаете.'};if(!JOBS[id])return {ok:false,message:'Нет такой работы.'};if(l.jobMove)return {ok:false,message:'Заявление уже подано.'};
 const miss=jobChecks(s,id).filter(x=>!x.ok);if(miss.length)return {ok:false,message:'Не подходите: '+miss.map(x=>x.text).join('; ')+'.'};
 l.jobMove={agency:id,ready:s.shift+TRANSFER.answer};return {ok:true,message:`Заявление подано: ${JOBS[id].label}. Собеседование и ответ — через ${TRANSFER.answer} смены.`};}
export function withdrawJob(s){if(!s.life?.jobMove)return {ok:false,message:'Заявления нет.'};s.life.jobMove=null;return {ok:true,message:'Заявление отозвано.'};}
export const validTransfer=l=>l?.jobMove===undefined||l.jobMove===null||(JOB_IDS.includes(l.jobMove.agency)&&Number.isInteger(l.jobMove.ready));
