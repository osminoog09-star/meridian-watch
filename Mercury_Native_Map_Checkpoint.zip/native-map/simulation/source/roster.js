// R5 «Табель начальника» (Claude, 11.10.2026): the chief's staff on the 12-hour PPA roster.
//   · Every officer has sleep debt and stress; night shifts tire more, days off restore.
//   · Leave: 35 days a year (PPA); a leave of one roster cycle (4 shifts) uses 8 calendar days
//     and needs the officer to be in reserve (not in a crew). Officers on leave cannot be hired
//     into patrols until they return.
//   · Night premium: Estonian Employment Contracts Act — night work (22:00–06:00) is paid ×1.25,
//     i.e. 8 of 12 hours of a night shift → wages ×(1 + 0.25·8/12).
// Pure rules; sim.js applies them in nextShift(). Scheduled chief campaigns only.
export const ROSTER=Object.freeze({nightSleep:25,daySleep:12,shortRest:-20,longRest:-60,stressPerShift:2,stressRestDays:-15,leaveShifts:4,leaveDays:8,yearDays:35,nightPremium:.25*8/12});
export function ensureOfficer(o){if(!Number.isFinite(o.sleepDebt))o.sleepDebt=0;if(!Number.isFinite(o.stress))o.stress=10;if(!Number.isFinite(o.leaveDays))o.leaveDays=ROSTER.yearDays;if(!Number.isInteger(o.leave))o.leave=0;if(!Number.isInteger(o.shiftsWorked))o.shiftsWorked=0;if(!Number.isInteger(o.nights))o.nights=0;return o;}
export const officerView=o=>({...o,sleepDebt:Number.isFinite(o.sleepDebt)?o.sleepDebt:0,stress:Number.isFinite(o.stress)?o.stress:10,leaveDays:Number.isFinite(o.leaveDays)?o.leaveDays:ROSTER.yearDays,leave:Number.isInteger(o.leave)?o.leave:0,shiftsWorked:o.shiftsWorked??0,nights:o.nights??0});
const clamp=v=>Math.max(0,Math.min(100,v));
// After a shift: who worked gets tired; everybody rests according to the gap before the next one.
export function rosterAfterShift(o,{worked,night,missed=0,restHours}){ensureOfficer(o);
 if(o.leave>0){o.leave--;o.sleepDebt=0;o.stress=clamp(o.stress-40);return;}
 if(worked){o.shiftsWorked++;if(night)o.nights++;o.sleepDebt=clamp(o.sleepDebt+(night?ROSTER.nightSleep:ROSTER.daySleep));o.stress=clamp(o.stress+ROSTER.stressPerShift+missed);}
 o.sleepDebt=clamp(o.sleepDebt+(restHours>=72?ROSTER.longRest:restHours>=24?ROSTER.longRest/2:ROSTER.shortRest));if(restHours>=72)o.stress=clamp(o.stress+ROSTER.stressRestDays);}
export const startFatigueOf=o=>Math.round(Math.min(60,(o.sleepDebt??0)*.5+Math.max(0,(o.stress??0)-60)*.3));
export const wagesFactor=night=>night?1+ROSTER.nightPremium:1;
export function canTakeLeave(s,o){ensureOfficer(o);if(o.leave>0)return 'Уже в отпуске.';if(o.leaveDays<ROSTER.leaveDays)return `Осталось ${o.leaveDays} дн. отпуска.`;if(s.units.some(u=>u.officerIds.includes(o.id)))return 'Сначала выведите сотрудника в резерв.';return null;}
export function validOfficerRoster(o){const n=(x,a,b)=>x===undefined||Number.isFinite(x)&&x>=a&&x<=b;const i=(x,a,b)=>x===undefined||Number.isInteger(x)&&x>=a&&x<=b;
 return n(o.sleepDebt,0,100)&&n(o.stress,0,100)&&n(o.leaveDays,0,ROSTER.yearDays)&&i(o.leave,0,ROSTER.leaveShifts)&&i(o.shiftsWorked,0,1e6)&&i(o.nights,0,1e6);}
