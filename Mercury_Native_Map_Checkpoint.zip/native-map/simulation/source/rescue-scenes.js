// Release H «Спасатели» (Claude, 12.10.2026): the work on scene of a rescue call in three steps, in the
// same format as the police scenes (dialogues.js): разведка и тактика → работа → завершение.
// The first step chooses the tactic (maps to the call decision: attack / defend / extricate / …);
// later steps change the fire model through `sets` (rescue.js reads hydrant, vent, ladder) and the
// ambulance call. Facts: rescueFacts() (merged into factsFor in dialogues.js).
const O=(id,label,hint,fx={},more={})=>({id,label,hint,fx,...more});
const finish=[
 O('check','Проверить скрытые очаги тепловизором','надёжно',{evidence:20,trust:.5},{rec:true,soft:true,line:'Скрытых очагов нет, место передано хозяевам.'}),
 O('quick','Свернуться и вернуться в часть','быстрее, но может разгореться',{pace:1.15,followUp:1.6},{line:'Свернулись быстро.'})];
export const RESCUE_SCRIPTS=Object.freeze({
 'fire-flat':[
  {stage:'approach',title:'Разведка',text:'Дым из окна третьего этажа. Соседи на улице: «Там пожилой мужчина, он курит в постели».',options:[
   O('attack','Звено в дыхательных аппаратах — внутрь, тушить и искать людей','если внутри люди',{pace:1,risk:.12},{maps:'attack',rec:true,line:f=>f.trapped?`Внутри ${f.trapped===1?'человек':f.trapped+' человека'} — звено заходит.`:'Звено заходит, людей пока не видно.',setsIf:f=>f.trapped?{ambulance:true}:null}),
   O('defend','Тушить снаружи, защищать соседей','безопасно, но людей внутри не спасти',{pace:.9},{maps:'defend',line:'Подаём воду в окно, держим соседние квартиры.'})]},
  {stage:'inquiry',title:'Работа',text:'Огонь в комнате, дым заполнил квартиру.',options:[
   O('hydrant','Сразу проложить линию от гидранта','вода без перерыва',{evidence:10},{rec:true,line:f=>f.hydrant?'Гидрант у подъезда — линия будет через пару минут.':'Ближайший гидрант далеко — ждём цистерну.',setsIf:f=>f.hydrant?{hydrant:'fast'}:null}),
   O('vent','Вентилятор в дверь, открыть окно','быстрее тушить и искать, но огонь получит воздух',{tension:5},{line:'Дым уходит, видимость лучше.',sets:{vent:true}}),
   O('ladder','Автолестница к окну','если кто-то у окна',{evidence:5},{line:f=>f.trapped?'Человека снимают с балкона лестницей.':'У окон никого нет.',setsIf:f=>f.trapped?{ladder:true}:null})]},
  {stage:'decision',title:'Завершение',text:'Пламя сбито.',options:[...finish,O('police','Установить причину, передать полиции','по правилам',{evidence:10},{line:f=>f.smoking?'Причина — сигарета в постели. Сведения переданы полиции.':'Причина — проводка. Сведения переданы полиции.'})]}],
 'fire-stairs':[
  {stage:'approach',title:'Разведка',text:'Подъезд в дыму, на балконах верхних этажей кричат жильцы.',options:[
   O('attack','Звено внутрь — к очагу и по этажам','люди наверху',{risk:.15},{maps:'attack',rec:true,line:f=>`Наверху ${f.trapped} человек — идём по этажам.`,setsIf:f=>f.trapped?{ambulance:true}:null}),
   O('defend','Тушить очаг снизу, жильцам не выходить','дым не пойдёт выше',{pace:.9},{maps:'defend',line:'Жильцам велено закрыть двери и ждать.'})]},
  {stage:'inquiry',title:'Работа',text:'Горит хлам в подвале, дым по лестнице вверх.',options:[
   O('vent','Открыть люк на крыше','дым уйдёт вверх',{},{rec:true,line:'Лестница очищается от дыма.',sets:{vent:true}}),
   O('ladder','Снимать людей с балконов лестницей','медленно, но наверняка',{},{line:'Лестница у балкона, первых снимают.',sets:{ladder:true}})]},
  {stage:'decision',title:'Завершение',text:'Очаг потушен.',options:finish}],
 'fire-chimney':[
  {stage:'approach',title:'Разведка',text:'Из трубы летят искры, на чердаке пахнет гарью.',options:[
   O('attack','Тушить дымоход сверху и проверить чердак','правильно',{},{maps:'attack',rec:true,line:'Поднимаемся на крышу.'}),
   O('defend','Залить чердак снаружи','быстро, но промочим дом',{pace:1.1,complaint:1.3},{maps:'defend',line:'Чердак проливаем водой.'})]},
  {stage:'inquiry',title:'Работа',text:'Сажа горит в трубе.',options:[
   O('dry','Сбить сажу, не лить воду в горячую трубу','труба не треснет',{evidence:10},{rec:true,line:'Труба цела.'}),
   O('water','Залить водой','быстрее, но труба может треснуть',{pace:1.15,followUp:1.3},{line:'Пар, труба треснула — хозяину нужен печник.'})]},
  {stage:'decision',title:'Завершение',text:'Огонь в трубе погас.',options:[O('advice','Рассказать о трубочисте и датчике дыма','профилактика',{trust:1},{rec:true,soft:true,line:'Хозяин обещает вызвать трубочиста.'}),...finish]}],
 'rescue-crash':[
  {stage:'approach',title:'Разведка',text:'Машина на боку, водитель зажат, течёт бензин.',options:[
   O('extricate','Обезопасить и сразу деблокировать','водитель в сознании?',{risk:.06},{maps:'extricate',rec:true,line:f=>f.conscious?'Водитель в сознании, жалуется на ногу.':'Водитель без сознания — счёт на минуты.'}),
   O('secure','Обезопасить место и ждать скорую','если спешить опасно',{pace:.85},{maps:'secure',line:'Место ограждено, бензин засыпан сорбентом.'})]},
  {stage:'inquiry',title:'Работа',text:'Двери заклинило.',options:[
   O('roof','Снять крышу гидравликой','больше места, бережнее для шеи',{evidence:10,pace:.9},{rec:true,line:'Крыша снята, медики работают с водителем.',sets:{ambulance:true}}),
   O('door','Вскрыть дверь','быстрее',{pace:1.15},{line:'Дверь вскрыта.',sets:{ambulance:true}})]},
  {stage:'decision',title:'Завершение',text:'Водитель передан скорой.',options:[O('road','Убрать стекло и бензин с дороги','безопасность',{trust:.5},{rec:true,soft:true,line:'Дорога очищена, полиция открывает движение.'}),...finish.slice(1)]}],
 'rescue-door':[
  {stage:'approach',title:'У двери',text:'Пожилой человек не отвечает, скорая ждёт у двери.',options:[
   O('extricate','Вскрыть замок','быстро',{},{maps:'extricate',rec:true,line:'Замок вскрыт за минуту.',sets:{ambulance:true}}),
   O('secure','Через балкон соседей','без повреждения двери, дольше',{pace:.8,trust:.5},{maps:'secure',line:'Заходим через балкон.',sets:{ambulance:true}})]},
  {stage:'inquiry',title:'Внутри',text:'Человек лежит на полу, дышит.',options:[O('help','Помочь медикам, вынести на носилках','',{evidence:10},{rec:true,soft:true,line:'Человек передан медикам.'})]},
  {stage:'decision',title:'Завершение',text:'Квартира открыта.',options:[O('lock','Закрыть квартиру и передать ключ родственникам','по правилам',{trust:1},{rec:true,soft:true,line:'Ключ передан дочери.'})]}],
 'alarm-auto':[
  {stage:'approach',title:'Разведка',text:'Сирена в торговом центре, люди выходят.',options:[
   O('check','Найти сработавший датчик','по правилам',{},{maps:'check',rec:true,line:f=>f.falseAlarm?'Сработал датчик на кухне кафе — пригорело.':'В техническом помещении дым!'}),
   O('evacuate','Полная эвакуация','надёжно, но долго',{pace:.8},{maps:'evacuate',line:'Здание эвакуируют.'})]},
  {stage:'inquiry',title:'Проверка',text:'Нужно убедиться, что огня нет.',options:[O('panel','Проверить пульт и камеры','',{evidence:20},{rec:true,line:'Пульт показывает одну зону.'})]},
  {stage:'decision',title:'Завершение',text:'Сигнализацию сбросили.',options:[O('report','Акт о срабатывании, совет владельцу','',{trust:.5},{rec:true,soft:true,line:'Владельцу выписано предписание проверить датчики.'})]}],
 'gas-smell':[
  {stage:'approach',title:'Разведка',text:'В подъезде сильно пахнет газом.',options:[
   O('evacuate','Эвакуировать подъезд, звонки не трогать','если утечка',{pace:.9},{maps:'evacuate',rec:true,line:'Жильцов выводят, свет не включаем.'}),
   O('check','Сразу замерить газоанализатором','быстрее',{risk:.08},{maps:'check',line:f=>f.gasLeak?'Концентрация высокая!':'Прибор показывает норму у двери.'})]},
  {stage:'inquiry',title:'Источник',text:'Запах сильнее у квартиры на втором этаже.',options:[O('valve','Перекрыть газ на стояке, проветрить','',{evidence:20},{rec:true,line:f=>f.gasLeak?'Утечка в плите, газ перекрыт.':'Утечки нет — запах из подвала.'})]},
  {stage:'decision',title:'Завершение',text:'Опасности нет.',options:[O('gasco','Передать газовой службе','по правилам',{trust:.5},{rec:true,soft:true,line:'Газовщики проверят стояк.'})]}]
});
// Generic three steps for the other rescue calls of each type (6 fire, 7 rescue, 8 water, 9 danger).
export const RESCUE_TYPE_SCRIPTS=Object.freeze({
 6:[{stage:'approach',title:'Разведка',text:'Огонь на открытом месте, рядом постройки.',options:[O('attack','Атаковать огонь стволами','быстро',{},{maps:'attack',rec:true,line:'Стволы поданы.'}),O('defend','Защитить постройки, огонь пусть догорит на открытом','медленнее',{pace:.85},{maps:'defend',line:'Защищаем сараи.'})]},
  {stage:'inquiry',title:'Работа',text:'Нужна вода.',options:[O('hydrant','Линия от гидранта','если рядом',{},{rec:true,line:f=>f.hydrant?'Гидрант рядом.':'Гидранта нет — работаем от цистерны.',setsIf:f=>f.hydrant?{hydrant:'fast'}:null}),O('tank','Работать от цистерны','',{pace:1.05},{line:'Вода из цистерны.'})]},
  {stage:'decision',title:'Завершение',text:'Огонь потушен.',options:finish}],
 7:[{stage:'approach',title:'Разведка',text:'Человеку или животному нужна помощь спасателей.',options:[O('extricate','Сразу освобождать','',{},{maps:'extricate',rec:true,line:'Работаем.'}),O('secure','Обезопасить и подготовиться','надёжнее',{pace:.85},{maps:'secure',line:'Место обезопасили.'})]},
  {stage:'inquiry',title:'Работа',text:'Нужен инструмент.',options:[O('tools','Верёвки, страховка, инструмент','по правилам',{evidence:15},{rec:true,line:'Страховка закреплена.'})]},
  {stage:'decision',title:'Завершение',text:'Работа выполнена.',options:[O('handover','Передать людей близким или скорой','',{trust:.5},{rec:true,soft:true,line:'Передали близким.'})]}],
 8:[{stage:'approach',title:'Разведка',text:'Человек в воде, счёт на минуты.',options:[O('ice','Спасатель в гидрокостюме с верёвкой','быстрее',{risk:.08},{maps:'ice',rec:true,line:'Спасатель идёт к человеку.',sets:{ambulance:true}}),O('reach','Подать конец или шест с берега','безопаснее, дольше',{pace:.85},{maps:'reach',line:'Бросаем конец.',sets:{ambulance:true}})]},
  {stage:'inquiry',title:'Работа',text:'Человек замёрз и слабеет.',options:[O('warm','Согреть, следить за дыханием до скорой','',{evidence:10},{rec:true,soft:true,line:'Укутали в одеяло, медики близко.'})]},
  {stage:'decision',title:'Завершение',text:'Человек на берегу.',options:[O('handover','Передать скорой','',{trust:1},{rec:true,soft:true,line:'Передан скорой.'})]}],
 9:[{stage:'approach',title:'Разведка',text:'Нужно проверить опасность.',options:[O('check','Проверить и обезопасить','',{},{maps:'check',rec:true,line:'Проверяем.'}),O('evacuate','Сначала вывести людей','',{pace:.85},{maps:'evacuate',line:'Людей вывели.'})]},
  {stage:'inquiry',title:'Работа',text:'Источник опасности найден.',options:[O('fix','Устранить: пила, перекрытие, ограждение','',{evidence:15},{rec:true,line:'Опасность устранена.'})]},
  {stage:'decision',title:'Завершение',text:'Место безопасно.',options:[O('report','Отчёт и передача ответственным службам','',{trust:.5},{rec:true,soft:true,line:'Передано ответственным.'})]}]
});
