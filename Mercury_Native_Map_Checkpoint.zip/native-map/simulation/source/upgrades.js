// R10 «Развитие отделения» (Claude, 11.10.2026): the chief invests in equipment and facilities that
// real police departments buy, each with one clear effect in the game. One-time price plus a small
// upkeep per shift for licensed/serviced items. Chief mode only.
export const UPGRADES=Object.freeze({
 bodycam:{label:'Нагрудные камеры',price:1500,upkeep:15,about:'Записи с камер: жалоб на сотрудников в 2,5 раза меньше, проверки по жалобам чаще заканчиваются в пользу полиции.'},
 tablets:{label:'Планшеты в машинах',price:1200,upkeep:20,about:'Карточка вызова и маршрут сразу в машине: вызов ждёт дольше, прежде чем сорваться (+15% времени).'},
 drone:{label:'Дрон отделения',price:2000,upkeep:25,about:'Поиск пропавших у всех экипажей на 30% быстрее.'},
 breath:{label:'Алкотестеры во все машины',price:600,upkeep:0,about:'Пьяные водители и люди в опьянении — работа у всех экипажей на 10% быстрее.'},
 restroom:{label:'Комната отдыха в участке',price:900,upkeep:5,about:'Сотрудники отдыхают в участке в 1,7 раза быстрее.'},
 training:{label:'Программа обучения',price:800,upkeep:10,about:'После каждой смены навык всех сотрудников +1% (до 95%).'},
 workshop:{label:'Мастерская в участке',price:1400,upkeep:10,about:'Ремонт на 35% дешевле и на 40% быстрее; между сменами механик обслуживает машины (износ снижается).'}
});
export const UPGRADE_IDS=Object.freeze(Object.keys(UPGRADES));
export const has=(s,id)=>s?.mode==='chief'&&Array.isArray(s.upgrades)&&s.upgrades.includes(id);
export const upgradesUpkeep=s=>s?.mode==='chief'?(s.upgrades??[]).reduce((n,id)=>n+(UPGRADES[id]?.upkeep??0),0):0;
export const UPGRADE_EFFECT=Object.freeze({complaints:.4,limit:1.15,search:1.3,drunk:1.1,rest:.7,skill:.01,skillCap:.95});
export function upgradeBonus(s,variant,type){let b=1;if(has(s,'drone')&&type===2)b*=UPGRADE_EFFECT.search;if(has(s,'breath')&&['drunk-driver','drunk-person'].includes(variant))b*=UPGRADE_EFFECT.drunk;return b;}
export const validUpgrades=s=>s.upgrades===undefined||Array.isArray(s.upgrades)&&s.upgrades.length<=UPGRADE_IDS.length&&new Set(s.upgrades).size===s.upgrades.length&&s.upgrades.every(id=>Object.hasOwn(UPGRADES,id));

// R12 «Внутренний контроль» (Claude, 11.10.2026): citizens can complain about an arrest or a failed
// call; complaints are reviewed after the shift (Estonia: PPA internal control, Sisekontroll).
// Stress and a strict standing order make complaints likelier; body cameras make them rarer and help
// the review. Deterministic by call id (no rng). Roster campaigns only.
export const COMPLAINTS=Object.freeze({arrest:.04,failed:.05,stress:.1,strict:.05,limit:10,foundedTrust:2,foundedDistrict:3,foundedStress:10,foundedXp:30,clearedBase:.8,clearedCam:.95});
const hash=(a,b)=>{let h=Math.imul((a|0)+211,2654435761)^Math.imul((b|0)+5,1597334677);h^=h>>>16;h=Math.imul(h,2246822519);return ((h^h>>>13)>>>0)/4294967296;};
export function complaintChance({arrest=false,failed=false,stress=0,strict=false,bodycam=false}){let c=(arrest?COMPLAINTS.arrest:0)+(failed?COMPLAINTS.failed:0);if(!c)return 0;if(stress>60)c+=COMPLAINTS.stress;if(strict)c+=COMPLAINTS.strict;if(bodycam)c*=UPGRADE_EFFECT.complaints;return Math.min(.5,c);}
export const complaintRolled=(seed,incidentId,chance)=>hash(incidentId,(seed|0)*3+1)<chance;
export const complaintCleared=(seed,incidentId,bodycam)=>hash(incidentId,(seed|0)*3+2)<(bodycam?COMPLAINTS.clearedCam:COMPLAINTS.clearedBase);
export const COMPLAINT_REASONS=Object.freeze({arrest:'Жалоба на задержание: «превышение полномочий»',failed:'Жалоба: «полиция не приехала вовремя»'});
export const validComplaints=s=>s.complaints===undefined||Array.isArray(s.complaints)&&s.complaints.length<=COMPLAINTS.limit&&s.complaints.every(c=>c&&Number.isInteger(c.incident)&&Number.isInteger(c.unit)&&typeof c.reason==='string'&&c.reason.length<=120&&['проверка','обоснована','не подтвердилась'].includes(c.status)&&(c.district===undefined||typeof c.district==='string'));
