// Game response policy, not an assertion of legal privileges on real roads.
// Claude (12.10.2026): rescue and ambulance crews drive with lights to fires, rescues, water, cardiac arrests,
// time-critical illness and injuries (types 6–8, 10–12); a call sent by the 112 desk follows its priority (A/B).
export function urgentIncident(state,id){const incident=state?.incidents?.find(i=>i.id===id);if(!incident)return false;if(incident.call?.priority)return ['A','B'].includes(incident.call.priority);return [1,2,4,6,7,8,10,11,12].includes(incident.type);}
export function urgentMovement(state,unit){return unit?.pursuing===true||unit?.status==='responding'&&urgentIncident(state,unit.incident);}
