// Game response policy, not an assertion of legal privileges on real roads.
export function urgentIncident(state,id){const incident=state?.incidents?.find(i=>i.id===id);return !!incident&&[1,2,4].includes(incident.type);}
export function urgentMovement(state,unit){return unit?.pursuing===true||unit?.status==='responding'&&urgentIncident(state,unit.incident);}
