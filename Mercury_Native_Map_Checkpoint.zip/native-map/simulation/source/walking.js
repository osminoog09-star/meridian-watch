import network from './walking-network.js';
export {network};
export const walkingNodes=new Map(Object.entries(network.nodes).map(([id,[x,y]])=>[id,{id,x,y}]));
const edges=new Map([...walkingNodes.keys()].map(id=>[id,[]]));
for(const s of network.segments){const a=walkingNodes.get(s.a),b=walkingNodes.get(s.b),length=Math.hypot(a.x-b.x,a.y-b.y);edges.get(a.id).push({id:b.id,length});edges.get(b.id).push({id:a.id,length});}
export function walkingRoute(start,end){if(!edges.has(start)||!edges.has(end))return [];const distance=new Map([[start,0]]),previous=new Map(),open=new Set([start]);while(open.size){let id=null;for(const n of open)if(id===null||distance.get(n)<distance.get(id))id=n;open.delete(id);if(id===end){const route=[end];while(route[0]!==start)route.unshift(previous.get(route[0]));return route.map(n=>walkingNodes.get(n));}for(const next of edges.get(id)){const d=distance.get(id)+next.length;if(d<(distance.get(next.id)??Infinity)){distance.set(next.id,d);previous.set(next.id,id);open.add(next.id);}}}return [];}
export function nearestWalking({x,y}){let best=null,d=Infinity;for(const n of walkingNodes.values()){const v=Math.hypot(x-n.x,y-n.y);if(v<d){best=n;d=v;}}return best;}
export const walkingCentre=nearestWalking({x:1.54,y:2.665});
