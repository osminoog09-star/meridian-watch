// Release A «Живой город» — Claude's part: people around a call (Claude, 12.10.2026).
// A crash, a fight or smoke from a window draws passers-by: they gather over the first minutes, keep a few
// metres away, some film on their phones, and when the crew cordons the place off they step back. A
// witness from the crowd comes up to the crew while the officers ask questions. How many come depends on
// the call, the hour, the weather and city events (a match or a concert brings more people onto the
// streets). Pure presentation: derived from the call each frame, nothing is stored in the campaign, so
// old saves and the native (Godot/QuickJS) port can use it as is.
import {MAP_METRES} from './world-scale.js';
import {WORLD_SECONDS_PER_TICK_SECOND} from './transport.js';
import {factsFor} from './dialogues.js';
import {inBuilding} from './acoustics.js';
export const ONLOOKERS=Object.freeze({max:9,gatherMinutes:8,ring:[10,22],cordon:[20,30],witnessMetres:4});
// Base crowd by call: variant first, then call type (1 road, 2 search, 3 public order, 4 home, 5 vehicle).
const BY_VARIANT=Object.freeze({'fire-smoke':7,'fan-fight':8,'street-fight':6,crash:5,'tree-down':3,'power-lines':3,'noise-venue':3,'yard-company':2,'lost-at-concert':3,shoplift:3,'drunk-person':3,'animal-road':2,'thin-ice':5,'car-break':2,domestic:1,'noise-flat':1});
const BY_TYPE=Object.freeze({1:4,2:1,3:3,4:1,5:0});
const hash=(a,b)=>{let h=Math.imul((a|0)+977,2654435761)^Math.imul((b|0)+31,1597334677);h^=h>>>15;h=Math.imul(h,2246822519);return ((h^h>>>13)>>>0)/4294967296;};
// Share of people on the street at this hour / in this weather / on an event day.
export function streetFactor(minute,weather,event){const m=((Number.isFinite(minute)?minute:720)%1440+1440)%1440,h=m/60;
 const hour=h<5?.25:h<7?.45:h<10?.8:h<18?1:h<22?1.1:.55,w=weather==='rain'?.5:weather==='snow'?.6:weather==='wind'?.6:weather==='heat'?1.15:weather==='fog'?.8:1,e=event==='football'||event==='concert'?1.6:event==='storm'?.6:1;
 return hour*w*e;}
export function crowdSize(i,ctx={}){if(!i||['resolved','missed'].includes(i.state))return 0;const base=BY_VARIANT[i.variant]??BY_TYPE[i.type]??2;if(!base)return 0;
 const n=Math.round(base*streetFactor(ctx.minute,ctx.weather,ctx.event)*(.75+hash(i.id,1)*.5));return Math.max(0,Math.min(ONLOOKERS.max,n));}
// People around the call: [{id,x,y,role:'onlooker'|'filming'|'witness',facing}], world coordinates.
export function onlookersFor(i,ctx={}){const total=crowdSize(i,ctx);if(!total||!Number.isFinite(i.x)||!Number.isFinite(i.y))return [];
 const worldMinutes=(i.age??0)*WORLD_SECONDS_PER_TICK_SECOND/60,shown=Math.min(total,Math.ceil(total*Math.min(1,worldMinutes/ONLOOKERS.gatherMinutes))),cordon=i.decision==='secure'||i.scene?.phase==='inspection',[r0,r1]=cordon?ONLOOKERS.cordon:ONLOOKERS.ring;
 const night=((ctx.minute??720)%1440)<6*60||((ctx.minute??720)%1440)>=21*60,witness=!!i.talk&&(i.talk.stage??0)>=1&&factsFor(i).witness,out=[];
 for(let k=0;k<shown;k++){let a=hash(i.id,k+10)*Math.PI*2,d=(r0+(r1-r0)*hash(i.id,k+40))/MAP_METRES,x=i.x+Math.cos(a)*d,y=i.y+Math.sin(a)*d;for(let n=1;n<8&&inBuilding(x,y);n++){a+=.8;x=i.x+Math.cos(a)*d;y=i.y+Math.sin(a)*d;}/* stand outside the buildings */let role=hash(i.id,k+70)<(night?.45:.3)?'filming':'onlooker';
  if(witness&&k===0){const b=a+.4;x=i.x+Math.cos(b)*ONLOOKERS.witnessMetres/MAP_METRES;y=i.y+Math.sin(b)*ONLOOKERS.witnessMetres/MAP_METRES;role='witness';}
  out.push({id:`${i.id}-o${k}`,x,y,role,facing:Math.atan2(i.y-y,i.x-x)});}
 return out;}
// The crowd near a point (for the murmur): people within `metres`, weighted by closeness.
export function crowdNear(incidents,p,ctx={},metres=60){if(!p||!Number.isFinite(p.x))return 0;let v=0;for(const i of incidents??[]){if(!Number.isFinite(i?.x))continue;const d=Math.hypot(i.x-p.x,i.y-p.y)*MAP_METRES;if(d>metres)continue;v+=onlookersFor(i,ctx).length*(1-d/metres);}return v;}
