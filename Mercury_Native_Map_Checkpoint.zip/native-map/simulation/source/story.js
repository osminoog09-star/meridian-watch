// Release T1 «Люди отдела» (Claude, 17.10.2026). Roadmap (owner 16.10: «сюжет: наставник, соперник, итоги года»).
// The career gets people who stay: the mentor of the first months and a classmate from the academy who serves in the
// next shift and wants the next rank first. Scenes come at fixed points of the career (one every 5–10 shifts) through
// the same «situation» card as the life events: two or three answers, each with an effect on the hero and on the
// relationship. The answers are remembered; the personal file shows the people, how things stand with them and the
// story so far. Names are fictional. Deterministic: the rival is picked by the seed; no rng.
import {mentorOf,PARTNERS} from './partner.js';
const RIVALS=Object.freeze({
 police:['Маркус Тальвик','Ева Кальюранд','Артур Рейнсалу','Лийна Пяхкель'],
 rescue:['Кевин Ымблус','Хелен Тамме','Сийм Ваарик','Анна Лепик'],
 ems:['Кристель Ниргисто','Олег Савчук','Мария Таммисте','Роберт Ялаканн'],
 dispatch:['Кайре Сильдвеэ','Игорь Белов','Мерилин Ыунап','Тарво Кийск']
});
const pick=(list,seed)=>{let h=Math.imul((seed|0)+911,2654435761);h^=h>>>15;return list[(h>>>0)%list.length];};
export const rivalName=(seed,agency)=>pick((RIVALS[agency]??RIVALS.police).filter(n=>!PARTNERS.some(p=>p.name===n)),seed);
export const mentorName=life=>mentorOf(life).name;
export const PEOPLE=Object.freeze({start:{rival:50,mentor:60},limit:12});
// An unanswered scene takes options[2] (or options[0] of two), like the life events: the order keeps that default calm.
export const STORY_EVENTS=Object.freeze({
 'story-rival':{shift:4,title:'Однокурсник',text:'На построении соседней смены — {rival}, вы вместе учились в академии. Громко, на весь коридор: «Ну что, кто первым получит следующее звание?»',options:[
  {id:'bet',label:'Поспорить на ужин',fx:{rival:5,xp:10,stress:-2},hint:'спор так спор'},
  {id:'laugh',label:'Посмеяться: «Посмотрим»',fx:{rival:10,stress:-3}},
  {id:'quiet',label:'Промолчать',fx:{rival:-5}}]},
 'story-swap':{shift:10,title:'Подменить в ночь',text:'{rival} просит подменить в ночь на субботу: у ребёнка день рождения, больше некого.',options:[
  {id:'no',label:'Отказать: самому нужен отдых',fx:{rival:-10,stress:-2}},
  {id:'swap',label:'Подменить',fx:{rival:20,sleep:20,stress:4,money:150},hint:'ночь вне графика оплачивается'}]},
 'story-mentor':{shift:16,title:'Совет наставника',text:'{mentor} звонит после смены: «Прочитал твой рапорт по последней драке. Есть пара мыслей — хочешь?»',options:[
  {id:'later',label:'«Давай в другой раз»',fx:{mentor:-5}},
  {id:'listen',label:'Послушать',fx:{mentor:10,xp:40,stress:-4},hint:'разбор с опытным коллегой'}]},
 'story-credit':{shift:22,title:'Чужая заслуга',text:'В сводке за месяц задержание на Ремесленной записано на {rival}, хотя работал ваш экипаж.',options:[
  {id:'report',label:'Написать руководителю смены',fx:{rival:-25,xp:30,stress:2},hint:'по правилам, но отношения испортятся'},
  {id:'talk',label:'Поговорить с {rival} с глазу на глаз',fx:{rival:10,xp:15,stress:-2}},
  {id:'let',label:'Махнуть рукой',fx:{rival:5,stress:6}}]},
 'story-car':{shift:30,title:'Ключи от машины',text:'После корпоратива {rival} садится за руль. Видно, что выпил.',options:[
  {id:'keys',label:'Забрать ключи и отвезти домой',fx:{rival:15,sleep:6,mentor:5},hint:'по-человечески и по закону'},
  {id:'report',label:'Сообщить дежурному',fx:{rival:-30,xp:40},hint:'его остановит патруль'},
  {id:'taxi',label:'Вызвать такси за свой счёт',fx:{rival:5,money:-15}},
  {id:'ignore',label:'Не моё дело',fx:{integrity:true,rival:2},hint:'промолчать о пьяном водителе — нарушение'}]},
 'story-retire':{shift:40,title:'Наставник уходит',text:'{mentor} уходит на пенсию. В пятницу — прощальный вечер в участке, будет вся смена.',options:[
  {id:'speech',label:'Сказать тост',fx:{mentor:15,stress:-10,money:-20},hint:'он это запомнит'},
  {id:'gift',label:'Скинуться на подарок и прийти',fx:{mentor:8,stress:-6,money:-30}},
  {id:'sleep',label:'Не пойти: нужно выспаться',fx:{mentor:-10,sleep:-10}}]},
 'story-pair':{shift:48,title:'Одна пара',text:'Из-за болезней вас с {rival} ставят в одну пару на ночную смену.',options:[
  {id:'lead',label:'Взять старшинство на себя',fx:{rival:-5,xp:30,stress:3}},
  {id:'equal',label:'Работать на равных',fx:{rival:12,xp:20,stress:-2}}]},
 'story-letter':{shift:60,title:'Письмо от наставника',text:'Открытка от {mentor}: «Слышал, как ты работаешь. Не торопись со званиями — торопись с людьми». И номер телефона: «Звони, если что».',options:[
  {id:'call',label:'Позвонить и поблагодарить',fx:{mentor:10,stress:-8}},
  {id:'keep',label:'Убрать открытку в шкафчик',fx:{stress:-3}}]},
 'story-year':{shift:72,title:'Год службы',text:'Год назад вы пришли в участок. {rival} подходит с кофе: «Ну что, кто кого?» — и впервые без подколки.',options:[
  {id:'toast',label:'«Ничья. Пойдём поужинаем»',fx:{rival:15,stress:-8,money:-25}},
  {id:'score',label:'Сравнить звания и вызовы',fx:{rival:-5,xp:20}}]}
});
export const STORY_IDS=Object.freeze(Object.keys(STORY_EVENTS));
const BEAT_AT=new Map(STORY_IDS.map(id=>[STORY_EVENTS[id].shift,id]));
// The scene due on this shift (the career's shift counter), or null.
export function storyBeat(s){const l=s.life;if(s.mode!=='career'||!l)return null;const id=BEAT_AT.get(s.shift);if(!id||(l.people?.log??[]).some(e=>e.id===id))return null;return id;}
export function ensurePeople(life){if(!life)return null;if(!life.people||typeof life.people!=='object')life.people={rival:PEOPLE.start.rival,mentor:PEOPLE.start.mentor,log:[]};return life.people;}
const clamp=v=>Math.max(0,Math.min(100,Math.round(v)));
// The answer: relationships move, the scene goes into the story log.
export function storyAnswer(life,id,choice,shift,fx){const p=ensurePeople(life);if(fx.rival)p.rival=clamp(p.rival+fx.rival);if(fx.mentor)p.mentor=clamp(p.mentor+fx.mentor);
 p.log=[...p.log.filter(e=>e.id!==id),{id,choice,shift}].slice(-PEOPLE.limit);}
export function storyText(str,s){return String(str).replaceAll('{rival}',rivalName(s.seed,s.life?.agency??s.agency)).replaceAll('{mentor}',mentorName(s.life));}
// How the hero stands with a person, in words.
export const standing=v=>v>=80?'близкие люди':v>=60?'хорошие отношения':v>=40?'ровно':v>=20?'холодно':'в ссоре';
// The rival's own career: by the hero's rank and the relationship — a rival who is helped tends to keep pace.
export function rivalRank(s){const r=s.rank??0,p=s.life?.people?.rival??50,h=(Math.imul((s.seed|0)+5,2246822519)>>>0)%3;return Math.max(0,Math.min(4,r+(h===0?1:h===1?0:-1)+(p>=70?0:p<30?-1:0)));}
export function validPeople(l){const p=l?.people;if(p===undefined)return true;const int=(x,a,b)=>Number.isInteger(x)&&x>=a&&x<=b;
 return !!p&&typeof p==='object'&&int(p.rival,0,100)&&int(p.mentor,0,100)&&Array.isArray(p.log)&&p.log.length<=PEOPLE.limit&&p.log.every(e=>e&&STORY_IDS.includes(e.id)&&typeof e.choice==='string'&&STORY_EVENTS[e.id].options.some(o=>o.id===e.choice)&&int(e.shift,0,1e6));}
