// R2 «Распорядок смены» (Claude, 11.10.2026): what a real 12-hour patrol shift looks like.
//   · Briefing (инструктаж) at the station: tasks and 1–2 lookouts (ориентировки) for the shift.
//   · Vehicle acceptance: below half a tank the crew refuels before patrol (fleet practice).
//   · One 1-hour meal break (PPA: 1 h + short pauses per 12 h shift), taken when the queue is
//     calm between the 4th and 8th hour; an urgent call interrupts it; no break → extra fatigue.
//   · Reports and car handover in the last 30 minutes at the station.
// Pure rules and texts; sim.js drives units through these statuses. Scheduled campaigns only.
import {WORLD_SECONDS_PER_TICK_SECOND} from './transport.js';
const ticks=minutes=>minutes*60/WORLD_SECONDS_PER_TICK_SECOND;
export const ROUTINE=Object.freeze({briefing:ticks(10),meal:ticks(60),mealFrom:ticks(4*60),mealTo:ticks(8*60),mealLate:ticks(9*60),reports:ticks(30),mealRecovery:16,skippedMeal:8,acceptFuelShare:.5,boloBonus:1.2,boloTrust:1});
export const ROUTINE_STATUSES=Object.freeze(['briefing','break','reports']);
export const STATUS_TEXT=Object.freeze({briefing:'Инструктаж в участке: задачи и ориентировки на смену.',break:'Обеденный перерыв (1 ч). Срочный вызов прервёт обед.',reports:'Конец смены: рапорты и сдача машины в участке.'});
/* J4: rescuers brief at the station (часть), ambulance crews at the substation; no «участок» for them */
const PLACE=Object.freeze({rescue:['в части','в части'],ems:['на подстанции','на подстанции'],dispatch:['в центре 112','в центре 112']});
export function statusText(status,agency){const text=STATUS_TEXT[status];const place=PLACE[agency];if(!text||!place)return text;return text.replace('Инструктаж в участке: задачи и ориентировки на смену.',agency==='ems'?'Пересменка на подстанции: укладка, лекарства, задачи на смену.':`Инструктаж ${place[0]}: задачи и проверка снаряжения на смену.`).replace('в участке',place[1]);}
// Lookouts: what the briefing asks crews to watch for; matched to a later call of that variant.
const BOLO=Object.freeze([
 {variant:'drunk-driver',text:'серый универсал, водитель мог быть пьян — номер на инструктаже'},
 {variant:'dangerous-driving',text:'тёмный седан, гонки по ночным улицам'},
 {variant:'vehicle-alert',text:'угнанный белый фургон'},
 {variant:'no-licence',text:'водитель, лишённый прав, ездит на синем хэтчбеке'},
 {variant:'shoplift',text:'мужчина в красной куртке, серия краж в магазинах'},
 {variant:'bike-theft',text:'подросток с болторезом в рюкзаке, кражи велосипедов'},
 {variant:'car-break',text:'двое в тёмной одежде вскрывают машины во дворах'},
 {variant:'missing-elder',text:'пожилой мужчина с деменцией, мог уйти из дома'}
]);
const mix=(a,b)=>{let h=Math.imul((a|0)+31,2654435761)^Math.imul((b|0)+17,40503);h^=h>>>13;return (h>>>0);};
export function briefingFor(seed,shift){const a=mix(seed,shift)%BOLO.length;let b=mix(shift,seed)%BOLO.length;if(b===a)b=(b+3)%BOLO.length;
 return [a,b].map((k,n)=>({id:n+1,variant:BOLO[k].variant,text:BOLO[k].text,matched:null}));}
export function validBolo(s){if(s.bolo===undefined)return true;return Array.isArray(s.bolo)&&s.bolo.length<=3&&s.bolo.every(b=>b&&Number.isInteger(b.id)&&typeof b.variant==='string'&&typeof b.text==='string'&&b.text.length<=160&&(b.matched===null||Number.isInteger(b.matched)));}

export function validRoutine(s){return s.units.every(u=>{
 const active=['briefing','break'].includes(u.status);
 if((active||u.status==='reports')&&s.schedule!=='ppa')return false;
 if(u.mealDone!==undefined&&typeof u.mealDone!=='boolean')return false;
 if(active&&u.routineLeft===undefined)return false;
 if(u.routineLeft!==undefined&&(!Number.isFinite(u.routineLeft)||u.routineLeft<0||u.routineLeft>(u.status==='briefing'?ROUTINE.briefing:ROUTINE.meal)))return false;
 return true;
});}
