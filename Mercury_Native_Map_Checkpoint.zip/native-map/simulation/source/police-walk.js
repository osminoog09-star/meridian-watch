import {network,walkingNodes} from './walking.js';
import {ROAD_NODES,point} from './geography.js';
import {advanceRoute,SPEED_KMH} from './transport.js';
import {MAP_METRES} from './world-scale.js';
const coord=p=>p.x+','+p.y;
const footCoords=new Map([...walkingNodes.values()].map(p=>[coord(p),p.id]));
const roadIds=new Set(ROAD_NODES.map(p=>p.id));
const links=new Map([...walkingNodes.keys()].map(id=>[id,[]]));
for(const e of network.segments){links.get(e.a).push(e.b);links.get(e.b).push(e.a);}
const plans=new Map();
const distance=(a,b)=>Math.hypot(a.x-b.x,a.y-b.y);
// One bounded search per shared road/foot destination, never per simulation tick.
export function policeWalkPlan(i){
 if(![0,3,4].includes(i.type))return null;
 const goal=footCoords.get(coord(i));if(!goal||!roadIds.has(goal))return null;
 if(plans.has(goal))return plans.get(goal);
 const dist=new Map([[goal,0]]),prev=new Map(),open=new Set([goal]);let start=null;
 while(open.size){let id=null;for(const n of open)if(id===null||dist.get(n)<dist.get(id))id=n;open.delete(id);const metres=dist.get(id)*MAP_METRES;if(metres>80)break;if(id!==goal&&roadIds.has(id)&&metres>=12){start=id;break;}for(const n of links.get(id)){const d=dist.get(id)+distance(walkingNodes.get(id),walkingNodes.get(n));if(d<(dist.get(n)??Infinity)){dist.set(n,d);prev.set(n,id);open.add(n);}}}
 let result=null;if(start){const ids=[start];while(ids.at(-1)!==goal)ids.push(prev.get(ids.at(-1)));result=Object.freeze({start,goal,ids:Object.freeze(ids),metres:dist.get(start)*MAP_METRES});}plans.set(goal,result);return result;
}
export function walkAccess(i){const plan=policeWalkPlan(i);return plan?walkingNodes.get(plan.start):i;}
export function beginPoliceWalk(u,i){
 const plan=policeWalkPlan(i);if(!plan||distance(u,walkingNodes.get(plan.start))>1e-7||u.route.length)return false;
 u.foot={version:1,incident:i.id,start:plan.start,goal:plan.goal,phase:'exit',timer:.08,actors:u.officerIds.map((id,k)=>({id,...point(u),heading:0,route:plan.ids.map(id=>({...walkingNodes.get(id)})),delay:k*.08}))};return true;
}
export const crewAtScene=u=>!u.foot||u.foot.phase==='onScene';
export function returnPoliceWalk(u){
 const f=u.foot;if(!f)return false;
 const plan=policeWalkPlan({...walkingNodes.get(f.goal),type:0});
 for(const a of f.actors){const count=f.phase==='onScene'?plan.ids.length:plan.ids.length-a.route.length;a.route=plan.ids.slice(0,Math.max(1,count)).reverse().map(id=>({...walkingNodes.get(id)}));a.delay=0;}
 f.phase='return';f.timer=0;u.incident=null;u.status='working';u.route=[];return true;
}
export function tickPoliceWalk(u,dt){
 const f=u.foot;if(!f)return;
 if(f.phase==='exit'){f.timer=Math.max(0,f.timer-dt);if(f.timer===0)f.phase='approach';return;}
 if(f.phase==='approach'||f.phase==='return'){let arrived=true;for(const a of f.actors){const seconds=Math.max(0,dt-a.delay);a.delay=Math.max(0,a.delay-dt);if(seconds>0)advanceRoute(a,seconds,SPEED_KMH.walking,{obeyLimits:false});if(a.route.length||a.delay>0)arrived=false;}if(arrived){f.phase=f.phase==='approach'?'onScene':'board';f.timer=f.phase==='board'?.08:0;}return;}
 if(f.phase==='board'){f.timer=Math.max(0,f.timer-dt);if(f.timer===0){u.foot=null;u.status='patrol';}}
}
export function policeWalkReason(u){return u.foot?({exit:'Остановились. Сотрудники выходят из машины.',approach:'Идём к участникам по проверенному пешеходному пути.',onScene:'Сотрудники на месте. Машина остаётся у дорожного доступа.',return:'Работа завершена. Сотрудники возвращаются к машине.',board:'Сотрудники садятся в машину.'})[u.foot.phase]:null;}
const onEdge=(p,a,b)=>Math.abs(distance(a,p)+distance(p,b)-distance(a,b))<1e-8;
export function validPoliceWalk(s,u){
 const f=u.foot;if(f===undefined||f===null)return true;
 if(!f||f.version!==1||!['exit','approach','onScene','return','board'].includes(f.phase)||!Number.isFinite(f.timer)||f.timer<0||f.timer>.08||!Number.isInteger(f.incident)||f.incident<1||f.incident>=s.nextId||!walkingNodes.has(f.goal)||!walkingNodes.has(f.start)||!Array.isArray(f.actors)||f.actors.length!==u.officerIds.length||u.route.length||distance(u,walkingNodes.get(f.start))>1e-7||!['working','decision'].includes(u.status)||u.pursuing)return false;
 const plan=policeWalkPlan({...walkingNodes.get(f.goal),type:0});if(!plan||plan.start!==f.start)return false;
 const closed=['return','board'].includes(f.phase);
 const incident=s.incidents.find(i=>i.id===f.incident);if(closed?u.incident!==null:!incident||u.incident!==f.incident||!['onscene','assigned'].includes(incident.state)||![0,3,4].includes(incident.type)||distance(incident,walkingNodes.get(f.goal))>1e-7)return false;
 return f.actors.every((a,k)=>{if(!a||a.id!==u.officerIds[k]||!Number.isFinite(a.x)||!Number.isFinite(a.y)||!Number.isFinite(a.heading)||!Number.isFinite(a.delay)||a.delay<0||a.delay>.08||!Array.isArray(a.route)||a.route.length>plan.ids.length)return false;
  const expected=closed?[...plan.ids].reverse():plan.ids,end=walkingNodes.get(closed?f.start:f.goal);
  if(f.phase==='exit')return distance(a,u)<1e-8&&a.route.length===plan.ids.length&&a.route.every((p,j)=>p&&p.id===plan.ids[j]&&distance(p,walkingNodes.get(p.id))<1e-8);
  if(['onScene','board'].includes(f.phase))return !a.route.length&&distance(a,end)<1e-8;
  if(!a.route.length)return distance(a,end)<1e-8;
  if(!a.route[0])return false;const start=expected.indexOf(a.route[0].id);if(start<0||a.route.length!==expected.length-start||!a.route.every((p,j)=>p&&p.id===expected[start+j]&&distance(p,walkingNodes.get(p.id))<1e-8))return false;
  const first=walkingNodes.get(a.route[0].id),previous=walkingNodes.get(expected[Math.max(0,start-1)]);return onEdge(a,previous,first);
 });
}
