// R23 «Подсказки новичку» (Claude, 11.10.2026). The service now has many systems (briefing, patrol work,
// fuel, meals, partner, monthly plan, news). A new roster campaign explains each one once, at the moment
// it first matters, in a small card over the map. Seen tips are stored in the campaign (`tipsSeen`);
// «Больше не показывать» turns them off (`tipsOff`). Pure rules; app.js shows the card.
import {shiftKind} from './schedule.js';
export const TIPS=Object.freeze([
 {id:'briefing',title:'Инструктаж',text:'Смена начинается в участке: экипажи слушают ориентировки и принимают машины. Через 10 минут они выйдут на линию.',when:s=>s.units.some(u=>u.status==='briefing')},
 {id:'chief-crews',title:'Нужны экипажи',text:'Без патрулей вызовы срываются. Откройте «Отделение»: наймите сотрудников и сформируйте хотя бы два патруля.',when:s=>s.mode==='chief'&&s.units.length<2&&!s.setupPending},
 {id:'first-call',title:'Новый вызов',text:'Вызов появился в списке «Вызовы». Выберите его и направьте экипаж — или оставьте автоматический режим, и экипаж поедет сам.',when:s=>s.incidents.some(i=>i.state==='waiting')},
 {id:'decision',title:'Экипаж на месте',text:'Откройте карточку вызова и выберите, как действовать: поговорить, проверить, вызвать подкрепление. Решение влияет на исход и на жалобы.',when:s=>s.units.some(u=>u.status==='decision')},
 {id:'patrol-work',title:'Вызовов нет',text:'Пока тихо, экипажу можно дать задание: рейд «Трезвый водитель», контроль скорости или пеший обход (панель экипажа). Любой вызов прервёт задание.',when:s=>s.time>60&&!s.incidents.some(i=>!['resolved','missed'].includes(i.state))&&s.units.some(u=>u.status==='patrol')},
 {id:'meal',title:'Обед',text:'По правилам ППА у экипажа час на обед за смену. Срочный вызов прервёт перерыв, а смена без обеда даёт лишнюю усталость.',when:s=>s.units.some(u=>u.status==='break')},
 {id:'fuel',title:'Топливо',text:'Бак почти пуст: экипаж сам заедет на АЗС, когда будет свободен. Пустой бак — машина встанет и придётся ждать канистру.',when:s=>(s.vehicles??[]).some(v=>Number.isFinite(v.fuel)&&v.fuel<12)},
 {id:'night',title:'Ночная смена',text:'Ночью усталость растёт быстрее, тяжелее всего в 4–5 утра. В пятницу и субботу ночью вызовов больше всего.',when:s=>s.units.some(u=>u.status==='patrol')&&shiftKind(s.shift-1)==='night'},
 {id:'partner',title:'Новый напарник',text:'Стажировка закончилась. У напарника свой характер, а слаженность пары ускоряет работу. Карточка — в «Личном деле».',when:s=>!!s.life?.partner&&s.life.partner.trait!=='mentor'&&s.life.partner.since===s.shift},
 {id:'detective',title:'Криминальная полиция',text:'Теперь вы следователь: патрульные вызовы берут другие экипажи. Дела — в панели экипажа: опросы, камеры, базы. Когда улик хватает, задерживайте. Нераскрытое дело уйдёт в архив.',when:s=>s.life?.role==='detective'},
 {id:'focus',title:'Задача смены',text:'Вы старший смены: на инструктаже выберите задачу — профилактика, быстрое реагирование или безопасность дорог. Она меняет работу всех экипажей.',when:s=>s.schedule==='ppa'&&!s.agency&&/* police only: other services have no shift focus */(s.mode==='chief'||(s.rank??0)>=3)&&s.units.some(u=>u.status==='briefing')},
 {id:'life-event',title:'Жизнь вне службы',text:'Случилась бытовая ситуация. Решите её на экране инструктажа или в личном деле до конца смены — иначе выберется самый осторожный вариант.',when:s=>!!s.life?.event},
 {id:'council',title:'Встреча с мэрией',text:'Каждый месяц мэрия ждёт начальника: попросить денег, пообещать меньше срывов или просто отчитаться. Выбор — в окне «Отделение».',when:s=>s.council?.choice==='pending'},
 {id:'shift-end',title:'Смена окончена',text:'В отчёте — разбор смены, история, план месяца и новости города. Потом — свободное время и следующая смена.',when:s=>s.ended}
]);
export const TIP_IDS=Object.freeze(TIPS.map(t=>t.id));
export function nextTip(s){if(s?.schedule!=='ppa'||s.tipsOff)return null;const seen=new Set(s.tipsSeen??[]);return TIPS.find(t=>!seen.has(t.id)&&t.when(s))??null;}
export function markTip(s,id,all=false){if(all){s.tipsOff=true;return;}if(!Array.isArray(s.tipsSeen))s.tipsSeen=[];if(!s.tipsSeen.includes(id)&&TIP_IDS.includes(id))s.tipsSeen.push(id);}
export const validTips=s=>(s.tipsSeen===undefined||Array.isArray(s.tipsSeen)&&s.tipsSeen.length<=TIP_IDS.length&&new Set(s.tipsSeen).size===s.tipsSeen.length&&s.tipsSeen.every(id=>TIP_IDS.includes(id)))&&(s.tipsOff===undefined||typeof s.tipsOff==='boolean');
