// Release E (Claude's part) «Доступность» (Claude, 12.10.2026). Settings of this phone, not of the
// campaign (stored in localStorage): larger text in panels and cards, high contrast, less motion, and
// visual/vibration signals for new calls when the sound is off. Pure rules; app.js applies them.
export const A11Y_KEY='meridian-watch-a11y-v1';
export const A11Y_DEFAULTS=Object.freeze({text:'normal',contrast:false,calm:false,visual:false});
export const TEXT_SIZES=Object.freeze({normal:{label:'Обычный',zoom:1},large:{label:'Крупный',zoom:1.15},huge:{label:'Очень крупный',zoom:1.3}});
export function a11yPreferences(raw){let p={};try{p=typeof raw==='string'?JSON.parse(raw):raw??{};}catch{}return {text:Object.hasOwn(TEXT_SIZES,p?.text)?p.text:'normal',contrast:p?.contrast===true,calm:p?.calm===true,visual:p?.visual===true};}
export function a11yClasses(p){const q=a11yPreferences(p);return [q.text!=='normal'?`a11y-text-${q.text}`:null,q.contrast?'a11y-contrast':null,q.calm?'a11y-calm':null].filter(Boolean);}
// A new call: a short flash of the screen edge and a vibration (urgent calls vibrate twice).
export function callSignal(incident,p){const q=a11yPreferences(p);if(!q.visual||!incident)return null;const urgent=[2,5].includes(incident.type);return {flash:urgent?'urgent':'call',vibrate:urgent?[180,90,180]:[140]};}
