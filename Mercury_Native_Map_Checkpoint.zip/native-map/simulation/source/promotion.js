// Release R3 «Звания как в жизни» (Claude, 17.10.2026). Owner 17.10: «система повышения за опыт неправильная — надо
// как в реальной жизни, а опыт пусть прокачивает навыки». In the Estonian police (PPVS, PPA) a personal rank is not
// earned by points: the head of the agency confers the next rank to an officer who has served the minimum time in the
// current rank, holds a position of the matching level, has a positive evaluation (the yearly development interview /
// attestation), valid mandatory admissions and no disciplinary penalty. In the game: the decision is taken at the
// attestation (every 6 months of service), from the shift's supervisor's recommendation, by these conditions.
// Experience no longer buys ranks: it grows the officer's skills — public order, traffic, search, thefts, rescue,
// first aid — and a skilled officer works faster on calls of that kind.
export const PROMOTION=Object.freeze([
 null,
 Object.freeze({months:6,grades:['A','B','C'],courses:0,clean:6,label:'конец испытательного срока: 6 месяцев службы, аттестация не ниже «удовлетворительно»'}),
 Object.freeze({months:12,grades:['A','B'],courses:1,clean:12,label:'12 месяцев в звании, аттестация «хорошо» или «отлично», один специальный курс'}),
 Object.freeze({months:18,grades:['A','B'],courses:2,clean:12,twice:true,label:'18 месяцев в звании, две аттестации подряд не ниже «хорошо», два специальных курса'}),
 Object.freeze({months:24,grades:['A'],courses:3,clean:18,award:true,label:'24 месяца в звании, «отлично» на аттестации, три специальных курса, служебная награда'})
]);
export const SKILLS=Object.freeze({order:'Общественный порядок',traffic:'Дорожное движение',search:'Поиск людей',theft:'Кражи',rescue:'Спасательные работы',medical:'Первая помощь'});
export const SKILL_IDS=Object.freeze(Object.keys(SKILLS));
const TYPE_SKILL=['order','traffic','search','theft','order','traffic','rescue','rescue','rescue','rescue','medical','medical','medical','medical'];
export const skillOf=type=>TYPE_SKILL[type]??'order';
/* level 10 needs about two years of calls of one kind (audit 17.10: the old curve was full in a few months) */
export const skillLevel=points=>Math.min(10,Math.floor(Math.sqrt(Math.max(0,points)/250)));
export const skillPace=(life,type)=>1+.02*skillLevel(life?.skills?.[skillOf(type)]??0);
export const LEVEL_WORDS=['новичок','новичок','начинающий','начинающий','уверенный','уверенный','опытный','опытный','мастер','мастер','эксперт'];
export function addSkill(life,type,xp){if(!life||!(xp>0))return;life.skills=life.skills??{};const k=skillOf(type);life.skills[k]=Math.min(50000,(life.skills[k]??0)+xp);}
// The conditions for the next rank, each with ok and a short text.
export function promotionCheck(s,{mandatory=true,courses=0,awards=0}={}){const next=(s.rank??0)+1,rule=PROMOTION[next];if(!rule)return null;const l=s.life??{},att=l.attestations??[],months=(l.months??0)-(l.rankMonth??0),last=att.at(-1),prev=att.at(-2);
 const breach=(l.breachMonth!==undefined&&(l.months??0)-l.breachMonth<rule.clean);
 const items=[
  {id:'time',ok:months>=rule.months,text:`Служба в звании: ${months} из ${rule.months} мес.`},
  {id:'grade',ok:!!last&&rule.grades.includes(last.grade)&&(!rule.twice||!!prev&&rule.grades.includes(prev.grade)),text:`Аттестация: ${rule.grades.length===1?'«отлично»':rule.grades.includes('C')?'не ниже «удовлетворительно»':'«хорошо» или «отлично»'}${rule.twice?' два раза подряд':''}${last?` (последняя: ${last.grade})`:' (ещё не было)'}`},
  {id:'admission',ok:!!mandatory,text:'Действующие стрельбы и физподготовка'},
  ...(rule.courses?[{id:'courses',ok:courses>=rule.courses,text:`Специальные курсы: ${courses} из ${rule.courses}`}]:[]),
  ...(rule.award?[{id:'award',ok:awards>0,text:'Служебная награда'}]:[]),
  {id:'clean',ok:!breach,text:`Без дисциплинарных нарушений ${rule.clean} мес.`}];
 return {rank:next,rule,items,ok:items.every(x=>x.ok)};}
export function validSkills(l){const k=l?.skills;if(k===undefined)return true;return !!k&&typeof k==='object'&&Object.entries(k).every(([id,v])=>SKILL_IDS.includes(id)&&Number.isFinite(v)&&v>=0&&v<=50000)&&(l.rankMonth===undefined||Number.isInteger(l.rankMonth)&&l.rankMonth>=0)&&(l.breachMonth===undefined||Number.isInteger(l.breachMonth)&&l.breachMonth>=0);}
