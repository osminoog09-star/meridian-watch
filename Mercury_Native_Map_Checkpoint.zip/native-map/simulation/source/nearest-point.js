// Exact static-point lookup. Preserve original array order on equal distances.
// Points must stay immutable; the returned objects are the original references.
export function createNearestPoint(points){
 if(!points.length)throw new Error('Nearest-point index requires points');
 const sorted=points.map((point,order)=>({point,order})).sort((a,b)=>a.point.x-b.point.x||a.order-b.order);
 return p=>{
  if(!Number.isFinite(p.x)||!Number.isFinite(p.y))return points[0];
  let lo=0,hi=sorted.length;
  while(lo<hi){const mid=(lo+hi)>>>1;if(sorted[mid].point.x<p.x)lo=mid+1;else hi=mid;}
  let left=lo-1,right=lo,best=points[0],order=0,distance=Math.hypot(p.x-best.x,p.y-best.y);
  while(left>=0||right<sorted.length){
   const dl=left>=0?Math.abs(p.x-sorted[left].point.x):Infinity,dr=right<sorted.length?Math.abs(p.x-sorted[right].point.x):Infinity;
   if(Math.min(dl,dr)>distance)break;
   const candidate=dl<=dr?sorted[left--]:sorted[right++];
   const d=Math.hypot(p.x-candidate.point.x,p.y-candidate.point.y);
   if(d<distance||(d===distance&&candidate.order<order)){best=candidate.point;order=candidate.order;distance=d;}
  }
  return best;
 };
}
