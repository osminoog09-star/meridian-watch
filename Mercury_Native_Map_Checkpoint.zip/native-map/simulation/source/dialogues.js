import {RESCUE_SCRIPTS,RESCUE_TYPE_SCRIPTS} from './rescue-scenes.js';
import {rescueFacts} from './rescue.js';import {emsFacts} from './ems.js';import {EMS_SCRIPTS,EMS_TYPE_SCRIPTS} from './ems-scenes.js';
// Release B «Глубина вызовов» (Claude, 12.10.2026). A call is a short story with the player's choices:
// approach → inquiry → decision, three steps on the scene. Every option has a price: tension, evidence,
// time, the risk of a complaint, the partner's view, follow-up risk and what ends up in the protocol.
// Facts of the case (blood alcohol, stolen value, earlier calls, injuries) are hashes of the call id
// (no rng): the inquiry reveals them, a careless decision ignores them and pays for it.
// Grounded in PPA practice: everyone in a road accident is breath-tested; above 1.5 g/l drink-driving
// is a crime, 0.2–1.49 a misdemeanour; at a domestic violence call the police fill in a risk assessment
// and may ban the aggressor from the home for up to 72 hours; victims are referred to victim support.
// A variant without its own script gets the script of its call type, so every call has a scene.
const h=(id,salt)=>{let x=Math.imul((id|0)+977,2654435761)^Math.imul((salt|0)+31,1597334677);x^=x>>>15;x=Math.imul(x,2246822519);return ((x^x>>>13)>>>0)/4294967296;};
// Facts of a call, revealed by questions.
export function factsFor(i){const id=i?.id??0;return {...(i?.type>=6&&i?.type<=9?rescueFacts(i):{}),...(i?.type>=10&&i?.type<=13?emsFacts(i):{}),
 promille:Math.round((.1+h(id,1)*2.1)*100)/100,// blood alcohol, g/l
 value:Math.round(12+h(id,2)*380),// stolen value, €
 repeat:h(id,3)<.4,// the address or person is known from earlier calls
 injured:h(id,4)<.45,
 witness:h(id,5)<.7,// a witness saw who started it
 refuses:h(id,6)<.15,// refuses the breath test
 documents:h(id,7)<.85,
 medical:h(id,8)<.3};}// confused person: a medical cause (diabetes, dementia)
const g=(n,v)=>v<1.5?`${v.toFixed(2).replace('.',',')} промилле`:`${v.toFixed(2).replace('.',',')} промилле — уголовный уровень`;
// Option effects: tension, evidence (0..100), pace (×work speed), complaint (×), bond, trust, followUp (×).
const O=(id,label,hint,fx={},more={})=>({id,label,hint,fx,...more});
export const SCRIPTS=Object.freeze({
 domestic:[
  {stage:'approach',title:'Подход',text:'За дверью крики. Открывает мужчина, за ним в коридоре плачет женщина.',options:[
   O('separate','Развести участников по комнатам','спокойнее, нужен второй сотрудник',{tension:-20,evidence:10,pace:.9},{maps:'talk',rec:true,soft:true,line:'Развели их по комнатам — крики стихли.'}),
   O('firm','Твёрдо: «Полиция, всем успокоиться»','быстро, но может обострить',{tension:8,pace:1.1,complaint:1.2,risk:.15},{maps:'talk',strict:true,line:'Команда подействовала, но мужчина огрызается.'}),
   O('backup','Ждать второй экипаж у двери','безопаснее, дольше',{tension:5,pace:.8},{maps:'backup',line:'Ждём второй экипаж, держим дверь в поле зрения.'})]},
  {stage:'inquiry',title:'Что произошло',text:'Нужно понять, насколько опасно оставлять их вместе.',options:[
   O('risk','Опросить женщину отдельно (лист оценки риска)','улики, выявит прежние случаи',{evidence:35,pace:.9},{rec:true,soft:true,line:f=>f.repeat?'Это не первый раз: соседи вызывали полицию и раньше. Риск высокий.':'Раньше полицию не вызывали, но угрозы были.'}),
   O('injury','Осмотреть следы побоев','при травмах — скорая',{evidence:20},{line:f=>f.injured?'Синяки на руке и лице — нужна скорая.':'Видимых травм нет.',setsIf:f=>f.injured?{ambulance:true}:null}),
   O('neighbours','Расспросить соседку-заявителя','свидетель со стороны',{evidence:15,pace:.95},{line:'Соседка слышала удары и угрозы.'})]},
  {stage:'decision',title:'Решение',text:'Что дальше с мужчиной?',options:[
   O('ban','Запрет на 72 часа + направление в помощь жертвам','нужна оценка риска; согласия пострадавшей не требуется',{trust:1,bond:2,followUp:.4},{needs:{evidence:30},rec:true,soft:true,sets:{custody:'warn',protocol:'Запрет приближаться к дому на 72 часа, лист оценки риска, направление в службу помощи жертвам'}}),
   O('arrest','Задержать мужчину','надёжно, но без улик — жалоба',{followUp:.3},{strict:true,sets:{custody:'arrest',protocol:'Задержан, материалы о семейном насилии, направление в службу помощи жертвам'}}),
   O('warn','Ограничиться предупреждением','быстро, высокий риск повторного вызова',{followUp:2,trust:-1,bond:-2},{sets:{custody:'warn',protocol:'Предупреждение, сведения — соцработнику'}})]}],
 'street-fight':[
  {stage:'approach',title:'Подход',text:'У бара толпа, двое сцепились, остальные снимают на телефоны.',options:[
   O('wait','Дождаться второго экипажа','безопаснее',{tension:6,pace:.8},{maps:'backup',rec:true,line:'Встали с мигалками на виду — толпа расступается.'}),
   O('separate','Развести дерущихся сразу','быстро, риск травмы',{tension:-10,pace:1.15,complaint:1.2,bond:-1,risk:.3},{maps:'talk',strict:true,line:'Растащили их, одному пришлось применить захват.'}),
   O('talk','Громко обратиться к толпе','снижает напряжение',{tension:-15},{maps:'talk',soft:true,line:'Толпа отходит, драка теряет зрителей.'})]},
  {stage:'inquiry',title:'Кто начал',text:'Оба кричат, что начал другой.',options:[
   O('witness','Опросить свидетелей','улики',{evidence:30,pace:.9},{rec:true,line:f=>f.witness?'Бармен видел: первым ударил парень в чёрной куртке.':'Свидетели путаются в показаниях.'}),
   O('video','Посмотреть видео с телефонов','надёжные улики, дольше',{evidence:40,pace:.85},{line:'На видео ясно, кто начал.'}),
   O('medic','Проверить раненых','при травмах — скорая',{evidence:5},{line:f=>f.injured?'У одного рассечена бровь — вызываем скорую.':'Серьёзных травм нет.',setsIf:f=>f.injured?{ambulance:true}:null})]},
  {stage:'decision',title:'Решение',text:'Как закончить?',options:[
   O('arrest','Задержать зачинщика','нужны улики',{trust:1},{needs:{evidence:30},rec:true,sets:{custody:'arrest',protocol:'Задержан зачинщик, материалы о побоях, видео приобщено'}}),
   O('fine','Протокол обоим за нарушение порядка','без доставки',{followUp:.8},{soft:true,sets:{custody:'warn',protocol:'Протоколы о нарушении общественного порядка обоим участникам'}}),
   O('both','Задержать обоих','без разбирательства — жалобы',{complaint:1.6},{strict:true,sets:{custody:'arrest',protocol:'Задержаны оба участника, материалы о побоях'}})]}],
 'drunk-driver':[
  {stage:'approach',title:'Остановка',text:'Машина виляет. Включаем маячки — водитель тормозит не сразу.',options:[
   O('safe','Остановить в безопасном месте, подойти с фонарём','по инструкции',{pace:.95},{maps:'check',rec:true,line:'Остановились на парковке. Из салона пахнет алкоголем.'}),
   O('block','Прижать к обочине сразу','быстро, риск',{pace:1.15,complaint:1.15,risk:.2},{maps:'chase',strict:true,line:'Прижали к обочине, водитель нервничает.'})]},
  {stage:'inquiry',title:'Проверка',text:'Водитель уверяет, что выпил «одно пиво».',options:[
   O('breath','Алкометр','точно и быстро',{evidence:60},{rec:true,line:f=>f.refuses?'Отказывается дуть — повезём на анализ крови.':`Алкометр: ${g(0,f.promille)}.`}),
   O('docs','Проверить права и машину по базе','может выявить лишение прав',{evidence:15,pace:.95},{line:f=>f.documents?'Документы в порядке.':'Права изъяты судом ещё в прошлом году.'}),
   O('trust','Поверить на слово','быстро, но…',{pace:1.2,followUp:3,bond:-3,trust:-1},{line:'Не проверяли. Напарник недоволен.'})]},
  {stage:'decision',title:'Решение',text:'Что с водителем?',options:[
   O('law','По закону по результату теста','протокол / уголовное дело по промилле',{trust:1},{needs:{evidence:50},rec:true,setsBy:f=>f.promille>=1.5||f.refuses?{custody:'arrest',protocol:`Уголовный уровень опьянения (${g(0,f.promille)}): водитель задержан, машина на штрафстоянку`}:f.promille>=.2?{custody:'warn',protocol:`Протокол о вождении в опьянении (${g(0,f.promille)}), отстранение от управления`}:{custody:'warn',protocol:'Трезв: проверка окончена, водитель отпущен'}}),
   O('release','Отпустить с предупреждением','если пил — он сядет за руль снова',{followUp:2.5,trust:-1},{sets:{custody:'warn',protocol:'Предупреждение водителю'}})]}],
 shoplift:[
  {stage:'approach',title:'В магазине',text:'Охранник держит молодого человека у кассы.',options:[
   O('security','Сначала выслушать охрану','улики',{evidence:15,pace:.95},{maps:'check',rec:true,line:'Охранник показывает украденное.'}),
   O('suspect','Сразу поговорить с задержанным','спокойнее',{tension:-10},{maps:'talk',soft:true,line:'Он признаётся почти сразу.'})]},
  {stage:'inquiry',title:'Обстоятельства',text:'Что и на сколько украдено?',options:[
   O('camera','Видео с камер магазина','надёжно',{evidence:40,pace:.9},{rec:true,line:f=>`На видео видно, как он прячет товар. Сумма — ${f.value} €.`}),
   O('base','Проверить по базе','рецидив?',{evidence:20},{line:f=>f.repeat?'Уже попадался на кражах в этом году.':'Ранее не задерживался.'}),
   O('receipt','Пересчитать товар по чекам','сумма',{evidence:25,pace:.95},{line:f=>`Сумма украденного — ${f.value} €.`})]},
  {stage:'decision',title:'Решение',text:'Мелкая кража — проступок, крупная — уголовное дело.',options:[
   O('law','По сумме и рецидиву','как положено',{trust:1},{needs:{evidence:35},rec:true,setsBy:f=>f.value>200||f.repeat?{custody:'arrest',protocol:`Кража на ${f.value} €${f.repeat?', повторно':''}: задержан, материалы — в криминальную полицию`}:{custody:'warn',protocol:`Протокол о мелкой краже (${f.value} €), товар возвращён магазину`}}),
   O('warn','Отпустить, если вернёт товар','мягко',{followUp:1.6},{soft:true,sets:{custody:'warn',protocol:'Товар возвращён, устное предупреждение'}})]}],
 'noise-flat':[
  {stage:'approach',title:'У двери',text:'Музыка на весь подъезд. Стучим — открывают не сразу.',options:[
   O('polite','Вежливо попросить сделать тише','быстро, мягко',{tension:-10,pace:1.1},{maps:'talk',rec:true,soft:true,line:'Хозяин извиняется, музыку выключают.'}),
   O('firm','Предупредить о протоколе','твёрже',{tension:5,complaint:1.1},{maps:'talk',strict:true,line:'Хозяин недоволен, но музыку убавляет.'})]},
  {stage:'inquiry',title:'Уточнить',text:'Соседи говорят, что так каждые выходные.',options:[
   O('history','Проверить прежние вызовы на адрес','повтор?',{evidence:30},{rec:true,line:f=>f.repeat?'Третий вызов за месяц на этот адрес.':'Раньше жалоб не было.'}),
   O('neighbours','Поговорить с соседями','',{evidence:15,trust:.5},{soft:true,line:'Соседи благодарят, что приехали.'})]},
  {stage:'decision',title:'Решение',text:'Тишина после 23:00 — по закону.',options:[
   O('fine','Протокол о нарушении тишины','по закону',{followUp:.6},{needs:{evidence:20},rec:true,sets:{custody:'warn',protocol:'Протокол о нарушении ночной тишины'}}),
   O('warn','Устное предупреждение','мягко, может повториться',{followUp:1.4},{soft:true,sets:{custody:'warn',protocol:'Устное предупреждение жильцам'}})]}],
 'drunk-person':[
  {stage:'approach',title:'На остановке',text:'Мужчина спит на лавке, не реагирует на голос.',options:[
   O('check','Разбудить и проверить дыхание и пульс','по инструкции',{pace:.95},{maps:'talk',rec:true,soft:true,line:'Дышит, приходит в себя, говорит невнятно.'}),
   O('shake','Растормошить и поднять','быстрее',{pace:1.1,complaint:1.2},{maps:'check',line:'Поднялся, качается.'})]},
  {stage:'inquiry',title:'Состояние',text:'Сам домой он не дойдёт.',options:[
   O('medical','Проверить, не нужна ли скорая','безопасность',{evidence:20},{rec:true,line:f=>f.medical?'Сахар! Он диабетик — нужна скорая.':'Просто сильно пьян.',setsIf:f=>f.medical?{ambulance:true}:null}),
   O('relatives','Найти родных по документам','',{evidence:15,pace:.95},{soft:true,line:f=>f.documents?'Дозвонились до жены, она приедет.':'Документов нет.'})]},
  {stage:'decision',title:'Решение',text:'Куда его?',options:[
   O('home','Передать родным','мягко',{trust:.5},{soft:true,rec:true,sets:{custody:'warn',protocol:'Передан родным, рапорт'}}),
   O('cell','В камеру протрезвления','надёжно',{followUp:.5},{strict:true,sets:{custody:'arrest',protocol:'Доставлен в камеру протрезвления, рапорт'}})]}],
 'confused-person':[
  {stage:'approach',title:'На дороге',text:'Пожилая женщина в халате идёт по проезжей части.',options:[
   O('calm','Подойти спереди, спокойно, без резких движений','',{tension:-15},{maps:'talk',rec:true,soft:true,line:'Она берёт сотрудника под руку и идёт на тротуар.'}),
   O('quick','Быстро увести с дороги за руку','быстрее, может напугать',{tension:10,pace:1.1,complaint:1.2},{maps:'check',line:'Испугалась и заплакала, но с дороги ушла.'})]},
  {stage:'inquiry',title:'Кто она',text:'Не помнит адрес.',options:[
   O('bracelet','Поискать браслет или записку с адресом','',{evidence:30},{rec:true,line:'На руке браслет с телефоном дочери.'}),
   O('base','Проверить заявления о пропавших','',{evidence:20,pace:.95},{line:'Дочь уже звонила 112.'})]},
  {stage:'decision',title:'Решение',text:'',options:[
   O('medic','Скорая и дочь','безопасно',{trust:1},{rec:true,sets:{ambulance:true,custody:'warn',protocol:'Передана врачам скорой и дочери'}}),
   O('home','Отвезти домой к дочери','',{bond:1},{soft:true,sets:{custody:'warn',protocol:'Доставлена домой, передана дочери'}})]}],
 'restraining-order':[
  {stage:'approach',title:'У двери',text:'Бывший партнёр стучит в дверь, требует впустить.',options:[
   O('backup','Ждать второй экипаж','он может быть агрессивен',{pace:.85},{maps:'backup',rec:true,line:'Второй экипаж подъехал, подходим вдвоём.'}),
   O('direct','Подойти сразу','быстрее, риск',{tension:10,pace:1.15,bond:-1,risk:.3},{maps:'talk',strict:true,line:'Он оборачивается и сжимает кулаки.'})]},
  {stage:'inquiry',title:'Проверка',text:'',options:[
   O('court','Проверить запрет суда по базе','улики',{evidence:50},{rec:true,line:'Запрет действует ещё полгода.'}),
   O('victim','Поговорить с женщиной через дверь','',{evidence:20},{soft:true,line:'Он звонил ей всю неделю.'})]},
  {stage:'decision',title:'Решение',text:'Нарушение запрета суда — уголовное дело.',options:[
   O('arrest','Задержать за нарушение запрета','по закону',{trust:1,followUp:.3},{needs:{evidence:40},rec:true,sets:{custody:'arrest',protocol:'Задержан за нарушение запрета на приближение, материалы — следователю'}}),
   O('warn','Увести и предупредить','он вернётся',{followUp:2.5,trust:-1},{soft:true,sets:{custody:'warn',protocol:'Предупреждение, рапорт о нарушении запрета — в суд'}})]}],
 'phone-scam':[
  {stage:'approach',title:'Засада',text:'Курьер должен прийти за деньгами к пенсионерке.',options:[
   O('wait','Ждать в квартире с пенсионеркой','поймать с поличным',{evidence:30,pace:.9},{maps:'check',rec:true,line:'Курьер звонит в дверь и берёт конверт.'}),
   O('street','Перехватить на улице','быстрее, но без поличного',{pace:1.15},{maps:'talk',line:'Остановили парня у подъезда — конверта при нём нет.'})]},
  {stage:'inquiry',title:'Курьер',text:'',options:[
   O('phone','Посмотреть его телефон (с согласия)','ниточка к организатору',{evidence:30},{rec:true,line:'В переписке — адрес и указания «оператора».'}),
   O('talk','Поговорить: кто послал','',{evidence:15},{soft:true,line:'Говорит, что нашёл «подработку» в интернете.'})]},
  {stage:'decision',title:'Решение',text:'',options:[
   O('arrest','Задержать, материалы следователю','',{trust:1.5},{needs:{evidence:30},rec:true,sets:{custody:'arrest',protocol:'Курьер задержан с поличным, переписка изъята, материалы — следователю'}}),
   O('release','Отпустить, взять объяснение','',{followUp:1.5},{soft:true,sets:{custody:'warn',protocol:'Объяснение курьера, материалы о мошенничестве'}})]}],
 'missing-child':[
  {stage:'approach',title:'Заявитель',text:'Мать в слезах: сын не вернулся с тренировки, телефон не отвечает.',options:[
   O('calm','Успокоить и записать приметы, взять фото','быстрее ориентировка',{evidence:25},{maps:'talk',rec:true,soft:true,line:'Синяя куртка, рюкзак с мячом, фото в телефоне матери.'}),
   O('drive','Сразу ехать по маршруту от спортзала','',{pace:1.05},{maps:'check',line:'Едем по маршруту, приметы — по ходу.'})]},
  {stage:'inquiry',title:'Где искать',text:'',options:[
   O('friends','Позвонить тренеру и друзьям','',{evidence:30,pace:.95},{rec:true,line:'Друг говорит: собирались на скейт-площадку у реки.'}),
   O('radio','Ориентировка всем экипажам','весь район ищет',{evidence:20,trust:.5},{line:'Ориентировка передана, ищут все экипажи.'})]},
  {stage:'decision',title:'Найден',text:'',options:[
   O('family','Передать матери, поговорить без упрёков','',{trust:1,bond:1},{rec:true,soft:true,sets:{protocol:'Розыск закрыт, ребёнок передан матери'}}),
   O('social','Передать матери и сообщить соцработнику','если такое повторяется',{trust:.5},{sets:{protocol:'Розыск закрыт, ребёнок передан матери, сведения — соцработнику'}})]}],
 'school-speeding':[
  {stage:'approach',title:'У школы',text:'Утро, дети идут к школе, машина проносится мимо.',options:[
   O('stop','Остановить за перекрёстком, не у детей','',{pace:.95},{maps:'chase',rec:true,line:'Остановили водителя в безопасном месте.'}),
   O('flash','Сразу мигалки и сирену','быстро, пугает детей',{pace:1.1,trust:-.5},{maps:'chase',line:'Сирена у школы — дети шарахаются.'})]},
  {stage:'inquiry',title:'Проверка',text:'',options:[
   O('radar','Показать запись радара','',{evidence:40},{rec:true,line:'Радар: 52 км/ч в зоне 30.'}),
   O('docs','Документы и база','',{evidence:20},{line:f=>f.documents?'Документы в порядке.':'Прав нет.'})]},
  {stage:'decision',title:'Решение',text:'',options:[
   O('fine','Протокол за превышение в школьной зоне','',{trust:1},{needs:{evidence:30},rec:true,sets:{protocol:'Протокол о превышении скорости в школьной зоне'}}),
   O('talk','Разъяснительная беседа без протокола','',{followUp:1.5},{soft:true,sets:{protocol:'Профилактическая беседа с водителем'}})]}],
 crash:[
  {stage:'approach',title:'ДТП',text:'Две машины на перекрёстке, одна дымит.',options:[
   O('secure','Огни, конусы, перекрыть полосу','безопасность',{pace:.95},{maps:'secure',rec:true,line:'Место огорожено, движение в объезд.'}),
   O('people','Сразу к людям','быстрее к пострадавшим',{pace:1.05,bond:-1},{maps:'secure',line:'Подбежали к машинам — сзади сигналят.'})]},
  {stage:'inquiry',title:'Участники',text:'Все участники ДТП проверяются алкометром.',options:[
   O('breath','Алкометр обоим водителям','по правилам',{evidence:40},{rec:true,line:f=>f.promille>=.2?`Один из водителей пьян: ${g(0,f.promille)}.`:'Оба трезвы.'}),
   O('injured','Проверить пострадавших','',{evidence:10},{line:f=>f.injured?'У пассажирки болит шея — скорая.':'Все целы.',setsIf:f=>f.injured?{ambulance:true}:null}),
   O('scheme','Схема и фото','для страховой',{evidence:25,pace:.9},{line:'Схема ДТП составлена.'})]},
  {stage:'decision',title:'Оформление',text:'',options:[
   O('law','Оформить по результатам проверки','',{trust:1},{needs:{evidence:35},rec:true,setsBy:f=>f.promille>=.2?{custody:'arrest',protocol:`ДТП, водитель в опьянении (${g(0,f.promille)}): задержан, материалы`}:{custody:'warn',protocol:'Схема ДТП, объяснения участников, протокол виновнику'}}),
   O('agree','Помочь оформить европротокол','быстро, если трезвы',{pace:1.15},{soft:true,sets:{custody:'warn',protocol:'Участники оформили европротокол'}})]}]
});
// Generic scripts by call type (0 order, 1 road scene, 2 search, 3 theft, 4 violence, 5 vehicle).
export const TYPE_SCRIPTS=Object.freeze([
 [{stage:'approach',title:'Подход',text:'Участники на месте, разговор на повышенных тонах.',options:[O('calm','Спокойно представиться','',{tension:-12},{maps:'talk',rec:true,soft:true,line:'Разговор стал спокойнее.'}),O('firm','Твёрдо потребовать порядка','быстрее, может обострить',{tension:6,pace:1.1,complaint:1.1},{maps:'check',strict:true,line:'Подчинились, но недовольны.'})]},
  {stage:'inquiry',title:'Обстоятельства',text:'',options:[O('witness','Опросить заявителя и свидетелей','',{evidence:30},{rec:true,line:'Картина ясна.'}),O('docs','Проверить документы','',{evidence:20,pace:.95},{line:f=>f.repeat?'Участники известны по прежним вызовам.':'Ранее не попадались.'})]},
  {stage:'decision',title:'Решение',text:'',options:[O('fine','Протокол','',{followUp:.7},{needs:{evidence:20},rec:true,sets:{custody:'warn'}}),O('warn','Предупреждение','',{followUp:1.3},{soft:true,sets:{custody:'warn'}})]}],
 [{stage:'approach',title:'На месте',text:'Опасный участок дороги.',options:[O('secure','Обезопасить место','',{pace:.95},{maps:'secure',rec:true,line:'Место огорожено.'}),O('fast','Сразу к людям','',{pace:1.05},{maps:'secure',line:'Работаем без ограждения.'})]},
  {stage:'inquiry',title:'Проверка',text:'',options:[O('people','Проверить людей','',{evidence:20},{rec:true,line:f=>f.injured?'Есть пострадавший — скорая.':'Пострадавших нет.',setsIf:f=>f.injured?{ambulance:true}:null}),O('photo','Фото и схема','',{evidence:25,pace:.92},{line:'Обстоятельства зафиксированы.'})]},
  {stage:'decision',title:'Завершение',text:'',options:[O('report','Оформить и передать службам','',{trust:.5},{rec:true,sets:{custody:'warn'}})]}],
 [{stage:'approach',title:'Поиск',text:'Родные волнуются, времени мало.',options:[O('calm','Успокоить и расспросить заявителя','быстрее найти ориентир',{evidence:20},{maps:'talk',rec:true,soft:true,line:'Узнали, во что одет и куда мог пойти.'}),O('streets','Сразу объехать улицы','',{pace:1.05},{maps:'check',line:'Начали объезд.'})]},
  {stage:'inquiry',title:'Ориентировка',text:'',options:[O('radio','Ориентировка по радио всем экипажам','',{evidence:25,trust:.5},{rec:true,line:'Все экипажи в районе ищут.'}),O('places','Проверить любимые места','',{evidence:20},{line:'Друзья подсказали несколько мест.'})]},
  {stage:'decision',title:'Найден',text:'',options:[O('family','Передать родным, проверить состояние','',{trust:1},{rec:true,sets:{custody:'warn'}}),O('medic','Скорая для осмотра','',{trust:.5},{sets:{ambulance:true,custody:'warn'}})]}],
 [{stage:'approach',title:'На месте кражи',text:'Заявитель ждёт у подъезда.',options:[O('victim','Выслушать потерпевшего','',{evidence:15},{maps:'check',rec:true,line:'Записали приметы.'}),O('search','Сразу осмотреть округу','',{pace:1.05},{maps:'talk',line:'Осматриваем дворы.'})]},
  {stage:'inquiry',title:'Улики',text:'',options:[O('camera','Камеры домофонов и магазинов','',{evidence:35,pace:.9},{rec:true,line:'На записи видно лицо.'}),O('base','Проверка по базе похожих краж','',{evidence:20},{line:f=>f.repeat?'Похожие кражи в этом районе — серия.':'Похожих случаев нет.'})]},
  {stage:'decision',title:'Решение',text:'',options:[O('law','По уликам','',{trust:.5},{needs:{evidence:30},rec:true,sets:{custody:'arrest'}}),O('statement','Принять заявление','',{},{soft:true,sets:{custody:'warn'}})]}],
 [{stage:'approach',title:'Подход',text:'Обстановка напряжённая.',options:[O('wait','Дождаться второго экипажа','',{tension:5,pace:.85},{maps:'backup',rec:true,line:'Вдвоём безопаснее.'}),O('talk','Деэскалация с дистанции','',{tension:-12},{maps:'talk',soft:true,line:'Голос спокойный, руки на виду — люди слушают.'})]},
  {stage:'inquiry',title:'Кто зачинщик',text:'',options:[O('witness','Свидетели и видео','',{evidence:35,pace:.9},{rec:true,line:'Зачинщик установлен.'}),O('medic','Проверить пострадавших','',{evidence:10},{line:f=>f.injured?'Есть травма — скорая.':'Без травм.',setsIf:f=>f.injured?{ambulance:true}:null})]},
  {stage:'decision',title:'Решение',text:'',options:[O('arrest','Задержать зачинщика','',{trust:.5},{needs:{evidence:30},rec:true,sets:{custody:'arrest'}}),O('warn','Развести и предупредить','',{followUp:1.4},{soft:true,sets:{custody:'warn'}})]}],
 [{stage:'approach',title:'Остановка',text:'Машина по ориентировке.',options:[O('safe','Остановить по инструкции','',{pace:.95},{maps:'check',rec:true,line:'Водитель остановился.'}),O('chase','Преследовать, если не остановится','',{pace:1.1,complaint:1.1},{maps:'chase',strict:true,line:'Включили сирену.'})]},
  {stage:'inquiry',title:'Проверка',text:'',options:[O('docs','Документы и база','',{evidence:30},{rec:true,line:f=>f.documents?'Документы в порядке.':'Водитель лишён прав.'}),O('breath','Алкометр','',{evidence:30},{line:f=>`Алкометр: ${g(0,f.promille)}.`})]},
  {stage:'decision',title:'Решение',text:'',options:[O('law','По результатам проверки','',{trust:.5},{needs:{evidence:25},rec:true,setsBy:f=>!f.documents||f.promille>=1.5?{custody:'arrest'}:{custody:'warn'}}),O('warn','Предупреждение','',{followUp:1.5},{soft:true,sets:{custody:'warn'}})]}]
]);
// A fan fight plays out like a street fight.
const ALIASES=Object.freeze({'fan-fight':'street-fight'});
// Balance (audit of Release B): full pace effects made peak nights miss 3–5× more calls; half of the
// effect keeps the choice noticeable without overloading the shift.
export const PACE_WEIGHT=.5;
export const scriptFor=i=>SCRIPTS[i?.variant]??RESCUE_SCRIPTS[i?.variant]??EMS_SCRIPTS[i?.variant]??SCRIPTS[ALIASES[i?.variant]]??TYPE_SCRIPTS[i?.type]??RESCUE_TYPE_SCRIPTS[i?.type]??EMS_TYPE_SCRIPTS[i?.type]??null;
export const SCRIPTED=Object.freeze([...Object.keys(SCRIPTS),...Object.keys(ALIASES),...Object.keys(RESCUE_SCRIPTS),...Object.keys(EMS_SCRIPTS)]);
// Risky options can hurt an officer (hash of the call id).
export const injuryRolled=(i,risk)=>!!risk&&h(i.id,17)<risk;
export const STAGES=Object.freeze(['approach','inquiry','decision']);
export function ensureTalk(i){if(i.talk)return i.talk;if(!scriptFor(i))return null;return i.talk={stage:0,choices:[],evidence:0,pace:1,complaint:1,bond:0,trust:0,followUp:1,sets:{}};}
export const currentStage=i=>{const sc=scriptFor(i),t=i?.talk;return sc&&t&&t.stage<sc.length?sc[t.stage]:null;};
export const optionOpen=(i,o)=>!o.needs||(i.talk?.evidence??0)>=o.needs.evidence;
// Apply a choice; returns the option and its result line.
export function applyChoice(i,optionId){const st=currentStage(i);const o=st?.options.find(x=>x.id===optionId);if(!o||!optionOpen(i,o))return null;const t=i.talk,f=factsFor(i),fx=o.fx??{};
 t.evidence=Math.min(100,t.evidence+(fx.evidence??0));if(fx.pace)t.pace*=1+(fx.pace-1)*PACE_WEIGHT;if(fx.complaint)t.complaint*=fx.complaint;t.bond+=fx.bond??0;t.trust+=fx.trust??0;if(fx.followUp)t.followUp*=fx.followUp;
 const sets={...(o.sets??{}),...(o.setsIf?.(f)??{}),...(o.setsBy?.(f)??{})};Object.assign(t.sets,sets);
 const line=(typeof o.line==='function'?o.line(f):o.line)||sets.protocol||`${o.label}.`;t.choices.push({stage:st.stage,id:o.id,line});t.stage++;return {option:o,line,tension:fx.tension??0};}
// Automatic choice by the department's standing order: recommended / strict / soft, first that is open.
export function autoOption(i,style='balanced'){const st=currentStage(i);if(!st)return null;const open=st.options.filter(o=>optionOpen(i,o));const pick=style==='strict'?open.find(o=>o.strict):style==='prevention'?open.find(o=>o.soft):null;return (pick??open.find(o=>o.recIf?o.recIf(factsFor(i)):o.rec)/* Release I: a recommendation that depends on what the crew found */??open[0])?.id??null;}
export const talkDone=i=>!!i?.talk&&!currentStage(i);
// A detention without enough evidence is the classic source of complaints; evidence protects the crew.
export const talkComplaintFactor=t=>!t?1:t.complaint*(t.sets.custody==='arrest'?(t.evidence<30?2:t.evidence>=50?.5:1):1);
export function validTalk(t){return t===undefined||!!t&&Number.isInteger(t.stage)&&t.stage>=0&&t.stage<=3&&Array.isArray(t.choices)&&t.choices.length<=3&&t.choices.every(c=>c&&typeof c.id==='string'&&typeof c.line==='string'&&c.line.length<=240&&STAGES.includes(c.stage))&&['evidence','pace','complaint','bond','trust','followUp'].every(k=>Number.isFinite(t[k]))&&t.evidence>=0&&t.evidence<=100&&t.pace>0&&t.pace<5&&t.sets&&typeof t.sets==='object'&&(t.sets.custody===undefined||['arrest','warn'].includes(t.sets.custody))&&(t.sets.protocol===undefined||typeof t.sets.protocol==='string'&&t.sets.protocol.length<=240)&&(t.injury===undefined||t.injury===true);}
