// R3 «Между сменами» (Claude, 11.10.2026): the career officer's life off duty on the realistic
// PPA roster (schedule.js). After every shift the player plans the free time until the next one:
// rest, an extra (overtime) shift, training courses, sport, family or a hobby. Choices change
// sleep debt, stress, fitness, money, skills and the officer's state at the start of the next shift.
// Facts behind the numbers: docs/REALISM_RESEARCH_CLAUDE_20261011.md (salary from 2035 € gross,
// 12 h rest around a shift, overtime is limited, yearly shooting and fitness checks).
// Pure rules; sim.js applies the plan in nextShift(). Only scheduled career campaigns use it.
import {restBefore} from './schedule.js';
export const PAY=Object.freeze({monthlyGross:2035,shiftsPerMonth:15,netShare:.76,overtime:1.5});
export const shiftGross=()=>Math.round(PAY.monthlyGross/PAY.shiftsPerMonth);// ≈136 € per 12 h shift
export const shiftNet=()=>Math.round(shiftGross()*PAY.netShare);
// Courses: days needed, what they give. `valid` = how many shifts a mandatory check stays valid
// (a year of service compressed for play: 24 shifts = six roster cycles).
export const COURSES=Object.freeze({
 firearms:{agency:'police',label:'Стрельбы (ежегодный допуск)',days:1,mandatory:true,valid:24,about:'Обязательная проверка: без действующего допуска не будет повышения.'},
 fitness:{agency:['police','rescue','ems'],label:'Физподготовка (ежегодный тест)',days:1,mandatory:true,valid:24,about:'Обязательный тест. Чем лучше форма, тем легче сдать.',minFitness:35},
 firstaid:{label:'Первая помощь',days:2,about:'Ваш экипаж на 10% быстрее работает с пострадавшими (ДТП, драка, человеку плохо).',variants:['crash','street-fight','drunk-person'],bonus:1.1},
 driving:{agency:'police',label:'Вождение спецмашины',days:2,about:'Плавная срочная езда: на срочных выездах ваша машина расходует топливо и изнашивается как в обычном патруле.'},
 tactics:{agency:'police',label:'Тактика задержания (ГБР)',days:3,about:'Допуск в группу быстрого реагирования (нужны звание «Старший констебль», форма от 70 и действующие стрельбы).'},
 k9:{agency:'police',label:'Кинологический курс',days:4,about:'Допуск к работе со служебной собакой (нужно звание «Констебль»).'},
 drone:{agency:'police',label:'Оператор дрона',days:2,about:'Допуск к полётам дрона на поиске и погонях (нужно звание «Констебль»).'},
 investigation:{agency:'police',label:'Курс следователя (криминальная полиция)',days:4,about:'Допуск к работе следователем: опросы, записи камер, базы, задержание по делу (нужно звание «Старший констебль»).'},
 negotiation:{agency:'police',label:'Переговоры и деэскалация',days:3,about:'Ваш экипаж на 10% быстрее на конфликтах, семейных ссорах и шуме.',variants:['street-fight','domestic','noise-venue','noise-flat','yard-company'],bonus:1.1},
 traffic:{agency:'police',label:'Дорожный надзор',days:2,about:'Допуск к переводу в дорожную полицию: алкотестер, измерение скорости, оформление ДТП (нужно звание «Констебль»).'},
 // Release H rescuers (Päästeamet): breathing apparatus is the yearly mandatory check, like shooting for the police.
 ba:{agency:'rescue',label:'Дыхательный аппарат (ежегодный допуск)',days:1,mandatory:true,valid:24,about:'Обязательная проверка: работа в задымлении в дыхательном аппарате. Без допуска не будет повышения.'},
 water:{agency:'rescue',label:'Спасение на воде и льду',days:3,about:'Гидрокостюм, лодка, спасение со льда. Допуск к роли водного спасателя (нужно звание «Спасатель»).'},
 height:{agency:'rescue',label:'Высотные и верёвочные работы',days:3,about:'Работа на высоте и с верёвками: лифты, крыши, колодцы. Допуск к роли спасателя-высотника.'},
 // Release I ambulance crews: advanced resuscitation is the mandatory yearly check of an ambulance worker.
 als:{agency:'ems',label:'Расширенная реанимация (ежегодный допуск)',days:1,mandatory:true,valid:24,about:'Обязательная проверка: дефибриллятор, препараты, работа в команде при остановке сердца. Без допуска не будет повышения.'},
 trauma:{agency:'ems',label:'Травма на догоспитальном этапе',days:3,about:'Тяжёлая травма, шина, щит, остановка кровотечения. Допуск к роли бригады травмы (нужно звание «Медтехник»).'},
 peds:{agency:'ems',label:'Неотложная педиатрия',days:3,about:'Дети: дыхание, ожоги, судороги, роды. Допуск к роли педиатрической бригады.'},
 ambdrive:{agency:'ems',label:'Водитель скорой',days:2,about:'Плавная срочная езда с пациентом: на выездах с сиреной расход топлива и износ как в обычной поездке.'},
 // Release J 112 operators: the call-taking protocol is the yearly check.
 protocol:{agency:'dispatch',label:'Протоколы опроса 112 (ежегодный допуск)',days:1,mandatory:true,valid:24,about:'Обязательная проверка: структурированный опрос, приоритеты, передача вызова службам. Без допуска не будет повышения.'},
 tcpr:{agency:'dispatch',label:'Реанимация по телефону',days:2,about:'Инструкция «массаж сердца» занимает вдвое меньше времени разговора.'},
 crisis:{agency:'dispatch',label:'Тяжёлые звонки и стресс',days:2,about:'Звонки о смерти, детях и пожарах дают вдвое меньше стресса.'},
 heavy:{agency:'rescue',label:'Водитель тяжёлой машины',days:2,about:'Плавная срочная езда на тяжёлой машине: на выездах с сиреной расход топлива и износ как в обычной поездке.'}
});
export const courseAgency=c=>c?.agency??'both';
export const courseFor=(id,agency)=>{const a=courseAgency(COURSES[id]);return a==='both'||a===(agency??'police')||Array.isArray(a)&&a.includes(agency??'police');};
export const COURSE_IDS=Object.freeze(Object.keys(COURSES));
import {ensurePartner,validPartner} from './partner.js';
import {validCases} from './detective.js';
import {SIDE,SIDE_JOBS,sideJobActive,sideJobDay,validSideJob} from './sidejob.js';
export const ACTIVITIES=Object.freeze({
 rest:{label:'Отдых и сон',about:'Высыпаетесь: недосып −40, стресс −10.',sleep:-40,stress:-10,fitness:0,money:0},
 family:{label:'Семья и друзья',about:'Стресс −25, немного недосыпа (+5). Расходы 30 €.',sleep:5,stress:-25,fitness:0,money:-30},
 sport:{label:'Спорт',about:'Форма +8, стресс −10. Абонемент 10 €.',sleep:0,stress:-10,fitness:8,money:-10},
 hobby:{label:'Хобби',about:'Стресс −15. Расходы 15 €.',sleep:0,stress:-15,fitness:0,money:-15},
 partner:{label:'Время с напарником',about:'Кофе, рыбалка или баня с напарником: связь +12, стресс −12. Расходы 20 €.',sleep:0,stress:-12,fitness:0,money:-20,bond:12},
 training:{label:'Обучение',about:'День курса или проверки. Недосып +10, стресс +5.',sleep:10,stress:5,fitness:0,money:0},
 health:{label:'День здоровья (оплачиваемый)',about:'Без больничного листа, 5 дней в год (ППА): недосып −30, стресс −20.',sleep:-30,stress:-20,fitness:0,money:0},
 sidejob:{label:'Подработка (вечер)',about:'Вторая работа — только после уведомления начальника (или на свой риск). Такси, доставка, охрана: деньги, но недосып.',sleep:0,stress:0,fitness:0,money:0},
 overtime:{label:'Доп. смена (12 ч)',about:'Оплата ×1.5, опыт. Недосып +35, стресс +10. Нужно ≥12 ч отдыха до и после; не больше одной за выходные.',sleep:35,stress:10,fitness:-1,money:0}
});
export const ACTIVITY_IDS=Object.freeze(Object.keys(ACTIVITIES));
// Leave (karjaar.politsei.ee): at least 35 days a year plus 5 paid health days.
export const LEAVE=Object.freeze({days:35,health:5,cycleDays:8,shiftsSkipped:4});
export const LIFE_LIMITS=Object.freeze({planDays:4});
// R21: monthly living costs of a patrol officer (rent, bills, food) — charged when the month closes;
// a net patrol salary (~1450 € a month) leaves a few hundred euros of savings. Debt adds stress.
export const LIVING=Object.freeze({monthly:950,debtStress:10});
const clamp=v=>Math.max(0,Math.min(100,v));
export function ensureLife(s){if(s.mode!=='career'||s.schedule!=='ppa')return null;if(!s.life||typeof s.life!=='object')s.life={...(s.agency?{agency:s.agency}:{}),sleepDebt:0,stress:10,fitness:55,money:0,earned:0,overtime:0,courses:Object.fromEntries(Object.keys(COURSES).filter(id=>COURSES[id].mandatory&&courseFor(id,s.agency)).map(id=>[id,s.shift])),progress:{},history:[],last:null,leaveDays:LEAVE.days,healthDays:LEAVE.health};return s.life;}// academy graduates start with valid checks
// Free blocks before the next shift (index = 0-based shift index of the next shift).
// 12 h → one evening; 24 h → one day; 96 h → four days. Overtime needs a 96 h gap (12 h rest on both sides).
export function freeBlocks(nextIndex){const rest=restBefore(nextIndex)??0;const days=rest>=72*60?4:1;return {days,rest:rest/60,overtime:rest>=72*60,training:rest>=24*60};}
export function validPlan(plan,blocks,life=null){if(!Array.isArray(plan)||plan.length!==blocks.days)return false;let ot=0,health=0;if(life?.forcedRest&&plan.some(p=>['overtime','training'].includes(p.activity)))return false;
 for(const p of plan){if(!p||!Object.hasOwn(ACTIVITIES,p.activity))return false;if(p.activity==='overtime'){ot++;if(!blocks.overtime)return false;}if(p.activity==='health')health++;
  if(p.activity==='training'){if(!blocks.training||!Object.hasOwn(COURSES,p.course))return false;}else if(p.course!==undefined)return false;}
 const side=plan.filter(p=>p.activity==='sidejob').length;if(side&&(!sideJobActive(life)||side>SIDE.perOff))return false;
 return ot<=1&&health<=(life?.healthDays??LEAVE.health);}
export const defaultPlan=blocks=>Array.from({length:blocks.days},()=>({activity:'rest'}));
export function courseValid(life,id,shift){const c=COURSES[id],done=life?.courses?.[id];if(!Number.isInteger(done))return false;return !c.valid||shift-done<c.valid;}
export function mandatoryOk(life,shift){return COURSE_IDS.filter(id=>COURSES[id].mandatory&&courseFor(id,life?.agency)).every(id=>courseValid(life,id,shift));}
// Apply one plan: returns lines for the summary. `shift` = number of the shift just finished.
export function applyPlan(life,plan,shift){const lines=[];let xp=0;
 for(const [day,p] of plan.entries()){const a=ACTIVITIES[p.activity];if(p.activity==='sidejob'){const r=sideJobDay(life,shift,day);lines.push(...r.lines);continue;}if(a.bond){const pr=ensurePartner(life);pr.bond=clamp(pr.bond+a.bond);lines.push(`${pr.name}: вечер вместе — связь +${a.bond}`);}life.sleepDebt=clamp(life.sleepDebt+a.sleep);life.stress=clamp(life.stress+a.stress);life.fitness=clamp(life.fitness+a.fitness);life.money+=a.money;
  if(p.activity==='overtime'){const pay=Math.round(shiftNet()*PAY.overtime);life.money+=pay;life.earned+=pay;life.overtime++;xp+=60;lines.push(`Доп. смена: +${pay} € на руки, опыт +60`);}
  else if(p.activity==='training'){const c=COURSES[p.course];life.progress[p.course]=(life.progress[p.course]??0)+1;
   if(life.progress[p.course]>=c.days){life.progress[p.course]=0;
    if(p.course==='fitness'&&life.fitness<c.minFitness){lines.push(`${c.label}: не сдан — форма ${Math.round(life.fitness)}%, нужно ${c.minFitness}%`);life.stress=clamp(life.stress+10);}
    else{life.courses[p.course]=shift;lines.push(`${c.label}: пройдено`);}}
   else lines.push(`${c.label}: день ${life.progress[p.course]} из ${c.days}`);}
  else{if(p.activity==='health')life.healthDays=Math.max(0,(life.healthDays??LEAVE.health)-1);lines.push(`${a.label}`);}}
 // Fitness slowly fades without sport (−2 per off period).
 if(!plan.some(p=>p.activity==='sport'))life.fitness=clamp(life.fitness-2);
// R4: two off periods in a row at stress ≥80 → the PPA psychologist sends the officer to rest.
 if(life.forcedRest){life.forcedRest=false;life.burnout=0;life.stress=clamp(life.stress-20);lines.push('Психолог ППА: восстановились, стресс −20');}
 else{life.burnout=life.stress>=80?(life.burnout??0)+1:0;if(life.burnout>=2){life.forcedRest=true;lines.push('Психолог ППА: признаки выгорания — в следующие выходные только отдых');}}
 life.history.unshift({shift,plan:plan.map(p=>p.activity+(p.course?':'+p.course:'')).join(',').slice(0,120)});if(life.history.length>12)life.history.length=12;
 return {lines,xp};}
// After a worked shift: pay and the strain of the shift itself.
export function workShift(life,{night=false,missed=0}={}){const pay=shiftNet();life.money+=pay;life.earned+=pay;life.sleepDebt=clamp(life.sleepDebt+(night?25:12));life.stress=clamp(life.stress+3+missed*2);return pay;}
// Officer state at the start of the next shift.
export const startFatigue=life=>life?Math.round(Math.min(60,life.sleepDebt*.5+Math.max(0,life.stress-60)*.3)):0;
// Course bonus for the player's own crew on a call variant.
export function courseBonus(life,variant){let b=1;for(const id of ['firstaid','negotiation']){const c=COURSES[id];if(Number.isInteger(life?.courses?.[id])&&c.variants.includes(variant))b=Math.max(b,c.bonus);}return b;}
export function validLife(s){const l=s.life;if(l===undefined)return true;if(s.mode!=='career'||s.schedule!=='ppa')return false;if(!validPartner(l?.partner)||!validCases(l)||!validSideJob(l))return false;const num=(x,a,b)=>Number.isFinite(x)&&x>=a&&x<=b;
 return !!l&&typeof l==='object'&&['sleepDebt','stress','fitness'].every(k=>num(l[k],0,100))&&num(l.money,-1e7,1e7)&&num(l.earned,0,1e8)&&Number.isInteger(l.overtime)&&l.overtime>=0
  &&(l.agency===undefined||['rescue','ems','dispatch'].includes(l.agency)&&s.agency===l.agency)&&l.courses&&typeof l.courses==='object'&&Object.entries(l.courses).every(([k,v])=>Object.hasOwn(COURSES,k)&&Number.isInteger(v)&&v>=0&&v<=s.shift)
  &&l.progress&&typeof l.progress==='object'&&Object.entries(l.progress).every(([k,v])=>Object.hasOwn(COURSES,k)&&Number.isInteger(v)&&v>=0&&v<COURSES[k].days)
  &&Array.isArray(l.history)&&l.history.length<=12&&l.history.every(h=>h&&Number.isInteger(h.shift)&&typeof h.plan==='string'&&h.plan.length<=120)
  &&(l.leaveDays===undefined||Number.isInteger(l.leaveDays)&&l.leaveDays>=0&&l.leaveDays<=LEAVE.days)&&(l.healthDays===undefined||Number.isInteger(l.healthDays)&&l.healthDays>=0&&l.healthDays<=LEAVE.health)&&(l.leaveYear===undefined||Number.isInteger(l.leaveYear))&&(l.role===undefined||l.role===null||Object.hasOwn(ROLES,l.role))&&(l.burnout===undefined||Number.isInteger(l.burnout)&&l.burnout>=0&&l.burnout<100)&&(l.forcedRest===undefined||typeof l.forcedRest==='boolean')&&(l.last===undefined||l.last===null||(Number.isInteger(l.last.shift)&&num(l.last.pay,0,1e6)&&Array.isArray(l.last.lines)&&l.last.lines.length<=10&&l.last.lines.every(x=>typeof x==='string'&&x.length<=160)));}
// Realistic promotion pace for scheduled campaigns: XP thresholds and valid mandatory checks.
export const RANK_XP=Object.freeze([0,600,1800,3600,6000]);
export function scheduledRank(s){const life=s.life;let r=0;for(let k=1;k<RANK_XP.length;k++)if(s.xp>=RANK_XP[k])r=k;
 if(r>s.rank&&!mandatoryOk(life,s.shift))return s.rank;// no promotion without valid shooting and fitness checks
 return Math.max(s.rank,r);}

// R6 «Роли» (Claude, 11.10.2026): after basic training a PPA officer can move into a role —
// rapid response, dog handler, drone operator (karjaar.politsei.ee). Each role needs a rank and
// its course, and changes how the player's own crew works on matching calls.
export const ROLES=Object.freeze({
 rapid:{agency:'police',label:'Группа быстрого реагирования префектуры',course:'tactics',rank:2,minFitness:70,needsFirearms:true,about:'Отдельное подразделение префектуры, не патруль: командный центр направляет вас по всему городу только на опасные вызовы — оружие, драки, семейное насилие, задержание подозреваемых по делам криминальной полиции, погони за машиной из ориентировки, взлом с сигнализацией. Вызов ГБР даёт вдвое больше опыта. Шум, кражи и ДТП берут патрули. Если патрулю долго не идёт подкрепление — едете вы; если все патрули заняты и вызов ждёт — берёте его как дополнительный патруль. Задержание на 30% быстрее, второй экипаж не нужен. Вооружённого, закрывшегося в квартире, уговариваете и задерживаете сами; K-Komando вызывают только при заложнике, а при угрозе жизни вы действуете, не дожидаясь его.',bonus:{'street-fight':1.3,'fan-fight':1.3,domestic:1.3,'restraining-order':1.3,'suspect-found':1.3,'vehicle-alert':1.2,'alarm-burglary':1.2},noCaution:true},
 k9:{agency:'police',label:'Кинолог',course:'k9',rank:1,about:'Поиск людей на 40% быстрее; по делам о кражах зацепка находится чаще (+20%).',bonus:{'missing-elder':1.4,'missing-child':1.4,'suspect-found':1.2},leadBonus:.2},
 detective:{agency:'police',label:'Следователь криминальной полиции',course:'investigation',rank:2,detective:true,about:'Вы ведёте дела: свидетели, камеры, базы, задержание. Обычные вызовы патруля берут другие экипажи.'},
 traffic:{agency:'police',label:'Дорожная полиция',course:'traffic',rank:1,about:'Пьяные и опасные водители, ДТП, превышение у школ — на 30% быстрее; на рейдах «Трезвый водитель» и контроле скорости нарушителей находится в 1,5 раза больше.',bonus:{'drunk-driver':1.3,'dangerous-driving':1.3,crash:1.3,'school-speeding':1.3,'no-licence':1.3},raid:1.5},
 diver:{agency:'rescue',label:'Водный спасатель',course:'water',rank:1,about:'Спасение на воде и льду на 40% быстрее, лодка и гидрокостюм всегда в машине.',bonus:{'water-ice':1.4,'water-swim':1.4,'water-boat':1.4}},
 rope:{agency:'rescue',label:'Спасатель-высотник',course:'height',rank:1,about:'Лифты, колодцы, крыши — на 30% быстрее; в задымлённом подъезде людей находят быстрее.',bonus:{'rescue-lift':1.3,'animal-rescue':1.3,'fire-stairs':1.15}},
 trauma:{agency:'ems',label:'Бригада травмы',course:'trauma',rank:1,about:'Травмы, падения, ожоги — на 30% быстрее: шина, щит и обезболивание без лишних минут.',bonus:{'ems-trauma':1.3,'ems-fall':1.3,'ems-sport':1.3,'ems-ice-fall':1.3,'ems-burn':1.2,'ems-cut':1.2}},
 peds:{agency:'ems',label:'Педиатрическая бригада',course:'peds',rank:1,about:'Дети и роды — на 35% быстрее; маленький пациент и родители спокойнее.',bonus:{'ems-burn':1.35,'ems-choking':1.35,'ems-birth':1.35,'ems-seizure':1.2,'ems-breath':1.2}},
 drone:{agency:'police',label:'Оператор дрона',course:'drone',rank:1,about:'Поиск на 30% быстрее, проверки и погони на 20% быстрее.',bonus:{'missing-elder':1.3,'missing-child':1.3,'vehicle-alert':1.2,'drunk-driver':1.2,'dangerous-driving':1.2}}
});
export const ROLE_IDS=Object.freeze(Object.keys(ROLES));
export function roleBlocker(life,id,rank,shift){const r=ROLES[id];if(!r)return 'Нет такой роли.';if((r.agency??'police')!==(life?.agency??'police'))return 'Эта роль — в другой службе.';if(rank<r.rank)return 'Нужно звание выше.';if(!Number.isInteger(life?.courses?.[r.course]))return `Нужен курс «${COURSES[r.course].label}».`;
 if(r.minFitness&&life.fitness<r.minFitness)return `Нужна физформа от ${r.minFitness}.`;if(r.needsFirearms&&!courseValid(life,'firearms',shift))return 'Нужен действующий допуск по стрельбе.';return null;}
export const roleBonus=(life,variant)=>ROLES[life?.role]?.bonus?.[variant]??1;
export const roleNoCaution=life=>!!ROLES[life?.role]?.noCaution;
export const roleLeadBonus=life=>ROLES[life?.role]?.leadBonus??0;

// Paid leave of one roster cycle: the four off days grow into twelve; full recovery, holiday pay.
export function canTakeVacation(life,blocks){if(!life)return 'Отпуск — в карьере по графику.';if(blocks?.days!==4)return 'Отпуск оформляется на выходные после ночных смен.';if((life.leaveDays??LEAVE.days)<LEAVE.cycleDays)return `Осталось ${life.leaveDays} дн. отпуска.`;return null;}
export function applyVacation(life,shift){const pay=LEAVE.shiftsSkipped*shiftNet();life.leaveDays=(life.leaveDays??LEAVE.days)-LEAVE.cycleDays;life.sleepDebt=0;life.stress=clamp(life.stress-40);life.fitness=clamp(life.fitness-2);life.money+=pay;life.earned+=pay;life.forcedRest=false;life.burnout=0;
 life.history.unshift({shift,plan:'vacation'});if(life.history.length>12)life.history.length=12;return {lines:[`Отпуск: 12 дней отдыха (−${LEAVE.cycleDays} дн., осталось ${life.leaveDays})`,`Отпускные: +${pay} €`],xp:0};}
// A new calendar year restores the leave and health days.
export function newYear(life,year){if(!life)return false;if(life.leaveYear===year)return false;const fresh=life.leaveYear!==undefined;life.leaveYear=year;life.leaveDays=LEAVE.days;life.healthDays=LEAVE.health;return fresh;}
