import {ensureDevelopment,validDevelopment} from './professional.js';
import {PROFILES} from './agency.js';
export const CAREER_PERMISSIONS=Object.freeze([
 {rank:0,title:'Стажёр',duty:'Управление Патрулём 01 и решения на месте'},
 {rank:1,title:'Патрульный',duty:'Выбор зоны своего патруля'},
 {rank:2,title:'Старший сотрудник',duty:'Координация других патрулей'},
 {rank:3,title:'Сержант',duty:'Разрешение выезда патрулей между зонами'},
 {rank:4,title:'Руководитель смены',duty:'Все оперативные полномочия карьеры'}
]);

export function ensureService(s){
 if(s.service===undefined)s.service=s.mode==='career'?{
  version:1,startShift:s.shift,startTime:s.time,legacy:s.time>0||s.shift>1||s.xp>0,
  events:[],promotions:[{rank:s.rank,shift:s.shift,time:s.time}]
 }:null;
 ensureDevelopment(s);return s.service;
}

export function careerPermission(s,u,action='command'){
 if(s?.agency==='dispatch')return {ok:false,reason:'Диспетчер 112 не управляет экипажами: принимает вызовы и направляет службы.'};/* Release J */
 if(!u)return {ok:false,reason:'Сначала выберите экипаж.'};
 if(s.mode==='chief')return {ok:true,reason:'Полномочия начальника смены.'};
 if(s.mode!=='career')return {ok:false,reason:'Команда недоступна.'};
 const own=u.id===1,rank=s.rank??0;
 if(action==='zone'&&rank<1)return {ok:false,reason:PROFILES[s.agency]?`Выбор района откроется со званием «${PROFILES[s.agency].ranks[1]}».`:'Выбор зоны откроется со званием «Патрульный».'};
 if(action==='cross'&&rank<3)return {ok:false,reason:PROFILES[s.agency]?`Выезд между районами откроется со званием «${PROFILES[s.agency].ranks[3]}».`:'Выезд между зонами откроется со званием «Сержант».'};
 if(!own&&rank<2)return {ok:false,reason:PROFILES[s.agency]?`Координация других машин откроется со званием «${PROFILES[s.agency].ranks[2]}».`:'Координация других экипажей откроется со званием «Старший сотрудник».'};
 return {ok:true,reason:own?'Ваш экипаж.':'Экипаж находится в вашем оперативном подчинении.'};
}

export function serviceEvent(s,incident,name,success,rankBefore){
 const service=ensureService(s);if(!service)return;
 service.events.unshift({incident:incident.id,name,success,shift:s.shift,time:Math.min(s.time,s.shiftLength),xp:s.xp,rank:s.rank});
 service.events=service.events.slice(0,100);
 if(s.rank>rankBefore&&!service.promotions.some(p=>p.rank===s.rank))service.promotions.push({rank:s.rank,shift:s.shift,time:Math.min(s.time,s.shiftLength)});
}

export function serviceSummary(s){
 const service=s.service;if(s.mode!=='career'||!service)return null;
 const table=PROFILES[s.agency]?.permissions??CAREER_PERMISSIONS,current=table[s.rank],next=table[s.rank+1]??null;
 return {current,next,legacy:service.legacy,events:service.events.map(e=>({...e})),promotions:service.promotions.map(p=>({...p})),success:service.events.filter(e=>e.success).length,failed:service.events.filter(e=>!e.success).length};
}

export function validService(s){
 const service=s.service;if(service===undefined)return true;if(s.mode==='chief')return service===null;
 if(!service||service.version!==1||!Number.isInteger(service.startShift)||service.startShift<1||service.startShift>s.shift||!Number.isFinite(service.startTime)||service.startTime<0||service.startTime>s.shiftLength||typeof service.legacy!=='boolean'||!Array.isArray(service.events)||service.events.length>100||!Array.isArray(service.promotions)||service.promotions.length>5)return false;
 const start=(service.startShift-1)*s.shiftLength+service.startTime,end=(s.shift-1)*s.shiftLength+s.time;
 const validMoment=e=>e&&Number.isInteger(e.shift)&&e.shift>=service.startShift&&e.shift<=s.shift&&Number.isFinite(e.time)&&e.time>=0&&e.time<=s.shiftLength&&(e.shift-1)*s.shiftLength+e.time>=start&&(e.shift-1)*s.shiftLength+e.time<=end;
 if(start>end||!service.promotions.every(p=>validMoment(p)&&Number.isInteger(p.rank)&&p.rank>=0&&p.rank<=s.rank))return false;
 if(new Set(service.promotions.map(p=>p.rank)).size!==service.promotions.length)return false;
 return validDevelopment(service.development,s)&&service.events.every(e=>validMoment(e)&&Number.isInteger(e.incident)&&e.incident>0&&e.incident<s.nextId&&typeof e.name==='string'&&e.name.length<160&&typeof e.success==='boolean'&&Number.isFinite(e.xp)&&e.xp>=0&&Number.isInteger(e.rank)&&e.rank>=0&&e.rank<CAREER_PERMISSIONS.length);
}
