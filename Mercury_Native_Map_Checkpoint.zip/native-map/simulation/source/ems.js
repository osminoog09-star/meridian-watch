// Release I «Скорая» (Claude, 12.10.2026). An emergency medical service campaign: the player works in
// (or runs) the ambulance substation of Meridian. Same city and engine; the calls are patients, the
// work on scene is to keep the patient alive and decide whether and how fast to take them to hospital.
// Facts behind the numbers (general emergency medicine, Estonian kiirabi practice; ERR/Terviseamet):
//  · calls are triaged A–D at the 112 centre; A (life threatening) — target about 10 minutes in a city;
//  · cardiac arrest: every minute without CPR and defibrillation costs roughly 7–10 % of the chance to
//    survive; CPR by a bystander (guided by the dispatcher) slows that two to three times; a public
//    defibrillator in the first minutes works best of all;
//  · stroke and heart attack: «time is brain / time is muscle» — a FAST check, an ECG sent ahead and a
//    short time on scene; clot-busting treatment for a stroke only within about 4.5 hours of onset;
//  · a brigade is two or three people (a nurse or a doctor in charge, an ambulance technician, a driver);
//    a resuscitation team (реанимобиль) and a doctor's rapid car without a stretcher work alongside;
//  · not every patient needs the hospital: many are treated and left at home with advice — but a wrong
//    «home» for a serious case means the patient calls again, worse.
// Pure rules: sim.js and dialogues.js call these; nothing here touches the police or rescue campaigns.
import {WORLD_SECONDS_PER_TICK_SECOND} from './transport.js';
export const EMS_SERVICE='ems';
export const isEms=s=>s?.agency===EMS_SERVICE;
const worldMin=dt=>dt*WORLD_SECONDS_PER_TICK_SECOND/60;
const hash=(a,b)=>{let h=Math.imul((a|0)+919,2654435761)^Math.imul((b|0)+53,1597334677);h^=h>>>15;h=Math.imul(h,2246822519);return ((h^h>>>13)>>>0)/4294967296;};
// Call types 10–13 (appended to sim.js TYPES after the rescue types). Options: [label, choice].
export const EMS_TYPES=Object.freeze([
 {name:'Остановка сердца',icon:'♥',severity:3,duration:18,limit:45,brief:'Мужчина упал на улице и не дышит. Прохожий по подсказке диспетчера делает непрямой массаж сердца.',options:[['Реанимация на месте: дефибриллятор и СЛР','resus'],['Погрузить и везти с СЛР в машине','scoop']]},
 {name:'Боль в груди',icon:'♥',severity:3,duration:14,limit:70,brief:'Мужчине 58 лет, давящая боль за грудиной уже полчаса, холодный пот. Диспетчер просит положить его и не давать ходить.',options:[['ЭКГ и лечение на месте','treat'],['Сразу в больницу, ЭКГ по дороге','scoop']]},
 {name:'Травма',icon:'✚',severity:2,duration:14,limit:100,brief:'Рабочий упал со стремянки на стройке, жалуется на боль в спине и ноге, двигаться не может.',options:[['Обезболить, шина, щит — и в больницу','treat'],['Быстро погрузить и везти','scoop']]},
 {name:'Плохое самочувствие',icon:'+',severity:1,duration:11,limit:160,brief:'Пожилой мужчина третий день слабый, температура, плохо ест. Звонит дочь из другого города.',options:[['Осмотреть и решить, нужна ли больница','assess'],['Сразу везти в больницу','transport']]}
]);
export const EMS_TYPE_IDS=Object.freeze([10,11,12,13]);
export const isEmsType=t=>t>=10&&t<=13;
export const EMS_CHOICES=Object.freeze(['resus','scoop','treat','assess','transport']);
// What the brigade finds (deterministic per call).
const SERIOUS={'ems-chest':.85,'ems-stroke':1,'ems-breath':.45,'ems-allergy':.35,'ems-birth':1,'ems-trauma':.9,'ems-fall':.85,'ems-sport':.5,'ems-cut':.55,'ems-burn':.7,'ems-ice-fall':.75,'ems-unwell':.35,'ems-diabetic':.3,'ems-seizure':.4,'ems-drunk':.2};
export function emsFacts(i){const id=i?.id??0,v=i?.variant;return {
 cpr:hash(id,1)<.6||!!i?.call?.instr?.includes('cpr'),// a bystander started CPR (or the 112 dispatcher talked them into it)
 shockable:hash(id,9)<(hash(id,1)<.6?.55:.3),// ventricular fibrillation: the defibrillator can restart the heart; asystole rarely comes back
 aedNear:hash(id,2)<.35,// a public defibrillator nearby (shops, the station, the sports hall)
 serious:i?.type===10?true:hash(id,3)<(SERIOUS[v]??.5),// needs the hospital
 stemi:v==='ems-chest'&&hash(id,4)<.45,// the ECG shows a heart attack: the cath lab must be warned
 window:hash(id,5)<.7,// stroke: onset known and recent — still in time for clot-busting
 hypo:v==='ems-diabetic'&&hash(id,6)<.8,// low sugar: glucose helps on the spot
 alone:hash(id,7)<.4,// lives alone: harder to leave at home
 age:v==='ems-sport'||v==='ems-cut'?18+Math.floor(hash(id,8)*30):v==='ems-burn'?2+Math.floor(hash(id,8)*6):55+Math.floor(hash(id,8)*35)};}
// ── The patient ───────────────────────────────────────────────────────────────────────────────────
export const PATIENT=Object.freeze({
 start:{'ems-arrest':45,'ems-unconscious':55,'ems-choking':45,'ems-chest':70,'ems-stroke':72,'ems-breath':58,'ems-allergy':55,'ems-birth':85,'ems-trauma':72,'ems-fall':80,'ems-sport':88,'ems-cut':75,'ems-burn':72,'ems-ice-fall':82,'ems-unwell':85,'ems-diabetic':60,'ems-seizure':70,'ems-drunk':82},
 decay:{'ems-arrest':4,'ems-unconscious':1.6,'ems-choking':5,'ems-chest':.7,'ems-stroke':.5,'ems-breath':1.2,'ems-allergy':1.8,'ems-birth':.15,'ems-trauma':.45,'ems-fall':.25,'ems-sport':.1,'ems-cut':.6,'ems-burn':.35,'ems-ice-fall':.25,'ems-unwell':.12,'ems-diabetic':1,'ems-seizure':.6,'ems-drunk':.2},// stability %/world min before the brigade
 cprDecay:.35,// bystander CPR keeps 35 % of the loss
 care:4,// stability %/world min per working brigade (two brigades at most)
 arrestCare:7,rosc:62,resusVehicle:1.5,cprDevice:1.3,// cardiac arrest: defibrillation and CPR
 asystole:.5,late:{cpr:14,none:8},lateCap:55,stopAfter:20,// no shockable rhythm: half the effect; found too late — no return, stop after 20 min
 aed:{minute:4,gain:20},// a volunteer with a public AED (upgrade «responders»)
 critical:40,// below this the brigade cannot leave or finish
 handoverEcg:.55,// an ECG sent ahead shortens the handover at the emergency department
 strokeWindow:45// world minutes from the call to the hospital that still count as «in time» in the game
});
const TIME_CRITICAL=new Set(['ems-chest','ems-stroke','ems-birth','ems-trauma']);
const ON_SCENE=new Set(['ems-breath','ems-allergy','ems-diabetic','ems-seizure','ems-choking','ems-cut']);
export function ensurePatient(i){if(!isEmsType(i?.type))return null;if(i.patient)return i.patient;const f=emsFacts(i),v=i.variant;return i.patient={stability:Math.max(5,(PATIENT.start[v]??70)+(i.type===10&&f.cpr?10:0)),rosc:false,brigades:[],aed:false,result:null};}
// Does the patient go to hospital? Decision, script choice (sets.home) and facts decide.
export function needsHospital(i){const f=emsFacts(i),sets=i.talk?.sets??{};if(sets.home)return false;if(sets.hospital)return true;if(['scoop','transport','resus'].includes(i.decision))return true;if(i.decision==='assess')return f.serious;return f.serious||!ON_SCENE.has(i.variant);}
// Stage of care: a factor of the call progress. `working`: brigades on scene (.vehicleType, .people).
export function patientStep(i,working,dt,opts={}){const p=ensurePatient(i);if(!p)return {rate:1};const m=worldMin(dt),f=emsFacts(i),v=i.variant,sets=i.talk?.sets??{};
 for(const u of working)if(!p.brigades.includes(u.id))p.brigades.push(u.id);if(working.length&&p.arrivedAt===undefined)p.arrivedAt=Math.round((i.age??0)*WORLD_SECONDS_PER_TICK_SECOND/60*10)/10;
 if(!working.length){let loss=(PATIENT.decay[v]??.5)*m*(i.call?.instr?.includes('side')||i.call?.instr?.includes('still')?.7:1);if(i.type===10&&f.cpr)loss*=PATIENT.cprDecay;
  if(i.type===10&&opts.responders&&f.aedNear&&!p.aed&&(i.age??0)*WORLD_SECONDS_PER_TICK_SECOND/60>=PATIENT.aed.minute){p.aed=true;p.stability=Math.min(100,p.stability+PATIENT.aed.gain);}
  p.stability=Math.max(0,p.stability-loss);
  if(p.stability<=0)return {rate:0,failure:i.type===10?'Пациента не удалось спасти: слишком долго без реанимации':'Пациент умер до приезда бригады'};return {rate:0};}
 const crews=Math.min(2,working.length),resus=working.some(u=>u.vehicleType==='resus')?PATIENT.resusVehicle:1;
 if(i.type===10){const arrest=v==='ems-arrest',late=arrest&&!f.shockable&&p.arrivedAt>(f.cpr?PATIENT.late.cpr:PATIENT.late.none);const gain=(i.decision==='scoop'?2:PATIENT.arrestCare)*crews*resus*(opts.cprDevice?PATIENT.cprDevice:1)*(arrest&&!f.shockable?PATIENT.asystole:1)*m;p.stability=Math.min(late?PATIENT.lateCap:100,p.stability+gain);if(p.stability>=PATIENT.rosc)p.rosc=true;
  if(late&&i.decision!=='scoop'){p.resus=(p.resus??0)+m;if(p.resus>=PATIENT.stopAfter)return {rate:0,failure:'Реанимация 20 минут без эффекта: асистолия, слишком поздно — констатирована смерть'};}
  if(i.decision==='scoop')return {rate:.8,carry:true};return {rate:p.rosc?1:0};}
 const scoop=i.decision==='scoop'||i.decision==='transport',half=scoop&&!TIME_CRITICAL.has(v);p.stability=Math.min(100,p.stability+PATIENT.care*crews*resus*(half?.5:1)*m);
 if(p.stability<PATIENT.critical)return {rate:0};
 // A rapid doctor's car has no stretcher: a patient for the hospital waits for an ambulance.
 if(needsHospital(i)&&!working.some(u=>u.transport!==false))return {rate:0,needTransport:true};
 const fit=scoop?(TIME_CRITICAL.has(v)?1.5:.85):i.type===11&&ON_SCENE.has(v)?1.2:1;return {rate:fit*(sets.fast?1.15:1)};}
export function patientOutcome(i,success){const p=i.patient,f=emsFacts(i),v=i.variant,min=Math.round((i.age??0)*WORLD_SECONDS_PER_TICK_SECOND/60);
 if(!success)return i.type===10?'Пациента не удалось спасти':'Бригада не успела: пациенту стало хуже';
 const hosp=needsHospital(i);
 if(i.type===10)return p?.rosc?`Сердце запустилось${p.aed?' (первым был доброволец с дефибриллятором)':''}, пациент доставлен в реанимацию`:'Доставлен в больницу с продолжающейся реанимацией';
 if(v==='ems-stroke')return min<=PATIENT.strokeWindow&&f.window?`Инсульт: доставлен за ${min} мин, в окне для тромболизиса`:'Инсульт: доставлен, но для тромболизиса поздно';
 if(v==='ems-chest')return f.stemi?`Инфаркт на ЭКГ: ${i.talk?.sets?.ecg?'кардиологи предупреждены, сразу в ангиографию':'доставлен в приёмное'}`:'Боль в груди: ЭКГ без инфаркта, доставлен под наблюдение';
 if(v==='ems-birth')return 'Роженица доставлена в родильное отделение';
 if(!hosp)return v==='ems-diabetic'&&f.hypo?'Сахар поднят глюкозой, пациент в сознании — остался дома с родственниками':'Помощь оказана на месте, госпитализация не нужна';
 return 'Пациент стабилизирован и доставлен в приёмное отделение';}
export function validPatient(p){if(p===undefined)return true;const n=(x,a,b)=>Number.isFinite(x)&&x>=a&&x<=b;return !!p&&n(p.stability,0,100)&&typeof p.rosc==='boolean'&&typeof p.aed==='boolean'&&Array.isArray(p.brigades)&&p.brigades.length<=6&&p.brigades.every(Number.isInteger)&&(p.arrivedAt===undefined||n(p.arrivedAt,0,1e5))&&(p.resus===undefined||n(p.resus,0,1e3))&&(p.result===null||typeof p.result==='string'&&p.result.length<=200);}
// A patient left at home who needed the hospital calls again (repeat call, worse).
export const homeMistake=i=>isEmsType(i?.type)&&!!i.talk?.sets?.home&&emsFacts(i).serious;
// ── Units, ranks, career ─────────────────────────────────────────────────────────────────────────
export const EMS_RANKS=Object.freeze(['Стажёр скорой','Медтехник','Медсестра скорой','Старший бригады','Заведующий подстанцией']);
export const EMS_PERMISSIONS=Object.freeze([
 {rank:0,title:'Стажёр скорой',duty:'Работа в бригаде под надзором старшего'},
 {rank:1,title:'Медтехник',duty:'Самостоятельная работа в бригаде, выбор района подстанции'},
 {rank:2,title:'Медсестра скорой',duty:'Ведёт вызов: координация других бригад на месте'},
 {rank:3,title:'Старший бригады',duty:'Выезды между районами, решения о госпитализации сложных пациентов'},
 {rank:4,title:'Заведующий подстанцией',duty:'Все полномочия подстанции'}]);
export const EMS_VEHICLES=Object.freeze({
 ambulance:{label:'Машина скорой помощи (тип B)',short:'Скорая',tank:80,per100:13,idlePerHour:1.2,price:2600,crew:3,transport:true},
 resus:{label:'Реанимобиль (тип C)',short:'Реанимобиль',tank:90,per100:14,idlePerHour:1.4,price:3600,crew:3,transport:true},
 rapid:{label:'Машина врача (без носилок)',short:'Врач',tank:60,per100:9,idlePerHour:.9,price:1600,crew:2,transport:false}
});
export const EMS_CREW_LIMIT=3;
// Ambulances are busier than the rescue station, quieter than the police radio.
export const EMS_CALL_GAP=1.6;
export const EMS_START=Object.freeze([
 {name:'Скорая 01',people:['Вы','Мерле Таль','Андрей Кузнецов'],role:'Бригада · старшая Мерле Таль',vehicle:'ambulance'},
 {name:'Реанимобиль 02',people:['Хельги Рооп','Сергей Мельник','Кайди Пыдер'],role:'Реанимационная бригада',vehicle:'resus'},
 {name:'Скорая 03',people:['Ольга Лаур','Мартин Кесккюла'],role:'Вторая бригада (Майский)',vehicle:'ambulance'}]);
export const EMS_RECRUITS=Object.freeze([
 {id:201,name:'Анне Валлик',specialty:'Экстренная медицина',skill:.84,fee:360,salary:46},
 {id:202,name:'Денис Яковлев',specialty:'Реанимация',skill:.86,fee:410,salary:52},
 {id:203,name:'Пирет Сарв',specialty:'Педиатрия',skill:.8,fee:330,salary:43},
 {id:204,name:'Игорь Тамм',specialty:'Водитель скорой',skill:.78,fee:260,salary:36},
 {id:205,name:'Лаура Мянд',specialty:'Экстренная медицина',skill:.79,fee:300,salary:40},
 {id:206,name:'Райво Кальм',specialty:'Реанимация',skill:.82,fee:370,salary:47},
 {id:207,name:'Элина Корр',specialty:'Экстренная медицина',skill:.88,fee:420,salary:53},
 {id:208,name:'Вадим Ушаков',specialty:'Водитель скорой',skill:.8,fee:280,salary:38}]);
// Between calls: restocking the bag and the drugs, disinfecting the ambulance, CPR lessons in schools.
export const EMS_TASKS=Object.freeze(['restock','disinfect','cpr-school']);
export const emsTaskFor=minute=>{const h=Math.floor((((minute%1440)+1440)%1440)/60);return h>=10&&h<15?(h%2===0?'cpr-school':'restock'):h>=7&&h<22?(h%3===0?'disinfect':null):null;};
