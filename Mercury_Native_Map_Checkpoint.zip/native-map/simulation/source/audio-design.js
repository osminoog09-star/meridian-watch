// Original synthesis parameters. Not recordings of real vehicle models.
export const ENGINE_HARMONICS=Object.freeze([0,1,.46,.22,.15,.09,.05,.025]);
export const SIREN_HARMONICS=Object.freeze([0,1,0,.18,0,.045]);
// R11 (Claude, 11.10.2026): siren modes as crews really use them — long «wail» on open road, fast
// «yelp» in a pursuit and over the last ~200 m to the call, where crews clear junctions and traffic.
export const SIREN_MODES=Object.freeze({wail:{period:3.4,depth:230},yelp:{period:.34,depth:260}});
export const YELP_METRES=200;
export const sirenMode=(unit,metresLeft=Infinity)=>unit?.pursuing===true||metresLeft<YELP_METRES?'yelp':'wail';
export function transportTone(unit,vehicle,time,speed=0,emergency=null,metresLeft=Infinity){const moving=!!unit?.route?.length,urgent=moving&&(emergency??(unit.status==='responding'||unit.pursuing===true)),load=Math.max(0,Math.min(1,Number.isFinite(speed)?speed/60:0)),mode=sirenMode(unit,metresLeft),m=SIREN_MODES[mode];return {moving,urgent,sirenMode:mode,engineHz:(32+load*34+(urgent?5:0))*(vehicle?.type==='suv'?.9:1),engineLevel:moving?.030+.014*load:0,sirenHz:700+Math.sin(time*Math.PI*2/m.period)*m.depth,sirenLevel:urgent?.040:0};}
// R11 weather in sound: rain hiss, stronger gusts in wind, snow muffles the city.
const WEATHER_SOUND=Object.freeze({rain:{rain:1,wind:1.15,traffic:1.1},wind:{rain:0,wind:2.2,traffic:1},snow:{rain:0,wind:.8,traffic:.45},ice:{rain:0,wind:1,traffic:.7},fog:{rain:0,wind:.6,traffic:.8},heat:{rain:0,wind:.5,traffic:1}});
export function weatherSound(kind){const w=WEATHER_SOUND[kind];return {rain:w?.rain??0,wind:w?.wind??1,traffic:w?.traffic??1};}
export const RAIN_LEVEL=.045;
// R11 New Year: fireworks over the city from 23:45 on 31 December to 01:30 on 1 January.
export function fireworksTime(date){if(!date)return false;const m=date.minute??0;return date.month===11&&date.dayOfMonth===31&&m>=23*60+45||date.month===0&&date.dayOfMonth===1&&m<90;}
// Deterministic gap between bursts (seconds) and burst pitch, by burst number.
export function fireworkBurst(n){let h=Math.imul((n|0)+97,2654435761);h^=h>>>15;const r=(h>>>0)/4294967296;return {gap:.5+r*2.2,hz:220+Math.floor(r*997)%420,thump:r<.5};}

// R22 (Claude, 11.10.2026) — sound of the time and place (A5) and of the car's condition (A2/A7).
// Night streets are quieter, the morning and evening rush louder; birds sing on spring and summer days
// (rarely in autumn, never at night or in winter); a stadium or concert crowd murmurs during the event.
const SEASON_BIRDS=Object.freeze({spring:1,summer:.8,autumn:.25,winter:0});
export function timeAmbience(date,eventId=null){if(!date)return {traffic:1,birds:0,crowd:0};const h=Math.floor((date.minute??0)/60),season=['winter','winter','spring','spring','spring','summer','summer','summer','autumn','autumn','autumn','winter'][date.month]??'autumn';
 const traffic=h<5?.35:h<7?.6:h<10?1.2:h<16?1:h<19?1.2:h<23?.85:.55,day=h>=5&&h<20,birds=day?(SEASON_BIRDS[season]??0)*(h<9?1.3:1):0;
 return {traffic,birds,crowd:eventId==='football'||eventId==='concert'?1:0};}
// A bird call: two short upward sweeps; gap and pitch by a counter (no rng).
export function birdCall(n){let h=Math.imul((n|0)+311,2654435761);h^=h>>>15;h=Math.imul(h,2246822519);const r=((h^h>>>13)>>>0)/4294967296;return {gap:2+r*6,from:2400+Math.floor(r*900),to:3300+Math.floor(r*1100),notes:r<.6?2:3};}
export const CROWD_LEVEL=.04;
// A worn car rattles: the engine level wobbles with wear (0–100 %).
export const engineWobble=(wear,time)=>1+Math.max(0,Math.min(100,wear??0))/100*.35*Math.sin(time*29)*Math.sin(time*3.1);
