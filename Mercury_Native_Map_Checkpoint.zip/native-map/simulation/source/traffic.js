import {MAP_METRES} from './world-scale.js';
import {VEHICLE_DYNAMICS} from './transport.js';

export const TRAFFIC=Object.freeze({minimumGap:3.5,emergencyGap:2.5,reactionSeconds:1.4,yieldDistance:70,yieldSpeed:8,yieldOffsetMetres:2,lookAhead:150,junctionLookAhead:120,passKmh:12,junctionClearance:20,junctionStopLine:3,planningSeconds:4.5});
const metres=(a,b)=>Math.hypot(a.x-b.x,a.y-b.y)*MAP_METRES;
const endpoint=e=>e.route?.[0];

function aligned(entity,dx,dy){
 let vx,vy;const next=endpoint(entity);
 if(next){vx=next.x-entity.x;vy=next.y-entity.y;}
 else if(Number.isFinite(entity.heading)){vx=Math.cos(entity.heading);vy=Math.sin(entity.heading);}
 else return false;
 const vl=Math.hypot(vx,vy),sl=Math.hypot(dx,dy);return vl<1e-12||sl<1e-12||((vx*dx+vy*dy)/(vl*sl)>.65);
}

// Distance to another vehicle projected onto the same upcoming path. Looking
// over several short OSM edges prevents a queue from disappearing at a node.
function aheadGap(follower,other,max=TRAFFIC.lookAhead){
 let from=follower,travelled=0;
 for(const to of (follower.route??[]).slice(0,14)){
  const dx=to.x-from.x,dy=to.y-from.y,d2=dx*dx+dy*dy,segment=Math.sqrt(d2)*MAP_METRES;
  if(d2>1e-16){
   const t=((other.x-from.x)*dx+(other.y-from.y)*dy)/d2;
   if(t>=-1e-9&&t<=1+1e-9){const px=from.x+dx*t,py=from.y+dy*t,lateral=Math.hypot(other.x-px,other.y-py)*MAP_METRES,along=travelled+Math.max(0,Math.min(1,t))*segment;if(along>.2&&along<=max&&lateral<=2.4&&aligned(other,dx,dy))return along;}
  }
  travelled+=segment;if(travelled>max)break;from=to;
 }
 return null;
}

function apply(entity,target,reason,leadId){if(target+1e-8<(entity.trafficTargetKmh??Infinity)){entity.trafficTargetKmh=Math.max(0,target);entity.trafficReason=reason;entity.trafficLeadId=leadId;}}
const junctionKey=p=>`${p.x.toFixed(9)}:${p.y.toFixed(9)}`;
function routeJunctions(entity){
 const result=[];let from=entity,distance=0;
 for(const p of (entity.route??[]).slice(0,18)){
  const dx=p.x-from.x,dy=p.y-from.y,length=Math.hypot(dx,dy)*MAP_METRES;distance+=length;
  if(distance>TRAFFIC.junctionLookAhead+1e-8)break;
  if(length>.01)result.push({key:junctionKey(p),point:p,distance,approach:{x:dx/(length/MAP_METRES),y:dy/(length/MAP_METRES)}});
  from=p;
 }
 return result;
}
function clearJunction(entity){delete entity.trafficJunctionKey;delete entity.trafficJunctionX;delete entity.trafficJunctionY;delete entity.trafficJunctionDx;delete entity.trafficJunctionDy;}
function heldJunction(entity){
 if(!entity.route?.length||typeof entity.trafficJunctionKey!=='string'||![entity.trafficJunctionX,entity.trafficJunctionY,entity.trafficJunctionDx,entity.trafficJunctionDy].every(Number.isFinite)){clearJunction(entity);return null;}
 const point={x:entity.trafficJunctionX,y:entity.trafficJunctionY},distance=metres(entity,point);
 if(distance>TRAFFIC.junctionClearance){clearJunction(entity);return null;}
 const approach={x:entity.trafficJunctionDx,y:entity.trafficJunctionDy},passed=(entity.x-point.x)*approach.x+(entity.y-point.y)*approach.y>1e-10;
 return {key:entity.trafficJunctionKey,point,distance,occupied:passed,approach};
}
function holdJunction(entity,node){entity.trafficJunctionKey=node.key;entity.trafficJunctionX=node.point.x;entity.trafficJunctionY=node.point.y;entity.trafficJunctionDx=node.approach.x;entity.trafficJunctionDy=node.approach.y;}
const conflict=(a,b)=>a&&b&&a.x*b.x+a.y*b.y<=.75;
const stoppingTarget=(desired,distance)=>{
 const usable=Math.max(0,distance-TRAFFIC.junctionStopLine),a=VEHICLE_DYNAMICS.braking,t=TRAFFIC.planningSeconds;
 // Account for the whole interval until the next fixed simulation decision,
 // then leave enough physical braking distance before the stop line.
 const metresPerSecond=Math.max(0,-a*t+Math.sqrt((a*t)**2+2*a*usable));
 return Math.min(desired,metresPerSecond*3.6);
};

// Items: {entity,id,desired,emergency,blocking}. The planner only changes
// targets/reasons. advanceVehicle remains the sole owner of movement.
export function planTraffic(items){
 for(const item of items){const e=item?.entity;if(!e)continue;e.trafficTargetKmh=Number.isFinite(item.desired)?item.desired:0;e.trafficReason=null;e.trafficLeadId=null;e.yieldingToEmergency=false;}
 const drivers=items.filter(i=>i?.entity?.route?.length&&Number.isFinite(i.desired)&&i.desired>=0),obstacles=items.filter(i=>i?.entity&&(i.entity.route?.length||i.blocking));

 // Mark a civilian first. An emergency vehicle must not brake behind a car
 // that has already moved into the visual emergency corridor.
 for(const item of drivers){
  if(item.emergency)continue;const e=item.entity;
  const approaching=drivers.filter(o=>o.emergency).map(o=>({...o,gap:aheadGap(o.entity,e,TRAFFIC.yieldDistance)})).filter(o=>o.gap!==null).sort((a,b)=>a.gap-b.gap)[0];
  if(approaching){e.yieldingToEmergency=true;e.trafficTargetKmh=Math.min(e.trafficTargetKmh,TRAFFIC.yieldSpeed);e.trafficReason='Уступает экстренному экипажу';e.trafficLeadId=approaching.id;}
 }

 for(const item of drivers){
  const e=item.entity,minimum=item.emergency?TRAFFIC.emergencyGap:TRAFFIC.minimumGap;
  // A crew already working a call does not block the second crew driving to the same call (`scene`):
  // it parks alongside (Claude, 11.10.2026: crews stood forever
  // one point short of the scene behind the first crew).
  const atGoal=o=>o.blocking&&item.scene!=null&&o.scene===item.scene;
  const leaders=obstacles.filter(o=>o!==item&&!(item.emergency&&o.entity.yieldingToEmergency)&&!atGoal(o)).map(o=>({...o,gap:aheadGap(e,o.entity)})).filter(o=>o.gap!==null).sort((a,b)=>a.gap-b.gap);
  const lead=leaders[0];if(!lead)continue;
  const desiredGap=minimum+Math.max(0,e.motionSpeedKmh??e.currentSpeedKmh??0)/3.6*TRAFFIC.reactionSeconds,span=Math.max(.1,desiredGap-minimum),factor=Math.max(0,Math.min(1,(lead.gap-minimum)/span));
  // Claude 23.10 (owner: «две машины зависли в одном месте и всё»): a car standing at another call — a crew at work, a
  // broken-down vehicle — is driven around at walking pace, never waited behind for the rest of the shift.
  if(lead.blocking&&!lead.entity.route?.length){apply(e,Math.min(item.desired,Math.max(item.desired*factor,TRAFFIC.passKmh)),'Объезжает стоящую машину',lead.id);continue;}
  apply(e,item.desired*factor,factor===0?'Ожидает свободный участок':'Держит дистанцию',lead.id);
 }

 const junctions=new Map();
 for(const item of drivers){
  const held=heldJunction(item.entity),nodes=routeJunctions(item.entity);if(held)nodes.unshift(held);
  for(const node of nodes){const group=junctions.get(node.key)??[];if(!group.some(entry=>entry.item===item))group.push({item,node});junctions.set(node.key,group);}
 }
 for(const group of junctions.values()){
  const conflicts=group.filter((entry,k)=>group.some((other,n)=>n!==k&&conflict(entry.node.approach,other.node.approach)));
  if(conflicts.length<2)continue;
  conflicts.sort((a,b)=>Number(!!b.node.occupied)-Number(!!a.node.occupied)||Number(!!b.item.emergency)-Number(!!a.item.emergency)||a.node.distance-b.node.distance||String(a.item.id).localeCompare(String(b.item.id)));
  const winner=conflicts[0];holdJunction(winner.item.entity,winner.node);
  for(const entry of conflicts.slice(1)){
   if(!conflict(winner.node.approach,entry.node.approach))continue;
   if(entry.item.entity.trafficJunctionKey===entry.node.key)clearJunction(entry.item.entity);
   apply(entry.item.entity,stoppingTarget(entry.item.desired,entry.node.distance),'Пропускает на перекрёстке',winner.item.id);
  }
 }
 // Deadlock breaker (Claude, 11.10.2026): cars stopped while yielding to each other in a cycle
 // (A waits for B, B waits for A — seen at the station after custody/refuel stops) would stand
 // forever. The first car of the cycle by id releases its hold and proceeds; the cycle is
 // re-checked every planning step, so it clears in a few ticks without random choices.
 const byId=new Map(drivers.map(i=>[i.id,i]));
 for(const item of drivers){if(item.entity.trafficTargetKmh>0)continue;const cycle=[item];let cur=item;
  for(let k=0;k<drivers.length;k++){const next=byId.get(cur.entity.trafficLeadId);if(!next||next.entity.trafficTargetKmh>0)break;
   if(next===item){const go=cycle.slice().sort((a,b)=>String(a.id).localeCompare(String(b.id)))[0];if(go.entity.trafficJunctionKey)clearJunction(go.entity);go.entity.trafficTargetKmh=go.desired;go.entity.trafficReason='Разъезжается после взаимной уступки';go.entity.trafficLeadId=null;break;}
   if(cycle.includes(next))break;cycle.push(next);cur=next;}}
 return drivers.map(i=>({id:i.id,target:i.entity.trafficTargetKmh,reason:i.entity.trafficReason,yielding:i.entity.yieldingToEmergency}));
}
