// «Живые вызовы» v1 (Claude, 11.10.2026). Realistic call variants on top of the six existing
// call mechanics: TYPES indices, scenes, decisions, assessment and saves keep working unchanged;
// an incident only gains a `variant` id that changes its shown name, brief, timing and place.
// Mix roughly follows Estonian police call categories (public order ~31%, traffic ~19%,
// violence ~14%; ERR/PPA) and typical night calls: alcohol, noise, traffic, family disputes.
import {SPECIALTIES,specialtyFor} from './professional.js';
import {SEASON_WEATHER} from './season.js';

// hours: when the call is most likely; place: preferred kind of location.
export const VARIANTS=Object.freeze([
 // 0 — public order (talk / check)
 {id:'noise-venue',type:0,name:'Шум у заведения',brief:'Посетители спорят у входа. Заявитель просит восстановить порядок.',hours:'night',place:'centre',w:3},
 {id:'noise-flat',type:0,name:'Громкая музыка в квартире',brief:'Соседи жалуются на музыку после 23:00. Хозяин квартиры открывает не сразу.',hours:'night',place:'residential',w:4},
 {id:'drunk-person',type:0,name:'Человек в опьянении на остановке',brief:'Прохожий сообщает: мужчина в сильном опьянении сидит на остановке и не может уйти сам. Нужно убедиться, что ему не требуется помощь.',hours:'night',place:'road',w:4},
 {id:'yard-company',type:0,name:'Шумная компания во дворе',brief:'Компания распивает алкоголь во дворе жилого дома. Жильцы просят приехать.',hours:'evening',place:'residential',w:2},
 // 1 — traffic scene (secure / backup)
 {id:'crash',type:1,name:'Дорожное происшествие',brief:'На перекрёстке столкнулись две машины. Нужно обезопасить место и проверить участников.',hours:'evening',place:'road',w:4},
 {id:'animal-road',type:1,name:'Животное на дороге',brief:'Водитель сообщает о сбитой косуле на проезжей части. Нужно обезопасить место и предупредить других водителей.',hours:'night',place:'road',w:1},
 {id:'fire-smoke',type:1,name:'Дым из окна квартиры',brief:'Соседи видят дым из окна жилого дома. Спасатели выехали; полиции нужно оцепить подъезд и помочь вывести жильцов.',hours:'any',place:'residential',w:1},
 {id:'blocked-exit',type:1,name:'Машина перекрыла проезд',brief:'Автомобиль брошен поперёк выезда, жильцы не могут уехать. Нужно обезопасить проезд и найти владельца.',hours:'day',place:'residential',w:1},
 // 2 — search (talk / check)
 {id:'missing-elder',type:2,name:'Пропал человек',brief:'Родственник потерял связь с пожилым человеком. Последний раз его видели у парка.',hours:'any',place:'any',w:2},
 {id:'missing-child',type:2,name:'Ребёнок не вернулся домой',brief:'Мать сообщает: сын десяти лет не вернулся после тренировки, телефон не отвечает.',hours:'evening',place:'residential',w:1},
 // 3 — theft (check / talk)
 {id:'shoplift',type:3,name:'Кража в магазине',brief:'Охрана сообщает о краже. Участники находятся рядом с магазином.',hours:'day',place:'centre',w:3},
 {id:'bike-theft',type:3,name:'Кража велосипеда',brief:'Владелец нашёл срезанный замок у подъезда. Свидетель видел, куда ушёл подозреваемый.',hours:'day',place:'residential',w:2},
 // Only from an investigation lead (weight 0: never random, the call mix does not change).
 {id:'suspect-found',type:3,name:'Подозреваемый замечен',brief:'По приметам из дела замечен подозреваемый в краже. Нужно проверить документы и задержать.',hours:'any',place:'any',w:0},
 {id:'car-break',type:3,name:'Взлом автомобиля',brief:'Сработала сигнализация, у машины разбито стекло. Свидетель ждёт рядом.',hours:'night',place:'residential',w:1},
 // 4 — violence (talk / backup)
 {id:'street-fight',type:4,name:'Конфликт на улице',brief:'Несколько человек конфликтуют. Обстановка напряжённая — рекомендуется подкрепление.',hours:'night',place:'centre',w:3},
 {id:'domestic',type:4,name:'Семейный конфликт',brief:'Соседка слышит крики и звук разбитой посуды за стеной. Обстановка может быть опасной — рекомендуется второй экипаж.',hours:'night',place:'residential',w:3},
 // 5 — vehicle (check / chase / observe)
 {id:'vehicle-alert',type:5,name:'Проверка автомобиля',brief:'Поступила ориентировка на автомобиль. Проверьте водителя. Он может сотрудничать или попытаться уехать.',hours:'any',place:'road',w:2},
 {id:'drunk-driver',type:5,name:'Возможно нетрезвый водитель',brief:'Водитель сообщает: машина впереди виляет по полосам. Номер известен.',hours:'night',place:'road',w:3},
 {id:'dangerous-driving',type:5,name:'Опасная езда',brief:'Несколько звонков: машина сильно превышает скорость и обгоняет по встречной.',hours:'evening',place:'road',w:2},
 {id:'no-licence',type:5,name:'Водитель без прав',brief:'Соседи сообщают: мужчина давно ездит без водительских прав, машина сейчас на ходу.',hours:'day',place:'residential',w:1},
 // R13 (Claude, 11.10.2026): calls of a real Estonian patrol shift, only in roster campaigns (`roster`)
 // and some only in a season (`seasons`), so older campaigns keep exactly the same call mix.
 {id:'confused-person',type:0,name:'Человек в спутанном сознании',brief:'Прохожие сообщают: пожилая женщина в домашней одежде идёт по проезжей части и не может назвать адрес. Нужно увести её в безопасное место, скорая выехала.',hours:'any',place:'road',w:1,roster:true},
 {id:'restraining-order',type:4,name:'Нарушение запрета на приближение',brief:'Женщина сообщает: бывший партнёр стоит у двери квартиры, хотя суд запретил ему приближаться. Он агрессивен — рекомендуется второй экипаж.',hours:'evening',place:'residential',w:1.5,roster:true},
 {id:'phone-scam',type:3,name:'Курьер телефонных мошенников',brief:'Пенсионерке позвонили «из банка» и велели отдать сбережения курьеру. Она догадалась и позвонила 112 — курьер едет к её дому.',hours:'day',place:'residential',w:1.5,roster:true},
 {id:'fuel-driveoff',type:3,name:'Уехал с АЗС без оплаты',brief:'Оператор АЗС сообщает: водитель заправил полный бак и уехал не заплатив. Номер записан камерой, машину видели на соседней улице.',hours:'any',place:'road',w:1,roster:true},
 {id:'school-speeding',type:5,name:'Превышение у школы',brief:'Родители жалуются: у школы машины едут намного быстрее 30 км/ч. Нарушитель только что проехал мимо — нужно остановить и составить протокол.',hours:'day',place:'residential',w:1,roster:true},
 {id:'lost-child-mall',type:2,name:'Ребёнок потерялся в торговом центре',brief:'Туристка из Финляндии потеряла сына пяти лет в торговом центре. Говорит по-английски и по-фински, очень волнуется.',hours:'day',place:'centre',w:1,roster:true},
 {id:'thin-ice',type:2,name:'Рыбаки на тонком льду',brief:'С берега видят двух рыбаков далеко на льду у устья реки, лёд трещит. Нужно найти их и вернуть на берег, спасатели предупреждены.',hours:'day',place:'any',w:1.5,roster:true,seasons:['winter']},
 // R18: calls that only happen during a city event (`events`, events.js).
 {id:'tree-down',type:1,name:'Дерево упало на дорогу',brief:'Ветер повалил дерево поперёк проезжей части, машины объезжают по встречной. Нужно перекрыть участок до приезда спасателей с пилой.',hours:'any',place:'road',w:6,roster:true,events:['storm']},
 {id:'power-lines',type:1,name:'Оборван провод',brief:'На тротуар упал оборванный провод, рядом ходят люди. Нужно оцепить место и не подпускать прохожих до приезда энергетиков.',hours:'any',place:'residential',w:3,roster:true,events:['storm']},
 {id:'fan-fight',type:4,name:'Драка болельщиков',brief:'У стадиона сцепились две группы фанатов, летят бутылки. Своими силами не справиться — нужен второй экипаж.',hours:'any',place:'centre',w:6,roster:true,events:['football']},
 {id:'lost-at-concert',type:2,name:'Подросток потерялся на концерте',brief:'Отец не может найти дочь четырнадцати лет в толпе у сцены, телефон разряжен.',hours:'any',place:'centre',w:5,roster:true,events:['concert']},
 {id:'alarm-burglary',type:3,name:'Сработала охранная сигнализация',brief:'Без света сработала сигнализация магазина. Охрана видит на камере человека у задней двери.',hours:'any',place:'centre',w:6,roster:true,events:['outage']},
 {id:'beach-party',type:0,name:'Ночная вечеринка на пляже',brief:'Жильцы у пляжа жалуются: большая компания с колонкой и костром, на песке разбитые бутылки.',hours:'night',place:'any',w:2,roster:true,seasons:['summer']}
]);
const byId=new Map(VARIANTS.map(v=>[v.id,v]));
export const variantOf=i=>byId.get(i?.variant)??null;
export const validVariant=i=>i.variant===undefined||byId.get(i.variant)?.type===i.type;
// The first variant of each type is the original wording of that type.
export const defaultVariant=type=>VARIANTS.find(v=>v.type===type)??null;

export function hourBucket(minuteOfDay){const h=Math.floor(((minuteOfDay%1440)+1440)%1440/60);return h>=22||h<6?'night':h>=17?'evening':'day';}
const ORDER=['day','evening','night'];
function hourFactor(variant,bucket){if(variant.hours==='any')return 1;const d=Math.abs(ORDER.indexOf(variant.hours)-ORDER.indexOf(bucket));return d===0?2:d===1?1:.5;}
// Roster-only and seasonal variants: the campaign's weather carries its season only in roster campaigns.
export const variantAllowed=(v,weather)=>(!v.roster||!!weather?.season)&&(!v.seasons||v.seasons.includes(weather?.season))&&(!v.events||v.events.includes(weather?.event?.id));
export function variantWeights(minuteOfDay,weather=null){const bucket=hourBucket(minuteOfDay);return VARIANTS.map(v=>variantAllowed(v,weather)?v.w*hourFactor(v,bucket)*weatherFactor(weather,v.id):0);}
export function pickVariant(random,minuteOfDay,weather=null){const weights=variantWeights(minuteOfDay,weather),total=weights.reduce((a,b)=>a+b,0);let r=random*total;for(let k=0;k<VARIANTS.length;k++){r-=weights[k];if(r<0)return VARIANTS[k];}return VARIANTS.at(-1);}

// Place preference among patrol targets. Falls back to every node when nothing matches.
const ROAD_KINDS=new Set(['primary','secondary','tertiary','trunk','primary_link','secondary_link','tertiary_link']),HOME_KINDS=new Set(['residential','living_street','unclassified','service']);
export function placeNodes(nodes,place,centre,centreRadius=.18){
 const match=place==='centre'?n=>Math.hypot(n.x-centre.x,n.y-centre.y)<centreRadius:place==='road'?n=>ROAD_KINDS.has(n.kind):place==='residential'?n=>HOME_KINDS.has(n.kind):()=>true;
 const list=nodes.filter(match);return list.length?list:nodes;
}

// Crew fit: an officer whose specialty matches the call works faster.
export const FIT_BONUS=1.15;
const SPECIALTY_KEYS=Object.freeze({'Переговоры':'negotiation','Поиск':'search','Дорожная полиция':'traffic','Вождение':'traffic','Проверка обстоятельств':'investigation'});
export const officerSpecialtyKey=specialty=>SPECIALTY_KEYS[specialty]??null;
export const callSpecialty=type=>({key:specialtyFor(type),label:SPECIALTIES[specialtyFor(type)]});
export function crewFits(officers,type){const key=specialtyFor(type);return officers.some(o=>officerSpecialtyKey(o?.specialty)===key||(Array.isArray(o?.extra)&&o.extra.includes(key)));}/* Release C2: a second specialty from a course counts too */

// «Последствия» v2 (Claude, 11.10.2026). Outcomes leave traces: a call handled softly or
// lost may return later in the same shift, and each district keeps its own trust.
export const variantById=id=>byId.get(id)??null;
export const DISTRICT_IDS=Object.freeze(['centre','ulejoe','raama','beach','mai','papiniidu','vana','raekula']);
// ok / fail: base chance of a follow-up after success / failure; okBackup: success with a second crew.
export const FOLLOW_UPS=Object.freeze({
 'noise-flat':{ok:.25,fail:.6,next:'noise-flat',reason:'Соседи звонят снова: музыка не прекратилась.'},
 'noise-venue':{ok:.15,fail:.45,next:'street-fight',reason:'Спор у заведения перерос в драку.'},
 'yard-company':{ok:.2,fail:.5,next:'street-fight',reason:'Компания во дворе снова шумит, начался конфликт.'},
 'drunk-person':{ok:.15,fail:.4,next:'drunk-person',reason:'Тот же человек снова лежит на улице.'},
 'domestic':{ok:.3,okBackup:.1,fail:.6,next:'domestic',reason:'Соседка звонит снова: крики возобновились.'},
 'street-fight':{ok:.1,fail:.4,next:'street-fight',reason:'Участники прежнего конфликта встретились снова.'},
 'drunk-driver':{ok:.05,fail:.5,next:'crash',reason:'Водитель, которого не остановили, попал в ДТП.'},
 'dangerous-driving':{ok:.05,fail:.4,next:'crash',reason:'Машина, которую не остановили, попала в ДТП.'},
 'shoplift':{ok:.05,fail:.3,next:'shoplift',reason:'Тот же магазин: повторная кража.'},
 'bike-theft':{ok:.05,fail:.25,next:'car-break',reason:'В том же дворе вскрыта машина.'},
 'restraining-order':{ok:.25,okBackup:.1,fail:.6,next:'domestic',reason:'Бывший партнёр вернулся, за дверью снова крики.'},
 'beach-party':{ok:.2,fail:.5,next:'street-fight',reason:'На пляже после вечеринки началась драка.'},
 'school-speeding':{ok:.05,fail:.3,next:'crash',reason:'У той же школы машина сбила велосипедиста.'}
});
// Low district trust makes repeat complaints more likely (×1.6 at 0%, ×0.6 at 100%).
export function followUpChance(variantId,success,decision,districtTrust=70){const r=FOLLOW_UPS[variantId];if(!r)return 0;const base=success?(decision==='backup'&&r.okBackup!==undefined?r.okBackup:r.ok):r.fail,trust=Number.isFinite(districtTrust)?Math.max(0,Math.min(100,districtTrust)):70;return Math.min(.9,base*(1.6-trust/100));}
export const FOLLOW_UP_DELAY=[30,80];
export const DISTRICT_TRUST_STEP={success:3,failure:-6};

// «Погода смены» (Claude, 11.10.2026). One weather per shift, derived from seed and shift number
// without consuming the campaign random stream. It changes the call mix and the map overlay only.
export const WEATHER=Object.freeze({
 clear:{label:'Ясно',icon:'☀',temps:[14,22],mods:{'yard-company':1.3,'noise-venue':1.2,'street-fight':1.1}},
 rain:{label:'Дождь',icon:'☂',temps:[6,14],mods:{crash:2,'animal-road':1.2,'yard-company':.5,'noise-venue':.7,'street-fight':.6,'bike-theft':.6,'drunk-person':.8}},
 fog:{label:'Туман',icon:'≋',temps:[3,10],mods:{crash:1.6,'animal-road':2,'dangerous-driving':.7}},
 wind:{label:'Ветер',icon:'≈',temps:[5,13],mods:{'blocked-exit':1.5,'yard-company':.7}},
 // Seasonal kinds (roster campaigns only, season.js).
 snow:{label:'Снег',icon:'❄',temps:[-9,-1],mods:{crash:2.5,'animal-road':1.3,'blocked-exit':1.6,'yard-company':.3,'noise-venue':.7,'bike-theft':.2,'street-fight':.7}},
 ice:{label:'Гололёд',icon:'⛸',temps:[-3,1],mods:{crash:3,'drunk-person':1.3,'yard-company':.3,'bike-theft':.3}},
 heat:{label:'Жара',icon:'☀',temps:[25,31],mods:{'yard-company':1.6,'noise-venue':1.4,'street-fight':1.3,'drunk-person':1.3,'noise-flat':1.2,'bike-theft':1.3}}
});
const WEATHER_ORDER=['clear','clear','rain','clear','fog','rain','wind','clear'];
export function weatherFor(seed,shift,season=null){const h=Math.abs(Math.imul((seed>>>0)^0x9e3779b9,31)+Math.imul(shift|0,7919))>>>0,table=season?SEASON_WEATHER[season]:null,order=table?.order??WEATHER_ORDER,kind=order[h%order.length],[lo,hi]=table?.temps?.[kind]??WEATHER[kind].temps;return {kind,temp:lo+(h>>>8)%(hi-lo+1),...(season?{season}:{})};}
// `prevention`: R13 short-lived effect of patrol work (patrolwork.js), e.g. fewer drunk drivers after a checkpoint.
export const weatherFactor=(weather,variantId)=>(WEATHER[weather?.kind]?.mods?.[variantId]??1)*(weather?.event?.mods?.[variantId]??1)*(weather?.prevention?.[variantId]??1);

// «Задержание и доставка» — 0.7.0 v1 (Claude, 11.10.2026). A successful call whose decision
// leads to an arrest keeps one crew busy: drive the detainee to the station, hand over, report.
export const CUSTODY=Object.freeze({
 'street-fight':['talk','backup'],'noise-venue':['backup'],'domestic':['talk','backup'],
 'drunk-driver':['check','chase'],'dangerous-driving':['check','chase'],'no-licence':['check','chase'],
 'shoplift':['check','talk'],'car-break':['check'],'bike-theft':['check'],'suspect-found':['check','talk'],
 'restraining-order':['talk','backup'],'phone-scam':['check','talk'],'fan-fight':['backup'],'alarm-burglary':['check'],'fuel-driveoff':['check'],'school-speeding':['chase']
});
export const custodyFor=(variantId,decision)=>!!CUSTODY[variantId]?.includes(decision);
// 0.7.0 step 2: at the scene the player may arrest or release with a warning. Without an explicit
// choice the old rule applies (arrest-type decision → arrest). Warning frees the crew at once but
// makes a repeat call likelier; arrest costs crew time but closes the case.
export const CUSTODY_CHOICES=Object.freeze({arrest:'Задержать',warn:'Отпустить с предупреждением'});
export const CUSTODY_FOLLOW_UP=Object.freeze({arrest:.4,warn:1.5});
export const canChooseCustody=variantId=>!!CUSTODY[variantId];
export function custodyDecision(i){if(!CUSTODY[i?.variant])return null;if(i.custodyChoice==='arrest'||i.custodyChoice==='warn')return i.custodyChoice;return custodyFor(i.variant,i.decision)?'arrest':'warn';}
export const HANDOVER_TIME=6;
export const CUSTODY_REWARD=Object.freeze({trust:1,district:2,xp:10});

// 0.7.1 v1 «Скорая помощь» (Claude, 11.10.2026): first non-police service. When police reach a
// call with possible injuries, an ambulance drives from the hospital, treats on scene and takes
// the patient to hospital. Runs alongside the police call; arriving in time adds public trust.
export const MEDICAL=Object.freeze({crash:'Пострадавшие в ДТП','drunk-person':'Человеку плохо','street-fight':'Есть пострадавшие','confused-person':'Спутанность сознания, нужен осмотр врача','thin-ice':'Переохлаждение после льда'});
export const needsAmbulance=variantId=>!!MEDICAL[variantId];
// 0.7.1 v2 (Claude, 11.10): more medical cases, decided by the call id (no rng): every second family
// conflict has an injured person; every third missing elderly person is found cold and weak.
export const MEDICAL_SOMETIMES=Object.freeze({domestic:{every:2,text:'Пострадавшая при семейном конфликте'},'missing-elder':{every:3,text:'Найденному нужна помощь: переохлаждение'}});
export const needsAmbulanceFor=i=>!!MEDICAL[i?.variant]||(!!MEDICAL_SOMETIMES[i?.variant]&&Number.isInteger(i.id)&&i.id%MEDICAL_SOMETIMES[i.variant].every===0);
export const medicalText=i=>MEDICAL[i?.variant]??MEDICAL_SOMETIMES[i?.variant]?.text??'Нужна помощь';
export const AMBULANCE=Object.freeze({treatTime:8,handoverTime:4,maxActive:3,kmh:60,trustBonus:1,paint:'#ece8c4',lights:'blue'});

// 0.7.2 v1 «Спасатели» (Claude, 11.10.2026): second service. A fire call alerts rescuers at once
// (112 is shared); a crash with a trapped driver alerts them when police reach the scene. Rescuers
// set up a safe zone, work (faster while police hold the cordon), then return to their station.
export const RESCUE=Object.freeze({'fire-smoke':'Возгорание в квартире',crash:'Водителя зажало в машине','thin-ice':'Люди на тонком льду','tree-down':'Дерево на дороге, нужна пила'});
// Every fire needs rescuers; a deterministic third of crashes (no RNG draw: campaign seeds unchanged).
export const needsRescue=i=>i?.variant==='fire-smoke'||i?.variant==='thin-ice'||i?.variant==='tree-down'||(i?.variant==='crash'&&Number.isInteger(i.id)&&i.id%3===0);
export const RESCUE_TEAM=Object.freeze({secureTime:3,workTime:{'fire-smoke':14,crash:9,'thin-ice':10,'tree-down':8},cordonSpeed:1.5,maxActive:2,kmh:55,trustBonus:1,paint:'#c23a2c',lights:'blue'});
export const SERVICE_LIMIT=AMBULANCE.maxActive+RESCUE_TEAM.maxActive;

// 0.7.0 step 3 «Дела смены» (Claude, 11.10.2026): every closed call becomes a short case record.
export const CASE_LIMIT=30;

// 0.7.0 step 4 «Розыск» (Claude, 11.10.2026): an unsolved theft stays open as a case. Evidence the
// crew collected (decision before the failure) raises the chance that the suspect is spotted later;
// then a «Подозреваемый замечен» call appears. All rolls are hashes of the call id, not rng().
export const THEFTS=Object.freeze(['shoplift','bike-theft','car-break','phone-scam','fuel-driveoff','alarm-burglary']);
export const EVIDENCE=Object.freeze({check:'записи камер и следы на месте',talk:'приметы со слов свидетеля'});
export const LEAD_RULES=Object.freeze({base:.35,evidence:.35,delay:[50,100]});
export const leadHash=(id,salt=0)=>{let h=Math.imul((id|0)+97,2246822519)^Math.imul(salt+13,3266489917);h^=h>>>13;h=Math.imul(h,1274126177);return ((h^h>>>16)>>>0)/4294967296;};
export function leadFor(i,extra=0){if(!THEFTS.includes(i?.variant))return null;const evidence=EVIDENCE[i.decision]??null,chance=Math.min(.95,LEAD_RULES.base+(evidence?LEAD_RULES.evidence:0)+extra),[a,b]=LEAD_RULES.delay;
 return {evidence,chance,found:leadHash(i.id,1)<chance,delay:a+leadHash(i.id,2)*(b-a)};}

// Paperwork after a call (Claude, 11.10.2026): what the patrol actually files — a misdemeanour
// protocol, materials for criminal police, a referral to social services and so on.
const P=(warn,arrest=warn)=>custody=>custody==='arrest'?arrest:warn;
export const PROTOCOLS=Object.freeze({
 'noise-flat':P('Протокол о нарушении ночной тишины','Доставлен в участок, протокол о проступке'),
 'noise-venue':P('Предупреждение заведению, рапорт в ведомость','Доставлен, протокол о нарушении порядка'),
 'yard-company':P('Протокол о распитии в общественном месте','Доставлен, протокол о проступке'),
 'drunk-person':P('Передан родным, рапорт','В камеру протрезвления, рапорт'),
 'crash':P('Схема ДТП, объяснения участников'),
 'animal-road':P('Сообщение службе дорог'),
 'blocked-exit':P('Найден владелец / вызван эвакуатор, протокол о стоянке'),
 'fire-smoke':P('Сведения переданы спасателям для акта о пожаре'),
 'missing-elder':P('Розыск закрыт, человек передан родственникам'),
 'missing-child':P('Розыск закрыт, ребёнок передан родителям, сведения — соцработнику'),
 'shoplift':P('Протокол о мелкой краже','Доставлен, материалы о краже'),
 'bike-theft':P('Заявление принято, материалы — в криминальную полицию','Задержан подозреваемый, материалы о краже'),
 'car-break':P('Заявление принято, следы зафиксированы','Задержан подозреваемый, материалы о взломе'),
 'street-fight':P('Объяснения участников, протокол о нарушении порядка','Задержан, материалы о побоях'),
 'domestic':P('Предупреждение, сведения — соцработнику','Задержан, материалы о семейном насилии, сведения — соцработнику'),
 'vehicle-alert':P('Машина и водитель проверены по базе','Задержан, машина в розыске'),
 'drunk-driver':P('Алкометр, протокол, водитель отстранён от управления','Задержан, материалы о вождении в опьянении'),
 'dangerous-driving':P('Протокол о превышении скорости','Задержан, материалы об опасной езде'),
 'no-licence':P('Протокол о вождении без права управления','Задержан, машина на штрафстоянку'),
 'suspect-found':P('Подозреваемый опрошен','Задержан по делу, материалы — следователю'),
 'confused-person':P('Передана врачам скорой, родственники найдены по базе'),
 'restraining-order':P('Предупреждение, рапорт о нарушении запрета — в суд','Задержан за нарушение запрета, материалы — следователю'),
 'phone-scam':P('Заявление о мошенничестве, материалы — в криминальную полицию','Курьер задержан, материалы о мошенничестве — следователю'),
 'fuel-driveoff':P('Водитель оплатил топливо, протокол о проступке','Задержан, материалы о краже топлива'),
 'school-speeding':P('Протокол о превышении скорости в школьной зоне','Водитель отстранён, протокол и материалы об опасной езде'),
 'lost-child-mall':P('Ребёнок найден и передан матери, рапорт'),
 'thin-ice':P('Рыбаки выведены на берег, предупреждение о запрете выхода на лёд'),
 'beach-party':P('Протокол о распитии и разведении костра на пляже','Доставлен, протокол о нарушении порядка'),
 'tree-down':P('Участок перекрыт, дерево убрано спасателями, сообщение службе дорог'),
 'power-lines':P('Место оцеплено, сведения переданы энергетикам'),
 'fan-fight':P('Объяснения участников, протокол о нарушении порядка','Задержаны зачинщики, материалы о хулиганстве'),
 'lost-at-concert':P('Подросток найден и передан отцу, рапорт'),
 'alarm-burglary':P('Объект осмотрен, следы проникновения зафиксированы','Задержан на месте, материалы о краже со взломом')
});
export const protocolFor=(variant,custody)=>PROTOCOLS[variant]?.(custody)??null;
