// Evidence is written only at successful simulation transitions, never by UI rendering.
export const LESSONS=Object.freeze([
 {kind:'accepted',title:'Принять вызов',hint:'Автомат сам принимает доступные вызовы. В ручном режиме выберите вызов и направьте Патруль 01.'},
 {kind:'arrived',title:'Прибыть на место',hint:'Дождитесь прибытия по улицам. Пока едем, оцените описание и приоритет вызова.'},
 {kind:'decision',title:'Выбрать действие',hint:'Наставник действует в автомате. В ручном режиме откройте карточку вызова и выберите действие.'},
 {kind:'resolved',title:'Завершить помощь',hint:'Дождитесь исхода. Неудачный вызов сохраняется в разборе; можно продолжить обучение на следующем.'}
]);
const kinds=new Set([...LESSONS.map(x=>x.kind),'failed']);
export function ensureTraining(s){if(s.training===undefined)s.training=s.mode==='career'?{version:1,startShift:s.shift,startTime:s.time,legacy:s.time>0||s.shift>1,events:[],completed:false}:null;return s.training;}
export function trainingEvent(s,kind,incident,manual=false,detail=''){
 const t=ensureTraining(s);if(!t||t.completed||!kinds.has(kind))return;
 if(t.events.some(e=>e.kind===kind&&e.incident===incident.id&&e.detail===detail))return;
 t.events.push({kind,incident:incident.id,shift:s.shift,time:Math.min(s.time,s.shiftLength),manual,detail});
 if(t.events.length>64){const first=new Set(LESSONS.map(l=>t.events.find(e=>e.kind===l.kind)).filter(Boolean));const discard=t.events.findIndex(e=>!first.has(e));t.events.splice(discard,1);}
 t.completed=LESSONS.every(l=>t.events.some(e=>e.kind===l.kind));
}
export function trainingSummary(s){const t=s.training;if(!t)return null;const lessons=LESSONS.map(l=>({...l,event:t.events.find(e=>e.kind===l.kind)??null}));return {lessons,completed:t.completed,done:lessons.filter(l=>l.event).length,manual:t.events.filter(e=>e.kind==='decision'&&e.manual).length,automatic:t.events.filter(e=>e.kind==='decision'&&!e.manual).length,failed:t.events.filter(e=>e.kind==='failed').length,legacy:t.legacy,events:t.events.slice(),hint:t.completed?'Первый цикл пройден. Продолжайте службу: полномочия и специализации — следующий этап.':lessons.find(l=>!l.event).hint};}
export function validTraining(s){const t=s.training;if(t===undefined)return true;if(s.mode==='chief')return t===null;if(!t||t.version!==1||!Number.isInteger(t.startShift)||t.startShift<1||t.startShift>s.shift||!Number.isFinite(t.startTime)||t.startTime<0||t.startTime>s.shiftLength||typeof t.legacy!=='boolean'||typeof t.completed!=='boolean'||!Array.isArray(t.events)||t.events.length>64)return false;let previous=(t.startShift-1)*s.shiftLength+t.startTime;for(const e of t.events){if(!e||!kinds.has(e.kind)||!Number.isInteger(e.incident)||e.incident<1||e.incident>=s.nextId||!Number.isInteger(e.shift)||e.shift<t.startShift||e.shift>s.shift||!Number.isFinite(e.time)||e.time<0||e.time>s.shiftLength||typeof e.manual!=='boolean'||typeof e.detail!=='string'||e.detail.length>160)return false;const time=(e.shift-1)*s.shiftLength+e.time;if(time<previous||time>(s.shift-1)*s.shiftLength+s.time)return false;previous=time;}return t.completed===LESSONS.every(l=>t.events.some(e=>e.kind===l.kind));}
