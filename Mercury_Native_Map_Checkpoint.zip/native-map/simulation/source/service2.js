// Release C2 «Служба 2.1» (Claude, 12.10.2026). What was left of «Карьера и отделение 2.0»:
//  · Chief — monthly duty plan: every officer works the full PPA roster, days only (no nights) or a
//    light schedule (0.75 of the post: every fourth shift off). Officers who are off are covered from the
//    reserve automatically; with nobody in reserve the crew goes out alone, and if nobody at all is left
//    the officer is called in anyway (stress). The home crew comes back on the next shift.
//  · Chief — staff training: an officer from the reserve goes on a course for one or two shifts and comes
//    back with a second specialty (a crew with the right specialty works 15% faster, calls.js) or with
//    higher skill.
//  · Career — transfer between departments is a request: three shifts of waiting, then the personnel
//    office decides (after an unsatisfactory attestation the transfer is refused). New department:
//    road police (Дорожная полиция).
//  · Career — what the savings are for: a gym pass, a holiday trip, an own car, a down payment for a flat.
//  · Chief — a workshop at the station: repairs cheaper and faster.
// Pure rules and validation; sim.js applies them. Roster campaigns only; old campaigns are unchanged.
import {officerSpecialtyKey} from './calls.js';
// ── График на месяц ──────────────────────────────────────────────────────────────────────────────
export const DUTY=Object.freeze({
 full:{label:'Полный график',about:'Все смены по графику ППА: 2 дня, 2 ночи, 4 выходных.',pay:1},
 days:{label:'Только дневные',about:'В ночные смены не выходит: меньше недосыпа. Ночью его закрывает резерв. Без ночной надбавки.',pay:1,noNight:true},
 light:{label:'Облегчённый (0,75 ставки)',about:'Каждую четвёртую смену отдыхает, зарплата ×0,75.',pay:.75,every:4}
});
export const DUTY_IDS=Object.freeze(Object.keys(DUTY));
export const dutyOf=o=>DUTY[o?.duty]??DUTY.full;
export function onDuty(o,shiftIndex,kind){const d=dutyOf(o);if(d.noNight&&kind==='night')return false;if(d.every&&((shiftIndex|0)+(o.id|0))%d.every===0)return false;return true;}
export const unavailable=o=>(o?.leave>0)||!!o?.study;
export const CALLED_IN_STRESS=8;
// Wage of one officer for one shift (night premium only for those who really work nights).
export const dutyWage=(o,nightFactor)=>Math.round((o.salary??0)*dutyOf(o).pay*(dutyOf(o).noNight?1:nightFactor)*100)/100;
// ── Обучение сотрудников ─────────────────────────────────────────────────────────────────────────
export const STAFF_COURSES=Object.freeze({
 negotiation:{label:'Переговоры и деэскалация',key:'negotiation',price:450,shifts:2,about:'Вторая специальность: конфликты, семейные ссоры, шум.'},
 search:{label:'Поиск людей',key:'search',price:450,shifts:2,about:'Вторая специальность: пропавшие люди.'},
 traffic:{label:'Дорожный надзор',key:'traffic',price:450,shifts:2,about:'Вторая специальность: ДТП, пьяные и опасные водители.'},
 investigation:{label:'Проверка обстоятельств',key:'investigation',price:450,shifts:2,about:'Вторая специальность: кражи, проверки, сигнализации.'},
 skill:{label:'Повышение квалификации',price:300,shifts:1,skill:.05,about:'Навык +5% (до 97%).'}
});
export const STAFF_COURSE_IDS=Object.freeze(Object.keys(STAFF_COURSES));
export const STAFF_SKILL_CAP=.97,EXTRA_LIMIT=3;
export const knows=(o,key)=>officerSpecialtyKey(o?.specialty)===key||(Array.isArray(o?.extra)&&o.extra.includes(key));
export function studyBlocker(s,o,id){const c=STAFF_COURSES[id];if(!c)return 'Нет такого курса.';if(!o)return 'Нет такого сотрудника.';if(s.units?.some(u=>u.officerIds.includes(o.id)))return 'Сначала выведите сотрудника в резерв.';
 if(o.leave>0)return 'Сотрудник в отпуске.';if(o.study)return 'Уже на курсе.';if(c.key&&knows(o,c.key))return 'Эта специальность уже есть.';if(c.key&&(o.extra?.length??0)>=EXTRA_LIMIT)return 'Больше специальностей не освоить.';
 if(c.skill&&(o.skill??0)>=STAFF_SKILL_CAP)return 'Навык уже максимальный.';if((s.budget??0)<c.price)return `Нужно ${c.price} в бюджете.`;return null;}
// One shift of the course passes; returns the result text when the course ends.
export function studyShift(o){const st=o.study;if(!st)return null;st.left--;if(st.left>0)return null;const c=STAFF_COURSES[st.course];delete o.study;
 if(c.key){o.extra=[...(o.extra??[]),c.key];return `${o.name}: курс «${c.label}» пройден — вторая специальность.`;}
 o.skill=Math.min(STAFF_SKILL_CAP,Math.round(((o.skill??0)+c.skill)*1000)/1000);return `${o.name}: курс «${c.label}» пройден — навык ${Math.round(o.skill*100)}%.`;}
// ── Перевод (карьера) ────────────────────────────────────────────────────────────────────────────
export const TRANSFER=Object.freeze({wait:3});
export function transferVerdict(life){const last=(life?.attestations??[]).at(-1);return last?.grade==='D'?'Отдел кадров отказал: последняя аттестация неудовлетворительная. Подайте рапорт после следующей аттестации.':null;}
// ── Личные цели (карьера) ────────────────────────────────────────────────────────────────────────
export const PURCHASES=Object.freeze({
 gym:{label:'Абонемент в спортзал на год',price:240,about:'Спорт даёт вдвое больше формы следующие 24 смены.',shifts:24},
 trip:{label:'Путёвка к морю',price:1200,about:'Следующий отпуск снимает весь стресс и недосып; семья довольна.'},
 car:{label:'Своя машина',price:6500,about:'Дорога на смену короче: недосып −4 перед каждой сменой. Содержание 40 € в месяц.',monthly:40,sleep:-4},
 apartment:{label:'Первый взнос за квартиру',price:15000,about:'Ипотека дешевле аренды: расходы на жизнь 950 → 720 € в месяц.',living:720}
});
export const PURCHASE_IDS=Object.freeze(Object.keys(PURCHASES));
export const owns=(life,id)=>!!life?.owned?.[id];
export function purchaseBlocker(life,id){const p=PURCHASES[id];if(!p)return 'Нет такой цели.';if(!life)return 'Только в карьере по графику.';if(id!=='gym'&&id!=='trip'&&owns(life,id))return 'Уже есть.';if(id==='gym'&&(life.owned?.gym??0)>0)return 'Абонемент ещё действует.';if(id==='trip'&&owns(life,'trip'))return 'Путёвка уже куплена.';if((life.money??0)<p.price)return `Нужно ${p.price} € (на счёте ${Math.round(life.money??0)} €).`;return null;}
export const livingCost=(life,base)=>owns(life,'apartment')?PURCHASES.apartment.living:base;
// ── Мастерская (начальник) ───────────────────────────────────────────────────────────────────────
export const WORKSHOP=Object.freeze({repairCost:.65,repairTime:.6,service:2});
// ── Валидация ────────────────────────────────────────────────────────────────────────────────────
const int=(x,a=0,b=1e7)=>Number.isInteger(x)&&x>=a&&x<=b;
export function validService2(s){
 for(const o of s.officers??[]){if(o.duty!==undefined&&!Object.hasOwn(DUTY,o.duty))return false;if(o.extra!==undefined&&!(Array.isArray(o.extra)&&o.extra.length<=EXTRA_LIMIT&&o.extra.every(k=>typeof k==='string'&&Object.values(STAFF_COURSES).some(c=>c.key===k))))return false;
  if(o.study!==undefined&&!(o.study&&Object.hasOwn(STAFF_COURSES,o.study.course)&&int(o.study.left,1,5)))return false;}
 const ids=new Set((s.officers??[]).map(o=>o.id));for(const u of s.units??[])if(u.homeCrew!==undefined&&!(Array.isArray(u.homeCrew)&&u.homeCrew.length>=1&&u.homeCrew.length<=2&&u.homeCrew.every(id=>Number.isInteger(id))))return false;
 const l=s.life;if(l){if(l.transfer!==undefined&&l.transfer!==null&&!(l.transfer&&typeof l.transfer.role==='string'&&int(l.transfer.ready)))return false;
  if(l.owned!==undefined&&!(l.owned&&typeof l.owned==='object'&&Object.entries(l.owned).every(([k,v])=>Object.hasOwn(PURCHASES,k)&&(v===true||int(v,0,1000)))))return false;}
 return ids.size===(s.officers??[]).length;}
