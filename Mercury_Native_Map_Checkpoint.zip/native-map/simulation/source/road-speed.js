// Numeric OSM tags only. Defaults are game tuning, not legal advice or verified signs.
export function parseSpeed(raw){
 if(typeof raw!=='string')return null;
 const m=raw.trim().match(/^(\d+(?:\.\d+)?)\s*(km\/h|kph|mph)?$/i);
 if(!m)return null;
 const speed=Number(m[1])*(m[2]?.toLowerCase()==='mph'?1.609344:1);
 return speed>0&&speed<=130?speed:null;
}
export function roadSpeed(road,forward=true){
 const tags=road.speedTags??{},key=forward?'maxspeed:forward':'maxspeed:backward';
 const raw=tags[key]??tags.maxspeed,parsed=parseSpeed(raw);
 const conditional=Boolean(tags['maxspeed:conditional']||tags[key+':conditional']||tags['maxspeed:variable']==='yes');
 const fallback=road.kind==='living_street'?20:road.kind==='service'?20:30;
 return {kmh:conditional?Math.min(parsed??fallback,fallback):parsed??fallback,source:parsed===null||conditional?'game-default':'osm',raw:raw??null,conditional,roadId:road.id};
}
