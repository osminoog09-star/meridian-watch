// Reusable membership index. References remain live when paint/skill/fatigue change.
const indexes=new WeakMap();
export function departmentIndex(s){let c=indexes.get(s);if(!c||c.officers!==s.officers||c.vehicles!==s.vehicles||c.officerCount!==s.officers.length||c.vehicleCount!==s.vehicles.length){c={officers:s.officers,vehicles:s.vehicles,officerCount:s.officers.length,vehicleCount:s.vehicles.length,byOfficer:new Map(s.officers.map(o=>[o.id,o])),byVehicle:new Map(s.vehicles.map(v=>[v.id,v]))};indexes.set(s,c);}return c;}
export function ensureStaff(s){const c=departmentIndex(s);for(const o of s.officers)if(o.fatigue===undefined)o.fatigue=0;for(const u of s.units){for(const id of u.officerIds){const o=c.byOfficer.get(id);if(o&&o.staffVersion===undefined){o.fatigue=u.fatigue;o.staffVersion=1;}}}for(const o of s.officers)if(o.staffVersion===undefined)o.staffVersion=1;return s;}
export function syncCrew(s,u){const c=departmentIndex(s);let fatigue=0,skill=0;for(const id of u.officerIds){const o=c.byOfficer.get(id);fatigue+=o.fatigue;skill+=o.skill;}u.fatigue=fatigue/u.officerIds.length;u.skill=skill/u.officerIds.length;}
export function tickStaff(s,dt){const c=departmentIndex(s),assigned=c.assigned??(c.assigned=new Set());assigned.clear();for(const u of s.units){for(let k=0;k<u.officerIds.length;k++){const id=u.officerIds[k],o=c.byOfficer.get(id);assigned.add(id);const rate=u.status==='resting'?-1.435:u.officerIds.length===1?.065:k===0?.07:.06;o.fatigue=Math.max(0,Math.min(100,o.fatigue+dt*rate));}syncCrew(s,u);}for(const o of s.officers)if(!assigned.has(o.id))o.fatigue=Math.max(0,o.fatigue-dt*.3);}
export function crewNeedsRest(s,u){const c=departmentIndex(s);return u.officerIds.some(id=>c.byOfficer.get(id).fatigue>78);}
export function crewReady(s,u){const c=departmentIndex(s);return u.officerIds.every(id=>c.byOfficer.get(id).fatigue<8);}
export function staffSummary(s,u){const c=departmentIndex(s);return u.officerIds.map((id,k)=>{const o=c.byOfficer.get(id);return {id,name:o.name,fatigue:o.fatigue,skill:o.skill,role:u.officerIds.length===1?'Одиночный сотрудник':k===0?'Ведущий / водитель':'Напарник / поддержка'};});}
export function prepareStaffShift(s,active){ensureStaff(s);const busy=new Set(s.units.filter(u=>active.has(u.incident)||u.foot).flatMap(u=>u.officerIds));for(const o of s.officers)if(!busy.has(o.id))o.fatigue=Math.min(o.fatigue,8);for(const u of s.units)syncCrew(s,u);}
export function validStaff(s){return s.officers.every(o=>o.staffVersion===undefined&&o.fatigue===undefined||o.staffVersion===1&&Number.isFinite(o.fatigue)&&o.fatigue>=0&&o.fatigue<=100);}

// Derived explanation: no hidden pair bonus, no campaign mutation or per-tick cache rebuild.
export function crewAssessment(s,u){
 const members=staffSummary(s,u),tired=members.filter(o=>o.fatigue>78);
 return {members,skill:members.reduce((sum,o)=>sum+o.skill,0)/members.length,needsRest:tired.length>0,
 explanation:members.length===1?'Одиночный патруль: сотрудник ведёт машину и работает на месте.': 'Пара: первый сотрудник ведёт машину и начинает работу, напарник поддерживает. Навык — среднее состава; скрытого бонуса за пару нет.',
 readiness:tired.length?'Нужен отдых: '+tired.map(o=>o.name).join(', ')+'.':'Состав готов по усталости.'};
}
