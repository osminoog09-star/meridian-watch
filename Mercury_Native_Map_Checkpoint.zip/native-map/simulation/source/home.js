// Release P1 «Дом и дорога» (Claude, 17.10.2026). Owner 16.10: «жизнь вне службы как в Sims: ездить на работу, дома
// самому решать, что делать; потребности». The officer lives somewhere: a rented flat or room in one of the districts
// (prices of a small Estonian town, 2026), pays rent, bills and food every month, and goes to the station before every
// shift — on foot, by bus or by own car. The way takes time (less rest), the bus may be late in snow, a tired officer
// oversleeps; being late to the briefing is noted by the shift supervisor, three times in a month is a reprimand that
// blocks the next rank for a while. The needs of the hero (rest, calm, fitness, company, money) are shown together.
import {byId,point} from './geography.js';
import {MAP_METRES} from './world-scale.js';
export const HOMES=Object.freeze({
 'mai-room':{district:'mai',label:'Однушка в Майском, панельный дом',rent:360},
 'ulejoe-studio':{district:'ulejoe',label:'Студия в Заречье, через мост от участка',rent:430},
 'raama-flat':{district:'raama',label:'Двушка в Северной слободе',rent:470},
 'vana-flat':{district:'vana',label:'Квартира в деревянном доме, Старый посад',rent:400},
 'centre-flat':{district:'centre',label:'Квартира в центре, пять минут до участка',rent:620},
 'beach-flat':{district:'beach',label:'Квартира у моря, Курортный',rent:680},
 'raekula-house':{district:'raekula',label:'Половина дома в Сосновом бору',rent:520}
});
export const HOME_IDS=Object.freeze(Object.keys(HOMES));
export const HOME=Object.freeze({start:'mai-room',bills:130,food:300,mortgage:420,walkKmh:5,busWait:9,busKmh:22,carKmh:30,park:3,lateBus:.05,lateSnow:.08,lateTired:.12,lateLimit:3});
const HQ=()=>point(byId('centre'));
export function homeOf(life){return HOMES[life?.home]??HOMES[HOME.start];}
export const homeKm=id=>{const h=HOMES[id]??HOMES[HOME.start],p=point(byId(h.district)),c=HQ();return Math.round(Math.hypot(p.x-c.x,p.y-c.y)*MAP_METRES*1.25/100)/10;};
// The way to the station: on foot under 1.2 km, otherwise the own car if there is one, else the bus.
export function commute(life,{car=false}={}){const km=homeKm(life?.home??HOME.start);
 if(km<1.2)return {mode:'foot',km,minutes:Math.round(km/HOME.walkKmh*60)+2,label:'пешком'};
 if(car)return {mode:'car',km,minutes:Math.round(km/HOME.carKmh*60)+HOME.park,label:'на своей машине'};
 return {mode:'bus',km,minutes:Math.round(km/HOME.busKmh*60)+HOME.busWait+4,label:'на автобусе'};}
// Monthly costs: rent (or the mortgage after the first payment for an own flat), bills and food.
export function monthlyCost(life,{own=false}={}){return (own?HOME.mortgage:homeOf(life).rent)+HOME.bills+HOME.food;}
const mix=(a,b)=>{let h=Math.imul((a|0)+0x3c6e,2654435761)^Math.imul((b|0)+0x1b87,2246822519);h^=h>>>15;return (h>>>0)/4294967296;};
// Before a shift: the way costs rest; sometimes the officer is late (deterministic by seed and shift).
export function beforeShift(life,seed,shift,{car=false,weather='clear'}={}){const c=commute(life,{car});const lines=[];
 life.sleepDebt=Math.min(100,(life.sleepDebt??0)+Math.round(c.minutes/12));
 let p=c.mode==='bus'?HOME.lateBus:0;if(['snow','ice'].includes(weather)&&c.mode!=='foot')p+=HOME.lateSnow;if((life.sleepDebt??0)>70)p+=HOME.lateTired;
 const late=mix(seed,shift)<p;lines.push(`Дорога на смену ${c.label}: ${c.minutes} мин.`);
 if(late){const minutes=5+Math.floor(mix(shift,seed)*20);life.late=(life.late??0)+1;life.stress=Math.min(100,(life.stress??0)+5);lines.push(`Опоздание на инструктаж на ${minutes} мин${c.mode==='bus'&&['snow','ice'].includes(weather)?' — автобус встал в снегу':(life.sleepDebt??0)>70?' — проспали':''}. Руководитель смены сделал замечание.`);}
 return {lines,late,commute:c};}
// At the end of a month: three late arrivals are a reprimand.
export function monthLate(life){const n=life.late??0;life.late=0;return n>=HOME.lateLimit;}
export function moveHome(life,id){const h=HOMES[id];if(!life)return {ok:false,message:'Только в карьере.'};if(!h)return {ok:false,message:'Нет такого жилья.'};if((life.home??HOME.start)===id)return {ok:false,message:'Вы уже здесь живёте.'};
 if(life.money<h.rent)return {ok:false,message:`Нужен залог — аренда за месяц, ${h.rent} €.`};life.money-=h.rent;life.home=id;return {ok:true,message:`Переезд: ${h.label}. Залог ${h.rent} € оплачен.`};}
// The needs of the hero, 0–100 (100 = all is well).
export function heroNeeds(life,{bond=50}={}){const c=v=>Math.max(0,Math.min(100,Math.round(v)));return {rest:c(100-(life?.sleepDebt??0)),calm:c(100-(life?.stress??0)),fitness:c(life?.fitness??50),company:c(bond),money:c(50+(life?.money??0)/40)};}
export const HERO_NEED_TEXT=Object.freeze({rest:'Отдых',calm:'Спокойствие',fitness:'Форма',company:'Близкие',money:'Деньги'});
export function validHome(l){return (l?.home===undefined||HOME_IDS.includes(l.home))&&(l?.late===undefined||Number.isInteger(l.late)&&l.late>=0&&l.late<100);}
