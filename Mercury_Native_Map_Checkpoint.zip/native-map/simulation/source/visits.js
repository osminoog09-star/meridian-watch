import {MAP_METRES} from './world-scale.js';
import {worldMinutes,advanceRoute,advanceVehicle,SPEED_KMH} from './transport.js';
// Bounded fictional visits on audited OSM footways; no opening-hours or interiors.
import {network,walkingNodes,walkingRoute} from './walking.js';
import {ROAD_NODES,roadRoute,onRoad} from './geography.js';
import {PLACE_NAMES} from './fiction.js';
export const VISIT=network.entrances[0];
export const VISIT_ACCESS=ROAD_NODES.find(n=>n.id===VISIT.carAccess);
const point=id=>{const p=walkingNodes.get(id);return [p.x,p.y];};
export const VISITS=Object.freeze(network.destinations.map(Object.freeze));
const destinations=new Map(VISITS.map(v=>[v.key,v])),visitorDestination=new Map([[6,'malmo'],[11,'ruutli'],[16,'museum']]);
const accessFor=destination=>ROAD_NODES.find(n=>n.id===destination.carAccess);
export const visitDestination=r=>destinations.get(r?.visit?.destination??(r?.id===16&&r?.visit?'museum':''))??null;
export const visitAccess=r=>{const destination=visitDestination(r);return destination?accessFor(destination):null;};
export const VISIT_STATUSES=['toVisit','walkVisit','visiting','walkBack','fromVisit'];
export const WALK_STATUSES=['walkVisit','visiting','walkBack'];
export const visitDefaults=()=>({visit:null,lastVisitDay:-1});
export function ensureVisit(r){for(const [k,v] of Object.entries(visitDefaults()))if(r[k]===undefined)r[k]=v;if(r.visit&&r.visit.destination===undefined&&r.id===16)r.visit.destination='museum';return r.visit;}
export function beginVisit(r,elapsed,origin){
 const day=Math.floor((17*60+worldMinutes(elapsed))/1440);
 const destination=destinations.get(visitorDestination.get(r.id));
 if(r.life&&(r.life.recreation<60||r.life.fatigue>80||r.life.hunger>85))return false;
 if(!destination||elapsed<60||r.lastVisitDay===day||r.status!==origin||!['home','work'].includes(origin))return false;
 r.visit={origin,destination:destination.key,waitUntil:0};r.lastVisitDay=day;r.status='toVisit';r.route=roadRoute(r,accessFor(destination));return true;
}
// Release G (Claude, 12.10.2026): a pedestrian stops at the kerb while a car with lights and siren passes
// (within SIREN_STOP metres) and walks on afterwards. Sirens are set by sim.js every tick from the units
// (transient, never saved).
export const SIREN_STOP=35;let sirens=[];
export function setSirens(list){sirens=Array.isArray(list)?list:[];}
export const nearSiren=(r,metres=SIREN_STOP)=>sirens.some(p=>Math.hypot(p.x-r.x,p.y-r.y)*MAP_METRES<=metres);
export function moveResident(r,dt,speed){if(WALK_STATUSES.includes(r.status)){if(sirens.length&&nearSiren(r))return;advanceRoute(r,dt,speed);}else advanceVehicle(r,dt,Math.min(speed,r.trafficTargetKmh??Infinity));}
export function tickVisit(r,elapsed,dt,originAccess){
 const destination=visitDestination(r),access=destination&&accessFor(destination);if(!VISIT_STATUSES.includes(r.status)||!destination||!access)return false;
 if(r.status==='visiting'){if(elapsed<r.visit.waitUntil)return true;r.visit.waitUntil=0;r.status='walkBack';r.route=walkingRoute(destination.id,destination.carAccess);}
 moveResident(r,dt,WALK_STATUSES.includes(r.status)?SPEED_KMH.walking:SPEED_KMH.civilian);
 if(!r.route.length){
  if(r.status==='toVisit'){r.status='walkVisit';r.route=walkingRoute(destination.carAccess,destination.id);}
  else if(r.status==='walkVisit'){r.status='visiting';r.visit.waitUntil=elapsed+destination.duration;}
  else if(r.status==='walkBack'){r.status='fromVisit';r.route=roadRoute(access,originAccess);}
  else if(r.status==='fromVisit'){r.status=r.visit.origin;r.visit=null;}
 }
 return true;
}
const coord=p=>`${p.x},${p.y}`;
const carNodes=new Map(ROAD_NODES.map(n=>[coord(n),n]));
const footNodes=new Map([...walkingNodes.values()].map(n=>[coord(n),n]));
const footEdges=new Map([...walkingNodes.keys()].map(id=>[id,[]]));for(const s of network.segments){footEdges.get(s.a).push(s.b);footEdges.get(s.b).push(s.a);}
function onEdge(p,a,b){return Math.abs(Math.hypot(a.x-p.x,a.y-p.y)+Math.hypot(b.x-p.x,b.y-p.y)-Math.hypot(a.x-b.x,a.y-b.y))<1e-8;}
export function validateVisit(r,elapsed,places,profile){
 if(r.visit===undefined&&r.lastVisitDay===undefined)return !VISIT_STATUSES.includes(r.status);
 if(!Number.isInteger(r.lastVisitDay)||r.lastVisitDay < -1||r.lastVisitDay>Math.floor((17*60+worldMinutes(elapsed))/1440))return false;
 if(!VISIT_STATUSES.includes(r.status))return r.visit===null;
 const destination=visitDestination(r),expected=visitorDestination.get(r.id),access=destination&&accessFor(destination);
 if(!destination||!access||destination.key!==expected||!r.visit||!['home','work'].includes(r.visit.origin)||!Number.isFinite(r.visit.waitUntil)||r.visit.waitUntil<0||r.lastVisitDay<0||r.incidentId!==null||r.resumeStatus!==null||r.recoveryUntil!==0)return false;
 const foot=WALK_STATUSES.includes(r.status),nodes=foot?footNodes:carNodes;
 if(r.status==='visiting')return r.route.length===0&&r.visit.waitUntil>=elapsed&&r.visit.waitUntil<=elapsed+destination.duration+.000001&&Math.hypot(r.x-destination.p[0],r.y-destination.p[1])<1e-8;
 if(r.visit.waitUntil!==0)return false;
 const adjacent=(a,b)=>foot?footEdges.get(a.id).includes(b.id):a.edges.some(e=>e.id===b.id);
 if(!r.route.length||!r.route.every((p,k)=>p&&nodes.has(coord(p))&&(!k||adjacent(nodes.get(coord(r.route[k-1])),nodes.get(coord(p))))))return false;
 const endpoint=r.status==='toVisit'?access:r.status==='fromVisit'?places.get(profile[r.visit.origin]).access:r.status==='walkVisit'?walkingNodes.get(destination.id):walkingNodes.get(destination.carAccess);
 if(Math.hypot(r.route.at(-1).x-endpoint.x,r.route.at(-1).y-endpoint.y)>1e-8)return false;
 const first=nodes.get(coord(r.route[0]));if(Math.hypot(r.x-first.x,r.y-first.y)<1e-8)return true;
 if(!foot&&!onRoad(r))return false;
 return [...nodes.values()].some(a=>adjacent(a,first)&&onEdge(r,a,first));
}
