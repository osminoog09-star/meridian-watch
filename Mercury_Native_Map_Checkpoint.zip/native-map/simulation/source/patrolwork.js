// R13 «Самостоятельная работа патруля» (Claude, 11.10.2026). Between calls real patrol crews are not
// idle: they set up sobriety checkpoints (PPA «joobekontroll», mass breath tests), run speed control
// near dangerous spots and walk the yards on foot to talk to residents. Each task takes crew time,
// any new call interrupts it, and a finished task leaves a result and a short-lived preventive
// effect on the call mix. Results are hashes of seed/shift/unit/start time (no rng). Roster only.
import {WORLD_SECONDS_PER_TICK_SECOND} from './transport.js';
const ticks=minutes=>minutes*60/WORLD_SECONDS_PER_TICK_SECOND;
export const TASKS=Object.freeze({
 'breath-check':{label:'Рейд «Трезвый водитель»',short:'рейд на трезвость',minutes:45,place:'road',about:'Пост на дороге: каждого водителя проверяют алкометром. Пьяных снимают с руля до того, как они попадут в ДТП.',prevent:{'drunk-driver':.55,crash:.85}},
 'speed-check':{label:'Контроль скорости',short:'контроль скорости',minutes:40,place:'road',about:'Радар у опасного участка: протоколы за превышение. Меньше опасной езды и аварий в ближайшие часы.',prevent:{'dangerous-driving':.6,'school-speeding':.5,crash:.85}},
 'foot-patrol':{label:'Пеший обход района',short:'пеший обход',minutes:30,place:'residential',about:'Экипаж оставляет машину и обходит дворы: разговоры с жителями, доверие района растёт, мелких нарушений меньше.',prevent:{'yard-company':.8,'noise-venue':.8,'bike-theft':.8,'car-break':.8,shoplift:.85}},
 // R25 criminal police: steps of a case (detective.js). Not patrol work — no prevention, no auto pick here.
 'case-witnesses':{label:'Опрос свидетелей',short:'опрос свидетелей',minutes:45,place:'residential',case:true,about:'Обойти соседей, найти очевидцев, записать приметы.',prevent:{}},
 'case-cameras':{label:'Записи камер',short:'сбор записей камер',minutes:35,place:'centre',case:true,about:'Изъять записи у магазинов, АЗС и домофонов по маршруту подозреваемого.',prevent:{}},
 'case-database':{label:'Проверка по базам',short:'проверка по базам в участке',minutes:25,place:'station',case:true,about:'Сверить приметы, номера и связи по полицейским базам.',prevent:{}},
 'case-interview':{label:'Допрос подозреваемого',short:'допрос подозреваемого в участке',minutes:40,place:'station',case:true,about:'Когда сведений от 30%: вызвать подозреваемого и допросить с адвокатом.',prevent:{}},
 'case-forensics':{label:'Отправить улики на экспертизу',short:'передача улик в лабораторию',minutes:20,place:'station',case:true,about:'Отпечатки, ДНК, записи — результат придёт к следующей смене.',prevent:{}},
 'case-arrest':{label:'Задержание подозреваемого',short:'задержание подозреваемого',minutes:30,place:'residential',case:true,about:'Когда улик достаточно: выйти на подозреваемого и задержать.',prevent:{}}
});
export const TASK_IDS=Object.freeze(Object.keys(TASKS).filter(id=>!TASKS[id].case));// patrol work (the buttons)
export const CASE_TASK_IDS=Object.freeze(Object.keys(TASKS).filter(id=>TASKS[id].case));
export const TASK_RULES=Object.freeze({prevention:ticks(120),preventionLimit:6,doneLimit:12,autoChance:.12,autoEvery:ticks(20),autoPerShift:2,breathMinutes:35,waitBeforeInterrupt:6,autoMaxLoad:1.6});
export const taskTicks=(id,fast=false)=>ticks(id==='breath-check'&&fast?TASK_RULES.breathMinutes:TASKS[id].minutes);
const hash=(a,b,c,d)=>{let h=Math.imul((a|0)+101,2654435761)^Math.imul((b|0)+7,1597334677)^Math.imul((c|0)+3,2246822519)^Math.imul((d|0)+11,3266489917);h^=h>>>15;h=Math.imul(h,2246822519);return ((h^h>>>13)>>>0)/4294967296;};
// What the task found. `busy` is the call load of the hour (season.js loadFactor): weekend nights
// mean more drunk drivers at a checkpoint.
export function taskResult(id,{seed=0,shift=0,unit=0,start=0,busy=1}={}){const r=hash(seed,shift,unit*1000+Math.floor(start)),k=Math.max(.6,Math.min(1.6,busy));
 if(id==='breath-check'){const checked=30+Math.floor(r*31),drunk=Math.min(4,Math.floor(r*2.6*k+(busy>1.3?.6:0)));return {checked,found:drunk,text:`проверено ${checked} водителей, пьяных за рулём: ${drunk}`};}
 if(id==='speed-check'){const n=2+Math.floor(r*6);return {checked:n,found:n,text:`протоколов за превышение: ${n}`};}
 const talks=4+Math.floor(r*7);return {checked:talks,found:talks,text:`поговорили с жителями: ${talks}`};}
// Rewards: public trust, district trust and experience (player's own crew in a career, any in chief).
export function taskReward(id,result){if(id==='breath-check')return {trust:.5+result.found*.5,district:1+result.found,xp:5+result.found*10};
 if(id==='speed-check')return {trust:.5,district:1,xp:5+result.found*2};return {trust:1,district:3,xp:8};}
// Which task a crew picks on its own: checkpoints at night, radar in the morning and afternoon,
// walking the yards around noon and in the evening.
export function autoTaskFor(minuteOfDay){const h=Math.floor(((minuteOfDay%1440)+1440)%1440/60);return h>=22||h<5?'breath-check':h>=17||h>=10&&h<13?'foot-patrol':'speed-check';}
export const autoTaskRoll=(seed,shift,unit,time)=>hash(seed,shift,unit,Math.floor(time/TASK_RULES.autoEvery))<TASK_RULES.autoChance;
export function preventionMods(s){const out={};for(const p of s.prevention??[])if(p.until>s.time)for(const [k,v] of Object.entries(TASKS[p.task]?.prevent??{}))out[k]=Math.min(out[k]??1,v);return out;}
export const validTask=t=>t===undefined||t!==null&&typeof t==='object'&&Object.hasOwn(TASKS,t.id)&&(!TASKS[t.id].case||Number.isInteger(t.caseId))&&['moving','working'].includes(t.phase)&&Number.isFinite(t.left)&&t.left>=0&&t.left<=ticks(60)&&Number.isFinite(t.start)&&typeof t.auto==='boolean';
export function validPatrolWork(s){const p=s.prevention,d=s.tasksDone;
 return (p===undefined||Array.isArray(p)&&p.length<=TASK_RULES.preventionLimit&&p.every(x=>x&&Object.hasOwn(TASKS,x.task)&&Number.isFinite(x.until)))&&(d===undefined||Array.isArray(d)&&d.length<=TASK_RULES.doneLimit&&d.every(x=>x&&Object.hasOwn(TASKS,x.task)&&Number.isInteger(x.unit)&&Number.isFinite(x.time)&&typeof x.text==='string'&&x.text.length<=160&&typeof x.district==='string'&&typeof x.done==='boolean'));}
