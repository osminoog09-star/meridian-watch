// Release A «Живой город» — Claude's part: sound of the place (Claude, 12.10.2026).
// The same siren or footstep sounds different in a closed courtyard of five-storey blocks, on an open
// street, in a park or by the river. This module reads the real map once (buildings, parks, water) into a
// coarse grid and answers «what kind of place is around this point»: the reverb (how long and how loud the
// echo is) and the ground under the feet. Pure functions, nothing stored in the campaign.
import data from './city-data.js';
import {MAP_METRES} from './world-scale.js';
export const CELL_METRES=40;
const CELL=CELL_METRES/MAP_METRES;
// How each place sounds: wet = share of echo, decay = echo length (s), pre = first reflection delay (s).
export const SPACES=Object.freeze({
 yard:{label:'Двор между домами',wet:.3,decay:1.1,pre:.012},
 street:{label:'Улица',wet:.18,decay:.75,pre:.02},
 park:{label:'Парк',wet:.07,decay:.45,pre:.035},
 water:{label:'У воды',wet:.05,decay:.4,pre:.04},
 open:{label:'Открытое место',wet:.09,decay:.5,pre:.03}
});
const GREEN=new Set(['park','grass','forest','wood','scrub','meadow','garden','cemetery','recreation_ground','allotments','pitch','flowerbed','greenfield','farmland']),WATER=new Set(['water','beach']);
let grid=null,areaBoxes=null;const cache=new Map();
const key=(cx,cy)=>cx*100000+cy;
function polygonArea(p){let a=0;for(let k=0,n=p.length;k<n;k++){const [x1,y1]=p[k],[x2,y2]=p[(k+1)%n];a+=x1*y2-x2*y1;}return Math.abs(a)/2;}
function box(p){let x0=Infinity,y0=Infinity,x1=-Infinity,y1=-Infinity;for(const [x,y] of p){if(x<x0)x0=x;if(y<y0)y0=y;if(x>x1)x1=x;if(y>y1)y1=y;}return [x0,y0,x1,y1];}
function inside(p,x,y){let c=false;for(let k=0,j=p.length-1;k<p.length;j=k++){const [xi,yi]=p[k],[xj,yj]=p[j];if((yi>y)!==(yj>y)&&x<(xj-xi)*(y-yi)/(yj-yi||1e-12)+xi)c=!c;}return c;}
// Built-up area per cell (world units²), spread over the cells a building covers.
let shapes=null;
function buildGrid(){grid=new Map();shapes=new Map();for(const b of data.buildings??[]){if(!b?.p?.length)continue;const a=polygonArea(b.p),[x0,y0,x1,y1]=box(b.p),cx0=Math.floor(x0/CELL),cx1=Math.floor(x1/CELL),cy0=Math.floor(y0/CELL),cy1=Math.floor(y1/CELL),n=(cx1-cx0+1)*(cy1-cy0+1);
  for(let cx=cx0;cx<=cx1;cx++)for(let cy=cy0;cy<=cy1;cy++){const k=key(cx,cy);grid.set(k,(grid.get(k)??0)+a/n);const list=shapes.get(k);if(list)list.push(b.p);else shapes.set(k,[b.p]);}}
 areaBoxes=(data.areas??[]).filter(a=>GREEN.has(a.kind)||WATER.has(a.kind)).map(a=>({kind:a.kind,p:a.p,b:box(a.p)}));}
function areaAt(x,y){let water=false,green=false;for(const a of areaBoxes){if(x<a.b[0]||x>a.b[2]||y<a.b[1]||y>a.b[3])continue;if(!inside(a.p,x,y))continue;if(WATER.has(a.kind))water=true;else green=true;if(water)break;}return {water,green};}
// The place around a world point: built-up share of the 3×3 cells around it, park or water under it.
export function placeAt(x,y){if(!Number.isFinite(x)||!Number.isFinite(y))return {space:'street',coverage:.2,green:false,water:false};if(!grid)buildGrid();
 const cx=Math.floor(x/CELL),cy=Math.floor(y/CELL),k=key(cx,cy);if(cache.has(k))return cache.get(k);
 let built=0;for(let dx=-1;dx<=1;dx++)for(let dy=-1;dy<=1;dy++)built+=grid.get(key(cx+dx,cy+dy))??0;const coverage=Math.min(1,built/(9*CELL*CELL)),{water,green}=areaAt((cx+.5)*CELL,(cy+.5)*CELL);
 const space=water&&coverage<.1?'water':coverage>=.3?'yard':green&&coverage<.15?'park':coverage>=.1?'street':'open';
 const out=Object.freeze({space,coverage:Math.round(coverage*100)/100,green,water});if(cache.size>4000)cache.clear();cache.set(k,out);return out;}
// Ground under the feet: weather first (snow, ice, wet), then the place (grass or gravel paths in parks).
export const SURFACES=Object.freeze(['asphalt','wet','snow','ice','grass']);
export function surfaceAt(place,weather){if(weather==='snow')return 'snow';if(weather==='ice')return 'ice';if(weather==='rain')return 'wet';return place?.green&&place.space==='park'?'grass':'asphalt';}
// Procedural stereo impulse response for the place: a few early reflections and a decaying diffuse tail.
// Deterministic (no Math.random) so every device hears the same courtyard.
export function impulseResponse(rate,space){const sp=SPACES[space]??SPACES.street,length=Math.max(64,Math.round(rate*sp.decay)),pre=Math.round(rate*sp.pre),out=[new Float32Array(length),new Float32Array(length)];
 for(let ch=0;ch<2;ch++){let s=(ch?40503:2654435)>>>0;const r=()=>{s=(Math.imul(s,1664525)+1013904223)>>>0;return s/4294967296*2-1;},o=out[ch];
  for(let k=pre;k<length;k++){const t=k/rate;o[k]=r()*Math.exp(-6.9*t/sp.decay)*.5;}
  for(let e=1;e<=4;e++){const at=pre+Math.round(rate*sp.pre*e*(1.3+ch*.17));if(at<length)o[at]+=.6/e;}}
 return out;}
// Is this point inside a building footprint? (people around a call stand outside, on the street or in the yard)
export function inBuilding(x,y){if(!Number.isFinite(x)||!Number.isFinite(y))return false;if(!grid)buildGrid();for(const p of shapes.get(key(Math.floor(x/CELL),Math.floor(y/CELL)))??[])if(inside(p,x,y))return true;return false;}
