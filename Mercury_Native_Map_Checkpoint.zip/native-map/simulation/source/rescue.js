// Release H «Спасатели» (Claude, 12.10.2026). A rescue campaign: the player serves in (or runs) the
// rescue station of Meridian instead of the police department. Same city, same engine; the calls,
// vehicles, crews, ranks and the work on scene are the rescuers'.
// Facts behind the numbers (Päästeamet; ERR 2019–2026; readiness rules of the Rescue Board):
//  · turnout: 60 s for high-risk calls with lights and siren, 3 min for low-risk calls;
//  · the first vehicle should be on scene within about 5 minutes in a city (15 min anywhere in Estonia);
//  · a city station keeps 8–11 rescuers on duty; a main vehicle (põhiauto) goes with 3–4, a ladder needs
//    four, the tanker (paakauto) brings extra water; ranks: rescuer, senior rescuer, team leader
//    (meeskonnavanem / rühmapealik), station commander (komandopealik);
//  · ≈2 300 fires a year, ≈400 in homes; smoking causes half of the deadly fires; homes without a working
//    smoke detector are where people die; rescuers visit homes and check detectors (prevention).
// Pure rules: sim.js and scenes.js call these; nothing here touches the police campaign.
import {MAP_METRES} from './world-scale.js';
import {WORLD_SECONDS_PER_TICK_SECOND} from './transport.js';
export const RESCUE_SERVICE='rescue';
export const isRescue=s=>s?.agency===RESCUE_SERVICE;/* `s.service` is the career service record — the agency is a separate field */
const worldMin=dt=>dt*WORLD_SECONDS_PER_TICK_SECOND/60;
const hash=(a,b)=>{let h=Math.imul((a|0)+733,2654435761)^Math.imul((b|0)+97,1597334677);h^=h>>>15;h=Math.imul(h,2246822519);return ((h^h>>>13)>>>0)/4294967296;};
// Call types 6–9 (appended to sim.js TYPES). Options: [label, choice].
export const RESCUE_TYPES=Object.freeze([
 {name:'Пожар в квартире',icon:'▲',severity:3,duration:22,limit:70,brief:'Дым из окна квартиры, соседи слышат сигнал датчика дыма. Возможно, внутри люди.',options:[['Внутренняя атака звеном и поиск людей','attack'],['Тушить снаружи и защищать соседей','defend']],rescue:true},
 {name:'ДТП, человек зажат',icon:'✚',severity:3,duration:18,limit:80,brief:'Столкновение двух машин, водителя зажало в салоне. Скорая выехала.',options:[['Деблокировать и освободить','extricate'],['Обезопасить место и ждать скорую','secure']],rescue:true},
 {name:'Человек провалился под лёд',icon:'≈',severity:3,duration:14,limit:42,brief:'Рыбак провалился под лёд недалеко от берега, держится за кромку.',options:[['Спасатель в гидрокостюме','ice'],['Подать спасательный конец с берега','reach']],rescue:true},
 {name:'Сработала пожарная сигнализация',icon:'!',severity:1,duration:10,limit:150,brief:'Автоматическая пожарная сигнализация в торговом центре. Часто это ложная тревога — но проверить нужно всегда.',options:[['Проверить и обезопасить','check'],['Эвакуировать жильцов','evacuate']],rescue:true}
]);
export const RESCUE_TYPE_IDS=Object.freeze([6,7,8,9]);
export const RESCUE_CHOICES=Object.freeze(['attack','defend','extricate','ice','reach','evacuate']);
export const isRescueType=t=>t>=6&&t<=9;
// What the crew finds on arrival (deterministic per call).
export function rescueFacts(i){const id=i?.id??0,v=i?.variant;return {
 trapped:v==='fire-flat'?Math.floor(hash(id,1)*3.2):v==='fire-stairs'?2+Math.floor(hash(id,1)*5):0,
 hydrant:hash(id,2)<(['fire-flat','fire-stairs','fire-rubbish'].includes(v)?.75:.35),
 smoking:hash(id,3)<.5,// the cause: a cigarette (half of deadly home fires) or the stove/wiring
 detector:hash(id,4)<.65,// a working smoke detector woke the people up
 falseAlarm:v==='alarm-auto'&&hash(id,5)<.7,
 gasLeak:v==='gas-smell'&&hash(id,6)<.45,
 conscious:hash(id,7)<.6};}
// ── Fire on scene ───────────────────────────────────────────────────────────────────────────────
export const FIRE=Object.freeze({
 growth:{'fire-flat':3,'fire-stairs':2.2,'fire-chimney':1.4,'fire-car':4,'fire-grass':2.6,'fire-rubbish':2},// size %/world min before water
 start:[15,30],flashover:100,
 knock:{attack:4.5,defend:3},// size %/world min per crew on water
 flow:{attack:220,defend:300},// litres/world min per crew
 tank:{engine:3000,ladder:0,tanker:10000},hydrantMinutes:6,
 air:30,airChange:6,// minutes of breathing air for the team inside; time to change the team
 search:5,// world minutes to find one person per crew searching inside
 hydrantFast:2,vent:1.25
});
const crewsOn=w=>w.length>0;
export function ensureFire(i){if(i.type!==6)return null;if(i.fire)return i.fire;const f=rescueFacts(i),[a,b]=FIRE.start;return i.fire={size:Math.round(a+hash(i.id,9)*(b-a)),trapped:f.trapped,saved:0,water:0,hydrant:f.hydrant?'near':'none',hydrantAt:0,air:FIRE.air,change:0,engines:[],flashover:false};}
// One step of the fire. `working`: crews on scene (units with .vehicleType and .people). Returns
// {rate, failure} like scenes.js sceneStep: progress rate for the call and an optional failure.
export function fireStep(i,working,dt,weather=null,opts={}){const f=ensureFire(i);if(!f)return {rate:1};const m=worldMin(dt);
 const sets=i.talk?.sets??{};for(const u of working)if(!f.engines.includes(u.id)){f.engines.push(u.id);f.water+=FIRE.tank[u.vehicleType]??FIRE.tank.engine;if(f.hydrant==='near'&&!f.hydrantAt)f.hydrantAt=i.age+FIRE.hydrantMinutes*60/WORLD_SECONDS_PER_TICK_SECOND;}
 if(sets.hydrant==='fast'&&f.hydrant==='near'&&f.hydrantAt)f.hydrantAt=Math.min(f.hydrantAt,i.age+FIRE.hydrantFast*60/WORLD_SECONDS_PER_TICK_SECOND);
 if(i.call?.instr?.includes('leave')&&!f.evacuated&&f.trapped>0){f.evacuated=true;f.trapped--;f.saved++;}/* Release J: the 112 dispatcher told them to get out */
 if(sets.ladder&&!f.ladderUsed&&f.trapped>0&&crewsOn(working)){f.ladderUsed=true;f.trapped--;f.saved++;}
 if(f.hydrant==='near'&&f.hydrantAt&&i.age>=f.hydrantAt)f.hydrant='on';
 const choice=i.decision==='defend'?'defend':'attack',crews=working.length,wind=weather?.kind==='wind'?1.5:1;
 if(f.size>0&&(!crews||(f.water<=0&&f.hydrant!=='on'))){f.size=Math.min(FIRE.flashover,f.size+m*(FIRE.growth[i.variant]??2.5)*wind);}
 else if(f.size>0){let inside=choice==='attack';if(inside){if(f.change>0){f.change=Math.max(0,f.change-m);inside=false;}else{f.air-=m;if(f.air<=0){f.air=FIRE.air;f.change=working.some(u=>(u.people?.length??0)>=4)?0:FIRE.airChange;}}}
  const knock=(inside||choice==='defend'?FIRE.knock[choice]:FIRE.knock.defend*.5)*crews*m*(sets.vent?FIRE.vent:1);f.size=Math.max(0,f.size-knock);if(f.hydrant!=='on')f.water=Math.max(0,f.water-FIRE.flow[choice]*crews*m);
  if(inside)f.searching=true;else delete f.searching;}
 // Searching: inside with breathing apparatus during the attack, or by anyone once the fire is out.
 if(crews&&f.trapped>0&&(f.searching&&f.size>0||f.size===0)){f.search=(f.search??0)+m*crews*(opts.search??1)*(sets.vent?FIRE.vent:1);while(f.search>=FIRE.search&&f.trapped>0){f.search-=FIRE.search;f.trapped--;f.saved++;}}
 if(f.size>=FIRE.flashover&&!f.flashover){f.flashover=true;if(f.trapped>0)return {rate:0,failure:`Квартира полностью охвачена огнём: ${f.trapped} ${f.trapped===1?'человек остался':'человека остались'} внутри`};}
 return {rate:f.size>0||f.trapped>0?0:1};}
export function fireOutcome(i,success){const f=i.fire;if(!f)return null;if(!success)return null;const saved=f.saved?`, выведено ${f.saved} ${f.saved===1?'человек':'чел.'}`:'';return f.flashover?`Пожар потушен, квартира выгорела${saved}`:`Пожар потушен${saved}`;}
export function validFire(f){if(f===undefined)return true;const n=(x,a,b)=>Number.isFinite(x)&&x>=a&&x<=b;return !!f&&n(f.size,0,100)&&Number.isInteger(f.trapped)&&f.trapped>=0&&f.trapped<=10&&Number.isInteger(f.saved)&&f.saved>=0&&f.saved<=10&&n(f.water,0,1e6)&&['near','none','on'].includes(f.hydrant)&&n(f.hydrantAt,0,1e7)&&n(f.air,-10,FIRE.air)&&n(f.change,0,FIRE.airChange)&&Array.isArray(f.engines)&&f.engines.length<=6&&typeof f.flashover==='boolean'&&(f.search===undefined||n(f.search,0,1e3))&&(f.searching===undefined||f.searching===true)&&(f.ladderUsed===undefined||f.ladderUsed===true)&&(f.evacuated===undefined||f.evacuated===true);}
// ── Other rescue calls ─────────────────────────────────────────────────────────────────────────
export function rescueStep(i,working,dt){if(i.type===6)return null;if(!working.length)return {rate:0};if(i.type===8&&i.decision==='reach')return {rate:.75};if(i.type===7&&i.decision==='secure')return {rate:.6};return {rate:1};}
export function rescueOutcome(i,success){if(!success)return i.type===8?'Человека не успели спасти':'Помощь не оказана вовремя';const f=rescueFacts(i);
 return i.type===6?fireOutcome(i,true):i.variant==='alarm-auto'?(f.falseAlarm?'Ложная тревога: сработал датчик на кухне кафе':'Задымление в техническом помещении, ликвидировано'):i.variant==='gas-smell'?(f.gasLeak?'Утечка газа перекрыта, дом проветрен':'Утечки нет: запах из подвала, газовщики проверили'):i.variant==='storm-tree'?'Дерево распилено, дорога открыта':i.type===8?'Человек вытащен из воды и передан скорой':i.variant==='rescue-crash'?'Водитель освобождён и передан скорой':i.variant==='rescue-lift'?'Люди выведены из лифта':i.variant==='rescue-door'?'Дверь вскрыта, человека передали скорой':i.variant==='animal-rescue'?'Животное достали и вернули хозяевам':'Работа завершена';}
// ── Units, ranks, career ─────────────────────────────────────────────────────────────────────────
export const RESCUE_RANKS=Object.freeze(['Спасатель-стажёр','Спасатель','Старший спасатель','Командир отделения','Командир части']);
export const RESCUE_PERMISSIONS=Object.freeze([
 {rank:0,title:'Спасатель-стажёр',duty:'Работа в звене под надзором командира'},
 {rank:1,title:'Спасатель',duty:'Самостоятельная работа в звене, выбор тактики своей машины'},
 {rank:2,title:'Старший спасатель',duty:'Старший машины: координация других экипажей на месте'},
 {rank:3,title:'Командир отделения',duty:'Руководитель спасательных работ: задача смены, выезды между районами'},
 {rank:4,title:'Командир части',duty:'Все полномочия части'}]);
export const RESCUE_VEHICLES=Object.freeze({
 engine:{label:'Основная машина (автоцистерна)',short:'Основная',tank:220,per100:32,idlePerHour:3.5,water:3000,price:4500,crew:4},
 ladder:{label:'Автолестница',short:'Лестница',tank:200,per100:30,idlePerHour:3,water:0,price:6500,crew:2},
 tanker:{label:'Цистерна (паакауто)',short:'Цистерна',tank:250,per100:34,idlePerHour:3.5,water:10000,price:4000,crew:2}
});
export const RESCUE_CREW_LIMIT=4;
export const crewLimit=s=>isRescue(s)?RESCUE_CREW_LIMIT:2;
// Calls come less often than to the police (a city station: about 6–10 a shift).
export const RESCUE_CALL_GAP=3;
// Starting crews of a rescue career: the player's main vehicle, the tanker and a second station.
export const RESCUE_START=Object.freeze([
 {name:'Спасатели 01',people:['Вы','Тарас Кульбок','Марек Таммик','Лийна Сепп'],role:'Командир · звено',vehicle:'engine'},
 {name:'Цистерна 02',people:['Андрес Пихл','Олег Савин'],role:'Подвоз воды',vehicle:'tanker'},
 {name:'Спасатели 03',people:['Кристо Ыун','Сийм Раннамяэ','Ирина Каск'],role:'Вторая часть (Майский)',vehicle:'engine'}]);
export const RESCUE_RECRUITS=Object.freeze([
 {id:101,name:'Тоомас Мяги',specialty:'Тушение пожаров',skill:.84,fee:380,salary:48},
 {id:102,name:'Карина Лаане',specialty:'Спасение на воде',skill:.8,fee:340,salary:44},
 {id:103,name:'Рейн Ветик',specialty:'Техническое спасение',skill:.86,fee:400,salary:50},
 {id:104,name:'Павел Орав',specialty:'Тушение пожаров',skill:.76,fee:280,salary:38},
 {id:105,name:'Хелен Кукк',specialty:'Техническое спасение',skill:.82,fee:330,salary:43},
 {id:106,name:'Артур Лепик',specialty:'Водитель тяжёлой техники',skill:.79,fee:300,salary:41},
 {id:107,name:'Марта Ильвес',specialty:'Спасение на воде',skill:.88,fee:390,salary:49},
 {id:108,name:'Йоэль Сакс',specialty:'Тушение пожаров',skill:.81,fee:320,salary:42}]);
// Between calls: hydrant checks, drills, home visits with smoke detectors (fewer home fires afterwards).
export const RESCUE_TASKS=Object.freeze(['hydrant-check','drill','home-visits']);
export const rescueTaskFor=minute=>{const h=Math.floor((((minute%1440)+1440)%1440)/60);return h>=9&&h<18?(h%3===0?'home-visits':h%3===1?'hydrant-check':'drill'):h>=18&&h<21?'drill':null;};
export const stationDistance=(u,hq)=>Math.hypot(u.x-hq.x,u.y-hq.y)*MAP_METRES;
