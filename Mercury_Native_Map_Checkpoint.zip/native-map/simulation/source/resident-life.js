// Fictional needs, expressed in percentages; elapsed uses campaign time.
const clamp=n=>Math.max(0,Math.min(100,n));
export const lifeDefaults=id=>({hunger:25+(id%4)*5,fatigue:30+(id%3)*5,recreation:id===16?65:20+(id%5)*8,activity:'routine',history:[]});
export function ensureLife(r){if(r.life===undefined)r.life=lifeDefaults(r.id);return r.life;}
export function tickLife(r,dt){
 const l=ensureLife(r),hours=Math.max(0,dt)*45/3600;
 const home=r.status==='home',rest=home||r.status==='recovering',visit=r.status==='visiting';
 l.hunger=clamp(l.hunger+hours*(home?-22:r.status==='work'?-3:7));
 l.fatigue=clamp(l.fatigue+hours*(rest?-18:visit?-8:r.status==='work'?9:5));
 l.recreation=clamp(l.recreation+hours*(visit?-55:home?-2:5));
 l.activity=r.status==='incident'?'incident':r.status==='recovering'?'rest':home?(l.hunger>45?'meal':l.fatigue>35?'rest':'home'):visit?'leisure':r.status==='work'?'work':'routine';
}
export const LIFE_ACTIVITY={routine:'Следует распорядку',meal:'Ест дома',rest:'Отдыхает дома',home:'Свободное время дома',leisure:'Отдыхает на прогулке',work:'Работает',incident:'Распорядок прерван происшествием'};
export function recordLife(r,previous,elapsed){if(r.status===previous)return;tickLife(r,0);const l=ensureLife(r);l.history.push({elapsed,status:r.status});if(l.history.length>24)l.history.splice(0,l.history.length-24);}
export function validLife(r,elapsed,statuses){const l=r.life;if(l===undefined)return true;return !!l&&['hunger','fatigue','recreation'].every(k=>Number.isFinite(l[k])&&l[k]>=0&&l[k]<=100)&&Object.hasOwn(LIFE_ACTIVITY,l.activity)&&Array.isArray(l.history)&&l.history.length<=24&&l.history.every((e,k)=>e&&Number.isFinite(e.elapsed)&&e.elapsed>=0&&e.elapsed<=elapsed&&Object.hasOwn(statuses,e.status)&&(!k||e.elapsed>=l.history[k-1].elapsed));}
