// Fictional presentation layer (owner decision 11.10.2026): the game city is «Меридиан».
// Geometry still comes from the bundled map snapshot, but no real city, street, district or
// building name is shown to the player. Mapping is deterministic, so the same real road always
// gets the same fictional name across sessions, saves and devices. Internal IDs are unchanged.
import data from './city-data.js';

export const CITY_NAME='Меридиан';
export const CITY_IN='в Меридиане';
export const LOCAL_STREET='Местная улица';

const ROOTS=['Липовая','Портовая','Речная','Маячная','Сосновая','Кленовая','Ольховая','Рябиновая','Берёзовая','Тополиная','Каштановая','Дубовая','Вишнёвая','Яблоневая','Сиреневая','Луговая','Полевая','Озёрная','Песчаная','Дюнная','Морская','Приморская','Корабельная','Якорная','Парусная','Рыбацкая','Лодочная','Причальная','Мостовая','Заречная','Береговая','Тихая','Солнечная','Ясная','Звёздная','Лунная','Ветряная','Садовая','Цветочная','Тенистая','Зелёная','Синяя','Янтарная','Гранитная','Каменная','Кирпичная','Мельничная','Кузнечная','Гончарная','Ткацкая','Столярная','Почтовая','Школьная','Театральная','Музейная','Рыночная','Торговая','Ратушная','Соборная','Церковная','Вокзальная','Курортная','Купальная','Парковая','Аллейная','Северная','Южная','Западная','Восточная','Новая','Старая','Средняя','Верхняя','Нижняя','Дальняя','Ближняя','Широкая','Узкая','Длинная','Короткая','Прямая','Кривая','Весенняя','Летняя','Осенняя','Зимняя','Утренняя','Вечерняя','Светлая','Тёплая','Ключевая','Родниковая','Овражная','Холмистая','Хвойная','Еловая','Можжевеловая','Брусничная','Черничная','Малиновая','Ореховая','Медовая','Пасечная','Сенная','Хлебная','Солодовая','Пивоварная','Ремесленная','Литейная','Канатная','Смоляная','Шкиперская','Лоцманская','Штурманская','Таможенная','Складская','Амбарная','Фонарная','Часовая','Колокольная','Ярмарочная'];
const KINDS=['улица','переулок','проезд','бульвар','аллея','набережная'];

// Frozen table for every road known today; names added by future map snapshots take the next
// free fictional name in a stable order, so existing streets are never renamed.
import FROZEN from './fiction-streets.js';
const allNames=(()=>{const out=[];for(let round=0;round<50;round++)for(const kind of KINDS)for(const root of ROOTS)out.push(`${root} ${kind}${round?' '+(round+1):''}`);return out;})();
const used=new Set(Object.values(FROZEN)),streetMap=new Map(Object.entries(FROZEN));
{let next=0;for(const name of [...new Set(data.roads.map(r=>r.name).filter(Boolean))].sort()){if(streetMap.has(name))continue;while(used.has(allNames[next]))next++;streetMap.set(name,allNames[next]);used.add(allNames[next]);}}
export function streetName(real){if(data.id==='meridian-city-v2'&&real)return real;if(!real||real===LOCAL_STREET)return LOCAL_STREET;return streetMap.get(real)??LOCAL_STREET;}

// District anchors keep their internal ids; only the shown names are fictional.
export const DISTRICTS=Object.freeze({centre:'Центр',ulejoe:'Заречье',raama:'Северная слобода',beach:'Речной парк',mai:'Майский',papiniidu:'Промышленный',vana:'Старый посад',raekula:'Сосновый бор'});
export const districtName=(id,fallback='Район')=>DISTRICTS[id]??fallback;

// Zones are described without a city name.
export const ZONE_NAMES=Object.freeze({all:'Весь город',west:'Западная часть',east:'Восточная часть'});

// Visit destinations.
export const PLACE_NAMES=Object.freeze({museum:{name:'Городской музей',address:'Музейная улица'},ruutli:{name:'Пешеходная Торговая улица',address:'Торговая улица'},malmo:{name:'Прогулка по Береговой',address:'Береговая улица'}});
