// Release P1 «Вторая работа» (Claude, 17.10.2026). Owner 16.10: «можно работать на двух работах, если начальство
// разрешит; таксистом — подработкой». Estonian public service act (ATS § 60): an official must notify the head in
// writing about side work; the head may forbid it when it harms the service or creates a conflict of interest (for a
// police officer, security work is one); not notifying is a breach of discipline. A taxi driver needs a service card
// (teenindajakaart) from the town government. Side work happens on days off and costs sleep.
import {citizen,CITIZEN_BASE,CITIZEN_COUNT} from './citizens.js';
export const SIDE_JOBS=Object.freeze({
 taxi:Object.freeze({label:'Такси',about:'Вечер за рулём такси через приложение: 8–14 поездок, пассажиры — жители города. Нужна карта обслуживающего лица из горуправы (30 €).',
  card:30,trips:[8,14],fare:[6,16],cut:.2,sleep:12,stress:5,fitness:0}),
 courier:Object.freeze({label:'Курьер доставки',about:'Доставка еды на велосипеде: 50–80 € за вечер, форма +2.',pay:[50,80],sleep:8,stress:3,fitness:2}),
 security:Object.freeze({label:'Охранник в клубе',about:'Ночь на входе в клуб: 100 € за ночь.',pay:[100,100],sleep:16,stress:6,fitness:0,conflict:['police']})
});
export const SIDE_JOB_IDS=Object.freeze(Object.keys(SIDE_JOBS));
export const SIDE=Object.freeze({answer:2,perOff:2,unreportedFound:4,stressLimit:70});
const mix=(a,b,c=0)=>{let h=Math.imul((a|0)+0x51ed,2654435761)^Math.imul((b|0)+0x3c6e,2246822519)^Math.imul((c|0)+0x1b87,3266489917);h^=h>>>15;h=Math.imul(h,2246822519);h^=h>>>13;return h>>>0;};
const span=([a,b],h)=>a+h%(b-a+1);
export const sideJobActive=life=>['approved','unreported'].includes(life?.sideJob?.status);
// The written notice to the head (ATS § 60); the answer comes in two shifts.
export function requestSideJob(life,kind,shift,{report=true}={}){const j=SIDE_JOBS[kind];if(!life)return {ok:false,message:'Подработка — в карьере по графику.'};if(!j)return {ok:false,message:'Нет такой работы.'};
 if(life.sideJob&&life.sideJob.status!=='refused'&&life.sideJob.kind===kind)return {ok:false,message:'Уже оформлено.'};
 if(kind==='taxi'&&!life.taxiCard){if(life.money<j.card)return {ok:false,message:`Карта таксиста стоит ${j.card} €.`};life.money-=j.card;life.taxiCard=true;}
 life.sideJob=report?{kind,status:'pending',ready:shift+SIDE.answer,days:0,earned:0}:{kind,status:'unreported',ready:shift,days:0,earned:0};
 return {ok:true,message:report?'Уведомление о побочной работе подано начальнику. Ответ — через две смены.':'Работаете без уведомления — это нарушение дисциплины.'};}
export function quitSideJob(life){if(!life?.sideJob)return {ok:false,message:'Подработки нет.'};life.sideJob=null;return {ok:true,message:'Подработка оставлена.'};}
// The head's answer: refused for a conflict of interest, a D at the last attestation or when the officer is worn out.
export function sideJobVerdict(life,agency,{grade=null}={}){const j=SIDE_JOBS[life?.sideJob?.kind];if(!j)return 'Нет заявления.';
 if(j.conflict?.includes(agency??'police'))return 'Конфликт интересов: полиция надзирает за охранной деятельностью.';
 if(grade==='D')return 'После оценки D на аттестации — сначала исправить службу.';
 if(life.forcedRest||life.stress>=SIDE.stressLimit)return 'Нагрузка уже мешает службе: сначала отдых.';return null;}
// One evening of side work: money, sleep, stress and a few lines about the people met.
export function sideJobDay(life,shift,day){const sj=life.sideJob,j=SIDE_JOBS[sj?.kind];if(!j)return {lines:[],money:0,found:false};const h=mix(shift,day,sj.days);let money=0;const lines=[];
 if(sj.kind==='taxi'){const trips=span(j.trips,h);let gross=0;for(let k=0;k<trips;k++)gross+=span(j.fare,mix(h,k));money=Math.round(gross*(1-j.cut));
  const p=citizen(CITIZEN_BASE+mix(h,7)%CITIZEN_COUNT);lines.push(`Такси: ${trips} поездок, +${money} € после комиссии приложения`);
  const e=mix(h,9)%6;if(p.age>=18){if(e===0){const lost=span(j.fare,h);money-=lost;lines.push(`${p.name} (${p.job}) вышел${p.gender==='f'?'а':''}, не заплатив: −${lost} €`);}
   else if(e===1){lines.push(`${p.name} забыл${p.gender==='f'?'а':''} телефон в машине — вернули владельцу`);life.stress=Math.max(0,life.stress-3);}
   else if(e===2){lines.push(`Ночью — ${p.name}, сильно пьян${p.gender==='f'?'а':''}: довезли домой, но нервы`);life.stress=Math.min(100,life.stress+3);}
   else if(e===3)lines.push(`Разговорились с пассажиром: ${p.name}, ${p.job}${p.place?' ('+p.place+')':''}`);}}
 else{money=span(j.pay,h);lines.push(`${j.label}: +${money} €`);}
 life.money+=money;life.earned+=Math.max(0,money);life.sleepDebt=Math.min(100,life.sleepDebt+j.sleep);life.stress=Math.min(100,life.stress+j.stress);life.fitness=Math.min(100,life.fitness+j.fitness);
 sj.days++;sj.earned+=money;const found=sj.status==='unreported'&&mix(h,11)%SIDE.unreportedFound===0;if(found)life.integrity=(life.integrity??0)+1;
 return {lines,money,found};}
export function validSideJob(l){const j=l?.sideJob;if(l?.taxiCard!==undefined&&typeof l.taxiCard!=='boolean')return false;if(j===undefined||j===null)return true;
 return !!SIDE_JOBS[j.kind]&&['pending','approved','refused','unreported'].includes(j.status)&&Number.isInteger(j.ready)&&Number.isInteger(j.days)&&j.days>=0&&Number.isFinite(j.earned)&&Math.abs(j.earned)<1e7&&(j.reason===undefined||typeof j.reason==='string'&&j.reason.length<200);}
