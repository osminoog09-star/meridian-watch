// R4 «Выгорание» (Claude, 11.10.2026). Stress and sleep debt have consequences, without a death
// spiral: tired and stressed officers work slower, and at night a very tired driver can nod off
// (Postimees 2020: 46% of patrol officers had a microsleep in an alarm vehicle at night, worst
// 04:00–05:00). The PPA has psychologists: a burnt-out officer is sent to rest, not punished.
// Deterministic (hashes of ids and time buckets), no rng(). Scheduled campaigns only.
import {WORLD_SECONDS_PER_TICK_SECOND} from './transport.js';
const ticks=minutes=>minutes*60/WORLD_SECONDS_PER_TICK_SECOND;
export const BURNOUT=Object.freeze({stressFrom:60,maxPenalty:.25,checkMinutes:20,nightFrom:0,nightTo:6*60,fatigueFrom:70,crashFrom:88,nearMissStop:ticks(5),crashStop:ticks(10),crashWear:6,burnoutStress:80,burnoutPeriods:2,psychologistRelief:20});
export const BURNOUT_STRESS=Object.freeze({failed:5,violent:2,custody:1});
export const VIOLENT=Object.freeze(['street-fight','domestic']);
// Work speed of a crew: stress above 60 slows it down, up to −25% at 100.
export const performanceFactor=stress=>1-Math.max(0,Math.min(40,(Number.isFinite(stress)?stress:0)-BURNOUT.stressFrom))/40*BURNOUT.maxPenalty;
const hash=(a,b)=>{let h=Math.imul((a|0)+101,2654435761)^Math.imul((b|0)+7,2246822519);h^=h>>>15;h=Math.imul(h,2246822519);return ((h^h>>>13)>>>0)/4294967296;};
// Chance per 20-minute bucket while driving at night: 0 at fatigue 70, 0.5 at 100.
export function microsleep(unitId,bucket,fatigue,minuteOfDay){const m=((minuteOfDay%1440)+1440)%1440;if(m<BURNOUT.nightFrom||m>=BURNOUT.nightTo||!(fatigue>=BURNOUT.fatigueFrom))return null;
 const chance=Math.min(.5,(fatigue-BURNOUT.fatigueFrom)/(100-BURNOUT.fatigueFrom)*.5);if(hash(unitId,bucket)>=chance)return null;
 return fatigue>=BURNOUT.crashFrom?'crash':'nearMiss';}
export const bucketOf=elapsed=>Math.floor(elapsed/ticks(BURNOUT.checkMinutes));
