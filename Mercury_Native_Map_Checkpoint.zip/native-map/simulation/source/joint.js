// Release K «Совместные происшествия» (Claude, 16.10.2026). A crash with a trapped driver or a house fire with
// casualties needs police, rescuers and an ambulance on one scene. The player's service does its own part with its
// own mechanics (police crash talk, rescue extrication/fire model, ambulance patient); the other services come as
// city crews. Each part depends on the others:
//   · rescuers on a road work faster behind a police cordon (and slower without one);
//   · the ambulance cannot finish while the patient is still trapped — it treats through the window;
//   · the rescuers hand the casualty to the ambulance, the police reopen the road only when both are done.
// When the call closes, a common debrief grades the cooperation (arrival times, waits, unsafe work).
// No random draws: which calls become joint is a hash of the campaign seed and the call id (seeds unchanged).
export const JOINT_SCENARIOS=Object.freeze({
 crash:Object.freeze({title:'ДТП: водитель зажат, есть пострадавшие',road:true,variants:Object.freeze({police:'crash',rescue:'rescue-crash',ems:'ems-trauma'}),rescueWork:9,rescueText:'ДТП, водителя зажало в машине',medical:'Пострадавший в ДТП, зажат в машине',
  lines:Object.freeze({police:'перекрыть движение, оформить ДТП',rescue:'обесточить машину, деблокировать водителя',ems:'стабилизировать и увезти пострадавшего'})}),
 fire:Object.freeze({title:'Пожар в доме, есть пострадавшие',road:false,variants:Object.freeze({police:'fire-smoke',rescue:'fire-flat',ems:'ems-unconscious'}),rescueWork:14,rescueText:'Пожар в квартире, внутри люди',medical:'Отравление дымом',
  lines:Object.freeze({police:'оцепить подъезд, освободить проезд',rescue:'потушить и вывести людей',ems:'принять и лечить пострадавших'})})
});
export const JOINT_IDS=Object.freeze(Object.keys(JOINT_SCENARIOS));
export const PARTS=Object.freeze(['police','rescue','ems']);
export const PART_NAMES=Object.freeze({police:'Полиция',rescue:'Спасатели',ems:'Скорая'});
export const JOINT=Object.freeze({
 every:3,              // every third suitable call (by hash) is a joint one
 policeKmh:65,         // a city patrol driving to the cordon
 cordonSpeed:1.5,      // rescuers on a road behind a police cordon
 noCordon:.8,          // ... and without one
 trappedRate:.35,      // the ambulance treats a trapped casualty through the window
 trappedCap:.6,        // ... but cannot finish before the rescuers free them
 hold:.97,             // a part waits at 97% until the parts it depends on are done
 limitScale:2,         // a joint call is not «missed» while the city partners still work
 quickArrival:12,      // minutes: a partner on scene within this is «quick»
 waitLimit:10,         // minutes a part may wait for another before the debrief marks it
 reward:Object.freeze({A:Object.freeze({trust:1,xp:10}),B:Object.freeze({trust:0,xp:5}),C:Object.freeze({trust:-1,xp:0})})
});
const mix=(a,b)=>{let h=Math.imul((a|0)+97,2654435761)^Math.imul((b|0)+13,40503);h^=h>>>15;return h>>>0;};
export function jointScenarioFor(agency,variant){for(const id of JOINT_IDS)if(JOINT_SCENARIOS[id].variants[agency??'police']===variant)return id;return null;}
// The player's service does its part; the others are city crews. 112 routes calls and has no part of its own (later).
export function makeJoint(s,i){
 const agency=s?.agency??'police';if(agency==='dispatch'||!i||i.joint)return null;
 const scenario=jointScenarioFor(agency,i.variant);if(!scenario)return null;
 if(mix(s.seed,i.id)%JOINT.every!==0)return null;
 const parts={};for(const p of PARTS)parts[p]={by:p===agency?'player':'city',state:'called',at:null,done:null,wait:0};
 i.joint={scenario,player:agency,parts,unsafe:0,report:null};return i.joint;
}
export const jointOf=i=>i?.joint&&JOINT_SCENARIOS[i.joint.scenario]?i.joint:null;
export const jointTitle=i=>JOINT_SCENARIOS[jointOf(i)?.scenario]?.title??'';
const onScene=part=>part&&(part.state==='onscene'||part.state==='done');
// What the player's part may do this step: speed factor and whether it may finish.
export function jointGate(i){
 const j=jointOf(i);if(!j)return {rate:1,cap:1,canClose:true,waitingFor:null};const sc=JOINT_SCENARIOS[j.scenario],p=j.parts;
 if(j.player==='police'){const left=['rescue','ems'].filter(k=>p[k].state!=='done');return {rate:1,cap:1,canClose:!left.length,waitingFor:left[0]??null};}
 if(j.player==='rescue'){const cordon=onScene(p.police),rate=sc.road?(cordon?JOINT.cordonSpeed:JOINT.noCordon):(cordon?1.15:.95);return {rate,cap:1,canClose:onScene(p.ems),waitingFor:onScene(p.ems)?null:'ems',unsafe:sc.road&&!cordon};}
 /* ems */const free=p.rescue.state==='done',cordon=!sc.road||onScene(p.police);return {rate:(free?1:JOINT.trappedRate)*(cordon?1:.85),cap:free?1:JOINT.trappedCap,canClose:free,waitingFor:free?null:'rescue',unsafe:sc.road&&!onScene(p.police)};
}
// Mark arrivals and completions; time in minutes of the call's age.
export function markPart(i,part,state,minute){const j=jointOf(i);if(!j||!j.parts[part])return false;const x=j.parts[part];
 if(state==='onscene'&&x.state==='called'){x.state='onscene';x.at=minute;return true;}
 if(state==='done'&&x.state!=='done'){if(x.at===null)x.at=minute;x.state='done';x.done=minute;return true;}return false;}
// The common debrief: who came when, who waited for whom, was anyone working on a road without a cordon.
export function jointReport(i,success){
 const j=jointOf(i);if(!j)return null;const sc=JOINT_SCENARIOS[j.scenario],lines=[];let points=success?3:0;
 for(const k of PARTS){const x=j.parts[k],who=PART_NAMES[k]+(x.by==='player'?' (вы)':'');
  if(x.at===null){lines.push(`${who}: не успели на место.`);points-=1;continue;}
  lines.push(`${who}: на месте через ${Math.round(x.at)} мин${x.done!==null?`, работа закончена на ${Math.round(x.done)} мин`:''} — ${sc.lines[k]}.`);
  if(x.by==='city'&&x.at>JOINT.quickArrival)points-=.5;
  if(x.wait>JOINT.waitLimit){lines.push(`${PART_NAMES[k]} ждали других ${Math.round(x.wait)} мин.`);points-=.5;}}
 if(j.unsafe>2){lines.push(`Работа на дороге без оцепления: ${Math.round(j.unsafe)} мин — опасно для расчёта и пострадавшего.`);points-=1;}
 const grade=points>=2.5?'A':points>=1.5?'B':'C';
 lines.unshift(`Совместный разбор: «${sc.title}» — оценка ${grade}.`);
 j.report={grade,lines:lines.slice(0,8)};return j.report;
}
export function validJoint(j){
 if(j===undefined)return true;if(!j||typeof j!=='object'||!JOINT_SCENARIOS[j.scenario]||!PARTS.includes(j.player))return false;
 const num=(x,min,max)=>Number.isFinite(x)&&x>=min&&x<=max,time=x=>x===null||num(x,0,10000);
 if(!j.parts||!PARTS.every(k=>{const x=j.parts[k];return x&&['player','city'].includes(x.by)&&(x.by==='player')===(k===j.player)&&['called','onscene','done'].includes(x.state)&&time(x.at)&&time(x.done)&&num(x.wait,0,10000);}))return false;
 if(!num(j.unsafe,0,10000))return false;
 return j.report===null||(!!j.report&&['A','B','C'].includes(j.report.grade)&&Array.isArray(j.report.lines)&&j.report.lines.length<=8&&j.report.lines.every(l=>typeof l==='string'&&l.length<300));
}
