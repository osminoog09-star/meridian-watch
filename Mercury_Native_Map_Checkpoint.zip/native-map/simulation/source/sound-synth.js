// R26 «Звук: качество и реализм» (Claude, 12.10.2026). Pure synthesis rules for the rewritten audio
// engine (audio.js). Everything is procedural and original — no recordings, no downloads.
//  · Noise beds: pink and brown noise (not white) with a crossfaded loop seam, so there is no hiss
//    and no audible click or period.
//  · Engine: four-stroke firing frequency from rpm with a five-gear box, idle when the car stands with
//    the engine on, a filter that opens with rpm, plus an intake/road noise layer.
//  · Siren: square-like electronic tone, wail 650–1450 Hz (slow rise, quicker fall, ~4.6 s) and
//    yelp (~3 sweeps per second); the nearest responding car is heard, not only the selected one.
//  · Space: stereo position and distance attenuation from the camera.
//  · Radio: squelch open → band-limited «voice» syllables → squelch tail → short roger chirp.
export const SYNTH=Object.freeze({loopSeconds:12,fadeSeconds:.35});
const lcg=seed=>{let s=seed>>>0;return ()=>{s=(Math.imul(s,1664525)+1013904223)>>>0;return s/4294967296*2-1;};};
// Pink noise (Paul Kellet's economy filter), peak-normalised to 0.5.
export function pinkNoise(length,seed=7){const r=lcg(seed),out=new Float32Array(length);let b0=0,b1=0,b2=0,peak=1e-9;
 for(let k=0;k<length;k++){const w=r();b0=.99765*b0+w*.099046;b1=.963*b1+w*.2965164;b2=.57*b2+w*1.0526913;const v=b0+b1+b2+w*.1848;out[k]=v;peak=Math.max(peak,Math.abs(v));}
 for(let k=0;k<length;k++)out[k]=out[k]/peak*.5;return out;}
// Brown (red) noise: leaky integration of white noise, DC removed, peak-normalised to 0.5.
export function brownNoise(length,seed=11){const r=lcg(seed),out=new Float32Array(length);let v=0,mean=0,peak=1e-9;
 for(let k=0;k<length;k++){v=v*.995+r()*.05;out[k]=v;mean+=v;}mean/=Math.max(1,length);for(let k=0;k<length;k++){out[k]-=mean;peak=Math.max(peak,Math.abs(out[k]));}
 for(let k=0;k<length;k++)out[k]=out[k]/peak*.5;return out;}
// Seamless loop: the last `fade` samples are crossfaded (equal power) into the first ones.
export function seamlessLoop(samples,fade){const n=samples.length,f=Math.max(1,Math.min(Math.floor(fade),Math.floor(n/3))),out=new Float32Array(n-f);
 for(let k=0;k<out.length;k++)out[k]=samples[k];for(let k=0;k<f;k++){const a=k/f;out[k]=samples[k]*Math.sin(a*Math.PI/2)+samples[n-f+k]*Math.cos(a*Math.PI/2);}return out;}
export const loopLength=rate=>Math.round(rate*(SYNTH.loopSeconds+SYNTH.fadeSeconds));
export const noiseLoop=(kind,rate)=>seamlessLoop(kind==='brown'?brownNoise(loopLength(rate)):pinkNoise(loopLength(rate)),rate*SYNTH.fadeSeconds);
// Slow natural modulation (0..1), incommensurate periods so it never repeats audibly.
export const gust=t=>Math.max(0,Math.min(1,.45+.25*Math.sin(t*.23)+.17*Math.sin(t*.61+1.3)+.13*Math.sin(t*1.7+.4)));
export const lapping=t=>.55+.25*Math.sin(t*1.9)+.2*Math.sin(t*.73+.8);
// Engine: gear, rpm, firing frequency, brightness and level.
const GEARS=[0,18,35,55,80,130];
export function engineSound(speedKmh,{type='sedan',moving=false,on=true}={}){const v=Math.max(0,Number.isFinite(speedKmh)?speedKmh:0);if(!on)return {rpm:0,hz:0,cutoff:200,level:0,noise:0,gear:0};
 let gear=1;while(gear<GEARS.length-1&&v>GEARS[gear])gear++;const lo=GEARS[gear-1],hi=GEARS[gear],frac=Math.max(0,Math.min(1,(v-lo)/(hi-lo)));
 const rpm=moving&&v>=2?Math.round(1100+frac*2500+(gear===1?0:300)):800,hz=rpm/30*(type==='suv'?.86:1),load=Math.min(1,v/90);
 return {rpm,hz,cutoff:220+rpm*.32,level:moving&&v>=2?.05+.04*load:.022,noise:moving&&v>=2?.02+.05*load:.006,gear};}
export const ENGINE_WAVE=Object.freeze([0,1,.72,.46,.33,.24,.17,.12,.09,.07,.05,.04]);
// Siren tone and sweep.
export const SIREN_WAVE=Object.freeze([0,1,.04,.34,.03,.2,.02,.14,.01,.1,.01,.07]);
export const SIREN_RANGE=Object.freeze({lo:650,hi:1450,wail:4.6,yelp:.32});
export function sirenFrequency(mode,t){const {lo,hi,wail,yelp}=SIREN_RANGE;if(mode==='yelp'){const p=((t%yelp)+yelp)%yelp/yelp;return lo+(hi-lo)*Math.pow(p,.8);}
 const p=((t%wail)+wail)%wail/wail,shape=p<.55?1-Math.pow(1-p/.55,2):1-Math.pow((p-.55)/.45,1.6);return lo+(hi-lo)*shape;}
// Stereo position and distance from the camera (scene: {x,y,zoom}).
export function spatial(p,scene){if(!p||!scene||![scene.x,scene.y,scene.zoom,p.x,p.y].every(Number.isFinite))return {pan:0,gain:1};
 const dx=(p.x-scene.x)*scene.zoom,dy=(p.y-scene.y)*scene.zoom,d=Math.hypot(dx,dy);
 return {pan:Math.max(-.85,Math.min(.85,dx*1.4)),gain:(1/(1+d*d*2.5))*(.45+.55*Math.min(1,scene.zoom/6))};}
// Radio «voice»: syllable levels for a line of text (deterministic). Duration 0.5–2.2 s.
export function radioPattern(text){const s=String(text??'');let h=2166136261;for(let k=0;k<s.length;k++)h=Math.imul(h^s.charCodeAt(k),16777619);const r=lcg(h);
 const duration=Math.min(2.2,.5+s.length*.028),out=[];let t=.06;let k=0;while(t<duration-.08&&k<60){const ch=s[Math.floor(k*s.length/Math.max(1,duration/.12))]??'a',pause=ch===' '||ch===','?1:0;
  const step=.09+(r()+1)*.03;out.push({t,level:pause?.08:.45+(r()+1)*.27});t+=step;k++;}return {duration,syllables:out};}
// ── Release A «Живой город» (Claude, 12.10.2026) ────────────────────────────────────────────────
// Footsteps by surface: one step = a short filtered noise burst. Snow crunches (several tiny grains),
// a wet pavement splashes (longer, duller), ice clicks, grass is soft. Shape = [[time, level], …].
export const FOOTSTEP=Object.freeze({
 asphalt:{hz:2100,q:1.1,length:.06,level:1,grains:1},
 wet:{hz:1250,q:.6,length:.11,level:1.15,grains:2},
 snow:{hz:850,q:.5,length:.17,level:.95,grains:5},
 ice:{hz:3300,q:1.6,length:.045,level:.75,grains:1},
 grass:{hz:650,q:.5,length:.12,level:.55,grains:3}
});
export function footstepShape(surface,step=0){const f=FOOTSTEP[surface]??FOOTSTEP.asphalt,shape=[[.004,1]];
 for(let g=1;g<f.grains;g++){const t=f.length*g/(f.grains+.5),v=.35+.4*(((step*7+g*13)%10)/10);shape.push([t-.006,.15],[t,v]);}
 shape.push([f.length*.8,.12]);return {hz:f.hz*(1+((step%3)-1)*.06),q:f.q,length:f.length,level:f.level,shape};}
// Other services. Ambulance: two-tone hi-lo; rescue truck: a deep two-tone horn. Fictional city,
// original tones (not a recording of any real vehicle).
export const SERVICE_SIREN=Object.freeze({ambulance:{lo:720,hi:960,period:1.2},rescue:{lo:392,hi:523,period:1.5}});
export function serviceSirenFrequency(kind,t){const s=SERVICE_SIREN[kind]??SERVICE_SIREN.ambulance,p=((t%s.period)+s.period)%s.period;return p<s.period/2?s.hi:s.lo;}
// Far sounds lose their highs: a low-pass that closes with distance (the spatial gain 0..1).
export const distanceCutoff=gain=>Math.round(Math.max(700,Math.min(9000,9000*Math.sqrt(Math.max(0,Math.min(1,Number.isFinite(gain)?gain:0))))));
// Voices at a scene: syllable-like level 0..1 (several people talking, never perfectly regular).
export function talkEnvelope(t){const a=Math.max(0,Math.sin(t*9.1)),b=Math.max(0,Math.sin(t*6.3+1.1)),pause=Math.sin(t*.9)>-.35?1:.15;return Math.min(1,(a*.7+b*.5)*pause);}
// A portable radio at the scene squawks now and then (seconds between calls, deterministic).
export const sceneRadioGap=n=>6+((n*37)%9);
