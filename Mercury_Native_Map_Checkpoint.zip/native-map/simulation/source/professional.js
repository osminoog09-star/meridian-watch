import {autoChoice} from './scenes.js';
export const SPECIALTIES=Object.freeze({negotiation:'Переговоры',search:'Поиск',traffic:'Дорожная работа',investigation:'Проверка обстоятельств'});
export function specialtyFor(type){return type===0||type===4?'negotiation':type===2?'search':type===1||type===5?'traffic':'investigation';}
export function ensureDevelopment(s){if(s.mode!=='career'||!s.service)return null;const service=s.service;if(service.development===undefined)service.development={version:1,practice:Object.fromEntries(Object.keys(SPECIALTIES).map(k=>[k,0])),reviews:[]};return service.development;}
export function recordAssessment(s,i,manual){
 if(s.mode!=='career'||!i.units.includes(1))return;
 const expected=autoChoice(i),choice=i.decision;
 i.assessment={choice,expected,manual,specialty:specialtyFor(i.type),reason:i.type===2?'Опрос помогает получить ориентировку быстрее.':i.type===5?(i.scene.participants[0].cooperative?'Сотрудничающий водитель допускает проверку на месте.':'Водитель не сотрудничает: наблюдение само по себе не останавливает машину.'):i.type===1?(i.variant==='fire-smoke'?'Сначала нужно оцепить подъезд и не мешать спасателям.':i.variant==='crash'||!i.variant?'Сначала необходимо обезопасить место ДТП.':'Сначала необходимо обезопасить место.'):i.type===0||i.type===4?'Спокойный разговор снижает напряжение.':'Проверка помогает установить обстоятельства.'};
}
export function developmentBonus(s,i,unit){const d=s.service?.development;if(s.mode!=='career'||unit?.id!==1||!d)return 0;return d.practice[specialtyFor(i.type)]/100*.04;}
export function completeAssessment(s,i,success){
 const d=ensureDevelopment(s),a=i.assessment;if(!d||!a||!i.units.includes(1)||d.reviews.some(r=>r.incident===i.id))return;
 const gain=success?(a.choice===a.expected?2:1):0,key=a.specialty;
 d.practice[key]=Math.min(100,d.practice[key]+gain);
 d.reviews.unshift({...a,incident:i.id,shift:s.shift,time:Math.min(s.time,s.shiftLength),success,gain});d.reviews=d.reviews.slice(0,40);
}
const choices=new Set(['talk','check','secure','backup','chase','observe']);
export function validAssessment(a,type){return a===undefined||!!a&&choices.has(a.choice)&&choices.has(a.expected)&&typeof a.manual==='boolean'&&a.specialty===specialtyFor(type)&&typeof a.reason==='string'&&a.reason.length<=240;}
export function validDevelopment(d,s){
 if(d===undefined)return true;if(!d||d.version!==1||!d.practice||!Object.keys(SPECIALTIES).every(k=>Number.isInteger(d.practice[k])&&d.practice[k]>=0&&d.practice[k]<=100)||!Array.isArray(d.reviews)||d.reviews.length>40)return false;
 const start=(s.service.startShift-1)*s.shiftLength+s.service.startTime;
 return new Set(d.reviews.map(r=>r?.incident)).size===d.reviews.length&&d.reviews.every(r=>r&&choices.has(r.choice)&&choices.has(r.expected)&&typeof r.manual==='boolean'&&Object.hasOwn(SPECIALTIES,r.specialty)&&typeof r.reason==='string'&&r.reason.length<=240&&Number.isInteger(r.incident)&&r.incident>0&&r.incident<s.nextId&&Number.isInteger(r.shift)&&r.shift>0&&r.shift<=s.shift&&Number.isFinite(r.time)&&r.time>=0&&r.time<=s.shiftLength&&(r.shift-1)*s.shiftLength+r.time>=start&&(r.shift-1)*s.shiftLength+r.time<=(s.shift-1)*s.shiftLength+s.time&&typeof r.success==='boolean'&&r.gain===(r.success?(r.choice===r.expected?2:1):0));
}
