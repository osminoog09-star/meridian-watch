// R18 «Крупные события смены» (Claude, 11.10.2026). Besides calendar holidays a roster shift can bring
// a city event that shapes the whole shift: an autumn/winter storm (fallen trees, torn wires — the
// weather turns to wind), a football match (fans, fights, drunk people), a summer concert (crowds,
// lost teenagers, thefts) or a winter power cut (dark crossings, burglar alarms). The event has the
// same shape as a holiday ({id,label,intensity,mods,about}) so the briefing, call mix, call rate and
// news handle it the same way. Chosen by a hash of the shift index (no rng): every campaign sees the
// same city calendar, like the weather.
import {shiftStartMinute} from './schedule.js';
import {dateOf,seasonOf,weekdayOf} from './season.js';
export const EVENTS=Object.freeze({
 storm:{label:'Шторм',about:'Порывы до 25 м/с: падают деревья, рвутся провода, на дорогах завалы.',intensity:1.3,weather:'wind',mods:{'tree-down':1,'power-lines':1,'blocked-exit':2.5,crash:1.5,'animal-road':1.3,'yard-company':.3,'beach-party':.1,'noise-venue':.6}},
 football:{label:'Футбольный матч на стадионе',about:'Тысячи болельщиков: давка у входа, драки фанатов, пьяные на улицах после игры.',intensity:1.3,mods:{'fan-fight':1,'street-fight':1.8,'drunk-person':1.7,'noise-venue':1.5,crash:1.2,shoplift:1.2}},
 concert:{label:'Концерт под открытым небом',about:'Большая сцена в парке: толпа, потерявшиеся подростки, карманные кражи, громкие компании.',intensity:1.3,mods:{'lost-at-concert':1,'drunk-person':1.8,'noise-venue':1.6,'yard-company':1.4,shoplift:1.5,'bike-theft':1.4,'street-fight':1.3}},
 outage:{label:'Отключение электричества',about:'Часть города без света: не работают светофоры, срабатывают охранные сигнализации.',intensity:1.2,mods:{'alarm-burglary':1,crash:1.8,'blocked-exit':1.3,'confused-person':1.5}}
});
export const EVENT_IDS=Object.freeze(Object.keys(EVENTS));
const hash=index=>{let h=Math.imul((index|0)+1013,2654435761);h^=h>>>15;h=Math.imul(h,2246822519);h^=h>>>13;return (h>>>0)%1000/1000;};
// Which special event (if any) falls on the shift with this 0-based index.
export function specialEvent(index,night){const start=shiftStartMinute(index),d=dateOf(start),season=seasonOf(d.month),wd=weekdayOf(start),r=hash(index);let id=null;
 if((season==='autumn'||season==='winter')&&r<.09)id='storm';
 else if(season==='winter'&&r>=.09&&r<.15)id='outage';
 else if(!night&&(wd===6||wd===0)&&d.month>=2&&d.month<=10&&r>=.5&&r<.8)id='football';
 else if((season==='summer'||d.month===4)&&(wd===5||wd===6)&&r>=.2&&r<.55)id='concert';
 return id?{id,...EVENTS[id]}:null;}
