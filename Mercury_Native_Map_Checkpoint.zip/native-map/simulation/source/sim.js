import {urgentMovement} from './response-priority.js';import {setSirens} from './visits.js';
import {recordAssessment,completeAssessment,developmentBonus,validAssessment} from './professional.js';
import {ensureTraining,trainingEvent,validTraining} from './training.js';
import {ensureService,careerPermission,serviceEvent,validService} from './career.js';
import {advanceVehicle,patrolSpeed,WORLD_SECONDS_PER_TICK_SECOND} from './transport.js';
import {LIVERIES,EXTRAS,SLOTS,FUEL,WEAR,REPAIR,ensureVehicle,addHistory,consume,speedFactor,emptyTank,needsFuel,broken,refuelCost,refuelLitres,repairCost,repairTime,repairMinutes,extraBonus,slotsOf,validVehicleState,toTicks,toMinutes,tankOf} from './garage.js';
import {ensurePopulation,resyncPopulation,tickPopulation,validatePopulation,linkResident,releaseResidents,validateResidentLinks} from './population.js';
import {SHIFT_TICKS,ROTA,isScheduled,validSchedule,shiftStartElapsed,nightFatigueFactor,shiftKind,restBefore} from './schedule.js';
import {ROUTINE,STATUS_TEXT,statusText,briefingFor,validBolo,validRoutine} from './routine.js';
import {TASKS,taskTicks,taskResult,taskReward,autoTaskFor,autoTaskRoll,preventionMods,validTask,validPatrolWork,TASK_RULES} from './patrolwork.js';
import {specialEvent} from './events.js';
import {FOCUS,canSetFocus,ATTEST,attestation,LIFE_EVENTS,lifeEventFor,INTEGRITY,COUNCIL,morale,MORALE,newCandidates,validCareer2} from './career2.js';
import {ARCS,CITY,chapterOf,spawnAt,arcPoint,nextArc,validCity,DONE_LIMIT,EFFECT,cityMods} from './arcs.js';
import {WEEK,STORY,weekActive,storyDay,storyPoint,dayResult,weekVerdict,validWeek,CHIEF_WEEK,CHIEF_REWARD,validChiefWeek} from './firstweek.js';
import {DUTY,onDuty,unavailable,CALLED_IN_STRESS,dutyWage,STAFF_COURSES,studyBlocker,studyShift,TRANSFER,transferVerdict,PURCHASES,purchaseBlocker,owns,livingCost,WORKSHOP,validService2} from './service2.js';
import {ensureTalk,applyChoice,autoOption,currentStage,talkDone,talkComplaintFactor,validTalk,optionOpen,scriptFor,injuryRolled} from './dialogues.js';
import {CASE_KINDS,stepEvidence,arrestReady,arrestSucceeds,autoCaseStep,newCases,openCases,isDetective,DETECTIVE,INTERVIEW_NEED,labResult} from './detective.js';
import {validTips} from './tips.js';
import {makeGoals,goalLabel,goalValue,goalMet,validGoals,GOAL_REWARD} from './goals.js';
import {newsRoom,callNews,checkpointNews,complaintNews,holidayNews,awardNews,pushNews,validNews} from './news.js';
import {ensurePartner,nextPartner,partnerPace,partnerComplaints,bondAfterShift,BOND,TRAITS} from './partner.js';
import {HISTORY_LIMIT,AWARD_LIMIT,AWARD_REWARD,shiftRecord,monthOf,monthSummary,newAwards,emptyStats,validHistory} from './history.js';
import {upgradeFor} from './upgrades.js';import {UPGRADES,UPGRADE_EFFECT,has,upgradesUpkeep,upgradeBonus,validUpgrades,COMPLAINTS,complaintChance,complaintRolled,complaintCleared,COMPLAINT_REASONS,validComplaints} from './upgrades.js';
import {shiftDate,seasonOf,SUN,weatherSpeed,shiftEvent,loadFactor,absoluteMinute,weekdayOf,WEEKDAY_LABEL} from './season.js';
import {worldMinutes} from './transport.js';
import {BURNOUT,BURNOUT_STRESS,VIOLENT,performanceFactor,microsleep,bucketOf} from './burnout.js';
import {ROSTER,ensureOfficer,rosterAfterShift,startFatigueOf,wagesFactor,canTakeLeave,validOfficerRoster} from './roster.js';
import {mandatoryOk,COURSES as LIFE_COURSES,LIVING,canTakeVacation,applyVacation,newYear,ensureLife,freeBlocks,validPlan,defaultPlan,applyPlan,workShift,startFatigue,courseBonus,validLife,scheduledRank,ROLES,roleBlocker,roleBonus,roleNoCaution,roleLeadBonus} from './life.js';
import {ensureScene,autoChoice,explainChoice,prepareScenes,sceneStep,closeScene,validateScene} from './scenes.js';import {isRescue,RESCUE_RANKS,RESCUE_TYPES,isRescueType,ensureFire,fireStep,rescueStep,rescueOutcome,validFire,RESCUE_START,RESCUE_RECRUITS,RESCUE_VEHICLES,RESCUE_CALL_GAP,rescueTaskFor} from './rescue.js';import {isService,profileOf,crewLimitOf,isServiceType,validAgency,PROFILES,typeAgency,unitAgency,unitProfile} from './agency.js';import {isDispatch,DISPATCH_FLEET,FLEET_LOOK,newDesk,validDesk,validCall,DESK,RELEASE,ticksOf,colleagueDecision,colleagueMinutes,gradeRoute,rightService,rightPriority,questionsFor,answerFor,INSTRUCTIONS,usefulInstruction,SERVICES,callGroup,callTitle} from './dispatch.js';import {EMS_TYPES,isEms,isEmsType,ensurePatient,patientStep,patientOutcome,validPatient,needsHospital,homeMistake,EMS_VEHICLES,PATIENT} from './ems.js';
import {MAP_ID,NODES,byId,nearest,point,roadRoute,atNode,migrateMap} from './geography.js';
import {containsWorldPoint} from './city-coverage.js';
import {planTraffic} from './traffic.js';
import {pickVariant,placeNodes,defaultVariant,variantOf,validVariant,crewFits,FIT_BONUS,variantById,DISTRICT_IDS,FOLLOW_UPS,followUpChance,leadHash,FOLLOW_UP_DELAY,DISTRICT_TRUST_STEP,weatherFor,WEATHER,custodyFor,HANDOVER_TIME,CUSTODY_REWARD,CUSTODY_CHOICES,CUSTODY_FOLLOW_UP,canChooseCustody,custodyDecision,needsAmbulance,MEDICAL,AMBULANCE,CASE_LIMIT,RESCUE,needsRescue,RESCUE_TEAM,SERVICE_LIMIT,leadFor,needsAmbulanceFor,medicalText,protocolFor} from './calls.js';
import {cityMinute} from './population.js';
import {cityGrant,RESERVE,reserveLimit} from './economy.js';
import {DISPATCH,callsign,serviceCallsign,radioText,pushRadio,validRadio} from './radio.js';
import {districtName} from './fiction.js';
import {POLICIES,policyOf,priorityOf,policyCost,validPolicy,PRIORITY_RULES} from './policy.js';
export const SIZE=6;
export const HQ=point(byId('centre')); 
export const RANKS=['Стажёр','Патрульный','Старший сотрудник','Сержант','Руководитель смены'];
export const rankTitle=(s,rank=s?.rank??0)=>(profileOf(s)?.ranks??RANKS)[rank]??RANKS[rank];/* Release H */
export const TYPES=[
 {name:'Шум у заведения',icon:'◉',severity:1,duration:14,limit:145,brief:'Посетители спорят у входа. Заявитель просит восстановить порядок.',options:[['Поговорить с участниками','talk'],['Установить обстоятельства','check']]},
 {name:'Дорожное происшествие',icon:'◇',severity:2,duration:20,limit:160,brief:'На перекрёстке столкнулись две машины. Нужно обезопасить место и проверить участников.',options:[['Обезопасить место и проверить людей','secure'],['Вызвать второй экипаж','backup']]},
 {name:'Пропал человек',icon:'◎',severity:2,duration:23,limit:190,brief:'Родственник потерял связь с пожилым человеком. Последний раз его видели у парка.',options:[['Опросить свидетелей','talk'],['Проверить ближайшие улицы','check']]},
 {name:'Кража в магазине',icon:'▣',severity:2,duration:18,limit:145,brief:'Охрана сообщает о краже. Участники находятся рядом с магазином.',options:[['Выяснить обстоятельства','check'],['Поговорить с участниками','talk']]},
 {name:'Конфликт на улице',icon:'△',severity:3,duration:25,limit:135,brief:'Несколько человек конфликтуют. Обстановка напряжённая — рекомендуется подкрепление.',options:[['Деэскалация и безопасная дистанция','talk'],['Запросить подкрепление','backup']]},
 {name:'Проверка автомобиля',icon:'◇',severity:2,duration:10,limit:190,brief:'Поступила ориентировка на автомобиль. Проверьте водителя. Он может сотрудничать или попытаться уехать.',options:[['Проверить документы','check'],['Следовать и остановить','chase'],['Наблюдать с дистанции','observe']]},
 ...RESCUE_TYPES.map(({rescue,...t})=>t)/* Release H: 6 fire, 7 technical rescue, 8 water, 9 danger check */,
 ...EMS_TYPES/* Release I: 10 cardiac arrest, 11 time-critical illness, 12 injury, 13 unwell */
];
export function rng(s){s.seed=(Math.imul(1664525,s.seed)+1013904223)>>>0;return s.seed/4294967296;}
export function zone(p){return nearest(p).sector;}
function baseGame(mode='career',seed=7182){return {version:1,seed,mode,time:0,shift:1,shiftLength:480,ended:false,xp:0,rank:0,budget:2400,trust:78,resolved:0,missed:0,nextIncident:12,nextId:1,incidents:[],history:[],logs:[],units:[
 {id:1,name:'Патруль 01',people:['Вы','Алексей Морозов'],role:'Наставник · стажёр',x:0,y:3,route:[],status:'patrol',auto:true,zone:'all',cross:true,fatigue:8,skill:0.85,incident:null,work:0},
 {id:2,name:'Патруль 02',people:['Анна Волкова','Марк Левин'],role:'Опытный экипаж',x:2,y:1,route:[],status:'patrol',auto:true,zone:'west',cross:false,fatigue:13,skill:0.82,incident:null,work:0},
 {id:3,name:'Патруль 03',people:['Илья Орлов','Ева Белова'],role:'Дорожный патруль',x:5,y:4,route:[],status:'patrol',auto:true,zone:'east',cross:false,fatigue:11,skill:0.78,incident:null,work:0}
]};}
export const RECRUITS=[
 {id:1,name:'Анна Волкова',specialty:'Переговоры',skill:.92,fee:420,salary:55},
 {id:2,name:'Марк Левин',specialty:'Вождение',skill:.80,fee:300,salary:40},
 {id:3,name:'Ева Белова',specialty:'Дорожная полиция',skill:.86,fee:360,salary:45},
 {id:4,name:'Илья Орлов',specialty:'Патрулирование',skill:.75,fee:250,salary:35},
 {id:5,name:'София Миронова',specialty:'Переговоры',skill:.88,fee:380,salary:50},
 {id:6,name:'Артём Соколов',specialty:'Поиск',skill:.78,fee:280,salary:40},
 {id:7,name:'Нина Крылова',specialty:'Патрулирование',skill:.83,fee:330,salary:45},
 {id:8,name:'Даниил Ветров',specialty:'Вождение',skill:.76,fee:260,salary:35}
];
// Release H: a rescue station instead of a police department — red vehicles, firefighter recruits.
/* Release J: the 112 campaign — the city's police, rescue and ambulance crews with their own vehicles */
function dispatchDepartment(s){for(const u of s.units){const f=DISPATCH_FLEET.find(x=>x.id===u.id),v=s.vehicles.find(x=>x.id===u.vehicleId);if(!f||!v)continue;const look=FLEET_LOOK[f.agency];Object.assign(v,{type:f.vehicle,name:u.name,paint:look.paint,lights:look.lights});for(const id of u.officerIds){const o=s.officers.find(x=>x.id===id);if(o){o.specialty=SERVICES[f.agency];o.salary=0;}}}s.candidates=[];}
function serviceDepartment(s){const P=profileOf(s);s.units.forEach((u,k)=>{const v=s.vehicles.find(x=>x.id===u.vehicleId),spec=P.start[k]?.vehicle??P.defaultVehicle;if(v)Object.assign(v,{type:spec,name:`${P.vehicles[spec].short} ${String(v.id).padStart(2,'0')}`,paint:P.paint,lights:P.lights});});for(const o of s.officers)o.specialty=P.specialty;s.candidates=P.recruits.map(c=>({...c}));}
export function ensureDepartment(s){if(s.version===2)return s;s.version=2;s.officers=[];s.vehicles=[];let oid=1;for(const u of s.units){u.officerIds=u.people.map(name=>{const id=oid++;s.officers.push({id,name,specialty:'Патрулирование',skill:u.skill??.8,salary:40});return id;});u.vehicleId=u.id;s.vehicles.push({id:u.id,name:'Седан '+String(u.id).padStart(2,'0')});}s.candidates=RECRUITS.filter(c=>!s.officers.some(o=>o.name===c.name)).map(c=>({...c}));s.nextOfficerId=oid;s.nextVehicleId=Math.max(0,...s.vehicles.map(v=>v.id))+1;s.nextUnitId=Math.max(0,...s.units.map(u=>u.id))+1;s.setupPending=false;return s;}
export function createGame(mode='career',seed=7182,options={}){const s=baseGame(mode,seed);const P0=options?.schedule==='ppa'&&Object.hasOwn(PROFILES,options?.service??'')?PROFILES[options.service]:null,P=P0?.careerOnly&&mode!=='career'?null:P0,rescue=!!P&&P.id!=='dispatch';if(P?.id==='dispatch'){s.agency='dispatch';s.units=DISPATCH_FLEET.map(f=>({...s.units[0],id:f.id,name:f.name,people:[...f.people],role:SERVICES[f.agency],agency:f.agency,zone:'all',cross:true,route:[],incident:null,status:'patrol',auto:true,fatigue:8,skill:.85,work:0}));s.desk=newDesk();}else if(P){s.agency=P.id;s.units=s.units.map((u,k)=>({...u,name:P.start[k].name,people:[...P.start[k].people],role:P.start[k].role,zone:'all',cross:true}));}if(mode==='chief')s.units=[];ensureDepartment(s);if(rescue)serviceDepartment(s);if(isDispatch(s))dispatchDepartment(s);ensureStaff(s);if(mode==='chief'){s.vehicles=rescue?P.chiefVehicles.map((type,k)=>({id:k+1,name:`${P.vehicles[type].short} ${String(k+1).padStart(2,'0')}`,type,paint:P.paint,lights:P.lights})):[{id:1,name:'Седан 01'},{id:2,name:'Седан 02'}];s.nextVehicleId=3;s.setupPending=true;}for(const v of s.vehicles)ensureVehicle(v);ensureFinance(s);s.mapId=MAP_ID;s.units.forEach((u,k)=>Object.assign(u,point(byId(['centre','ulejoe','papiniidu'][k%3]))));if(isDispatch(s))for(const u of s.units){const f=DISPATCH_FLEET.find(x=>x.id===u.id);if(f?.at==='hq')Object.assign(u,{x:HQ.x,y:HQ.y});else if(f?.at==='hospital')Object.assign(u,{x:HOSPITAL.x,y:HOSPITAL.y});else if(f)Object.assign(u,point(byId(f.at)));}ensurePopulation(s);ensureTraining(s);ensureService(s);if(options?.schedule==='ppa')applySchedule(s);return s;}
// R1: realistic 12-hour PPA roster for new campaigns (schedule.js). Legacy saves stay unchanged.
function applySchedule(s){s.schedule='ppa';s.shiftLength=SHIFT_TICKS;resyncPopulation(s,shiftStartElapsed(s.shift-1));ensureLife(s);startRoutine(s);}
export const rankOf=s=>s.mode==='career'&&isScheduled(s)&&s.life?scheduledRank(s):Math.min(RANKS.length-1,Math.floor(s.xp/150));
// Realistic pace: a 12-hour roster shift has twice the calls, so each one is worth a third of the XP.
// R21: roster careers grow over months, not weeks (rank 4 after roughly half a year of service).
const xpGain=(s,base)=>isScheduled(s)?Math.max(1,Math.round(base/ROSTER_XP_DIVISOR)):base;
export const ROSTER_XP_DIVISOR=6,ROSTER_CALL_INCOME=15;// R21: a call pays the department a token sum; the budget lives on the city grant, not on volume
export const offDuty=s=>s.mode==='career'&&isScheduled(s)?freeBlocks(s.shift):null;
export function ensureFinance(s){if(!s.finance)s.finance={opening:s.budget,entries:[],legacy:s.time>0||s.shift>1};return s;}
export function transact(s,amount,category,label){ensureFinance(s);if(!Number.isFinite(amount)||s.budget+amount<0)throw Error('Некорректная операция');s.budget+=amount;s.finance.entries.push({time:s.time,amount,category,label});}
export function financialSummary(s){ensureFinance(s);const income=s.finance.entries.filter(e=>e.amount>0).reduce((n,e)=>n+e.amount,0),expenses=-s.finance.entries.filter(e=>e.amount<0).reduce((n,e)=>n+e.amount,0);const grant=Math.max(-s.budget,cityGrant(s).total);return {opening:s.finance.opening,income,expenses,balance:s.budget,pending:shiftCost(s),grant,support:Math.max(0,shiftCost(s)-s.budget-grant),legacy:s.finance.legacy,entries:s.finance.entries.map(e=>({...e}))};}
export function unitReason(s,u){if(!u)return 'Выберите экипаж.';const foot=policeWalkReason(u);if(foot)return foot;const incident=s.incidents.find(i=>i.id===u.incident);if(u.pullover>0)return 'Остановились у обочины: водитель приходит в себя после микросна.';if(STATUS_TEXT[u.status])return statusText(u.status,unitAgency(s,u));if(u.status==='proactive'&&u.task){const k=TASKS[u.task.id];return u.task.phase==='moving'?`Едем на место: ${k.short}.`:`${k.label}: ещё ~${Math.ceil(u.task.left*WORLD_SECONDS_PER_TICK_SECOND/60)} мин. Любой вызов прервёт работу.`;}if(u.status==='servicing'){const v=departmentIndex(s).byVehicle.get(u.vehicleId),k=v?.service?.kind;const st=FUEL_STATIONS[v?.service?.station];return k==='tow'?'Машина сломалась: ждём эвакуатор.':k==='canister'?'Кончилось топливо: ждём канистру.':k==='repair'?`Машина в ремонте, ещё ~${Math.ceil(toMinutes(v.service.left))} мин.`:u.route.length?`Едем на заправку: ${st?.name??'АЗС'}.`:`Заправляемся: ${st?.name??'АЗС'}.`;}if(u.status==='resting')return 'Восстанавливаем силы в участке. Вернёмся к патрулю после отдыха.';if(u.status==='returning')return 'Едем в участок на отдых.';if(u.status==='transporting')return u.transport?.hospital?`Везём пациента в больницу (вызов №${u.transport.from}).`:`Везём задержанного в участок (вызов №${u.transport?.from}).`;if(u.status==='handover')return u.transport?.hospital?'Передаём пациента в приёмном отделении.':'Передаём задержанного дежурному и пишем рапорт.';if(u.status==='responding')return `Едем на вызов №${u.incident}. Приоритет: ${TYPES[incident?.type??0].severity}.`;if(u.status==='decision')return 'Ручной режим: ждём вашу команду в карточке вызова.';if(u.status==='working'&&incident?.scene)return incident.scene.reason;if(u.status==='working')return incident?.backupRequested&&incident.units.length<2?'Работаем осторожно, пока второй экипаж в пути или недоступен.':'На месте: выполняем выбранное действие. Навык, усталость и оснащение влияют на скорость.';return u.auto?`Патрулируем ${u.zone==='west'?'западную часть города':u.zone==='east'?'восточную часть города':'город'}. Принимаем доступные вызовы, сначала наиболее срочные.`:'Ручной режим: назначьте вызов или включите автомат.';}
export function hireOfficer(s,cid){if(s.mode!=='chief'||s.ended)return {ok:false,message:'Найм доступен начальнику во время смены.'};const c=s.candidates.find(c=>c.id===cid);if(!c)return {ok:false,message:'Кандидат уже нанят.'};if(s.budget<c.fee)return {ok:false,message:'Недостаточно бюджета для найма.'};transact(s,-c.fee,'hire','Найм: '+c.name);const {fee,...person}=c;s.officers.push({...person,id:s.nextOfficerId++,staffVersion:1,fatigue:0});s.candidates=s.candidates.filter(c=>c.id!==cid);log(s,`В отделение принят сотрудник: ${c.name}. Расходы: ${fee}.`);return {ok:true,message:'Сотрудник принят в отделение'};}
function hiringReserve(s){return s.setupPending?s.candidates.map(c=>c.fee).sort((a,b)=>a-b).slice(0,Math.max(0,1-s.officers.length)).reduce((n,v)=>n+v,0):0;}
export function buyVehicle(s,type='sedan'){const P=profileOf(s),rv=P?.vehicles[type],price=rv?rv.price:type==='suv'?1200:800;if(P?!rv:!['sedan','suv'].includes(type))return {ok:false,message:'Неизвестная модель.'};if(s.mode!=='chief'||s.ended)return {ok:false,message:'Покупка недоступна.'};if(s.budget<price)return {ok:false,message:'Недостаточно бюджета: нужно '+price+'.'};if(s.budget-price<hiringReserve(s))return {ok:false,message:'Сначала наймите хотя бы одного сотрудника: оставьте бюджет на первый патруль.'};if(s.vehicles.length>=6)return {ok:false,message:'В гараже максимум 6 машин.'};const id=s.nextVehicleId++;const bought={id,name:(rv?rv.short+' ':type==='suv'?'Внедорожник ':'Седан ')+String(id).padStart(2,'0'),type,paint:rv?P.paint:'white',lights:rv?P.lights:'redblue',kit:'base',km:0,wear:0,extras:[],history:[],service:null};ensureVehicle(bought);addHistory(bought,s.time,'Новая машина поступила в гараж');s.vehicles.push(bought);transact(s,-price,'vehicle','Покупка: '+(type==='suv'?'внедорожник':'седан'));return {ok:true,message:'Машина доставлена в гараж'};}
export const PAINTS=Object.freeze(Object.fromEntries(Object.entries(LIVERIES).map(([k,v])=>[k,v.paint])));
export function configureVehicle(s,id,config){const v=s.vehicles.find(v=>v.id===id);if(s.mode!=='chief'||!v||s.ended)return {ok:false,message:'Настройка недоступна.'};const u=s.units.find(u=>u.vehicleId===id);if(u&&!['patrol','idle','resting'].includes(u.status))return {ok:false,message:'Дождитесь завершения вызова.'};if(typeof config.name!=='string'||config.name.trim().length<1||config.name.length>30||!Object.hasOwn(PAINTS,config.paint)||!['redblue','blue'].includes(config.lights)||!['base','aid','search'].includes(config.kit))return {ok:false,message:'Проверьте настройки машины.'};const price=config.kit!==(v.kit??'base')&&config.kit!=='base'?150:0;if(s.budget<price)return {ok:false,message:'Комплект стоит 150. Недостаточно бюджета.'};if(s.budget-price<hiringReserve(s))return {ok:false,message:'Сначала наймите хотя бы одного сотрудника.'};if(price)transact(s,-price,'equipment','Оснащение: '+v.name);Object.assign(v,{name:config.name.trim(),paint:config.paint,lights:config.lights,kit:config.kit});return {ok:true,message:price?'Машина настроена. Комплект: 150.':'Машина настроена'};}
export function createPatrol(s,first,second,vehicleId,area='all'){if(s.mode!=='chief'||s.ended)return {ok:false,message:'Создание патруля недоступно.'};const ids=second==null||second===0?[first]:[first,second];const people=ids.map(id=>s.officers.find(o=>o.id===id));if(new Set(ids).size!==ids.length||people.some(p=>!p))return {ok:false,message:'Выберите сотрудника и, при желании, другого напарника.'};if(s.units.some(u=>u.officerIds.some(id=>id===first||id===second)))return {ok:false,message:'Один из сотрудников уже в экипаже.'};if(people.some(p=>p.leave>0))return {ok:false,message:'Сотрудник в отпуске.'};if(people.some(p=>p.study))return {ok:false,message:'Сотрудник на курсе.'};if(!s.vehicles.some(v=>v.id===vehicleId)||s.units.some(u=>u.vehicleId===vehicleId))return {ok:false,message:'Выберите свободную машину.'};if(s.vehicles.find(v=>v.id===vehicleId).service)return {ok:false,message:'Машина на обслуживании.'};if(!['all','west','east'].includes(area))return {ok:false,message:'Выберите зону патруля.'};const id=s.nextUnitId++;s.units.push({id,name:(profileOf(s)?.unit??'Патруль')+' '+String(id).padStart(2,'0'),people:people.map(o=>o.name),officerIds:ids,vehicleId,role:'Создан начальником',x:HQ.x,y:HQ.y,route:[],status:'patrol',auto:true,zone:area,cross:area==='all',fatigue:0,skill:people.reduce((sum,o)=>sum+o.skill,0)/people.length,incident:null,work:0});syncCrew(s,s.units.at(-1));s.setupPending=false;log(s,`Патруль ${id} сформирован и приступает к службе.`);return {ok:true,message:'Патруль создан. Автомат включён.',unitId:id};}
export function disbandPatrol(s,id){const u=s.units.find(u=>u.id===id);if(s.mode!=='chief'||!u||!['patrol','idle','resting'].includes(u.status)||s.ended)return {ok:false,message:'Дождитесь завершения вызова или возвращения экипажа.'};s.units=s.units.filter(u=>u.id!==id);log(s,`Патруль ${id} расформирован. Сотрудники и машина свободны.`);return {ok:true,message:'Сотрудники и машина возвращены в резерв'};}
export function shiftCost(s){return s.mode==='chief'?shiftWages(s)+s.vehicles.length*30+policyCost(s)+upgradesUpkeep(s):240;}
// R5: night shifts on the roster pay the legal night premium (×1.25 for 22:00–06:00); officers on leave keep their salary.
export const shiftWages=s=>isScheduled(s)?Math.round(s.officers.reduce((n,o)=>n+dutyWage(o,wagesFactor(shiftKind(s.shift-1)==='night')),0)):Math.round(s.officers.reduce((n,o)=>n+o.salary,0));/* Release C2: light duty ×0.75, days-only without the night premium */
export function log(s,text){s.logs.unshift({time:s.time,text});s.logs=s.logs.slice(0,45);}
export function routeTo(u,p){u.route=roadRoute(u,p);}
// «Живые вызовы»: a random call picks a realistic variant by hour and kind of place (calls.js).
// An explicit type keeps the original wording and uniform location (tests, scripted calls).
export function spawnIncident(s,type,options=null){let t=type,variant,node;if(options?.variant){variant=variantById(options.variant);t=variant.type;node=options.point;}else if(t==null){const cm=s.city?.effects?.length?cityMods(s.city,s.shift):null,pm=s.prevention?.length?preventionMods(s):null,mods=cm&&pm?Object.fromEntries([...new Set([...Object.keys(cm),...Object.keys(pm)])].map(k=>[k,(cm[k]??1)*(pm[k]??1)])):cm??pm;/* Release F: a story's ending changes its calls for a while */variant=pickVariant(rng(s),cityMinute(s.population?.elapsed??s.time),{...shiftWeather(s),...(mods?{prevention:mods}:{}),...(isService(s)?{service:s.agency}:{})});t=variant.type;const nodes=placeNodes(NODES,variant.place,byId('centre'));node=nodes[Math.floor(rng(s)*nodes.length)];}else{variant=defaultVariant(t);node=NODES[Math.floor(rng(s)*NODES.length)];}const i={id:s.nextId++,type:t,variant:variant?.id,...point(node),age:0,state:'waiting',units:[],progress:0,decision:null,backupRequested:false};if(options?.followUp)i.followUp={from:options.followUp.from,reason:options.followUp.reason};ensureScene(i);linkResident(s,i);s.incidents.push(i);if(isDispatch(s)){i.call={status:'ringing',at:s.time,asked:[],instr:[],cost:0};log(s,`112: входящий вызов №${i.id} — «${callTitle(i)}».`);}else{log(s,`Диспетчер: ${callName(i)}. Новый вызов №${i.id}.`);radio(s,'broadcast',null,i,DISPATCH);}matchBolo(s,i);if(i.variant==='fire-smoke')callRescue(s,i);return i;}
export const callName=i=>(i.followUp?(i.variant==='suspect-found'?'Розыск: ':'Повторно: '):'')+(variantOf(i)?.name??TYPES[i.type].name);
export const callBrief=i=>variantOf(i)?.brief??TYPES[i.type].brief;
// Redirect: a crew still driving to a call may be taken to a strictly more urgent one.
export function canRedirect(s,u,i){if(!u||!i||u.status!=='responding'||u.incident===i.id||u.foot)return false;const current=s.incidents.find(x=>x.id===u.incident);return !current||TYPES[i.type].severity>TYPES[current.type].severity;}
function detach(s,u){const old=s.incidents.find(x=>x.id===u.incident);if(old){old.units=old.units.filter(id=>id!==u.id);if(!old.units.length&&old.state==='assigned')old.state='waiting';log(s,`${u.name}: снят с вызова №${old.id} ради более срочного.`);}u.incident=null;u.status='patrol';u.route=u.route.length?[u.route[0]]:[];}
function autoRedirect(s){for(const i of s.incidents){if(i.state!=='waiting'||TYPES[i.type].severity<3||i.age<1.5)continue;const options=s.units.filter(u=>u.auto&&dispatchReady(s,u,i)&&canRedirect(s,u,i)&&(u.cross||u.zone==='all'||zone(i)===u.zone)).sort((a,b)=>Math.hypot(a.x-i.x,a.y-i.y)-Math.hypot(b.x-i.x,b.y-i.y));if(options.length)assign(s,options[0].id,i.id,true);}}
function crewFit(s,u,type){const c=departmentIndex(s);return crewFits((u.officerIds??[]).map(id=>c.byOfficer.get(id)),type)?FIT_BONUS:1;}
export function unitFitsCall(s,u,i){return !!u&&!!i&&crewFit(s,u,i.type)>1;}
export function canControl(s,u,action='command'){return careerPermission(s,u,action).ok;}
export function controlReason(s,u,action='command'){return careerPermission(s,u,action).reason;}
export function setUnitAutomation(s,uid,value){const u=s.units.find(u=>u.id===uid);if(!careerPermission(s,u,'command').ok||typeof value!=='boolean'||s.ended)return false;u.auto=value;log(s,`${u.name}: ${u.auto?'автономное патрулирование':'ручное управление'}.`);return true;}
export function configurePatrolArea(s,uid,zoneValue,crossValue){const u=s.units.find(u=>u.id===uid);if(!u||s.ended||!['all','west','east'].includes(zoneValue)||typeof crossValue!=='boolean')return false;if(!careerPermission(s,u,'zone').ok||crossValue!==u.cross&&!careerPermission(s,u,'cross').ok)return false;u.zone=zoneValue;u.cross=crossValue;if(u.status==='patrol')u.route=u.route.slice(0,1);log(s,`${u.name}: зона патруля изменена.`);return true;}
export function assign(s,uid,iid,system=false){const u=s.units.find(u=>u.id===uid),i=s.incidents.find(i=>i.id===iid);if(!u||!i||(!system&&!canControl(s,u))||s.ended||!['waiting','assigned','onscene'].includes(i.state))return false;if(!system&&['briefing','break','reports'].includes(u.status)){const what=({briefing:'инструктаж',break:'обед',reports:'рапорты'})[u.status];if(u.status==='break')u.mealDone=true;delete u.routineLeft;u.status='patrol';log(s,`${u.name}: по вашему приказу прерываем ${what}.`);}if(u.status==='proactive')stopTask(s,u,system?'call':'order');const redirect=canRedirect(s,u,i);if(!['patrol','idle'].includes(u.status)&&!redirect)return false;
 if(i.units.length&&!i.backupRequested)return false;
 if(redirect)detach(s,u);
 u.incident=i.id;u.status='responding';i.units.push(uid);i.state=i.state==='waiting'?'assigned':i.state;routeTo(u,Math.hypot(u.x-i.x,u.y-i.y)<1e-7&&!u.route.length?i:walkAccess(i));if(s.mode==='career'&&u.id===1)trainingEvent(s,'accepted',i,!system);log(s,`${u.name}: принят вызов №${i.id}.`);radio(s,'dispatch',u,i,DISPATCH);radio(s,'accept',u,i);return true;}
export function decide(s,uid,choice){const u=s.units.find(x=>x.id===uid),i=s.incidents.find(x=>x.id===u?.incident);if(!u||!i||!crewAtScene(u)||!['decision','working'].includes(u.status)||s.ended||!canControl(s,u)||!TYPES[i.type].options.some(o=>o[1]===choice))return false;
 i.decision=choice;explainChoice(i);recordAssessment(s,i,true);if(s.mode==='career'&&u.id===1)trainingEvent(s,'decision',i,true,choice);if(choice==='backup'){i.backupRequested=true;i.backupAt=s.time;radio(s,'backup',u,i);log(s,`${u.name}: запрашиваем подкрепление.`);}u.status='working';return true;}
export function rest(s,uid){const u=s.units.find(u=>u.id===uid);if(!u||s.ended||!canControl(s,u)||!['patrol','idle','proactive'].includes(u.status))return false;if(u.status==='proactive')stopTask(s,u,'order');u.status='returning';routeTo(u,HQ);log(s,`${u.name}: возвращаемся на отдых.`);return true;}
function move(u,dt,s,v=null){advanceVehicle(u,dt,Math.min(patrolSpeed(u)*speedFactor(v)*roadWeather(s),u.trafficTargetKmh??Infinity),{obeyLimits:!urgentMovement(s,u)});}
function trafficItems(s){const items=[];for(const r of s.population?.residents??[])if(!['walkVisit','walkBack','visiting'].includes(r.status))items.push({entity:r,id:'resident-'+r.id,desired:30,emergency:false});for(const u of s.units)items.push({entity:u,id:'unit-'+u.id,desired:patrolSpeed(u),emergency:urgentMovement(s,u),blocking:!u.route.length&&['decision','working'].includes(u.status),scene:u.incident??null});for(const i of s.incidents)if(i.type===5&&i.scene)for(const a of i.scene.participants)items.push({entity:a,id:'actor-'+a.id,desired:a.status==='fleeing'?40:15,emergency:false});return items;}
function finish(s,i,success,failure){if(i.arc&&s.city?.arc&&s.city.arc.incident===i.id)s.city.arc.outcome=success?'ok':'miss';/* Release F: city story chapter */if(i.story&&s.life?.week&&s.life.week.incident===i.id)s.life.week.outcome=dayResult(i.story,{...i,state:success?'resolved':'missed'}).points;/* Release E: first-week story call */if(s.mode==='career'&&i.units.includes(1))trainingEvent(s,success?'resolved':'failed',i,false);completeAssessment(s,i,success);if(i.talk&&success)finishTalk(s,i);const outcome0=closeScene(i,success,failure),outcome=isEmsType(i.type)?(failure??patientOutcome(i,success)):isRescueType(i.type)?(failure??rescueOutcome(i,success)):outcome0;if(isEmsType(i.type)&&i.patient)i.patient.result=outcome.slice(0,200);if(isServiceType(i.type)&&i.scene){i.scene.outcome=outcome;i.scene.reason=outcome;}releaseResidents(s,i,success,outcome);i.state=success?'resolved':'missed';i.finished=s.time;s[success?'resolved':'missed']++;addTrust(s,success?2:-4);if(success&&i.medical==='treated')addTrust(s,AMBULANCE.trustBonus);if(success&&i.rescue==='done')addTrust(s,RESCUE_TEAM.trustBonus);if(success&&i.bolo){addTrust(s,ROUTINE.boloTrust);log(s,`Вызов №${i.id}: ориентировка с инструктажа подтвердилась.`);}if(success)applyPolicyCustody(s,i);recordConsequences(s,i,success);recordCase(s,i,success,outcome);investigate(s,i,success);if(isScheduled(s)){callStress(s,i,success);fileComplaint(s,i,success);if(success&&s.mode==='career'&&i.units.includes(1))s.myCalls=(s.myCalls??0)+1;{const item=callNews(i,success,{district:districtName(districtOf(i),'городе'),minutes:(i.age??0)*WORLD_SECONDS_PER_TICK_SECOND/60});if(newsRoom(s,item))pushNews(s,item);}}if(success)assignCustody(s,i);if(success&&isEmsType(i.type))emsAfterCall(s,i);const rankBefore=s.rank;if(success){transact(s,isScheduled(s)?ROSTER_CALL_INCOME:110,'incident',`Завершён вызов №${i.id}`);if(i.units.includes(1)||s.mode==='chief')s.xp+=xpGain(s,30);}s.rank=rankOf(s);if(s.mode==='career'&&i.units.includes(1))serviceEvent(s,i,callName(i),success,rankBefore);
 for(const id of i.units){const u=s.units.find(u=>u.id===id);if(u&&!u.transport)radio(s,success?'clear':'failed',u,i);if(returnPoliceWalk(u))continue;u.incident=null;u.status='patrol';u.pursuing=false;u.route=u.route.length?[u.route[0]]:[];}
 const text=success?`Вызов №${i.id} завершён. ${outcome}.`:`Вызов №${i.id}: ${outcome}. Доверие снизилось.`;log(s,text);s.history.unshift({id:i.id,name:callName(i),success,time:s.time,outcome});s.history=s.history.slice(0,50);}
export function tick(s,dt){if(s.ended||s.setupPending)return;s.time+=dt;s.nextIncident-=dt;
 if(s.nextIncident<=0&&s.incidents.filter(i=>!['resolved','missed'].includes(i.state)).length<(isDispatch(s)?9:6)){spawnIncident(s);s.nextIncident=(38+rng(s)*25)*(profileOf(s)?.callGap??1)/(isScheduled(s)?(shiftWeather(s).event?.intensity??1)*loadNow(s):1);}
 releaseFollowUps(s);if(isDispatch(s))deskTick(s);if(weekActive(s))storyTick(s);if(s.city?.arc&&isScheduled(s))cityTick(s);
 tickServices(s,dt);
 tickStaff(s,dt);if(has(s,'restroom'))restroomRecovery(s,dt);if(isScheduled(s))nightDuty(s,dt);planTraffic(trafficItems(s));setSirens(isScheduled(s)?s.units.filter(u=>u.route?.length&&urgentMovement(s,u)).map(u=>({x:u.x,y:u.y})):[]);tickPopulation(s,dt);prepareScenes(s,dt);
 tickParkedService(s,dt);
 for(const u of s.units){const vehicle=departmentIndex(s).byVehicle.get(u.vehicleId);u.kit=vehicle?.kit??'base';if(u.status==='servicing'&&tickServicing(s,u,vehicle,dt))continue;if((u.status==='briefing'||u.status==='break')&&tickRoutine(s,u,vehicle,dt))continue;if(u.pullover>0){u.pullover-=dt;if(u.pullover<=0)delete u.pullover;continue;}move(u,dt,s,vehicle);if(vehicle)wearAndFuel(s,u,vehicle,dt);if(isScheduled(s))nodOff(s,u,vehicle);const footBefore=u.foot?.phase;tickPoliceWalk(u,dt);if(footBefore==='approach'&&u.foot?.phase==='onScene'){const i=s.incidents.find(i=>i.id===u.incident);if(i){if(!u.auto&&!i.decision)u.status='decision';if(s.mode==='career'&&u.id===1)trainingEvent(s,'arrived',i);log(s,`${u.name}: сотрудники у участников вызова №${i.id}.`);}}
 if(tickCustody(s,u,dt))continue;
 if(u.status==='proactive'&&tickTask(s,u,dt))continue;
 if(u.status==='reports')continue;
 if(u.status==='returning'&&!u.route.length)u.status='resting';
 if(u.status==='resting'){if(crewReady(s,u)){u.status='patrol';log(s,`${u.name}: снова готовы к работе.`);}continue;}
 if(u.status==='responding'&&!u.route.length){const i=s.incidents.find(i=>i.id===u.incident);if(i&&wrongCrew(s,u,i))continue;if(i){i.state='onscene';if(isScheduled(s))ensureTalk(i);callAmbulance(s,i);callRescue(s,i);u.status=u.auto?'working':'decision';const walking=beginPoliceWalk(u,i);if(walking)u.status='working';else if(s.mode==='career'&&u.id===1)trainingEvent(s,'arrived',i);log(s,`${u.name}: ${walking?'припарковались, идём к участникам':'на месте вызова'} №${i.id}.`);radio(s,'arrive',u,i);}}
 if(u.status==='decision'&&u.auto)u.status='working';
 if(u.status==='working'&&u.auto&&crewAtScene(u)){const i=s.incidents.find(i=>i.id===u.incident);if(i&&!i.decision){const st0=isScheduled(s)&&ensureTalk(i)?talkStep(s,u,i,autoOption(i,talkStyle(s))):null;i.decision=i.type===5?autoChoice(i):st0?.option?.maps??autoChoice(i);/* a driver who flees is always pursued */explainChoice(i);recordAssessment(s,i,false);if(s.mode==='career'&&u.id===1)trainingEvent(s,'decision',i,false,i.decision);if(TYPES[i.type].severity===3){i.backupRequested=true;i.backupAt=s.time;if(isServiceType(i.type)){pushRadio(s,callsign(u),PROFILES[typeAgency(i.type)]?.backup??'Нужна вторая машина.');log(s,`${u.name}: запрашиваем ${isEmsType(i.type)?'вторую бригаду':'вторую машину'}.`);}else{radio(s,'backup',u,i);log(s,`${u.name}: держим дистанцию, запрашиваем второй экипаж.`);}}else log(s,`${u.name}: ${i.scene.reason}`);}}

 if(isScheduled(s)&&['patrol','idle'].includes(u.status)&&routineDue(s,u))continue;
 if(['patrol','idle'].includes(u.status)&&u.auto){if(crewNeedsRest(s,u)){u.status='returning';routeTo(u,HQ);continue;}
 if(isDetective(s,u)){if(u.incident==null&&s.time<s.shiftLength-ROUTINE.reports){const st=autoCaseStep(s.life);if(st)startTask(s,u,st.step,true,{caseId:st.caseId});}continue;}// R25: a detective works the case file, patrol calls go to other crews
 const candidates=s.incidents.filter(i=>i.state==='waiting'||(i.backupRequested&&i.units.length<2&&!i.units.includes(u.id))).filter(i=>dispatchReady(s,u,i)).filter(i=>u.cross||u.zone==='all'||zone(i)===u.zone).sort((a,b)=>TYPES[b.type].severity-TYPES[a.type].severity||priorityRank(s,a)-priorityRank(s,b)||Math.hypot(a.x-u.x,a.y-u.y)-Math.hypot(b.x-u.x,b.y-u.y));
 if(candidates.length)assign(s,u.id,candidates[0].id,true);
 else if(autoTaskDue(s,u)&&(!unitProfile(s,u)||unitProfile(s,u).taskFor(cityMinute(s.population?.elapsed??s.time))))startTask(s,u,unitProfile(s,u)?unitProfile(s,u).taskFor(cityMinute(s.population?.elapsed??s.time)):focusTask(s,autoTaskFor(cityMinute(s.population?.elapsed??s.time))),true);
 else if(!u.route.length){if(unitProfile(s,u)){const base=serviceBase(s,u);if(Math.hypot(u.x-base.x,u.y-base.y)>1e-4)routeTo(u,base);}else{const places=NODES.filter(p=>u.zone==='all'||p.sector===u.zone);routeTo(u,places[Math.floor(rng(s)*places.length)]);}}}/* Release H: rescuers wait at the station */
 }
 autoRedirect(s);
 for(const i of s.incidents){if(['resolved','missed'].includes(i.state))continue;i.age+=dt;const working=s.units.filter(u=>u.incident===i.id&&u.status==='working'&&crewAtScene(u));
 const sceneResult=isEmsType(i.type)?emsStep(s,i,working,dt):isRescueType(i.type)?(i.type===6?fireStep(i,working.map(u=>({id:u.id,people:u.people,vehicleType:departmentIndex(s).byVehicle.get(u.vehicleId)?.type})),dt,shiftWeather(s),{search:has(s,'thermal')?2:1}):rescueStep(i,working,dt)):sceneStep(i,working,dt);if(sceneResult.failure){finish(s,i,false,sceneResult.failure);continue;}tickTalk(s,i,working);
 if(working.length){if(!i.decision)i.decision='check';const multi=working.length>1?1.45:1;const mine=s.mode==='career'&&working[0].id===1,caution=!isServiceType(i.type)&&i.backupRequested&&working.length<2&&(s.time-(i.backupAt??s.time)<25)&&!(mine&&roleNoCaution(s.life))?.15:1;i.progress+=dt*sceneResult.rate*multi*(i.talk?.pace??1)*(s.mode==='chief'&&(s.morale??0)>=MORALE.good?MORALE.goodPace:1)*(s.mode==='career'&&working[0].id===1&&s.life?.partner?partnerPace(s.life.partner,i.type):1)*caution*crewFit(s,working[0],i.type)*(1-working[0].fatigue*.004)*(.7+working[0].skill*.4+developmentBonus(s,i,working[0]))*((i.type===1&&working[0].kit==='aid')||(i.type===2&&working[0].kit==='search')?1.2:1)*extraBonus(departmentIndex(s).byVehicle.get(working[0].vehicleId),i.variant)*(s.mode==='career'&&working[0].id===1?courseBonus(s.life,i.variant)*roleBonus(s.life,i.variant):1)*(i.bolo?ROUTINE.boloBonus:1)*performanceFactor(crewStress(s,working[0]))*upgradeBonus(s,i.variant,i.type)*(isScheduled(s)?ROSTER_WORK_PACE:1);if(i.progress>=TYPES[i.type].duration){finish(s,i,true);continue;}}
 if(i.age>TYPES[i.type].limit*(has(s,'tablets')?UPGRADE_EFFECT.limit:1))finish(s,i,false);
 }
 s.incidents=s.incidents.filter(i=>!i.finished||s.time-i.finished<18);
 if(s.time>=s.shiftLength){s.time=s.shiftLength;s.ended=true;if(isScheduled(s)&&s.population){const end=shiftStartElapsed(s.shift-1)+s.shiftLength;if(s.population.elapsed<end&&end-s.population.elapsed<1){s.population.elapsed=end;for(const r of s.population.residents)if(r.visit&&r.visit.waitUntil>0&&r.visit.waitUntil<end)r.visit.waitUntil=end;}}log(s,'Смена окончена. Посмотрите итоговый отчёт.');}
}
export function nextShift(s,options={}){
 const closed=JSON.parse(JSON.stringify(s));ensureFinance(closed);const grant=cityGrant(closed),over=closed.mode==='chief'&&isScheduled(closed)&&grant.total>0&&closed.budget>reserveLimit(shiftCost(closed)),grantAmount=Math.max(-closed.budget,over?Math.round(grant.total*RESERVE.overGrant):grant.total);if(grantAmount)transact(closed,grantAmount,'grant',grantAmount>0?(over?'Финансирование мэрии по доверию (резерв превышен — половина)':'Финансирование мэрии по доверию'):'Мэрия урезала финансирование');const cost=shiftCost(closed),support=Math.max(0,cost-closed.budget);
 if(support)transact(closed,support,'support','Антикризисная субсидия (упрощённая экономика)');
 if(closed.mode==='chief'){const wages=shiftWages(closed);if(wages)transact(closed,-wages,'salary',isScheduled(closed)&&shiftKind(closed.shift-1)==='night'?'Зарплаты за ночную смену (+25% за ночные часы)':'Зарплаты за смену');if(closed.vehicles.length)transact(closed,-closed.vehicles.length*30,'maintenance','Содержание автопарка');const rules=policyCost(closed);if(rules)transact(closed,-rules,'policy','Правила отделения');const upkeep=upgradesUpkeep(closed);if(upkeep)transact(closed,-upkeep,'upkeep','Обслуживание оснащения отделения');}
 else transact(closed,-cost,'maintenance','Содержание смены');
 const n=createGame(s.mode,s.seed);if(s.agency)n.agency=s.agency;if(isDispatch(s))n.desk={...newDesk(),stats:{...s.desk.stats},last:s.desk.last.slice(0,8)};n.shift=s.shift+1;if(options.vacation&&s.mode==='career'&&isScheduled(s)&&s.life&&!canTakeVacation(s.life,freeBlocks(s.shift)))n.shift+=ROTA.length;n.xp=s.xp;n.rank=s.rank;n.budget=closed.budget;n.trust=s.trust;if(s.districts)n.districts={...s.districts};if(s.policy)n.policy=s.policy;if(s.upgrades)n.upgrades=[...s.upgrades];if(s.tipsSeen)n.tipsSeen=[...s.tipsSeen];if(s.tipsOff)n.tipsOff=true;if(s.priorityDistrict)n.priorityDistrict=s.priorityDistrict;
 n.incidents=isScheduled(s)?[]:s.incidents.filter(i=>!['resolved','missed'].includes(i.state)).map(i=>({...JSON.parse(JSON.stringify(i)),units:[...i.units],carriedFrom:i.carriedFrom??s.shift,...(i.backupAt!==undefined?{backupAt:i.backupAt-s.time}:{})}));
 const activeIds=new Set(n.incidents.map(i=>i.id));
 n.units=s.units.map(u=>activeIds.has(u.incident)||u.foot?{...u,people:[...u.people],officerIds:[...u.officerIds],route:u.route.map(p=>({...p})),...(u.foot?{foot:JSON.parse(JSON.stringify(u.foot))}:{})}:{...u,people:[...u.people],officerIds:[...u.officerIds],x:HQ.x,y:HQ.y,route:[],incident:null,status:'patrol',fatigue:8});
 for(const k of ['officers','candidates'])n[k]=s[k].map(x=>({...x}));if(s.mode==='chief'&&has(s,'training'))for(const o of n.officers)if(o.skill<UPGRADE_EFFECT.skillCap)o.skill=Math.min(UPGRADE_EFFECT.skillCap,Math.round((o.skill+UPGRADE_EFFECT.skill)*1000)/1000);n.vehicles=JSON.parse(JSON.stringify(s.vehicles));overnightGarage(n,s.time);for(const k of ['nextUnitId','nextOfficerId','nextVehicleId','setupPending','nextId'])n[k]=s[k];
 // A custody still in progress at shift end is completed off-screen and credited.
 // R21 fix: `n` has no schedule/life yet here — rankOf would use the legacy xp/150 rule and promote a
 // roster officer to the top rank; roster ranks are recomputed in the roster block below.
 for(const u of n.units)if(!activeIds.has(u.incident)&&!u.foot&&(u.transport||u.handover!==undefined)){if(u.transport){addTrust(n,CUSTODY_REWARD.trust);if(n.districts?.[u.transport.district]!==undefined)addDistrictTrust(n,u.transport.district,CUSTODY_REWARD.district);if(u.id===1||n.mode==='chief'){n.xp+=CUSTODY_REWARD.xp;if(!isScheduled(s))n.rank=rankOf(n);}}delete u.transport;delete u.handover;}
 prepareStaffShift(n,activeIds);
 n.population=JSON.parse(JSON.stringify(ensurePopulation(s)));if(isScheduled(s)){n.schedule=s.schedule;n.shiftLength=s.shiftLength;resyncPopulation(n,shiftStartElapsed(n.shift-1));for(const u of n.units){delete u.foot;delete u.task;delete u.tasksToday;Object.assign(u,{x:HQ.x,y:HQ.y,route:[],incident:null,status:'patrol',pursuing:false});}prepareStaffShift(n,new Set());if(s.mode==='career'&&s.life)offDutyLife(s,n,options.plan);if(s.mode==='chief')rosterBetweenShifts(s,n);n.news=(s.news??[]).map(x=>({...x}));carryInvestigations(s,n);reviewComplaints(s,n);career2Shift(s,n);service2Shift(s,n,options.plan);weekShift(s,n);chiefWeekShift(s,n);cityShift(s,n);partnerBetweenShifts(s,n);detectiveBetweenShifts(n);trustDrift(n);serviceHistory(s,n);startRoutine(n);cityLookout(n);}n.training=JSON.parse(JSON.stringify(ensureTraining(s)));n.service=JSON.parse(JSON.stringify(ensureService(s)));
 n.finance={opening:n.budget,entries:[],legacy:false};n.previousReport={shift:s.shift,resolved:s.resolved,missed:s.missed,carried:n.incidents.length,finance:financialSummary(closed)};
 log(n,`Новая смена. Расходы: ${cost}.${support?' Субсидия: '+support+'.':''} ${isScheduled(n)?' Смена начинается с инструктажа в участке.':` Продолжаем вызовы: ${n.incidents.length}. Занятые экипажи остаются на месте.`}`);return n;
}
export function serialize(s){return JSON.stringify(s);}
export function deserialize(raw){
 const s=JSON.parse(raw),num=(x,min=0,max=1e9)=>Number.isFinite(x)&&x>=min&&x<=max,str=x=>typeof x==='string'&&x.length<500,pointInMap=p=>s.mapId===MAP_ID?containsWorldPoint(p):p&&num(p.x,0,5)&&num(p.y,0,5);
 const valid=s&&[1,2].includes(s.version)&&['career','chief'].includes(s.mode)&&num(s.seed,0,4294967295)&&validSchedule(s)&&num(s.time,0,s.shiftLength)&&Number.isInteger(s.shift)&&s.shift>0&&Number.isInteger(s.rank)&&s.rank>=0&&s.rank<RANKS.length&&num(s.xp)&&num(s.budget)&&num(s.trust,0,100)&&num(s.resolved)&&num(s.missed)&&num(s.nextIncident,-1000,10000)&&Number.isInteger(s.nextId)&&typeof s.ended==='boolean'&&Array.isArray(s.units)&&s.units.length<=(s.agency==='dispatch'?9:6)&&new Set(s.units.map(u=>u.id)).size===s.units.length&&s.units.every((u,k)=>Number.isInteger(u.id)&&u.id>0&&str(u.name)&&Array.isArray(u.people)&&u.people.length>=1&&u.people.length<=crewLimitOf(s)&&u.people.every(str)&&pointInMap(u)&&num(u.fatigue,0,100)&&(u.pursuing===undefined||typeof u.pursuing==='boolean')&&typeof u.auto==='boolean'&&typeof u.cross==='boolean'&&['all','west','east'].includes(u.zone)&&['patrol','idle','responding','decision','working','returning','resting','transporting','handover','servicing','briefing','break','reports','proactive'].includes(u.status)&&validTask(u.task)&&(u.task===undefined)===(u.status!=='proactive')&&(u.transport===undefined||u.transport===null||Number.isInteger(u.transport.from)&&typeof u.transport.label==='string'&&u.transport.label.length<120&&typeof u.transport.district==='string')&&(u.handover===undefined||num(u.handover,0,100))&&(u.incident===null||Number.isInteger(u.incident))&&Array.isArray(u.route)&&u.route.length<3000&&u.route.every(pointInMap))&&Array.isArray(s.incidents)&&s.incidents.length<30&&s.incidents.every(i=>Number.isInteger(i.id)&&Number.isInteger(i.type)&&TYPES[i.type]&&validVariant(i)&&(s.mapId===MAP_ID?atNode(i):s.mapId==='parnumaa-1'?Number.isFinite(i.x)&&Number.isFinite(i.y):Number.isInteger(i.x)&&Number.isInteger(i.y))&&pointInMap(i)&&num(i.age)&&num(i.progress)&&['waiting','assigned','onscene','resolved','missed'].includes(i.state)&&Array.isArray(i.units)&&i.units.every(id=>Number.isInteger(id)&&id>0))&&Array.isArray(s.logs)&&s.logs.length<=45&&s.logs.every(l=>num(l.time)&&str(l.text))&&Array.isArray(s.history)&&s.history.length<=50&&s.history.every(h=>num(h.id)&&str(h.name)&&num(h.time)&&typeof h.success==='boolean');
 if(!valid||s.mapId&&!['parnumaa-1',MAP_ID].includes(s.mapId))throw Error('Несовместимое сохранение');ensureDepartment(s);for(const u of s.units)if(u.currentSpeedKmh!==undefined&&(!Number.isFinite(u.currentSpeedKmh)||u.currentSpeedKmh<0||u.currentSpeedKmh>200))u.currentSpeedKmh=0;
 const usedOfficers=s.units.flatMap(u=>u.officerIds??[]),usedVehicles=s.units.map(u=>u.vehicleId);
 if(!Array.isArray(s.officers)||!s.officers.every(o=>Number.isInteger(o.id)&&str(o.name)&&str(o.specialty)&&num(o.skill,0,1)&&num(o.salary)&&validOfficerRoster(o))||!Array.isArray(s.vehicles)||s.vehicles.length>(s.agency==='dispatch'?9:6)||!s.vehicles.every(v=>Number.isInteger(v.id)&&str(v.name)&&validVehicleState(v))||!Array.isArray(s.candidates)||!s.candidates.every(c=>Number.isInteger(c.id)&&str(c.name)&&str(c.specialty)&&num(c.skill,0,1)&&num(c.fee)&&num(c.salary))||!['nextOfficerId','nextVehicleId','nextUnitId'].every(k=>Number.isInteger(s[k])&&s[k]>0)||typeof s.setupPending!=='boolean'||new Set(usedOfficers).size!==usedOfficers.length||new Set(usedVehicles).size!==usedVehicles.length||!s.units.every(u=>Array.isArray(u.officerIds)&&u.officerIds.length>=1&&u.officerIds.length<=crewLimitOf(s)&&u.officerIds.length===u.people.length&&u.officerIds.every(id=>s.officers.some(o=>o.id===id))&&s.vehicles.some(v=>v.id===u.vehicleId)&&num(u.skill,0,1)))throw Error('Повреждены данные отделения');
 const live=s.incidents.filter(i=>!['resolved','missed'].includes(i.state));
 if(new Set(s.officers.map(o=>o.id)).size!==s.officers.length||new Set(s.vehicles.map(v=>v.id)).size!==s.vehicles.length||s.nextOfficerId<=Math.max(0,...s.officers.map(o=>o.id))||s.nextVehicleId<=Math.max(0,...s.vehicles.map(v=>v.id))||s.nextUnitId<=Math.max(0,...s.units.map(u=>u.id))||new Set(s.incidents.map(i=>i.id)).size!==s.incidents.length||s.nextId<=Math.max(0,...s.incidents.map(i=>i.id))||!s.units.every(u=>u.incident===null||live.some(i=>i.id===u.incident&&i.units.includes(u.id)))||!live.every(i=>i.units.every(id=>s.units.some(u=>u.id===id&&u.incident===i.id))))throw Error('Нарушены связи вызовов и экипажей');
 ensureFinance(s);const f=s.finance;
 if(!num(f.opening)||!Array.isArray(f.entries)||f.entries.length>10000||!f.entries.every(e=>num(e.time)&&num(e.amount,-1e9,1e9)&&str(e.category)&&str(e.label))||Math.abs(f.opening+f.entries.reduce((n,e)=>n+e.amount,0)-s.budget)>.001)throw Error('Некорректный финансовый журнал');
 if(s.previousReport&&(!Number.isInteger(s.previousReport.shift)||!num(s.previousReport.resolved)||!num(s.previousReport.missed)||!num(s.previousReport.carried)||!s.previousReport.finance||!['opening','income','expenses','balance'].every(k=>num(s.previousReport.finance[k]))))throw Error('Повреждён отчёт смены');migrateMap(s);for(const i of s.incidents){if(!validAssessment(i.assessment,i.type))throw Error('Повреждён разбор решения');if(i.scene&&!validateScene(i.scene,i.type))throw Error('Повреждены участники происшествия');ensureScene(i);}if(s.population!==undefined&&!validatePopulation(s.population))throw Error('Повреждены данные жителей');ensurePopulation(s);if(!validateResidentLinks(s))throw Error('Нарушены связи жителей и происшествий');if(!validTraining(s))throw Error('Повреждён журнал обучения');ensureTraining(s);if(!validService(s))throw Error('Повреждена история службы');ensureService(s);if(!validStaff(s))throw Error('Повреждено состояние сотрудников');ensureStaff(s);if(!s.units.every(u=>validPoliceWalk(s,u)))throw Error('Повреждён пеший цикл полиции');if(!validConsequences(s))throw Error('Повреждены последствия вызовов');return s;
}
import {departmentIndex,ensureStaff,syncCrew,tickStaff,crewNeedsRest,crewReady,prepareStaffShift,validStaff} from './staff.js';
import {walkAccess,beginPoliceWalk,crewAtScene,returnPoliceWalk,tickPoliceWalk,policeWalkReason,validPoliceWalk} from './police-walk.js';

// 0.6b: reserve management and crew changes. A crew is changed only while it patrols, waits or
// rests in the station: never during a call, on foot or while driving to rest, so a scene keeps
// the people who started it. Personal fatigue/skill stay with each officer (staff.js).
export const CREW_CHANGE_STATUSES=Object.freeze(['patrol','idle','resting']);
export const CREW_CHANGE_FATIGUE_LIMIT=78;
export function reserveOfficers(s){const busy=new Set(s.units.flatMap(u=>u.officerIds));return s.officers.filter(o=>!busy.has(o.id)&&!unavailable(o));}
export function crewChangeReason(s,u){
 if(s.mode!=='chief')return 'Перестановку экипажей выполняет начальник смены.';
 if(s.ended)return 'Смена завершена.';
 if(!u)return 'Выберите экипаж.';
 if(u.foot)return 'Сотрудники вне машины. Перестановка — после посадки.';
 if(!CREW_CHANGE_STATUSES.includes(u.status))return u.incident!=null?`Экипаж занят вызовом №${u.incident}. Перестановка — после завершения.`:'Экипаж едет в участок. Перестановка — в участке или на патрулировании.';
 return '';
}
export function changeCrew(s,uid,outId=null,inId=null){
 const u=s.units.find(u=>u.id===uid),reason=crewChangeReason(s,u);if(reason)return {ok:false,message:reason};
 const out=outId==null||outId===''?null:Number(outId),incoming=inId==null||inId===''?null:Number(inId);
 if(out===null&&incoming===null)return {ok:false,message:'Выберите сотрудника для перестановки.'};
 if(out!==null&&!u.officerIds.includes(out))return {ok:false,message:'Этот сотрудник не входит в экипаж.'};
 const c=departmentIndex(s);let person=null;
 if(incoming!==null){person=c.byOfficer.get(incoming);if(!person||s.units.some(x=>x.officerIds.includes(incoming)))return {ok:false,message:'Выберите свободного сотрудника из резерва.'};if(person.leave>0)return {ok:false,message:`${person.name} в отпуске.`};if(person.study)return {ok:false,message:`${person.name} на курсе.`};if(person.fatigue>CREW_CHANGE_FATIGUE_LIMIT)return {ok:false,message:`${person.name}: усталость ${Math.round(person.fatigue)}%. Сначала отдых.`};}
 let next;
 if(out!==null&&incoming!==null)next=u.officerIds.map(id=>id===out?incoming:id);
 else if(out!==null){if(u.officerIds.length<2)return {ok:false,message:'Единственного сотрудника нельзя убрать: замените его или расформируйте патруль.'};next=u.officerIds.filter(id=>id!==out);}
 else{if(u.officerIds.length>=crewLimitOf(s))return {ok:false,message:crewLimitOf(s)>2?`В экипаже уже ${crewLimitOf(s)} человека.`:'В экипаже уже два сотрудника.'};next=[...u.officerIds,incoming];}
 const left=out===null?null:c.byOfficer.get(out);
 delete u.homeCrew;u.officerIds=next;u.people=next.map(id=>c.byOfficer.get(id).name);syncCrew(s,u);
 const text=left&&person?`${left.name} → резерв, ${person.name} в экипаже`:left?`${left.name} → резерв, одиночный патруль`:`${person.name} — напарник`;
 log(s,`${u.name}: ${text}.`);
 return {ok:true,message:`${u.name}: ${text}`};
}

// «Последствия» v2: district trust and follow-up calls (calls.js holds the rules).
const DISTRICT_NODES=NODES.filter(n=>DISTRICT_IDS.includes(n.id));
export function districtOf(p){let best=DISTRICT_NODES[0],d=Infinity;for(const n of DISTRICT_NODES){const k=Math.hypot(n.x-p.x,n.y-p.y);if(k<d){d=k;best=n;}}return best.id;}
// Read-only view for UI: never mutates the campaign.
export const districtTrust=(s,id)=>s.districts?.[id]??s.trust;
export function ensureDistricts(s){if(!s.districts)s.districts=Object.fromEntries(DISTRICT_IDS.map(id=>[id,s.trust]));if(!Array.isArray(s.followUps))s.followUps=[];return s.districts;}
function recordConsequences(s,i,success){const districts=ensureDistricts(s),d=districtOf(i);addDistrictTrust(s,d,success?DISTRICT_TRUST_STEP.success+(priorityOf(s)===d?PRIORITY_RULES.districtBonus:0):DISTRICT_TRUST_STEP.failure);
 const rule=FOLLOW_UPS[i.variant];if(!rule||s.followUps.length>=12)return;const choice=success?custodyDecision(i):null,chance=Math.min(.9,followUpChance(i.variant,success,i.decision,districts[d])*(choice?CUSTODY_FOLLOW_UP[choice]:1)*policyOf(s).followUp*(success?(i.talk?.followUp??1):1));if(rng(s)>=chance)return;
 const [a,b]=FOLLOW_UP_DELAY;s.followUps.push({at:s.time+a+rng(s)*(b-a),variant:rule.next,x:i.x,y:i.y,from:i.id,reason:rule.reason});}
function releaseFollowUps(s){if(!s.followUps?.length)return;const active=()=>s.incidents.filter(i=>!['resolved','missed'].includes(i.state)).length;for(const f of [...s.followUps]){if(s.time<f.at||active()>=6)continue;s.followUps=s.followUps.filter(x=>x!==f);const i=spawnIncident(s,null,{variant:f.variant,point:{x:f.x,y:f.y},followUp:{from:f.from,reason:f.reason}});log(s,f.variant==='suspect-found'?`Диспетчер: вызов №${i.id} — ${f.reason}`:`Диспетчер: повторный вызов №${i.id} — ${f.reason}`);}}
function validConsequences(s){const num=(x,min,max)=>Number.isFinite(x)&&x>=min&&x<=max;
 if(s.districts!==undefined&&!(s.districts&&typeof s.districts==='object'&&Object.entries(s.districts).every(([k,v])=>DISTRICT_IDS.includes(k)&&num(v,0,100))))return false;
 if(s.followUps!==undefined&&!(Array.isArray(s.followUps)&&s.followUps.length<=12&&s.followUps.every(f=>num(f.at,0,2000)&&variantById(f.variant)&&containsWorldPoint(f)&&Number.isInteger(f.from)&&typeof f.reason==='string'&&f.reason.length<200)))return false;
 if(s.custodyDone!==undefined&&!(Number.isInteger(s.custodyDone)&&s.custodyDone>=0&&s.custodyDone<10000))return false;
 if(!s.incidents.every(i=>(i.custodyChoice===undefined||Object.hasOwn(CUSTODY_CHOICES,i.custodyChoice))&&(i.medical===undefined||['called','treated'].includes(i.medical))&&(i.rescue===undefined||['called','working','done'].includes(i.rescue))))return false;
 if(!validServices(s)||!validCases(s)||!validRadio(s)||!validPolicy(s)||!validLife(s)||!validBolo(s)||!validRoutine(s)||!validUpgrades(s)||!validComplaints(s)||!validPatrolWork(s)||!validHistory(s)||!validNews(s)||!validGoals(s)||!validTips(s)||!validCareer2(s)||!validService2(s)||!validWeek(s.life?.week)||!(s.agency===undefined||s.agency!=='police'&&validAgency(s.agency)&&isScheduled(s)&&(s.agency!=='dispatch'||s.mode==='career'))||!validDesk(s.desk)||(s.desk!==undefined)!==isDispatch(s)||!s.units.every(u=>u.agency===undefined||isDispatch(s)&&['police','rescue','ems'].includes(u.agency))||!validChiefWeek(s.chiefWeek)||!validCity(s.city)||!s.incidents.every(i=>(i.bolo===undefined||Number.isInteger(i.bolo))&&(i.story===undefined||Number.isInteger(i.story)&&i.story>=1&&i.story<=7)&&(i.arc===undefined||Object.hasOwn(ARCS,i.arc))&&validFire(i.fire)&&(!isRescueType(i.type)||isRescue(s)||isDispatch(s))&&validPatient(i.patient)&&(!isEmsType(i.type)||isEms(s)||isDispatch(s))&&validCall(i.call)&&(i.call===undefined||isDispatch(s))&&validTalk(i.talk)))return false;
 return s.incidents.every(i=>i.followUp===undefined||Number.isInteger(i.followUp.from)&&typeof i.followUp.reason==='string'&&i.followUp.reason.length<200);}

// Weather of the current shift: derived (not stored), so old saves and the random stream are unchanged.
export const shiftWeather=s=>{if(!isScheduled(s))return weatherFor(7182,s.shift);const night=shiftKind(s.shift-1)==='night',event=shiftEvent(s.shift-1,night)??specialEvent(s.shift-1,night),w=weatherFor(7182,s.shift,seasonOf(shiftDate(s.shift-1).month));return {...w,...(event?.weather?{kind:event.weather}:{}),event};};// R18: a storm turns the weather to wind
// Roster campaigns: real date of the current shift and the sun of that month (season.js).
export const shiftDateOf=s=>isScheduled(s)?shiftDate(s.shift-1):null;
export const sunOf=s=>{const d=shiftDateOf(s);return d?SUN[d.month]:null;};

// 0.7.0 v1 custody cycle: patrol -> transporting (to HQ) -> handover (timer) -> patrol with report.
function assignCustody(s,i){const choice=custodyDecision(i);if(choice==='warn'){const bonus=policyOf(s).warnDistrict;if(bonus){const d=ensureDistricts(s),id=districtOf(i);d[id]=Math.min(100,d[id]+bonus);}log(s,`Вызов №${i.id}: участников отпустили с предупреждением.`);return;}if(choice!=='arrest')return;const u=s.units.find(x=>i.units.includes(x.id));if(!u||u.transport)return;u.transport={from:i.id,label:callName(i),district:districtOf(i)};}
function tickCustody(s,u,dt){
 if(u.status==='patrol'&&u.transport&&!u.foot&&u.incident===null){u.status='transporting';if(u.transport.hospital){routeTo(u,HOSPITAL);pushRadio(s,callsign(u),'Пациент в машине, едем в приёмное.');log(s,`${u.name}: пациент в машине, везём в больницу (вызов №${u.transport.from}).`);return true;}routeTo(u,HQ);radio(s,'transport',u,null);log(s,`${u.name}: задержанный в машине, везём в участок (вызов №${u.transport.from}).`);return true;}
 if(u.status==='transporting'){if(!u.route.length){u.status='handover';if(u.transport?.hospital){const busy=s.units.filter(x=>x!==u&&x.status==='handover'&&x.transport?.hospital).length;u.handover=Math.min(60,HANDOVER_TIME*(u.transport.ecg?PATIENT.handoverEcg:1)*(1+.35*busy));log(s,`${u.name}: в приёмном отделении${busy?`, перед нами ${busy} ${busy===1?'бригада':'бригады'}`:''}, передаём пациента.`);}else{u.handover=HANDOVER_TIME;log(s,`${u.name}: в участке, передаём задержанного дежурному.`);}}return true;}
 if(u.status==='handover'){u.handover-=dt;if(u.handover>0)return true;const t=u.transport;u.status='patrol';u.transport=null;delete u.handover;
  if(t?.hospital){addTrust(s,.5);if(u.id===1||s.mode==='chief')s.xp+=xpGain(s,8);s.rank=rankOf(s);const file=(s.cases??[]).find(c=>c.id===t.from);if(file)file.status='Пациент передан в приёмное отделение';log(s,`${u.name}: пациент передан врачам приёмного отделения, карта вызова заполнена. Свободны.`);return true;}
  addTrust(s,CUSTODY_REWARD.trust);const d=ensureDistricts(s);if(t&&d[t.district]!==undefined)d[t.district]=Math.min(100,d[t.district]+CUSTODY_REWARD.district);if(u.id===1||s.mode==='chief')s.xp+=xpGain(s,CUSTODY_REWARD.xp);s.rank=rankOf(s);s.custodyDone=(s.custodyDone??0)+1;
  const file=(s.cases??[]).find(c=>c.id===t?.from);if(file)file.status='Передано дежурному';radio(s,'handover',u,null);log(s,`${u.name}: рапорт по вызову №${t?.from} составлен, дело передано. Возвращаемся к патрулю.`);return true;}
 return false;}

// Player choice at the scene (manual crews): arrest or release with a warning.
export function setCustodyChoice(s,uid,choice){const u=s.units.find(x=>x.id===uid),i=s.incidents.find(x=>x.id===u?.incident);
 if(!u||!i||s.ended||!(Object.hasOwn(CUSTODY_CHOICES,choice))||!canChooseCustody(i.variant)||!crewAtScene(u)||!['decision','working'].includes(u.status)||!canControl(s,u))return false;
 i.custodyChoice=choice;log(s,`${u.name}: ${choice==='arrest'?'задерживаем участника, повезём в участок':'отпустим с предупреждением'} (вызов №${i.id}).`);return true;}

// 0.7.1 v1 ambulance service: hospital -> scene (treat) -> hospital (handover) -> done.
export const HOSPITAL=point(byId('raama'));
/* Release J: the 112 desk — who may take a call, a crew sent to the wrong kind of call, the operators */
function dispatchReady(s,u,i){if(!isDispatch(s))return true;const c=i.call;return !!c&&c.status==='routed'&&s.time>=(c.release??0)&&c.sent===unitAgency(s,u);}
function wrongCrew(s,u,i){if(!isDispatch(s)||unitAgency(s,u)===typeAgency(i.type))return false;const right=typeAgency(i.type);pushRadio(s,callsign(u),`На месте. Это не наш вызов — нужна ${SERVICES[right].toLowerCase()}. Передайте в 112.`);log(s,`${u.name}: вызов №${i.id} не по профилю, нужна ${SERVICES[right].toLowerCase()}. Вызов передан заново.`);
 i.units=i.units.filter(id=>id!==u.id);if(!i.units.length&&i.state!=='onscene')i.state='waiting';u.incident=null;u.status='patrol';u.route=[];if(i.call){i.call.sent=right;i.call.release=s.time+ticksOf(1);i.call.wrongTrip=true;}if(s.desk)s.desk.stats.wrong++;return true;}
const routeLog=(s,i,who)=>{const c=i.call;log(s,`112${who?' ('+who+')':''}: вызов №${i.id} → ${SERVICES[c.sent]}, приоритет ${c.priority}.`);};
function routeCall(s,i,service,priority,who){const c=i.call;c.status='routed';c.sent=service;c.sent0=service;c.priority=priority;c.release=s.time+ticksOf(RELEASE[priority]+c.cost/60);c.grade=gradeRoute(i,TYPES);routeLog(s,i,who);
 if(c.instr.includes('away')&&i.scene)i.scene.tension=Math.max(0,i.scene.tension-10);
 const d=s.desk;d.stats.handled++;if(c.grade.service)d.stats.service++;if(c.grade.exact)d.stats.priority++;if(c.grade.instr)d.stats.instructions++;if(c.grade.under)d.stats.under++;
 if(c.handler==='player'){d.last.unshift({id:i.id,text:`№${i.id}: ${c.grade.text}`});d.last=d.last.slice(0,8);s.xp+=xpGain(s,c.grade.xp);s.rank=rankOf(s);if(s.life){const heavy=i.type===10||i.type===6||['missing-child','ems-choking','ems-burn'].includes(i.variant);s.life.stress=Math.min(100,s.life.stress+(heavy?DESK.stress.heavy:DESK.stress.call)*(Number.isInteger(s.life.courses?.crisis)?DESK.stress.trained:1));}}else d.stats.colleague++;}
function deskTick(s){const d=s.desk;if(!d)return;
 if(d.player!=null){const p=s.incidents.find(x=>x.id===d.player);if(!p||['resolved','missed'].includes(p.state)||p.call?.status!=='talking'){d.player=null;if(p&&p.state!=='missed')log(s,`112: разговор по вызову №${p.id} прерван.`);}}
 for(const i of s.incidents)if(i.call?.status==='talking'&&(i.call.handler==='player'?d.player!==i.id:!d.colleagues.some(c=>c.call===i.id))){i.call.status='ringing';delete i.call.handler;delete i.call.colleague;}/* a call left on the line (new shift, lost connection) rings again */
 for(const c of d.colleagues){if(c.call!=null&&s.time>=c.until){const i=s.incidents.find(x=>x.id===c.call);c.call=null;if(i?.call?.status==='talking'&&i.call.handler==='colleague'){const r=colleagueDecision(i,c.skill,TYPES);i.call.instr=r.instr;routeCall(s,i,r.service,r.priority,c.name);}}}
 for(const i of s.incidents){if(i.call?.status!=='ringing'||['resolved','missed'].includes(i.state)||s.time-i.call.at<ticksOf(DESK.pickup))continue;const c=d.colleagues.find(x=>x.call==null);if(!c)break;c.call=i.id;c.until=s.time+ticksOf(colleagueMinutes(i));i.call.status='talking';i.call.handler='colleague';i.call.colleague=c.id;}}
export function takeCall(s,id){const i=s.incidents.find(x=>x.id===id),d=s.desk;if(!isDispatch(s)||!d||s.ended||!i?.call)return {ok:false,message:'Вызов недоступен.'};if(d.player!=null&&d.player!==id)return {ok:false,message:'Сначала закончите текущий разговор.'};if(i.call.status!=='ringing')return {ok:false,message:'На этот вызов уже ответили.'};i.call.status='talking';i.call.handler='player';d.player=id;return {ok:true,message:'112, что у вас случилось?'};}
const myCall=(s,id)=>{const i=s.incidents.find(x=>x.id===id);return isDispatch(s)&&!s.ended&&i?.call?.status==='talking'&&i.call.handler==='player'&&s.desk?.player===id?i:null;};
export function askCaller(s,id,qid){const i=myCall(s,id);if(!i)return {ok:false,message:'Нет разговора.'};if(!questionsFor(i).some(q=>q.id===qid)||i.call.asked.includes(qid))return {ok:false,message:'Этот вопрос уже задан.'};i.call.asked.push(qid);i.call.cost=Math.min(600,i.call.cost+DESK.question);return {ok:true,message:answerFor(i,qid,{injured:needsAmbulanceFor(i)})};}
export function instructCaller(s,id,key){const i=myCall(s,id);if(!i||!INSTRUCTIONS[key])return {ok:false,message:'Нет разговора.'};if(i.call.instr.includes(key)||i.call.instr.length>=3)return {ok:false,message:'Инструкция уже дана.'};i.call.instr.push(key);i.call.cost=Math.min(600,i.call.cost+(key==='cpr'&&Number.isInteger(s.life?.courses?.tcpr)?DESK.instructionTrained:DESK.instruction));return {ok:true,message:INSTRUCTIONS[key].line};}
export function pickRoute(s,id,service,priority){const i=myCall(s,id);if(!i)return false;i.call.pick={...(i.call.pick??{}),...(service&&SERVICES[service]?{service}:{}),...(priority&&'ABCD'.includes(priority)&&priority.length===1?{priority}:{})};return true;}
export function sendCall(s,id){const i=myCall(s,id),p=i?.call.pick;if(!i||!p?.service||!p?.priority)return {ok:false,message:'Выберите службу и приоритет.'};s.desk.player=null;routeCall(s,i,p.service,p.priority,null);return {ok:true,message:`Направлено: ${SERVICES[p.service]}, приоритет ${p.priority}.`};}
/* Release I: where an idle service crew waits — the rescue station (HQ) or the ambulance substation at the hospital */
const serviceBase=(s,u)=>unitProfile(s,u)?.base==='hospital'?HOSPITAL:HQ;
/* Release I: one step of the patient on an ambulance call; a rapid car without a stretcher calls an ambulance */
function emsStep(s,i,working,dt){const idx=departmentIndex(s),r=patientStep(i,working.map(u=>{const type=idx.byVehicle.get(u.vehicleId)?.type;return {id:u.id,people:u.people,vehicleType:type,transport:EMS_VEHICLES[type]?.transport??true};}),dt,{responders:has(s,'responders'),cprDevice:has(s,'cpr-device')});
 if(r.needTransport&&!i.backupRequested){i.backupRequested=true;i.backupAt=s.time;const u=working[0];if(u){pushRadio(s,callsign(u),'Пациента нужно везти, высылайте машину с носилками.');log(s,`${u.name}: нужна машина для транспортировки.`);}}return r;}
/* Release I: after an ambulance call — the patient goes to hospital in a brigade with a stretcher; a serious patient left at home calls again */
function emsAfterCall(s,i){if(needsHospital(i)){const idx=departmentIndex(s),u=s.units.find(x=>i.units.includes(x.id)&&(EMS_VEHICLES[idx.byVehicle.get(x.vehicleId)?.type]?.transport??true)&&!x.transport);if(u)u.transport={from:i.id,label:callName(i),district:districtOf(i),hospital:true,...(i.talk?.sets?.ecg||has(s,'ecg-link')&&['ems-chest','ems-stroke'].includes(i.variant)?{ecg:true}:{})};}
 else if(homeMistake(i)&&(s.followUps??=[]).length<12)s.followUps.push({at:s.time+30+((i.id*37)%30),variant:i.variant,x:i.x,y:i.y,from:i.id,reason:'Пациенту стало хуже после того, как бригада оставила его дома'});}
function callAmbulance(s,i){if(!(needsAmbulanceFor(i)||i.talk?.sets?.ambulance)||i.medical)return;if(!Array.isArray(s.services))s.services=[];if(s.services.filter(a=>a.kind==='ambulance').length>=AMBULANCE.maxActive)return;
 const id=(s.nextServiceId??1);s.nextServiceId=id+1;const a={id,kind:'ambulance',x:HOSPITAL.x,y:HOSPITAL.y,route:[],status:'responding',incident:i.id,timer:0,target:{x:i.x,y:i.y}};a.route=roadRoute(a,a.target);s.services.push(a);i.medical='called';
 log(s,`Скорая ${id}: ${medicalText(i)} — выезжаем на вызов №${i.id}.`);pushRadio(s,serviceCallsign(a),radioText('ambulance',i.id,id));}
function tickServices(s,dt){if(!s.services?.length)return;for(const a of [...s.services]){if(a.kind==='rescue'){tickRescue(s,a,dt);continue;}
 if(a.status==='responding'||a.status==='transporting'){advanceVehicle(a,dt,AMBULANCE.kmh*roadWeather(s),{obeyLimits:false});if(a.route.length)continue;
  if(a.status==='responding'){a.status='treating';a.timer=AMBULANCE.treatTime;const i=s.incidents.find(x=>x.id===a.incident);if(i&&!['resolved','missed'].includes(i.state))i.medical='treated';log(s,`Скорая ${a.id}: на месте, оказываем помощь (вызов №${a.incident}).`);}
  else{a.status='handover';a.timer=AMBULANCE.handoverTime;log(s,`Скорая ${a.id}: пострадавший доставлен в больницу.`);}continue;}
 a.timer-=dt;if(a.timer>0)continue;
 if(a.status==='treating'){a.status='transporting';a.route=roadRoute(a,HOSPITAL);log(s,`Скорая ${a.id}: везём пострадавшего в больницу.`);}
 else s.services=s.services.filter(x=>x!==a);}}
const SERVICE_TEXT={ambulance:{responding:'едет на вызов',treating:'помогает на месте',transporting:'везёт в больницу',handover:'в больнице'},rescue:{responding:'едут на вызов',securing:'ставят безопасную зону',working:'работают на месте',returning:'возвращаются в часть'}};
export const serviceStatus=a=>SERVICE_TEXT[a.kind??'ambulance']?.[a.status]??'';

// 0.7.2 v1 rescue service: station -> scene (safe zone, work) -> station.
export const FIRE_STATION=point(byId('ulejoe'));
function callRescue(s,i){if(!needsRescue(i)||i.rescue)return;if(!Array.isArray(s.services))s.services=[];if(s.services.filter(a=>a.kind==='rescue').length>=RESCUE_TEAM.maxActive)return;
 const id=(s.nextServiceId??1);s.nextServiceId=id+1;const a={id,kind:'rescue',x:FIRE_STATION.x,y:FIRE_STATION.y,route:[],status:'responding',incident:i.id,timer:0,target:{x:i.x,y:i.y}};a.route=roadRoute(a,a.target);s.services.push(a);i.rescue='called';
 log(s,`Спасатели ${id}: ${RESCUE[i.variant]} — выезжаем на вызов №${i.id}.`);pushRadio(s,serviceCallsign(a),radioText('rescue',i.id,id));}
const policeCordon=(s,i)=>s.units.some(u=>u.incident===i.id&&['decision','working'].includes(u.status)&&crewAtScene(u));
function tickRescue(s,a,dt){const i=s.incidents.find(x=>x.id===a.incident),open=i&&!['resolved','missed'].includes(i.state);
 if(a.status==='responding'||a.status==='returning'){advanceVehicle(a,dt,RESCUE_TEAM.kmh*roadWeather(s),{obeyLimits:false});if(a.route.length)return;
  if(a.status==='returning'){s.services=s.services.filter(x=>x!==a);return;}
  a.status='securing';a.timer=RESCUE_TEAM.secureTime;if(i)i.rescue='working';log(s,`Спасатели ${a.id}: на месте, ставим безопасную зону (вызов №${a.incident}).`);return;}
 a.timer-=dt*(a.status==='working'&&open&&policeCordon(s,i)?RESCUE_TEAM.cordonSpeed:1);if(a.timer>0)return;
 if(a.status==='securing'){a.status='working';a.timer=RESCUE_TEAM.workTime[i?.variant]??RESCUE_TEAM.workTime.crash;log(s,`Спасатели ${a.id}: ${i?.variant==='fire-smoke'?'тушим возгорание и выводим жильцов':i?.variant==='thin-ice'?'выходим на лёд со спасательными санями':i?.variant==='tree-down'?'распиливаем и убираем дерево':'деблокируем водителя'}${open&&policeCordon(s,i)?', полиция держит оцепление':''}.`);return;}
 if(i)i.rescue='done';a.status='returning';a.route=roadRoute(a,FIRE_STATION);log(s,`Спасатели ${a.id}: ${i?.variant==='fire-smoke'?'возгорание потушено, жильцы в безопасности':i?.variant==='thin-ice'?'рыбаки на берегу, переданы медикам':i?.variant==='tree-down'?'дорога свободна':'водитель освобождён и передан медикам'}. Возвращаемся в часть.`);}
function validServices(s){if(s.services===undefined)return true;const num=(x,min,max)=>Number.isFinite(x)&&x>=min&&x<=max;
 return Array.isArray(s.services)&&s.services.length<=SERVICE_LIMIT&&(s.nextServiceId===undefined||Number.isInteger(s.nextServiceId))&&s.services.every(a=>Number.isInteger(a.id)&&(a.kind==='ambulance'?['responding','treating','transporting','handover']:a.kind==='rescue'?['responding','securing','working','returning']:[]).includes(a.status)&&Number.isInteger(a.incident)&&num(a.timer,-1000,1000)&&containsWorldPoint(a)&&Array.isArray(a.route)&&a.route.length<3000&&a.route.every(p=>containsWorldPoint(p)));}

// Open investigations outlive the shift on the roster: «Розыск» cases and their pending leads move
// to the next shift (the lead comes 30–90 minutes into it, by hash, no rng).
function carryInvestigations(s,n){const open=(s.cases??[]).filter(c=>/^Розыск/.test(c.status)).slice(0,10).map(c=>({...c,fromShift:c.fromShift??s.shift,time:0}));if(open.length)n.cases=open;
 const leads=(s.followUps??[]).filter(f=>f.variant==='suspect-found'&&open.some(c=>c.id===f.from)).map(f=>({...f,at:40+((f.from*37)%80)}));if(leads.length)n.followUps=leads;}

// R2 shift routine (routine.js): briefing with lookouts, vehicle acceptance, meal break, reports.
function startRoutine(s){s.bolo=isService(s)?[]:briefingFor(s.seed,s.shift);if(isScheduled(s)&&(!s.goals||s.goals.month!==monthOf(s.shift-1).key)){ensureDistricts(s);s.goals=makeGoals(s,s.shift-1);log(s,`План на ${s.goals.label}: ${s.goals.list.map(goalLabel).join('; ')}.`);}const ev=isScheduled(s)?shiftWeather(s).event:null;if(ev){log(s,`Инструктаж: ${ev.label} — усиленный режим, вызовов больше обычного.${ev.about?' '+ev.about:''}`);pushNews(s,holidayNews(ev.label,s.shift));}else if(isScheduled(s)&&shiftKind(s.shift-1)==='night'&&[5,6].includes(weekdayOf(cityAbsoluteMinute(s))))log(s,`Инструктаж: ночь на ${weekdayOf(cityAbsoluteMinute(s))===5?'субботу':'воскресенье'} — бары, компании, пьяные водители. Будет жарко.`);for(const u of s.units){Object.assign(u,{status:'briefing',route:[],routineLeft:ROUTINE.briefing,mealDone:false});}
 log(s,`Инструктаж: ориентировки на смену — ${s.bolo.map(b=>b.text).join('; ')}.`);}
function matchBolo(s,i){if(!isScheduled(s)||!Array.isArray(s.bolo))return;const b=s.bolo.find(b=>b.matched===null&&b.variant===i.variant);if(!b)return;b.matched=i.id;i.bolo=b.id;log(s,`Дежурный: вызов №${i.id} похож на ориентировку с инструктажа (${b.text}).`);}
const crewOfficers=(s,u)=>u.officerIds.map(id=>departmentIndex(s).byOfficer.get(id)).filter(Boolean);
function acceptVehicle(s,u,v){if(!v)return;ensureVehicle(v);const share=v.fuel/tankOf(v);
 if(v.wear>=WEAR.slow)log(s,`${u.name}: приёмка машины — износ ${Math.round(v.wear)}%, нужен ремонт.`);
 if(share<ROUTINE.acceptFuelShare&&!v.service){const st=nearestStation(u);u.status='servicing';v.service={kind:'fuel',left:toTicks(FUEL.refuelMinutes),cost:0,station:st.id};routeTo(u,st);log(s,`${u.name}: приёмка машины — в баке ${Math.round(v.fuel)} л, заправимся перед патрулём (${st.name}).`);}
 else log(s,`${u.name}: машина принята (${Math.round(v.fuel)} л, износ ${Math.round(v.wear)}%), выходим в патруль.`);}
function tickRoutine(s,u,v,dt){if(!isScheduled(s))return false;u.routineLeft=(u.routineLeft??0)-dt;
 if(u.status==='briefing'){if(u.routineLeft>0)return true;delete u.routineLeft;u.status='patrol';acceptVehicle(s,u,v);return true;}
 for(const o of crewOfficers(s,u))o.fatigue=Math.max(0,o.fatigue-dt*ROUTINE.mealRecovery/ROUTINE.meal);
 const urgent=s.incidents.some(i=>i.state==='waiting'&&TYPES[i.type].severity>=3);
 if(urgent||u.routineLeft<=0){delete u.routineLeft;u.status='patrol';u.mealDone=true;log(s,urgent?`${u.name}: обед прерван — срочный вызов.`:`${u.name}: обед окончен, снова на линии.`);return !urgent;}
 return true;}
function routineDue(s,u){if(u.incident!=null||u.foot||u.transport)return false;
 if(s.time>=s.shiftLength-ROUTINE.reports){u.status='reports';routeTo(u,HQ);log(s,`${u.name}: конец смены, едем в участок писать рапорты.`);return true;}
 if(!u.mealDone&&s.time>=ROUTINE.mealLate){u.mealDone=true;for(const o of crewOfficers(s,u))o.fatigue=Math.min(100,o.fatigue+ROUTINE.skippedMeal);log(s,`${u.name}: смена без обеда — усталость выше.`);return false;}
 if(!u.mealDone&&s.time>=ROUTINE.mealFrom&&s.time<=ROUTINE.mealTo&&!s.incidents.some(i=>i.state==='waiting')){u.status='break';u.route=[];u.routineLeft=ROUTINE.meal;log(s,`${u.name}: обеденный перерыв.`);return true;}
 return false;}

// R9: call load by hour and weekday (season.js) — Friday/Saturday nights are the peak.
export const cityAbsoluteMinute=s=>absoluteMinute(worldMinutes(s.population?.elapsed??0));
export const loadNow=s=>isScheduled(s)?loadFactor(cityAbsoluteMinute(s))*ROSTER_CALL_RATE:1;
// Real calls take longer on scene (statements, checks, paperwork): 30–60 minutes is common, so on
// the roster scene work runs at 0.6 of the legacy pace and calls come 1.25× as often.
const ROSTER_WORK_PACE=.6,ROSTER_CALL_RATE=1.25;
export const weekdayNow=s=>isScheduled(s)?WEEKDAY_LABEL[weekdayOf(cityAbsoluteMinute(s))]:null;

// Snow, black ice and fog slow every car on roster campaigns (legacy campaigns unchanged).
const roadWeather=s=>isScheduled(s)?weatherSpeed(shiftWeather(s).kind):1;

// R10 department upgrades (upgrades.js), chief only.
export function buyUpgrade(s,id){const u=UPGRADES[id];if(s.mode!=='chief'||s.ended||!u||!upgradeFor(s,id))return {ok:false,message:'Недоступно.'};if(has(s,id))return {ok:false,message:'Уже есть.'};if(s.budget<u.price)return {ok:false,message:`Стоит ${u.price}. Недостаточно бюджета.`};if(s.budget-u.price<hiringReserve(s))return {ok:false,message:'Сначала наймите хотя бы одного сотрудника.'};
 transact(s,-u.price,'upgrade',u.label);if(!Array.isArray(s.upgrades))s.upgrades=[];s.upgrades.push(id);log(s,`Начальник: куплено — ${u.label}.`);return {ok:true,message:u.label+': готово'};}
function restroomRecovery(s,dt){const c=departmentIndex(s);for(const u of s.units)if(u.status==='resting')for(const id of u.officerIds){const o=c.byOfficer.get(id);if(o)o.fatigue=Math.max(0,o.fatigue-dt*1.435*UPGRADE_EFFECT.rest);}}
// R12 internal control: complaints after arrests or failed calls, reviewed between shifts.
function fileComplaint(s,i,success){const custody=success?custodyDecision(i):null,arrest=custody==='arrest',failed=!success;if(!arrest&&!failed)return;const u=s.units.find(x=>i.units.includes(x.id));if(!u)return;
 const chance=complaintChance({arrest,failed,stress:crewStress(s,u),strict:policyOf(s).custody==='arrest',bodycam:has(s,'bodycam')});if(!complaintRolled(s.seed,i.id,chance*talkComplaintFactor(i.talk)*(s.mode==='career'&&u.id===1?partnerComplaints(s.life?.partner):1)))return;
 if(!Array.isArray(s.complaints))s.complaints=[];if(s.complaints.length>=COMPLAINTS.limit)return;s.complaints.push({incident:i.id,unit:u.id,reason:COMPLAINT_REASONS[arrest?'arrest':'failed'],status:'проверка',district:districtOf(i)});log(s,`Внутренний контроль: поступила жалоба по вызову №${i.id} (${u.name}).`);}
function reviewComplaints(s,n){const open=(s.complaints??[]).filter(c=>c.status==='проверка');if(!open.length)return;const cam=has(s,'bodycam');n.complaints=open.map(c=>({...c,status:complaintCleared(s.seed,c.incident,cam)?'не подтвердилась':'обоснована'}));
 for(const c of n.complaints){if(c.status==='не подтвердилась'){log(n,`Внутренний контроль: жалоба по вызову №${c.incident} не подтвердилась${cam?' (записи нагрудных камер)':''}.`);continue;}
  n.trust=Math.max(0,n.trust-COMPLAINTS.foundedTrust);if(n.districts&&c.district&&n.districts[c.district]!==undefined)n.districts[c.district]=Math.max(0,n.districts[c.district]-COMPLAINTS.foundedDistrict);
  if(n.mode==='career'&&c.unit===1&&n.life){n.life.stress=Math.min(100,n.life.stress+COMPLAINTS.foundedStress);n.xp=Math.max(0,n.xp-COMPLAINTS.foundedXp);}
  else{const u=n.units.find(x=>x.id===c.unit);for(const id of u?.officerIds??[]){const o=departmentIndex(n).byOfficer.get(id);if(o){o.stress=Math.min(100,(o.stress??10)+COMPLAINTS.foundedStress);}}}
  pushNews(n,complaintNews(c.incident));log(n,`Внутренний контроль: жалоба по вызову №${c.incident} обоснована — замечание экипажу, доверие −${COMPLAINTS.foundedTrust}.`);}}

// R6 roles (life.js ROLES): the career officer applies for a role once rank and course allow.
export function setRole(s,id){if(s.mode!=='career'||!isScheduled(s)||!s.life)return {ok:false,message:'Роли — в карьере по графику.'};if(id===null||id===''){s.life.role=null;log(s,'Вы вернулись в обычный патруль.');return {ok:true,message:'Обычный патруль'};}
 const why=roleBlocker(s.life,id,s.rank,s.shift);if(why)return {ok:false,message:why};s.life.role=id;log(s,`Приказ: вы назначены — ${ROLES[id].label}.`);return {ok:true,message:ROLES[id].label};}

// R4 burnout (burnout.js): stress slows work; very tired drivers can nod off at night.
function crewStress(s,u){if(!isScheduled(s)||!u)return 0;if(s.mode==='career'&&u.id===1)return s.life?.stress??0;return Math.max(0,...u.officerIds.map(id=>departmentIndex(s).byOfficer.get(id)?.stress??0));}
function callStress(s,i,success){const add=success?(VIOLENT.includes(i.variant)?BURNOUT_STRESS.violent:0):BURNOUT_STRESS.failed;if(!add)return;
 if(s.mode==='career'){if(i.units.includes(1)&&s.life)s.life.stress=Math.min(100,s.life.stress+add);return;}
 for(const u of s.units)if(i.units.includes(u.id))for(const o of crewOfficers(s,u)){ensureOfficer(o);o.stress=Math.min(100,o.stress+add);}}
function nodOff(s,u,v){if(!u.route.length||(u.currentSpeedKmh||0)<20||!s.population)return;const b=bucketOf(s.population.elapsed);if(u.sleepCheck===b)return;u.sleepCheck=b;
 const r=microsleep(u.id,b,u.fatigue,cityMinute(s.population.elapsed));if(!r)return;
 if(r==='crash'){u.pullover=BURNOUT.crashStop;if(v){ensureVehicle(v);v.wear=Math.min(WEAR.broken-1,v.wear+BURNOUT.crashWear);addHistory(v,s.time,'Задели ограждение: водитель задремал');}
  if(s.mode==='career'&&u.id===1&&s.life)s.life.stress=Math.min(100,s.life.stress+10);else if(s.mode==='chief')s.trust=Math.max(0,s.trust-1);
  log(s,`${u.name}: водитель задремал и задел ограждение. Машина повреждена, 10 минут разбора на месте.`);}
 else{u.pullover=BURNOUT.nearMissStop;log(s,`${u.name}: водитель чуть не заснул за рулём — остановились на 5 минут прийти в себя.`);}
 radio(s,'nodoff',u,null);}
// R5 chief roster (roster.js): sleep debt, stress and leave of every officer between shifts.
function rosterBetweenShifts(s,n){const worked=new Set(s.units.flatMap(u=>u.officerIds)),night=shiftKind(s.shift-1)==='night',rest=(restBefore(s.shift)??720)/60;
 for(const o of n.officers){rosterAfterShift(o,{worked:worked.has(o.id),night,missed:Math.min(5,s.missed),restHours:rest});o.fatigue=Math.max(o.fatigue,startFatigueOf(o));}
 for(const u of n.units)syncCrew(n,u);}
// Release F «Истории города» (arcs.js): multi-shift stories, one chapter (call) per shift in the story's
// district; the briefing gives the chapter and a lookout, the press follows, the ending changes trust.
function cityTick(s){const a=s.city.arc,ch=chapterOf(a);if(!ch||a.spawned===s.shift||s.time<spawnAt(s.seed,s.shift,s.shiftLength)||s.time>s.shiftLength*CITY.end)return;
 const i=spawnIncident(s,null,{variant:ch.variant,point:arcPoint(a.id,a.chapter)});if(!i)return;i.arc=a.id;a.spawned=s.shift;a.incident=i.id;delete a.outcome;
 const u=s.units.find(x=>x.id===1);if(s.mode==='career'&&u&&u.incident==null&&!u.foot&&['patrol','idle'].includes(u.status)&&s.life?.role!=='detective')assign(s,1,i.id,true);
 pushRadio(s,'Дежурный',`${ARCS[a.id].title}, глава ${a.chapter+1}: ${ch.brief.split('. ')[0]}.`);log(s,`История города «${ARCS[a.id].title}», глава ${a.chapter+1} из ${ARCS[a.id].chapters.length}: ${ch.brief}`);}
function cityShift(s,n){if(isService(s))return;const c=s.city?JSON.parse(JSON.stringify(s.city)):{done:[],next:CITY.firstShift,arc:null};n.city=c;const a=c.arc;
 if(a&&a.spawned===s.shift){const ok=a.outcome==='ok',story=ARCS[a.id],ch=story.chapters[a.chapter];delete a.spawned;delete a.incident;delete a.outcome;
  const end=win=>{const r=win?CITY.reward:CITY.penalty;addTrust(n,r.trust);if(n.districts?.[story.district]!==undefined)addDistrictTrust(n,story.district,r.district);
   if(win){if(n.mode==='career')n.xp+=CITY.reward.xp;else n.budget+=CITY.reward.budget;}log(n,`История города «${story.title}»: ${win?story.good:story.bad}`);pushNews(n,{title:win?ch.news:story.bad,tone:win?'good':'bad',media:'Вестник Меридиана'});c.done=[...c.done,{id:a.id,ok:win,shift:n.shift}].slice(-DONE_LIMIT);c.effects=[...(c.effects??[]).filter(e=>e.until>=n.shift),{id:a.id,factor:win?EFFECT.solved:EFFECT.failed,until:n.shift+EFFECT.shifts}].slice(-EFFECT.limit);c.total=(c.total??0)+1;c.arc=null;c.next=n.shift+CITY.gap;};
  if(ok){a.miss=0;if(a.chapter>=story.chapters.length-1)end(true);else{log(n,`История города «${story.title}»: глава ${a.chapter+1} закрыта. ${ch.news}.`);pushNews(n,{title:ch.news,tone:'good',media:'Меридиан Online'});a.chapter++;}}
  else{a.miss++;if(a.miss>=CITY.misses)end(false);else log(n,`История города «${story.title}»: глава ${a.chapter+1} сорвалась — будет ещё один шанс.`);}}
 if(!c.arc&&n.shift>=c.next){const id=nextArc(n.seed,c.done,c.total??c.done.length),again=(c.total??c.done.length)>=Object.keys(ARCS).length;if(id){c.arc={id,chapter:0,miss:0};log(n,`В городе${again?' снова':''}: ${ARCS[id].intro}`);pushNews(n,{title:(again?'Снова: ':'')+ARCS[id].intro,tone:'neutral',media:'Портал «Наш район»'});}}}
function cityLookout(n){const ch=chapterOf(n.city?.arc);if(ch&&Array.isArray(n.bolo)&&n.bolo.length<3)n.bolo.push({id:3,variant:ch.variant,text:ch.lookout.slice(0,160),matched:null});}
// Release E (Claude's part) «Первая неделя службы» (firstweek.js): a new roster career can start with a
// guided week — one story call a shift for the player's crew, mentor advice at the briefing, a debrief.
export function startFirstWeek(s){if(s.mode!=='career'||!isScheduled(s)||!s.life||s.life.week||isService(s))return false;s.life.week={day:1,results:[]};return true;}
export function startChiefWeek(s){if(s.mode!=='chief'||!isScheduled(s)||s.chiefWeek||isService(s))return false;s.chiefWeek={day:1,results:[]};return true;}
export function skipFirstWeek(s){const w=s.mode==='chief'?s.chiefWeek:s.life?.week;if(!w||w.done)return {ok:false,message:'Обучения нет.'};w.done=true;log(s,'Наставник: хорошо, дальше сам. Если что — я рядом.');return {ok:true,message:'Обучение пропущено'};}
function storyTick(s){const w=s.life.week,d=storyDay(s);if(!d||w.spawned===s.shift||s.time<s.shiftLength*STORY.startShare||s.time>s.shiftLength*.8)return;const u=s.units.find(x=>x.id===1);if(!u||u.incident!=null||u.foot||!['patrol','idle'].includes(u.status))return;
 const i=spawnIncident(s,null,{variant:d.variant,point:storyPoint(HQ,d.day)});if(!i)return;i.story=d.day;w.spawned=s.shift;w.incident=i.id;assign(s,1,i.id,true);
 pushRadio(s,'Наставник',`День ${d.day}: ${d.title}. ${d.brief.split('. ')[0]}.`);log(s,`Первая неделя, день ${d.day} — «${d.title}». Наставник: ${d.brief}`);}
function chiefWeekShift(s,n){const w=s.chiefWeek;if(!w)return;n.chiefWeek=JSON.parse(JSON.stringify(w));const c=n.chiefWeek;if(c.done||n.mode!=='chief')return;const d=CHIEF_WEEK.find(x=>x.day===c.day);if(!d)return;
 const ok=d.test(s)?1:0;c.results=[...c.results,ok];c.last=(ok?`Заместитель: «${d.title}» — выполнено.`:`Заместитель: «${d.title}» не получилось. ${d.brief}`).slice(0,400);log(n,c.last);c.day++;
 if(c.day>CHIEF_WEEK.length){c.done=true;const pts=c.results.reduce((a,b)=>a+b,0),pass=pts>=CHIEF_REWARD.pass;c.last=pass?`Первая неделя начальника: ${pts} из ${CHIEF_WEEK.length}. Префектура довольна — +${CHIEF_REWARD.budget} к бюджету.`:`Первая неделя начальника: ${pts} из ${CHIEF_WEEK.length}. Префектура ждёт улучшений.`;log(n,c.last);if(pass){n.budget+=CHIEF_REWARD.budget;pushNews(n,{title:'Новый начальник отделения Меридиана прошёл первую неделю',tone:'good',media:'Вестник Меридиана'});}}}
function weekShift(s,n){const w=n.life?.week;if(!w||w.done||n.mode!=='career')return;if(w.spawned!==s.shift)return;const live=s.incidents.find(x=>x.id===w.incident),points=Number.isInteger(s.life?.week?.outcome)?s.life.week.outcome:dayResult(w.day,live).points,d=WEEK.find(x=>x.day===w.day);
 w.results=[...w.results,{day:w.day,points}];w.last=(points===2?d.good:points===1?`${d.good} Но: ${d.bad}`:d.bad).slice(0,240);delete w.outcome;log(n,`Разбор дня ${w.day}: ${w.last}`);w.day++;delete w.spawned;delete w.incident;
 if(w.day>WEEK.length){const v=weekVerdict(w.results);w.done=true;w.last=v.text;log(n,v.text);if(v.passed){n.xp+=STORY.reward.xp;if(n.life.partner)n.life.partner.bond=Math.min(100,n.life.partner.bond+STORY.reward.bond);pushNews(n,{title:'Новый патрульный Меридиана прошёл испытательную неделю',tone:'good',media:'Вестник Меридиана'});}}}
// Release C2 «Служба 2.1» (service2.js): duty plan and staff training (chief), transfers and personal
// goals (career). The duty plan is applied when a shift starts: officers who are off today are covered
// from the reserve; the home crew comes back the next shift.
export function setOfficerDuty(s,officerId,duty){const o=s.officers?.find(x=>x.id===officerId);if(s.mode!=='chief'||!isScheduled(s)||!o||!Object.hasOwn(DUTY,duty))return {ok:false,message:'График недоступен.'};if((o.duty??'full')===duty)return {ok:true,message:DUTY[duty].label};
 if(duty==='full')delete o.duty;else o.duty=duty;log(s,`График: ${o.name} — ${DUTY[duty].label.toLowerCase()} со следующей смены.`);return {ok:true,message:`${o.name}: ${DUTY[duty].label}`};}
export function sendToCourse(s,officerId,courseId){const o=s.officers?.find(x=>x.id===officerId);if(s.mode!=='chief'||!isScheduled(s)||s.ended)return {ok:false,message:'Обучение назначает начальник во время смены.'};const why=studyBlocker(s,o,courseId);if(why)return {ok:false,message:why};const c=STAFF_COURSES[courseId];
 transact(s,-c.price,'training',`Курс «${c.label}»: ${o.name}`);o.study={course:courseId,left:c.shifts};log(s,`Обучение: ${o.name} направлен на курс «${c.label}» (${c.shifts} ${c.shifts===1?'смена':'смены'}).`);return {ok:true,message:`${o.name}: курс оформлен`};}
export function requestTransfer(s,role){const l=s.life;if(s.mode!=='career'||!isScheduled(s)||!l)return {ok:false,message:'Переводы — в карьере по графику.'};
 if(role===null||role===''){if(!l.role&&!l.transfer)return {ok:true,message:'Обычный патруль'};l.transfer=null;l.role=null;log(s,'Рапорт: вы вернулись в обычный патруль.');return {ok:true,message:'Обычный патруль'};}
 if(l.role===role)return {ok:true,message:ROLES[role]?.label??''};const why=roleBlocker(l,role,s.rank,s.shift);if(why)return {ok:false,message:why};
 l.transfer={role,ready:s.shift+TRANSFER.wait};log(s,`Рапорт о переводе: ${ROLES[role].label}. Отдел кадров ответит через ${TRANSFER.wait} смены.`);return {ok:true,message:`Рапорт подан: ответ через ${TRANSFER.wait} смены`};}
export function buyPersonal(s,id){const l=s.life,why=purchaseBlocker(l,id);if(s.mode!=='career'||!isScheduled(s))return {ok:false,message:'Только в карьере по графику.'};if(why)return {ok:false,message:why};const p=PURCHASES[id];
 l.money-=p.price;l.owned={...(l.owned??{}),[id]:id==='gym'?p.shifts:true};log(s,`Личное: ${p.label} — −${p.price} €. ${p.about}`);return {ok:true,message:p.label};}
function service2Shift(s,n,plan){if(!isScheduled(n))return;
 if(n.mode==='chief'){for(const o of n.officers){const done=studyShift(o);if(done){log(n,`Обучение: ${done}`);}}
  const index=n.shift-1,kind=shiftKind(index),byId=new Map(n.officers.map(o=>[o.id,o])),inUnit=()=>new Set(n.units.flatMap(u=>u.officerIds));
  for(const u of n.units)if(u.homeCrew){const other=new Set(n.units.filter(x=>x!==u).flatMap(x=>x.officerIds)),home=u.homeCrew.filter(id=>byId.has(id)&&!other.has(id)&&!unavailable(byId.get(id)));if(home.length)u.officerIds=home;delete u.homeCrew;}
  const off=[],subs=[],called=[];
  for(const u of n.units){const home=[...u.officerIds];let crew=[...u.officerIds];
   for(const id of home){const o=byId.get(id);if(!o||onDuty(o,index,kind))continue;const busy=inUnit(),sub=n.officers.filter(x=>!busy.has(x.id)&&!crew.includes(x.id)&&!unavailable(x)&&onDuty(x,index,kind)).sort((a,b)=>(a.stress??0)-(b.stress??0)||a.id-b.id)[0];
    if(sub){crew=crew.map(x=>x===id?sub.id:x);u.officerIds=crew;off.push(o.name);subs.push(`${sub.name} → ${u.name}`);}
    else if(crew.length>1){crew=crew.filter(x=>x!==id);u.officerIds=crew;off.push(o.name);}
    else{o.stress=Math.min(100,(o.stress??10)+CALLED_IN_STRESS);called.push(o.name);}}
   if(crew.join()!==home.join()){u.homeCrew=home;u.people=crew.map(id=>byId.get(id).name);syncCrew(n,u);}}
  if(off.length)log(n,`График: сегодня не выходят — ${off.join(', ')}.${subs.length?` Замены из резерва: ${subs.join('; ')}.`:' Резерва нет — экипажи работают в одиночку.'}`);
  if(called.length)log(n,`График: некем заменить — ${called.join(', ')} вызваны на смену (стресс +${CALLED_IN_STRESS}).`);}
 if(n.mode==='career'&&n.life){const l=n.life,was=s.life??{};
  if(l.transfer&&n.shift>=l.transfer.ready){const role=l.transfer.role,why=transferVerdict(l)??roleBlocker(l,role,n.rank,n.shift);l.transfer=null;
   if(why)log(n,`Отдел кадров: перевод отклонён. ${why}`);else{l.role=role;log(n,`Приказ: вы переведены — ${ROLES[role].label}.`);pushNews(n,{title:`В отделении Меридиана новый сотрудник: ${ROLES[role].label.toLowerCase()}`,tone:'good',media:'Вестник Меридиана'});}}
  if(owns(l,'car'))l.sleepDebt=Math.max(0,l.sleepDebt+PURCHASES.car.sleep);
  if((l.owned?.gym??0)>0){const blocks=freeBlocks(s.shift),chosen=validPlan(plan,blocks,was)?plan:defaultPlan(blocks),sport=chosen.filter(p=>p.activity==='sport').length;if(sport)l.fitness=Math.min(100,l.fitness+sport*8);l.owned.gym--;if(!l.owned.gym)delete l.owned.gym;}
  if(n.shift>s.shift+1&&owns(l,'trip')){l.stress=0;l.sleepDebt=0;delete l.owned.trip;log(n,'Отпуск у моря: стресс и недосып ушли полностью.');}}}
export function grantLeave(s,officerId){const o=s.officers.find(x=>x.id===officerId);if(s.mode!=='chief'||!isScheduled(s)||s.ended||!o)return {ok:false,message:'Отпуск недоступен.'};const why=canTakeLeave(s,o);if(why)return {ok:false,message:why};
 o.leave=ROSTER.leaveShifts;o.leaveDays-=ROSTER.leaveDays;log(s,`Начальник: ${o.name} в отпуске на ${ROSTER.leaveShifts} смены (−${ROSTER.leaveDays} дн., осталось ${o.leaveDays}).`);return {ok:true,message:`${o.name}: отпуск оформлен`};}

// R3: the career officer's time between roster shifts (life.js). Pay for the finished shift, the
// chosen plan for the free days, then the officer starts the next shift with sleep debt/stress.
function offDutyLife(s,n,plan){const life=JSON.parse(JSON.stringify(s.life)),blocks=freeBlocks(s.shift),vacation=n.shift>s.shift+1;const chosen=validPlan(plan,blocks,s.life)?plan:defaultPlan(blocks);
 const pay=workShift(life,{night:shiftKind(s.shift-1)==='night',missed:s.missed});const r=vacation?applyVacation(life,s.shift):applyPlan(life,chosen,s.shift);if(newYear(life,shiftDate(n.shift-1).year))r.lines.push('Новый год: 35 дней отпуска и 5 дней здоровья');n.life=life;n.xp+=r.xp;n.rank=rankOf(n);
 life.last={shift:s.shift,pay,lines:[`Зарплата за смену: ${pay} € на руки`,...r.lines].slice(0,10)};
 const me=departmentIndex(n).byOfficer.get(1);if(me)me.fatigue=Math.max(me.fatigue,startFatigue(life));for(const u of n.units)syncCrew(n,u);
 for(const line of life.last.lines.slice().reverse())log(n,'Между сменами: '+line);}

// R1: extra fatigue on night duty (peak 04:00–05:00), only for crews on duty.
function nightDuty(s,dt){const f=nightFatigueFactor(cityMinute(s.population?.elapsed??0));if(f<=1)return;const c=departmentIndex(s);
 for(const u of s.units){if(['resting','servicing'].includes(u.status))continue;for(const id of u.officerIds){const o=c.byOfficer.get(id);if(o)o.fatigue=Math.min(100,o.fatigue+dt*.065*(f-1));}}}

// 0.6.1 garage (garage.js): realistic fuel in litres, idling, filling stations, wear, breakdown/tow, repair.
// Filling stations: the nearest main-road node to three districts (fictional names).
const STATION_ROADS=new Set(['primary','secondary','tertiary','trunk']);
export const FUEL_STATIONS=Object.freeze([['raama','АЗС «Северная»'],['mai','АЗС «Восточная»'],['vana','АЗС «Западная»']].map(([anchor,name],k)=>{const a=byId(anchor);const road=NODES.filter(n=>STATION_ROADS.has(n.kind));const n=(road.length?road:NODES).reduce((b,n)=>Math.hypot(n.x-a.x,n.y-a.y)<Math.hypot(b.x-a.x,b.y-a.y)?n:b);return Object.freeze({id:k,name,x:n.x,y:n.y});}));
export const nearestStation=p=>FUEL_STATIONS.reduce((b,st)=>Math.hypot(st.x-p.x,st.y-p.y)<Math.hypot(b.x-p.x,b.y-p.y)?st:b);
const ENGINE_ON=new Set(['patrol','idle','responding','decision','working','transporting','proactive']);
function chargeGarage(s,cost,category,label){const amount=Math.min(Math.max(0,Math.round(cost)),Math.max(0,s.budget));if(s.mode==='chief'&&amount>0)transact(s,-amount,category,label);return amount;}
function leaveCall(s,u){const old=s.incidents.find(x=>x.id===u.incident);if(old){old.units=old.units.filter(id=>id!==u.id);if(!old.units.length&&['assigned','onscene'].includes(old.state))old.state='waiting';}u.incident=null;u.pursuing=false;u.route=[];u.status='servicing';}
function wearAndFuel(s,u,v,dt){ensureVehicle(v);const hours=toMinutes(dt)/60,speed=u.currentSpeedKmh||0,km=speed*hours,idle=speed<1&&ENGINE_ON.has(u.status)?hours:0;
 const smooth=s.mode==='career'&&u.id===1&&(Number.isInteger(s.life?.courses?.driving)||Number.isInteger(s.life?.courses?.heavy)||Number.isInteger(s.life?.courses?.ambdrive));consume(v,km,{urgent:!smooth&&urgentMovement(s,u),pursuit:!smooth&&!!u.pursuing,idleHours:idle});
 if(v.service||u.foot||u.transport)return;
 if(broken(v)){leaveCall(s,u);v.service={kind:'tow',left:toTicks(WEAR.towMinutes),cost:0};addHistory(v,s.time,`Поломка на ${Math.round(v.km)} км, вызван эвакуатор`);log(s,`${u.name}: машина сломалась, ждём эвакуатор.`);radio(s,'breakdown',u,null);return;}
 if(emptyTank(v)){leaveCall(s,u);v.service={kind:'canister',left:toTicks(FUEL.canisterMinutes),cost:0};addHistory(v,s.time,'Кончилось топливо, ждём канистру');log(s,`${u.name}: кончилось топливо, ждём доставку канистры.`);radio(s,'empty',u,null);return;}
 if(needsFuel(v)&&['patrol','idle'].includes(u.status)&&u.incident==null){const st=nearestStation(u);u.status='servicing';v.service={kind:'fuel',left:toTicks(FUEL.refuelMinutes),cost:0,station:st.id};routeTo(u,st);log(s,`${u.name}: в баке ${Math.round(v.fuel)} л из ${tankOf(v)}, едем на ${st.name}.`);radio(s,'fuel',u,null);}}
function finishService(s,u,v){const k=v.service.kind,station=FUEL_STATIONS[v.service.station]??null;v.service=null;
 if(k==='fuel'){const litres=refuelLitres(v),cost=chargeGarage(s,refuelCost(v),'fuel','Топливо: '+v.name);v.fuel=tankOf(v);addHistory(v,s.time,`Заправка ${litres.toFixed(1)} л${cost?` · ${cost}`:''}${station?` · ${station.name}`:''}`);if(u){log(s,`${u.name}: заправились (${litres.toFixed(0)} л), продолжаем патруль.`);radio(s,'refueled',u,null);}}
 else if(k==='canister'){v.fuel=Math.min(tankOf(v),FUEL.canisterLitres);addHistory(v,s.time,`Канистра: ${FUEL.canisterLitres} л`);if(u)log(s,`${u.name}: залили канистру, едем на заправку.`);}
 else{v.wear=0;addHistory(v,s.time,'Ремонт завершён');if(u){log(s,`${u.name}: ремонт завершён, машина в строю.`);radio(s,'repaired',u,null);}else log(s,`Гараж: ${v.name} отремонтирована.`);}
 if(u){u.status='patrol';u.route=[];}}
function tickServicing(s,u,v,dt){if(!v){u.status='patrol';return false;}ensureVehicle(v);if(!v.service){u.status='patrol';return false;}
 if(v.service.kind==='tow'){v.service.left-=dt;if(v.service.left>0)return true;Object.assign(u,point(HQ));u.route=[];const time=repairTime(v),cost=chargeGarage(s,repairCost(v),'repair','Ремонт после поломки: '+v.name);v.service={kind:'repair',left:time,cost};addHistory(v,s.time,`Эвакуатор доставил в гараж, ремонт${cost?` · ${cost}`:''}`);log(s,`${u.name}: машина в гараже, ремонт ~${Math.round(toMinutes(time))} мин.`);return true;}
 if(u.route.length){move(u,dt,s,v);consume(v,(u.currentSpeedKmh||0)*toMinutes(dt)/60);return true;}
 v.service.left-=dt;if(v.service.left<=0)finishService(s,u,v);return true;}
// Cars without a crew can still be in repair.
function tickParkedService(s,dt){for(const v of s.vehicles){if(!v.service||s.units.some(u=>u.vehicleId===v.id))continue;v.service.left-=dt;if(v.service.left<=0)finishService(s,null,v);}}
function overnightGarage(n,time){for(const v of n.vehicles){ensureVehicle(v);if(v.service){if(['repair','tow'].includes(v.service.kind))v.wear=0;v.service=null;addHistory(v,0,'Обслуживание завершено между сменами');}if(n.mode!=='chief')v.wear=Math.max(0,v.wear-REPAIR.shiftService);else if(has(n,'workshop'))v.wear=Math.max(0,v.wear-REPAIR.shiftService*WORKSHOP.service);}for(const u of n.units)if(u.status==='servicing'){u.status='patrol';u.route=[];}}
export function repairVehicle(s,id){const v=s.vehicles.find(x=>x.id===id);if(s.mode!=='chief'||s.ended||!v)return {ok:false,message:'Ремонт недоступен.'};ensureVehicle(v);if(v.service)return {ok:false,message:'Машина уже на обслуживании.'};if(v.wear<1)return {ok:false,message:'Машина исправна.'};
 const u=s.units.find(x=>x.vehicleId===id);if(u&&!['patrol','idle','resting'].includes(u.status))return {ok:false,message:'Дождитесь завершения вызова.'};const ws=has(s,'workshop'),cost=Math.round(repairCost(v)*(ws?WORKSHOP.repairCost:1)),time=repairTime(v)*(ws?WORKSHOP.repairTime:1);if(s.budget<cost)return {ok:false,message:`Ремонт стоит ${cost}. Недостаточно бюджета.`};
 transact(s,-cost,'repair','Ремонт: '+v.name);v.service={kind:'repair',left:time,cost};addHistory(v,s.time,`Плановый ремонт · ${cost}`);if(u){u.status='servicing';routeTo(u,HQ);}const minutes=repairMinutes(v);log(s,`Гараж: ${v.name} — ремонт ~${minutes} мин, ${cost}.`);return {ok:true,message:`Ремонт начат: ~${minutes} мин`};}
export function setVehicleExtra(s,id,extra,on){const v=s.vehicles.find(x=>x.id===id);if(s.mode!=='chief'||s.ended||!v||!Object.hasOwn(EXTRAS,extra))return {ok:false,message:'Оснащение недоступно.'};ensureVehicle(v);
 const u=s.units.find(x=>x.vehicleId===id);if(u&&!['patrol','idle','resting'].includes(u.status))return {ok:false,message:'Дождитесь завершения вызова.'};
 if(!on){if(!v.extras.includes(extra))return {ok:false,message:'Этого нет в багажнике.'};v.extras=v.extras.filter(x=>x!==extra);addHistory(v,s.time,'Снято: '+EXTRAS[extra].label);return {ok:true,message:'Снято без возврата денег'};}
 if(v.extras.includes(extra))return {ok:false,message:'Уже в багажнике.'};if(v.extras.length>=slotsOf(v))return {ok:false,message:`Багажник заполнен: мест ${slotsOf(v)}.`};const price=EXTRAS[extra].price;if(s.budget<price)return {ok:false,message:`Стоит ${price}. Недостаточно бюджета.`};if(s.budget-price<hiringReserve(s))return {ok:false,message:'Сначала наймите хотя бы одного сотрудника.'};
 transact(s,-price,'equipment',EXTRAS[extra].label+': '+v.name);v.extras.push(extra);addHistory(v,s.time,`Установлено: ${EXTRAS[extra].label} · ${price}`);return {ok:true,message:EXTRAS[extra].label+' в багажнике'};}
export const vehicleOf=(s,u)=>departmentIndex(s).byVehicle.get(u?.vehicleId)??null;

// 0.6.2 department rules (policy.js): standing order and priority district, chief mode only.
const priorityRank=(s,i)=>{const p=priorityOf(s);return p&&districtOf(i)===p?0:1;};
function applyPolicyCustody(s,i){const rule=policyOf(s).custody;if(rule&&canChooseCustody(i.variant)&&i.custodyChoice===undefined)i.custodyChoice=rule;}
export function setPolicy(s,id){if(s.mode!=='chief'||s.agency||s.ended||!Object.hasOwn(POLICIES,id)||(s.policy??'balanced')===id)return false;s.policy=id;log(s,`Начальник: введён режим «${POLICIES[id].label}».`);return true;}
export function setPriorityDistrict(s,id){if(s.mode!=='chief'||s.ended)return false;const next=DISTRICT_IDS.includes(id)?id:null;if((s.priorityDistrict??null)===next)return false;s.priorityDistrict=next;log(s,next?`Начальник: приоритет патрулирования — район ${districtName(next)}.`:'Начальник: приоритет районов снят.');return true;}

// 0.7.0 step 4: investigation of unsolved thefts (deterministic lead, see calls.js leadFor).
function investigate(s,i,success){const file=(s.cases??[]).find(c=>c.id===i.id);
 if(i.variant==='suspect-found'&&i.followUp){const origin=(s.cases??[]).find(c=>c.id===i.followUp.from);if(origin)origin.status=success?'Раскрыто: подозреваемый задержан':'Розыск: подозреваемый снова скрылся';if(success)log(s,`Дело №${i.followUp.from} раскрыто: подозреваемый задержан (вызов №${i.id}).`);return;}
 if(success)return;const lead=leadFor(i,s.mode==='career'?roleLeadBonus(s.life):0);if(!lead)return;if(file){file.evidence=lead.evidence;file.status=lead.found?'Розыск: есть зацепка':'Розыск';file.outcome='Подозреваемый скрылся до задержания';}
 log(s,`Дело №${i.id}: подозреваемый скрылся, открыт розыск${lead.evidence?` (улики: ${lead.evidence})`:''}.`);
 if(!lead.found||(s.followUps??[]).length>=12)return;if(!Array.isArray(s.followUps))s.followUps=[];const n=NODES[Math.floor(leadHash(i.id,3)*NODES.length)];
 s.followUps.push({at:s.time+lead.delay,variant:'suspect-found',x:n.x,y:n.y,from:i.id,reason:`по делу №${i.id} замечен подозреваемый.`});}

// Radio exchange (templates, deterministic wording).
const lower=x=>x?x[0].toLocaleLowerCase('ru')+x.slice(1):x;
function radio(s,kind,u,i,from=callsign(u)){pushRadio(s,from,radioText(kind,i?.id??0,u?.id??0,callsign(u),i?{call:lower(callName(i)),place:districtName(districtOf(i),'город')}:{}));}

// 0.7.0 step 3: case records of the current shift (newest first, bounded).
function recordCase(s,i,success,outcome){if(!Array.isArray(s.cases))s.cases=[];const option=TYPES[i.type].options.find(o=>o[1]===i.decision);const custody=success?custodyDecision(i):null;
 s.cases.unshift({id:i.id,name:callName(i),district:districtOf(i),time:s.time,success,decision:option?option[0]:null,custody,medical:i.medical==='treated',rescue:i.rescue==='done',lead:i.variant==='suspect-found',...(success&&talkProtocol(i,custody)?{protocol:talkProtocol(i,custody)}:{}),...(i.talk?.choices?.length?{talk:i.talk.choices.map(c=>c.line).filter(Boolean).slice(0,3)}:{}),repeatOf:i.followUp?.from??null,outcome:String(outcome??'').slice(0,160),status:!success?'Не раскрыто':custody==='arrest'?'Задержанный в пути в участок':custody==='warn'?'Отпущены с предупреждением':'Закрыто на месте'});
 s.cases=s.cases.slice(0,CASE_LIMIT);}
function validCases(s){if(s.cases===undefined)return true;const str=(x,n)=>typeof x==='string'&&x.length<=n;
 return Array.isArray(s.cases)&&s.cases.length<=CASE_LIMIT&&s.cases.every(c=>Number.isInteger(c.id)&&str(c.name,160)&&str(c.district,40)&&Number.isFinite(c.time)&&typeof c.success==='boolean'&&(c.decision===null||str(c.decision,160))&&[null,'arrest','warn'].includes(c.custody)&&typeof c.medical==='boolean'&&(c.rescue===undefined||typeof c.rescue==='boolean')&&(c.lead===undefined||typeof c.lead==='boolean')&&(c.protocol===undefined||str(c.protocol,160))&&(c.fromShift===undefined||Number.isInteger(c.fromShift)&&c.fromShift>=1&&c.fromShift<=s.shift)&&(c.evidence===undefined||c.evidence===null||str(c.evidence,80))&&(c.repeatOf===null||Number.isInteger(c.repeatOf))&&str(c.outcome,160)&&str(c.status,60));}

// R13 patrol work between calls (patrolwork.js). Roster campaigns only.
function taskPlace(u,id,district=null){const place=TASKS[id].place;if(place==='station')return HQ;const list=placeNodes(NODES,place,byId('centre')).filter(p=>district?districtOf(p)===district:u.zone==='all'||!p.sector||p.sector===u.zone);const pool=list.length?list:NODES;return pool.reduce((b,p)=>Math.hypot(p.x-u.x,p.y-u.y)<Math.hypot(b.x-u.x,b.y-u.y)?p:b,pool[0]);}
function startTask(s,u,id,auto=false,extra=null){if(!TASKS[id])return false;const fast=id==='breath-check'&&has(s,'breath'),c=extra?.caseId?s.life?.cases?.find(x=>x.id===extra.caseId):null;u.task={id,phase:'moving',left:taskTicks(id,fast),start:s.time,auto,...(c?{caseId:c.id}:{})};u.status='proactive';routeTo(u,taskPlace(u,id,c?.district));
 if(c){log(s,`${u.name}: дело «${CASE_KINDS[c.kind].title}» — ${TASKS[id].short}.`);pushRadio(s,callsign(u),`Работаем по делу: ${TASKS[id].short}.`);return true;}
 log(s,`${u.name}: ${auto?'вызовов нет — ':''}${TASKS[id].short}.`);pushRadio(s,callsign(u),`Свободны, встаём на ${TASKS[id].short}.`);u.tasksToday=(u.tasksToday??0)+1;return true;}
function stopTask(s,u,why){const t=u.task;delete u.task;u.status='patrol';if(!t)return;recordTask(s,u,t,null);log(s,`${u.name}: ${TASKS[t.id].short} прерван — ${why==='order'?'приказ дежурного':why==='shift'?'конец смены':why==='fatigue'?'экипажу нужен отдых':'срочный вызов'}.`);}
function recordTask(s,u,t,result){if(!Array.isArray(s.tasksDone))s.tasksDone=[];s.tasksDone.unshift({task:t.id,unit:u.id,time:s.time,district:districtOf(u),done:!!result,found:result?result.found:0,text:result?result.text:'прервано'});if(s.tasksDone.length>TASK_RULES.doneLimit)s.tasksDone.length=TASK_RULES.doneLimit;}
function tickTask(s,u,dt){const t=u.task;if(!t){u.status='patrol';return false;}
 if(s.time>=s.shiftLength-ROUTINE.reports){stopTask(s,u,'shift');return false;}
 if(u.auto&&crewNeedsRest(s,u)){stopTask(s,u,'fatigue');return false;}
 if(u.auto&&!isDetective(s,u)&&s.incidents.some(i=>i.state==='waiting'&&(u.cross||u.zone==='all'||zone(i)===u.zone)&&((i.age??0)>TASK_RULES.waitBeforeInterrupt||!s.units.some(o=>o!==u&&o.auto&&['patrol','idle'].includes(o.status)&&o.incident==null&&(o.cross||o.zone==='all'||zone(i)===o.zone))))){stopTask(s,u,'call');return false;}
 if(t.phase==='moving'){if(u.route.length)return true;t.phase='working';log(s,`${u.name}: на месте, ${TASKS[t.id].short}.`);return true;}
 t.left=Math.max(0,t.left-dt);if(t.left>0)return true;
 if(TASKS[t.id].case){caseStepDone(s,u,t);return false;}
 const result=taskResult(t.id,{seed:s.seed,shift:s.shift,unit:u.id,start:t.start,busy:loadNow(s)});if(s.mode==='career'&&u.id===1&&ROLES[s.life?.role]?.raid&&['breath-check','speed-check'].includes(t.id)){result.found=Math.round(result.found*ROLES[s.life.role].raid);if(t.id==='speed-check'){result.checked=result.found;result.text=`протоколов за превышение: ${result.found}`;}else result.text=`проверено ${result.checked} водителей, пьяных за рулём: ${result.found}`;}/* Release C2: road police find more on raids */const r=taskReward(t.id,result),d=districtOf(u);if(t.id==='drill')for(const o of crewOfficers(s,u))o.skill=Math.min(.95,Math.round(((o.skill??.8)+.004)*1000)/1000);/* Release H: drills train the crew */
 addTrust(s,r.trust);if(s.districts?.[d]!==undefined)addDistrictTrust(s,d,r.district);if(u.id===1||s.mode==='chief'){s.xp+=xpGain(s,r.xp);s.rank=rankOf(s);}
 if(!Array.isArray(s.prevention))s.prevention=[];s.prevention=s.prevention.filter(p=>p.until>s.time);s.prevention.push({task:t.id,until:s.time+TASK_RULES.prevention});if(s.prevention.length>TASK_RULES.preventionLimit)s.prevention.splice(0,s.prevention.length-TASK_RULES.preventionLimit);
 delete u.task;u.status='patrol';recordTask(s,u,t,result);if(t.id==='breath-check')pushNews(s,checkpointNews(result.found,s.seed+s.shift*31+u.id));log(s,`${u.name}: ${TASKS[t.id].label} — ${result.text}. Доверие района +${r.district}.`);pushRadio(s,callsign(u),`Закончили: ${result.text}. Свободны.`);return false;}
function autoTaskDue(s,u){const f=FOCUS[s.shiftFocus??'balanced']?.task??1;if(!f)return false;return isScheduled(s)&&u.auto&&u.incident==null&&loadNow(s)<TASK_RULES.autoMaxLoad&&!s.incidents.some(i=>!['resolved','missed'].includes(i.state)&&!i.units.length)&&!u.foot&&!u.transport&&(u.tasksToday??0)<TASK_RULES.autoPerShift&&s.time<s.shiftLength-ROUTINE.reports-ticks60()&&(autoTaskRoll(s.seed,s.shift,u.id,s.time)||f>1&&autoTaskRoll(s.seed,s.shift,u.id+50,s.time))&&!crewNeedsRest(s,u);}
const ticks60=()=>60*60/WORLD_SECONDS_PER_TICK_SECOND;
export function startPatrolTask(s,uid,id){const u=s.units.find(x=>x.id===uid);if(!u||s.ended||!isScheduled(s))return {ok:false,message:'Доступно в кампаниях с графиком смен.'};if(!canControl(s,u))return {ok:false,message:'Этим экипажем управлять нельзя.'};if(!TASKS[id])return {ok:false,message:'Неизвестное задание.'};if(!['patrol','idle'].includes(u.status)||u.incident!=null)return {ok:false,message:'Экипаж занят.'};if(s.time>=s.shiftLength-ROUTINE.reports)return {ok:false,message:'Смена заканчивается.'};startTask(s,u,id,false);return {ok:true,message:TASKS[id].label};}

// R14 service history, month results and awards (history.js). Roster campaigns only.
function serviceHistory(s,n){const done=(s.tasksDone??[]).filter(t=>t.done),drunk=done.filter(t=>t.task==='breath-check').reduce((k,t)=>k+(Number.isInteger(t.found)?t.found:0),0);
 n.shiftLog=[...(s.shiftLog??[]).map(r=>({...r})),shiftRecord(s,{tasks:done.length,drunk})].slice(-HISTORY_LIMIT);
 const st={...emptyStats(),...(s.stats??{})},founded=(n.complaints??[]).filter(c=>c.status==='обоснована').length;st.calls+=s.resolved;st.drunk+=drunk;st.founded+=founded;st.monthFounded+=founded;
 n.awards=(s.awards??[]).map(a=>({...a}));const was=monthOf(s.shift-1),now=monthOf(n.shift-1);let summary=null;
 if(s.goals)n.goals=JSON.parse(JSON.stringify(s.goals));let goals=null,yearCtx=null;st.yearResolved=(st.yearResolved??0)+s.resolved;st.yearMissed=(st.yearMissed??0)+s.missed;const ownFounded=n.mode==='career'?(n.complaints??[]).filter(c=>c.unit===1&&c.status==='обоснована').length:founded;st.ownFounded=(st.ownFounded??0)+ownFounded;st.yearFounded=(st.yearFounded??0)+ownFounded;/* a career officer answers for the own crew */
 if(now.key!==was.key){summary=monthSummary(n.shiftLog,was.key,was.label);if(n.mode==='career'&&n.life){const living=livingCost(n.life,LIVING.monthly)+(owns(n.life,'car')?PURCHASES.car.monthly:0);n.life.money-=living;log(n,`${owns(n.life,'apartment')?'Ипотека':'Квартира'}, счета и продукты${owns(n.life,'car')?', машина':''} за ${was.label}: −${living} €. На счёте ${Math.round(n.life.money)} €.`);if(n.life.money<0){n.life.stress=Math.min(100,n.life.stress+LIVING.debtStress);log(n,'Денег не хватает: долги добавляют стресса.');}}if(n.goals?.month===was.key)goals=closeGoals(n,st);delete n.goals;yearCtx=career2Month(s,n,st,was,now,goals);st.cleanMonths=st.monthFounded===0?st.cleanMonths+1:0;st.monthFounded=0;}
 n.stats=st;const fresh=newAwards({s:n,stats:st,summary,year:yearCtx},n.awards);
 for(const a of fresh){n.awards.push({id:a.id,shift:s.shift,...(summary?{month:summary.label}:{})});if(n.mode==='career')n.xp+=AWARD_REWARD.xp;else n.budget+=AWARD_REWARD.budget;log(n,`Награда: ${a.label}. ${a.about}`);pushNews(n,awardNews(a.label,n.shift));}
 if(n.awards.length>AWARD_LIMIT)n.awards.splice(0,n.awards.length-AWARD_LIMIT);n.rank=rankOf(n);
 if(summary){n.monthReport={...summary,shift:n.shift,awards:fresh.map(a=>a.id),...(goals?{goals}:{})};log(n,`Итоги месяца (${summary.label}): смен ${summary.shifts}, закрыто ${summary.resolved}, сорвано ${summary.missed} — ${summary.rate}% успеха.`);}}

// R15 trust balance (Claude, 11.10.2026). With 25–35 calls in a 12-hour roster shift, +2 per call kept
// public trust pinned at 100%. In roster campaigns a good call now adds less the higher trust already
// is, failures cost in full, and between shifts opinion drifts back toward a neutral 70%. Flawless
// service holds trust in the low 90s, a missed call or two per shift brings it down to the 80s.
// Legacy campaigns keep the old +2/−4 rule.
export const TRUST_BALANCE=Object.freeze({gain:.25,span:30,neutral:70,drift:.2,districtGain:.5,districtDrift:.1});
function addTrust(s,d){if(!Number.isFinite(d)||!d)return;if(isScheduled(s)&&d>0)d*=TRUST_BALANCE.gain*Math.max(0,100-s.trust)/TRUST_BALANCE.span;s.trust=Math.max(0,Math.min(100,s.trust+d));}
function trustDrift(n){n.trust=Math.round((n.trust+(TRUST_BALANCE.neutral-n.trust)*TRUST_BALANCE.drift)*10)/10;if(n.districts)for(const k of Object.keys(n.districts))n.districts[k]=Math.round((n.districts[k]+(TRUST_BALANCE.neutral-n.districts[k])*TRUST_BALANCE.districtDrift)*10)/10;}
function addDistrictTrust(s,id,d){if(!s.districts||s.districts[id]===undefined||!Number.isFinite(d)||!d)return;const v=s.districts[id];if(isScheduled(s)&&d>0)d*=TRUST_BALANCE.districtGain*Math.max(0,100-v)/TRUST_BALANCE.span;s.districts[id]=Math.max(0,Math.min(100,v+d));}

// R16 partner (partner.js): bond after each shift, end of probation with the mentor, transfer requests.
function partnerBetweenShifts(s,n){if(n.mode!=='career'||!n.life)return;const p=ensurePartner(n.life),founded=(n.complaints??[]).filter(c=>c.unit===1&&c.status==='обоснована').length;
 const before=p.bond;bondAfterShift(p,{calls:s.myCalls??0,missed:s.missed,founded});
 if(p.trait==='mentor'&&n.rank>=1&&s.shift>=BOND.probation)switchPartner(n,nextPartner(n.seed,n.shift,p.name),`Стажировка окончена. ${p.name}: «Дальше сам. Удачи на улицах». Новый напарник`);
 else if(p.low>=2){n.life.stress=Math.min(100,n.life.stress+5);switchPartner(n,nextPartner(n.seed,n.shift,p.name),`${p.name} попросил(а) перевода в другой экипаж. Новый напарник`);}
 else if(Math.round(p.bond)!==Math.round(before))log(n,`Напарник ${p.name}: связь ${Math.round(p.bond)}% (${p.bond>before?'+':''}${Math.round(p.bond-before)}).`);}
function switchPartner(n,np,text){const u=n.units.find(x=>x.id===1),id=u?.officerIds?.[1],o=n.officers.find(x=>x.id===id);if(o)o.name=np.name;if(u&&u.people.length>1)u.people[1]=np.name;
 n.life.partner={name:np.name,trait:np.trait,bond:BOND.newPartner,since:n.shift,low:0};log(n,`${text}: ${np.name} — ${TRAITS[np.trait].label.toLowerCase()}. ${TRAITS[np.trait].about}`);}

// R19 monthly plan (goals.js): evaluated when the month closes, before the month counters reset.
function closeGoals(n,st){const view={shiftLog:n.shiftLog,stats:st,districts:n.districts,trust:n.trust};let met=0;
 const res=n.goals.list.map(g=>{const value=goalValue(view,g,n.goals.month,{live:false}),ok=goalMet(g,value);if(ok){met++;if(n.mode==='chief')n.budget+=GOAL_REWARD.budget;else{n.xp+=GOAL_REWARD.xp;if(n.life)n.life.money+=GOAL_REWARD.money;}}return {id:g.id,label:goalLabel(g),target:g.target,value,met:ok};});
 log(n,`План на ${n.goals.label}: выполнено ${met} из ${res.length}${met?n.mode==='chief'?` — премия отделению ${met*GOAL_REWARD.budget}`:` — премия ${met*GOAL_REWARD.money} € и +${met*GOAL_REWARD.xp} опыта`:''}.`);
 if(met===res.length)pushNews(n,{title:`Полиция Меридиана выполнила план на ${n.goals.label}`,tone:'good',media:'Вестник Меридиана'});return res;}

// R25 criminal police (detective.js): a finished case step, case file between shifts, manual steps.
function caseStepDone(s,u,t){const c=s.life?.cases?.find(x=>x.id===t.caseId&&x.status==='open');delete u.task;u.status='patrol';if(!c)return;const k=CASE_KINDS[c.kind],where=districtName(c.district,'городе');
 if(t.id==='case-arrest'){c.steps++;if(arrestSucceeds(c)){c.status='solved';s.xp+=DETECTIVE.solveXp;s.rank=rankOf(s);addTrust(s,DETECTIVE.solveTrust);addDistrictTrust(s,c.district,DETECTIVE.solveDistrict);recordTask(s,u,t,{found:1,text:`дело раскрыто: ${k.title}`});
   log(s,`Дело раскрыто: ${k.title} (${where}). Подозреваемый задержан, материалы — прокурору.`);pushRadio(s,callsign(u),'Подозреваемый задержан, дело закрываем.');pushNews(s,{title:`Криминальная полиция раскрыла дело: ${k.title.toLowerCase()} (${where})`,tone:'good',media:'Вестник Меридиана'});}
  else{c.evidence=Math.max(0,c.evidence+DETECTIVE.failedArrest);recordTask(s,u,t,{found:0,text:'подозреваемый скрылся'});log(s,`Дело «${k.title}»: подозреваемый скрылся при задержании — улик стало меньше (${Math.round(c.evidence)}%).`);pushRadio(s,callsign(u),'Подозреваемого на адресе нет, ушёл.');}return;}
 if(t.id==='case-forensics'){c.labSent=true;c.steps++;recordTask(s,u,t,{found:0,text:`${k.title}: улики в лаборатории`});log(s,`Дело «${k.title}»: улики переданы на экспертизу, результат — к следующей смене.`);return;}
 if(t.id==='case-interview')c.interviewed=true;
 const gain=stepEvidence(c,t.id);c.evidence=Math.min(100,c.evidence+gain);c.steps++;recordTask(s,u,t,{found:gain,text:`${k.title}: улик +${gain}%`});
 log(s,`Дело «${k.title}»: ${TASKS[t.id].label.toLowerCase()} — улик +${gain}% (всего ${Math.round(c.evidence)}% из ${k.need}%).${arrestReady(c)?' Улик достаточно — можно задерживать.':''}`);}
function detectiveBetweenShifts(n){const life=n.life;if(n.mode!=='career'||!life||life.role!=='detective')return;
 for(const c of openCases(life))if(c.labSent&&!c.lab){c.lab=labResult(c);c.evidence=Math.min(100,c.evidence+c.lab);log(n,`Экспертиза по делу «${CASE_KINDS[c.kind].title}»: улик +${c.lab}% (всего ${Math.round(c.evidence)}%).`);}
 for(const c of openCases(life))if(n.shift>c.deadline){c.status='cold';addTrust(n,DETECTIVE.coldTrust);log(n,`Дело «${CASE_KINDS[c.kind].title}» ушло в архив нераскрытым.`);pushNews(n,{title:`Полиция так и не нашла виновных: ${CASE_KINDS[c.kind].title.toLowerCase()} (${districtName(c.district,'город')})`,tone:'bad',media:'Меридиан Online'});}
 const made=newCases(life,n.seed,n.shift);if(made.length)log(n,`Новые дела: ${made.map(c=>`${CASE_KINDS[c.kind].title} (${districtName(c.district,'город')})`).join('; ')}.`);}
export function startCaseStep(s,caseId,step){const u=s.units.find(x=>x.id===1),c=s.life?.cases?.find(x=>x.id===caseId&&x.status==='open');if(!u||!isDetective(s,u)||s.ended)return {ok:false,message:'Дела ведёт следователь.'};if(!c)return {ok:false,message:'Дело закрыто.'};if(!TASKS[step]?.case)return {ok:false,message:'Неизвестное действие.'};
 if(step==='case-interview'&&(c.evidence<INTERVIEW_NEED||c.interviewed))return {ok:false,message:c.interviewed?'Подозреваемый уже допрошен.':`Для допроса нужно ${INTERVIEW_NEED}% сведений.`};if(step==='case-forensics'&&c.labSent)return {ok:false,message:'Улики уже в лаборатории.'};
 if(step==='case-arrest'&&!arrestReady(c))return {ok:false,message:`Мало улик: ${Math.round(c.evidence)}% из ${CASE_KINDS[c.kind].need}%.`};if(!['patrol','idle'].includes(u.status)||u.incident!=null)return {ok:false,message:'Экипаж занят.'};
 if(s.time>=s.shiftLength-ROUTINE.reports)return {ok:false,message:'Смена заканчивается.'};startTask(s,u,step,false,{caseId});return {ok:true,message:TASKS[step].label};}

// Release B: scene dialogues (dialogues.js). Stage 1 is the approach (chosen on arrival), stage 2 the
// inquiry, stage 3 the decision. A manual crew answers in the call card; an automatic crew — or an
// unanswered stage once the work is far enough — follows the department's standing order.
const talkStyle=s=>s.mode==='chief'?(s.policy??'balanced'):'balanced';
function talkStep(s,u,i,optionId,manual=false){const st=currentStage(i);const r=optionId?applyChoice(i,optionId):null;if(!r)return null;const sc=i.scene;if(sc&&r.tension)sc.tension=Math.max(0,Math.min(100,sc.tension+r.tension));
 if(manual&&i.talk.sets.custody&&canChooseCustody(i.variant))i.custodyChoice=i.talk.sets.custody;/* automatic crews keep the standing order (policy.js) */if(i.talk.sets.ambulance&&!i.medical)callAmbulance(s,i);
 if(r.line)log(s,`${u?.name??'Экипаж'}: ${r.line}`);if(sc)sc.reason=r.line||sc.reason;
 const bond=r.option.fx?.bond??0,pn=s.mode==='career'&&u?.id===1?s.life?.partner?.name?.split(' ')[0]:null;if(pn&&bond)log(s,bond<0?`${pn}: «${PARTNER_REMARKS.bad[i.id%PARTNER_REMARKS.bad.length]}»`:`${pn}: «${PARTNER_REMARKS.good[i.id%PARTNER_REMARKS.good.length]}»`);
 if(u&&injuryRolled(i,r.option.fx?.risk)){i.talk.injury=true;if(s.mode==='career'&&u.id===1&&s.life){s.life.stress=Math.min(100,s.life.stress+10);if(s.life.partner)s.life.partner.bond=Math.max(0,s.life.partner.bond-3);}for(const o of crewOfficers(s,u)){o.fatigue=Math.min(100,o.fatigue+25);if(isScheduled(s)){ensureOfficer(o);o.stress=Math.min(100,(o.stress??10)+12);}}
  log(s,`${u.name}: при задержании сотрудник получил ушиб — продолжает работу, но устал сильнее.`);pushRadio(s,callsign(u),'У нас сотрудник с ушибом, помощь не нужна, работаем.');}
 return r;}
export function chooseTalk(s,uid,optionId){const u=s.units.find(x=>x.id===uid),i=s.incidents.find(x=>x.id===u?.incident);if(!u||!i||s.ended||!canControl(s,u)||!crewAtScene(u)||!['decision','working'].includes(u.status))return {ok:false,message:'Сейчас нельзя.'};
 if(!isScheduled(s)||!ensureTalk(i))return {ok:false,message:'Диалоги на месте — в кампаниях по графику.'};const st=currentStage(i),o=st?.options.find(x=>x.id===optionId);if(!o)return {ok:false,message:'Этот шаг уже пройден.'};if(!optionOpen(i,o))return {ok:false,message:`Мало сведений: нужно ${o.needs.evidence}%, сейчас ${Math.round(i.talk.evidence)}%.`};
 if(i.talk.stage===0){const choice=i.type===5?autoChoice(i):o.maps&&TYPES[i.type].options.some(x=>x[1]===o.maps)?o.maps:TYPES[i.type].options[0][1];decide(s,uid,choice);}/* vehicle stops: a fleeing driver is pursued whatever the approach */
 const r=talkStep(s,u,i,optionId,true);return {ok:!!r,message:r?.line||o.label};}
// Unanswered stages are taken automatically once the work has gone far enough (never blocks the call).
function tickTalk(s,i,working){if(!i.talk||talkDone(i)||!working.length)return;const u=working[0],p=i.progress/TYPES[i.type].duration,stage=i.talk.stage,auto=u.auto;
 if(stage===0)return;const due=stage===1?(auto?.15:.4):(auto?.6:.8);if(p>=due)talkStep(s,u,i,autoOption(i,talkStyle(s)));}
function finishTalk(s,i){let guard=0;while(!talkDone(i)&&guard++<3)talkStep(s,s.units.find(x=>i.units.includes(x.id)),i,autoOption(i,talkStyle(s)));const t=i.talk;
 if(t.trust)addTrust(s,t.trust);if(t.bond&&s.mode==='career'&&i.units.includes(1)&&s.life?.partner)s.life.partner.bond=Math.max(0,Math.min(100,s.life.partner.bond+t.bond));}

// The scene's protocol text is used when it matches what really happened (custody), or when the call has no custody step.
const talkProtocol=(i,custody)=>i.talk?.sets?.protocol&&(!canChooseCustody(i.variant)||i.talk.sets.custody===undefined||i.talk.sets.custody===(custody??'warn'))?i.talk.sets.protocol:protocolFor(i.variant,custody);

// Release B: the partner comments on choices that change the bond (partner.js).
const PARTNER_REMARKS=Object.freeze({bad:['Так нельзя было, проверь в следующий раз.','Рискованно. Я за тебя переживал.','Мы же по инструкции работаем, давай без самодеятельности.'],good:['Правильно сделал.','Вот так и надо.','Хорошо разрулили.']});

// Release C (career2.js): shift focus, half-year review, life outside work, city council, morale,
// candidate market, officer of the year.
const focusTask=(s,id)=>{const f=FOCUS[s.shiftFocus??'balanced'];if(f?.prefer==='foot-patrol')return 'foot-patrol';if(f?.prefer==='traffic')return id==='foot-patrol'?'speed-check':id;return id;};
export function setShiftFocus(s,id){if(!canSetFocus(s)||s.ended||!Object.hasOwn(FOCUS,id))return {ok:false,message:'Задачу смены ставит старший смены (звание «Сержант») или начальник.'};if((s.shiftFocus??'balanced')===id)return {ok:true,message:FOCUS[id].label};
 s.shiftFocus=id;if(id==='traffic'){if(!Array.isArray(s.prevention))s.prevention=[];for(const task of ['breath-check','speed-check'])s.prevention.push({task,until:s.shiftLength});if(s.prevention.length>TASK_RULES.preventionLimit)s.prevention.splice(0,s.prevention.length-TASK_RULES.preventionLimit);}
 log(s,`Задача смены: ${FOCUS[id].label}. ${FOCUS[id].about}`);return {ok:true,message:FOCUS[id].label};}
function career2Month(s,n,st,was,now,goals){let year=null;
 if(now.key%12===0){const r=st.yearResolved??0,m=st.yearMissed??0;year={rate:r+m?Math.round(r/(r+m)*100):100,founded:st.yearFounded??0,resolved:r,label:String(Math.floor(was.key/12))};log(n,`Итоги ${year.label} года: закрыто ${r}, сорвано ${m} (${year.rate}% успеха), обоснованных жалоб ${year.founded}.`);st.yearResolved=0;st.yearMissed=0;st.yearFounded=0;
  if(n.mode==='chief'){const keep=reserveLimit(shiftCost(n)),back=Math.floor(n.budget-keep);if(back>0){transact(n,-back,'council','Неизрасходованный остаток года возвращён в казну города');log(n,`Мэрия: остаток бюджета ${back} возвращён в казну, резерв отделения ${keep}.`);}}}
 if(n.mode==='career'&&n.life){const l=n.life;l.months=(l.months??0)+1;if(l.months%ATTEST.every===0){const from=now.key-ATTEST.every,recs=(n.shiftLog??[]).filter(r=>r.month>=from&&r.month<now.key),res=recs.reduce((k,r)=>k+r.resolved,0),mis=recs.reduce((k,r)=>k+r.missed,0),fnd=Math.max(0,(st.ownFounded??0)-(l.attFounded??0)),aw=(n.awards??[]).filter(a=>a.shift>(l.attShift??0)).length;
  const a=attestation({resolved:res,missed:mis,founded:fnd,coursesOk:mandatoryOk(l,n.shift),bond:l.partner?.bond??50,awards:aw}),g=ATTEST.grades[a.grade];n.xp+=g.xp;l.money+=g.money;if(g.stress)l.stress=Math.min(100,l.stress+g.stress);
  l.attestations=[...(l.attestations??[]),{grade:a.grade,score:a.score,label:was.label}].slice(-ATTEST.limit);l.attFounded=st.ownFounded??0;l.attShift=n.shift;
  log(n,`Аттестация (${was.label}): оценка ${a.grade} — ${g.label}. Успешных вызовов ${a.rate}%, баллов ${a.score}.${g.xp?` +${g.xp} опыта, премия ${g.money} €.`:''}`);if(a.grade==='A')pushNews(n,{title:'Патрульный отделения Меридиана получил высшую оценку на аттестации',tone:'good',media:'Вестник Меридиана'});}}
 if(n.mode==='chief'){const p=s.promise;if(p&&p.month===was.key){const missed=(n.shiftLog??[]).filter(r=>r.month===was.key).reduce((k,r)=>k+r.missed,0);if(missed<=p.limit){n.budget+=COUNCIL.promise.reward;log(n,`Мэрия: обещание выполнено (${missed} срывов при лимите ${p.limit}) — +${COUNCIL.promise.reward} к бюджету.`);}else{addTrust(n,COUNCIL.promise.penalty);log(n,`Мэрия: обещание не выполнено (${missed} срывов при лимите ${p.limit}) — доверие ${COUNCIL.promise.penalty}.`);}}delete n.promise;
  if(s.council?.choice==='pending'){n.budget+=COUNCIL.report.money;log(n,'Мэрия: встреча прошла без начальника — отчёт принят по умолчанию.');}n.council={month:now.key,label:now.label,choice:'pending'};
  const taken=new Set([...n.officers.map(o=>o.name),...(n.candidates??[]).map(c=>c.name)]);n.candidates=[...(n.candidates??[]),...newCandidates(n.seed,now.key,taken)].slice(-6);log(n,'Отдел кадров: новые кандидаты на службу.');}
 return year;}
export function chooseCouncil(s,id){const c=s.council;if(s.mode!=='chief'||!c||c.choice!=='pending'||!Object.hasOwn(COUNCIL,id)||s.ended)return {ok:false,message:'Встречи с мэрией сейчас нет.'};const k=COUNCIL[id];c.choice=id;
 if(id==='ask'){if(s.trust>=k.high){transact(s,k.big,'council','Мэрия выделила дополнительные средства');log(s,`Мэрия: доверие ${Math.round(s.trust)}% — выделено ${k.big}.`);}else{transact(s,k.small,'council','Мэрия: небольшая добавка');addTrust(s,-1);log(s,`Мэрия: при доверии ${Math.round(s.trust)}% денег мало — ${k.small}, мэр недоволен.`);}}
 else if(id==='promise'){const lim=Math.max(2,Math.floor((s.goals?.list?.find(g=>g.id==='missed')?.target??8)/2));s.promise={month:c.month,limit:lim};log(s,`Мэрия: вы пообещали не больше ${lim} сорванных вызовов за ${c.label}.`);}
 else{transact(s,k.money,'council','Отчёт перед мэрией');addTrust(s,k.trust);log(s,'Мэрия: спокойная встреча, отчёт принят.');}
 return {ok:true,message:k.label};}
export function chooseLifeEvent(s,optionId){const l=s.life,e=l?.event,ev=e&&LIFE_EVENTS[e.id];if(!ev)return {ok:false,message:'Нет ситуации.'};const o=ev.options.find(x=>x.id===optionId);if(!o)return {ok:false,message:'Нет такого варианта.'};applyLifeFx(s,l,o.fx,ev.title);l.event=null;return {ok:true,message:o.label};}
function applyLifeFx(s,l,fx,title){const c=v=>Math.max(0,Math.min(100,v));if(fx.money)l.money+=fx.money;if(fx.stress)l.stress=c(l.stress+fx.stress);if(fx.sleep)l.sleepDebt=c(l.sleepDebt+fx.sleep);if(fx.bond&&l.partner)l.partner.bond=c(l.partner.bond+fx.bond);if(fx.xp){s.xp+=fx.xp;s.rank=rankOf(s);}
 if(fx.health){if((l.healthDays??0)>0)l.healthDays--;else l.money-=100;}if(fx.course&&LIFE_COURSES[fx.course]){const d=(l.progress?.[fx.course]??0)+1;l.progress=l.progress??{};if(d>=LIFE_COURSES[fx.course].days){l.courses[fx.course]=s.shift;delete l.progress[fx.course];}else l.progress[fx.course]=d;}
 if(fx.integrity)l.integrity=(l.integrity??0)+1;log(s,`Жизнь: ${title} — ${Object.entries(fx).filter(([k])=>['money','stress'].includes(k)).map(([k,v])=>k==='money'?`${v>0?'+':''}${v} €`:`стресс ${v>0?'+':''}${v}`).join(', ')||'решено'}.`);}
function career2Shift(s,n){if(s.lastQuit!==undefined)n.lastQuit=s.lastQuit;if(isScheduled(s)&&s.shiftFocus)n.shiftFocus=s.shiftFocus;if(s.council)n.council=n.council?.month>s.council.month?n.council:{...s.council};if(s.promise)n.promise={...s.promise};
 if(n.mode==='career'&&n.life){const l=n.life;if(l.event){const ev=LIFE_EVENTS[l.event.id];if(ev)applyLifeFx(n,l,ev.options[ev.options.length>2?2:0].fx,ev.title);l.event=null;}/* unanswered: the safe default */
  if(l.integrity){if(lifeEventFor(n.seed+77,n.shift)!==null||n.shift%3===0){n.xp=Math.max(0,n.xp+INTEGRITY.xp);l.stress=Math.min(100,l.stress+INTEGRITY.stress);addTrust(n,INTEGRITY.trust);log(n,'Внутренний контроль: выявлено нарушение служебной дисциплины — выговор, опыт −150.');pushNews(n,{title:'Проверка выявила нарушение дисциплины полицейским',tone:'bad',media:'Меридиан Online'});l.integrity=0;}}
  const id0=lifeEventFor(n.seed,n.shift),id=id0==='car-broke'&&!owns(l,'car')?null:id0;/* Release C2: no car, no broken car */if(id){l.event={id,shift:n.shift};log(n,`Жизнь: ${LIFE_EVENTS[id].title}. Решите до конца смены (инструктаж или личное дело).`);}}
 if(n.mode==='chief'){n.morale=morale(n);if(n.morale<MORALE.quit){const solo=new Set(n.units.filter(u=>u.officerIds.length===1).flatMap(u=>u.officerIds));const o=n.officers.filter(x=>(x.stress??0)>MORALE.quitStress&&!solo.has(x.id)).sort((a,b)=>(b.stress??0)-(a.stress??0))[0];
  if(o&&n.shift-(n.lastQuit??-99)>=MORALE.quitGap){n.lastQuit=n.shift;n.officers=n.officers.filter(x=>x!==o);for(const u of n.units){const k=u.officerIds.indexOf(o.id);if(k>=0){u.officerIds.splice(k,1);u.people.splice(k,1);syncCrew(n,u);}}log(n,`Кадры: ${o.name} уволился — выгорание, моральный дух отделения ${n.morale}%.`);pushNews(n,{title:'Из полиции Меридиана уходят люди: «устали работать за двоих»',tone:'bad',media:'Портал «Наш район»'});n.morale=morale(n);}}}}
