import data from './city-data.js';

// Runtime coverage contract. The OSM snapshot owns its geographic bounds;
// every consumer derives world coordinates from the same immutable metadata.
export const GEO_BOUNDS=Object.freeze({west:data.bbox[0],south:data.bbox[1],east:data.bbox[2],north:data.bbox[3]});
export const WORLD_SCALE=Object.freeze({x:35,y:65});
export const WORLD_BOUNDS=Object.freeze({
 minX:0,minY:0,
 maxX:Number(((GEO_BOUNDS.east-GEO_BOUNDS.west)*WORLD_SCALE.x).toFixed(6)),
 maxY:Number(((GEO_BOUNDS.north-GEO_BOUNDS.south)*WORLD_SCALE.y).toFixed(6))
});
export const VIEW_PADDING=Object.freeze({x:.375,y:.45});
export const projectGeo=(lon,lat)=>({x:(lon-GEO_BOUNDS.west)*WORLD_SCALE.x,y:(GEO_BOUNDS.north-lat)*WORLD_SCALE.y});
export const unprojectWorld=(x,y)=>({lon:GEO_BOUNDS.west+x/WORLD_SCALE.x,lat:GEO_BOUNDS.north-y/WORLD_SCALE.y});
export const containsWorldPoint=p=>Number.isFinite(p?.x)&&Number.isFinite(p?.y)&&p.x>=WORLD_BOUNDS.minX&&p.x<=WORLD_BOUNDS.maxX&&p.y>=WORLD_BOUNDS.minY&&p.y<=WORLD_BOUNDS.maxY;
export const coverageInfo=()=>({id:'parnu-core-2026-10',region:'Pärnumaa',place:'Pärnu',source:data.source,date:data.date,geo:{...GEO_BOUNDS},world:{...WORLD_BOUNDS},scale:{...WORLD_SCALE}});
