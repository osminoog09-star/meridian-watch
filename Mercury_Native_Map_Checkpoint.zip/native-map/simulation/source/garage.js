// 0.6.1 «Гараж» (Claude, 11.10.2026): fuel, wear, repair, trunk equipment and liveries.
// Pure rules + vehicle bookkeeping; sim.js drives it from the real distance a car covers.
// No rng(): every rule is deterministic, so campaign seeds keep their meaning.
// Realistic figures (owner request 11.10): fuel is kept in litres.
//   · Sedan (diesel, Octavia/Passat class): 55 l tank, ~7.8 l/100 km in town, ~0.8 l/h idling.
//   · SUV (Tiguan/RAV4 class): 70 l tank, ~10.8 l/100 km in town, ~1.2 l/h idling.
//   · Hard emergency driving costs ~30% more, a pursuit ~60% more. Police cars idle at scenes
//     (lights, radio, heating), so a stopped car with the crew on duty still burns fuel.
//   · Crews refuel at a filling station at a quarter tank (common fleet rule); a full tank
//     lasts ~600–700 km, i.e. several shifts. Diesel ~1.65 per litre.
//   · Wear (tyres, brakes, suspension): ~5000 km of normal patrol to 100%; urgent runs ×2,
//     pursuits ×5. From 70% the car is slower; at 100% it breaks down and is towed.
// Times are in world minutes (1 tick unit = 0.75 world minute); sim converts with toTicks().
import {WORLD_SECONDS_PER_TICK_SECOND} from './transport.js';
export const toTicks=minutes=>minutes*60/WORLD_SECONDS_PER_TICK_SECOND;
export const toMinutes=ticks=>ticks*WORLD_SECONDS_PER_TICK_SECOND/60;
export const CAR_SPECS=Object.freeze({
 sedan:Object.freeze({label:'Седан, дизель',tank:55,per100:7.8,idlePerHour:.8}),
 suv:Object.freeze({label:'Внедорожник, дизель',tank:70,per100:10.8,idlePerHour:1.2})
});
export const FUEL=Object.freeze({lowShare:.25,refuelMinutes:6,pricePerLitre:1.65,urgent:1.3,pursuit:1.6,canisterMinutes:25,canisterLitres:10});
export const WEAR=Object.freeze({perKm:.02,urgent:2,pursuit:5,slow:70,slowFactor:.9,broken:100,towMinutes:35});
export const REPAIR=Object.freeze({pricePerPercent:10,baseMinutes:30,minutesPerPercent:.9,shiftService:40});
export const SLOTS=Object.freeze({sedan:1,suv:2});
export const EXTRAS=Object.freeze({
 medkit:{label:'Аптечка',price:90,about:'Первая помощь до приезда скорой: ДТП, драка, человеку плохо — работа на 15% быстрее.',variants:['crash','street-fight','drunk-person'],bonus:1.15},
 breathalyzer:{label:'Алкотестер',price:70,about:'Быстрая проверка водителя и человека в опьянении — работа на 15% быстрее.',variants:['drunk-driver','drunk-person','vehicle-alert','no-licence'],bonus:1.15},
 extinguisher:{label:'Огнетушитель',price:80,about:'Помогает сдержать огонь до спасателей: пожар — работа на 25% быстрее.',variants:['fire-smoke'],bonus:1.25},
 cones:{label:'Конусы и жилеты',price:60,about:'Ограждение места на дороге: ДТП, животное, перекрытый проезд — на 10% быстрее.',variants:['crash','animal-road','blocked-exit'],bonus:1.1}
});
export const EXTRA_IDS=Object.freeze(Object.keys(EXTRAS));
// Ready liveries: body colour + stripe colour (model palette slot «stripe»).
export const LIVERIES=Object.freeze({
 white:{label:'Белая, синяя полоса',paint:'#e0e6df',stripe:'#34779d'},
 navy:{label:'Синяя, белая полоса',paint:'#6d8eaf',stripe:'#e0e6df'},
 black:{label:'Графитовая, серебро',paint:'#48535b',stripe:'#b8c2c8'},
 yellow:{label:'Жёлто-синяя, заметная',paint:'#e2cf4c',stripe:'#2d5fa8'},
 grey:{label:'Серая, без маркировки',paint:'#8a9399',stripe:'#8a9399'}
});
export const HISTORY_LIMIT=8;
const typeOf=v=>v?.type==='suv'?'suv':'sedan';
export const specOf=v=>CAR_SPECS[typeOf(v)];
export function ensureVehicle(v){if(!v)return v;if(!Number.isFinite(v.km))v.km=0;if(!Number.isFinite(v.fuel))v.fuel=specOf(v).tank;if(!Number.isFinite(v.litres))v.litres=0;if(!Number.isFinite(v.wear))v.wear=(v.id*7)%20;if(!Array.isArray(v.extras))v.extras=[];if(!Array.isArray(v.history))v.history=[];if(v.service===undefined)v.service=null;return v;}
// Read-only view with defaults (UI must not mutate the campaign while drawing).
export const vehicleView=v=>({...v,km:Number.isFinite(v?.km)?v.km:0,fuel:Number.isFinite(v?.fuel)?v.fuel:specOf(v).tank,litres:Number.isFinite(v?.litres)?v.litres:0,wear:Number.isFinite(v?.wear)?v.wear:((v?.id??0)*7)%20,extras:v?.extras??[],history:v?.history??[],service:v?.service??null});
export function addHistory(v,time,text){ensureVehicle(v);v.history.unshift({time,text:String(text).slice(0,120)});if(v.history.length>HISTORY_LIMIT)v.history.length=HISTORY_LIMIT;}
export const slotsOf=v=>SLOTS[typeOf(v)];
// Distance driven (km) and idling time (hours) this tick → litres and wear.
export function consume(v,km,{urgent=false,pursuit=false,idleHours=0}={}){ensureVehicle(v);const spec=specOf(v),mode=pursuit?FUEL.pursuit:urgent?FUEL.urgent:1;
 const litres=(km>0?km*spec.per100/100*mode:0)+(idleHours>0?idleHours*spec.idlePerHour:0);if(!(litres>0))return 0;
 if(km>0){v.km+=km;v.trackKm=(Number.isFinite(v.trackKm)?v.trackKm:0)+km;v.wear=Math.min(WEAR.broken,v.wear+km*WEAR.perKm*(pursuit?WEAR.pursuit:urgent?WEAR.urgent:1));}
 const used=Math.min(v.fuel,litres);v.fuel-=used;v.litres+=used;return used;}
export const tankOf=v=>specOf(v).tank;
export const fuelShare=v=>(v?.fuel??tankOf(v))/tankOf(v);
// Average over the distance actually tracked (older cars may have km from before fuel tracking).
export const averagePer100=v=>v?.trackKm>=20&&v?.litres>0?v.litres/v.trackKm*100:specOf(v).per100;
export const rangeKm=v=>Math.max(0,(v?.fuel??tankOf(v))/averagePer100(v)*100);
export function speedFactor(v){if(!v)return 1;let f=1;if(v.wear>=WEAR.slow)f*=WEAR.slowFactor;return f;}
export const emptyTank=v=>!!v&&v.fuel<=0;
export const needsFuel=v=>!!v&&fuelShare(v)<FUEL.lowShare;
export const broken=v=>!!v&&v.wear>=WEAR.broken;
export const refuelLitres=v=>Math.max(0,tankOf(v)-(v?.fuel??tankOf(v)));
export const refuelCost=v=>Math.round(refuelLitres(v)*FUEL.pricePerLitre);
export const repairCost=v=>Math.round((v?.wear??0)*REPAIR.pricePerPercent);
export const repairMinutes=v=>Math.round(REPAIR.baseMinutes+(v?.wear??0)*REPAIR.minutesPerPercent);
export const repairTime=v=>toTicks(repairMinutes(v));
// Progress bonus of trunk equipment for a call variant (best single item; no stacking).
export function extraBonus(v,variant){let best=1;for(const id of v?.extras??[]){const e=EXTRAS[id];if(e&&e.variants.includes(variant))best=Math.max(best,e.bonus);}return best;}
export function validVehicleState(v){const num=(x,a,b)=>Number.isFinite(x)&&x>=a&&x<=b;
 if(v.km!==undefined&&!num(v.km,0,1e7))return false;if(v.fuel!==undefined&&!num(v.fuel,0,tankOf(v)))return false;if(v.litres!==undefined&&!num(v.litres,0,1e8))return false;if(v.trackKm!==undefined&&!num(v.trackKm,0,1e7))return false;if(v.wear!==undefined&&!num(v.wear,0,100))return false;
 if(v.extras!==undefined&&!(Array.isArray(v.extras)&&v.extras.length<=SLOTS.suv&&new Set(v.extras).size===v.extras.length&&v.extras.every(id=>Object.hasOwn(EXTRAS,id))&&v.extras.length<=slotsOf(v)))return false;
 if(v.history!==undefined&&!(Array.isArray(v.history)&&v.history.length<=HISTORY_LIMIT&&v.history.every(h=>h&&Number.isFinite(h.time)&&typeof h.text==='string'&&h.text.length<=120)))return false;
 if(v.service!==undefined&&v.service!==null&&!(['fuel','repair','tow','canister'].includes(v.service.kind)&&num(v.service.left,0,1000)&&(v.service.station===undefined||Number.isInteger(v.service.station))&&num(v.service.cost??0,0,100000)))return false;
 if(v.paint!==undefined&&!Object.hasOwn(LIVERIES,v.paint))return false;
 return true;}
