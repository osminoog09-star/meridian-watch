// Release I (Claude, 12.10.2026): the services a campaign can be played in. Police is the default and
// has no profile (s.agency is undefined); every other service has its own calls, crews, vehicles,
// ranks and work between calls. sim.js and app.js read the profile instead of asking «is it rescue?».
import {RESCUE_RANKS,RESCUE_PERMISSIONS,RESCUE_VEHICLES,RESCUE_START,RESCUE_RECRUITS,RESCUE_CREW_LIMIT,RESCUE_CALL_GAP,rescueTaskFor,isRescueType} from './rescue.js';
import {DISPATCH_RANKS,DISPATCH_PERMISSIONS} from './dispatch.js';
import {EMS_RANKS,EMS_PERMISSIONS,EMS_VEHICLES,EMS_START,EMS_RECRUITS,EMS_CREW_LIMIT,EMS_CALL_GAP,emsTaskFor,isEmsType} from './ems.js';
export const AGENCY_IDS=Object.freeze(['police','rescue','ems','dispatch']);
export const PROFILES=Object.freeze({
 rescue:Object.freeze({id:'rescue',label:'Спасатели',ranks:RESCUE_RANKS,permissions:RESCUE_PERMISSIONS,vehicles:RESCUE_VEHICLES,start:RESCUE_START,recruits:RESCUE_RECRUITS,crewLimit:RESCUE_CREW_LIMIT,callGap:RESCUE_CALL_GAP,taskFor:rescueTaskFor,
  defaultVehicle:'engine',chiefVehicles:['engine','tanker'],paint:'red',lights:'blue',specialty:'Тушение пожаров',base:'station',chiefTitle:'Начальник части',crew:'расчёт',crewPlural:'расчёты',
  unit:'Спасатели',isType:isRescueType,backup:'Нужна вторая машина и вода, высылайте.',cheapest:4000}),
 ems:Object.freeze({id:'ems',label:'Скорая',ranks:EMS_RANKS,permissions:EMS_PERMISSIONS,vehicles:EMS_VEHICLES,start:EMS_START,recruits:EMS_RECRUITS,crewLimit:EMS_CREW_LIMIT,callGap:EMS_CALL_GAP,taskFor:emsTaskFor,
  defaultVehicle:'ambulance',chiefVehicles:['ambulance','rapid'],paint:'ems',lights:'blue',specialty:'Экстренная медицина',base:'hospital',chiefTitle:'Заведующий подстанцией',crew:'бригада',crewPlural:'бригады',
  unit:'Скорая',isType:isEmsType,backup:'Нужна вторая бригада, пациент тяжёлый.',cheapest:1600}),
 dispatch:Object.freeze({id:'dispatch',label:'Диспетчер 112',ranks:DISPATCH_RANKS,permissions:DISPATCH_PERMISSIONS,vehicles:Object.freeze({}),start:Object.freeze([]),recruits:Object.freeze([]),crewLimit:4,callGap:.55,taskFor:()=>null,
  defaultVehicle:'sedan',chiefVehicles:[],paint:'white',lights:'redblue',specialty:'Патрулирование',base:'station',chiefTitle:'Руководитель смены 112',crew:'экипаж',crewPlural:'экипажи',
  unit:'Экипаж',isType:()=>false,backup:'Нужна поддержка.',cheapest:1e9})
});
// J4: rescue and ambulance campaigns call crews «расчёт» / «экипаж», never «патруль» (all cases, capitalised too).
const PATROL_FORMS=Object.freeze(['патруль','патруля','патрулю','патрулём','патрулем','патруле','патрули','патрулей','патрулям','патрулями','патрулях']);
export const CREW_FORMS=Object.freeze({rescue:Object.freeze(['расчёт','расчёта','расчёту','расчётом','расчётом','расчёте','расчёты','расчётов','расчётам','расчётами','расчётах']),ems:Object.freeze(['экипаж','экипажа','экипажу','экипажем','экипажем','экипаже','экипажи','экипажей','экипажам','экипажами','экипажах'])});
export function serviceText(agency,text){const forms=CREW_FORMS[agency];if(!forms||typeof text!=='string')return text;return text.replace(/(?<![А-Яа-яЁё])([Пп])атрул(?:ь|я|ю|ём|ем|е|и|ей|ям|ями|ях)(?![А-Яа-яЁё])/g,(w,p)=>{const r=forms[PATROL_FORMS.indexOf(w.toLowerCase())]??w;return p==='П'?r[0].toUpperCase()+r.slice(1):r;});}
export const agencyOf=s=>s?.agency??'police';
export const isService=s=>!!s?.agency&&Object.hasOwn(PROFILES,s.agency);// any non-police campaign
export const profileOf=s=>PROFILES[s?.agency]??null;
export const crewLimitOf=s=>profileOf(s)?.crewLimit??2;
export const isServiceType=t=>isRescueType(t)||isEmsType(t);
export const typeAgency=t=>isRescueType(t)?'rescue':isEmsType(t)?'ems':'police';
export const validAgency=a=>a===undefined||Object.hasOwn(PROFILES,a);
// Release J: in the 112 campaign every crew belongs to its own service (u.agency); elsewhere to the campaign's.
export const unitAgency=(s,u)=>u?.agency??s?.agency??'police';
export const unitProfile=(s,u)=>PROFILES[unitAgency(s,u)]??null;
