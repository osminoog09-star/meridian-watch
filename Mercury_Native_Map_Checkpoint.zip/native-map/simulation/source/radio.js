// «Радиопереговоры» (Claude, 11.10.2026): template radio exchange without voice-over. Each crew has a
// callsign; the same event gets different wording. The choice is a hash of the call and crew ids,
// not rng(), so campaigns stay deterministic and old saves continue unchanged.
export const RADIO_LIMIT=24;
export const DISPATCH='Дежурный';
export const callsign=u=>`Меридиан-${String(u?.id??0).padStart(2,'0')}`;
export const serviceCallsign=a=>`${a?.kind==='rescue'?'Спасатель':a?.kind==='police'?'Наряд':'Скорая'}-${a?.id??0}`;

const PHRASES=Object.freeze({
 broadcast:[(c,x)=>`Всем экипажам: ${x.call}, ${x.place}.`,(c,x)=>`Внимание экипажам: ${x.call}, ${x.place}. Кто ближе?`,(c,x)=>`Новый вызов: ${x.call}, ${x.place}.`],
 dispatch:[(c,x)=>`${c}, ${x.call}, ${x.place}. Приём.`,(c,x)=>`${c}, для вас вызов: ${x.call}, ${x.place}.`,(c,x)=>`${c}, примите вызов: ${x.call}, ${x.place}. Как приняли?`],
 accept:[()=>'Принял, выдвигаемся.',()=>'Понял вас, едем.',()=>'Принято, будем через несколько минут.',()=>'Принял. Выезжаем.'],
 arrive:[()=>'На месте.',()=>'Прибыли, выходим к участникам.',()=>'На адресе, работаем.',()=>'Подъехали, оцениваем обстановку.'],
 backup:[()=>'Обстановка напряжённая, нужен второй экипаж.',()=>'Прошу подкрепление, держим дистанцию.',()=>'Своими силами не справимся, нужен второй экипаж.'],
 clear:[()=>'Свободны, возвращаемся к патрулю.',()=>'Закончили на адресе, готовы к вызовам.',()=>'Освободились, продолжаем патрулирование.',()=>'Вызов закрыт, свободны.'],
 failed:[()=>'На месте никого, вызов не отработан.',()=>'Опоздали, участники ушли.',()=>'Не успели, возвращаемся к патрулю.'],
 transport:[()=>'Везём задержанного в участок.',()=>'Задержанный в машине, следуем в участок.',()=>'Едем в участок с задержанным.'],
 handover:[()=>'Задержанного передали дежурному, рапорт сдан.',()=>'В участке, задержанный передан. Свободны.'],
 fuel:[()=>'Топливо на исходе, едем на заправку.',()=>'Бак почти пустой, заедем в участок заправиться.'],
 empty:[()=>'Встали, кончилось топливо. Нужна канистра.',()=>'Бак пустой, стоим. Пришлите топливо.'],
 refueled:[()=>'Заправились, снова на линии.',()=>'Бак полный, продолжаем патруль.'],
 breakdown:[()=>'Машина встала, нужна эвакуация.',()=>'Поломка, дальше не едем. Вызываем эвакуатор.'],
 repaired:[()=>'Машину починили, выходим на линию.',()=>'Ремонт закончен, мы снова в строю.'],
 nodoff:[()=>'Водитель устал, остановились на пару минут.',()=>'Встали у обочины, водителю нужно прийти в себя.'],
 ambulance:[()=>'Выехали на вызов полиции.',()=>'Принято, едем к пострадавшему.'],
 rescue:[()=>'Расчёт выехал.',()=>'Принято, выдвигаемся с оборудованием.']
});
export const RADIO_KINDS=Object.freeze(Object.keys(PHRASES));
// Small deterministic mix of two integers.
export function pick(kind,a=0,b=0){const list=PHRASES[kind];if(!list)return null;let h=Math.imul((a|0)+1,2654435761)^Math.imul((b|0)+7,1597334677);h^=h>>>15;return list[(h>>>0)%list.length];}
export function radioText(kind,a,b,c,x={}){const f=pick(kind,a,b);return f?f(c,x):'';}
export function pushRadio(s,from,text){if(!text)return;if(!Array.isArray(s.radio))s.radio=[];s.radio.unshift({time:s.time,from:String(from).slice(0,40),text:String(text).slice(0,200)});if(s.radio.length>RADIO_LIMIT)s.radio.length=RADIO_LIMIT;}
export function validRadio(s){if(s.radio===undefined)return true;return Array.isArray(s.radio)&&s.radio.length<=RADIO_LIMIT&&s.radio.every(r=>r&&Number.isFinite(r.time)&&typeof r.from==='string'&&r.from.length<=40&&typeof r.text==='string'&&r.text.length<=200);}
