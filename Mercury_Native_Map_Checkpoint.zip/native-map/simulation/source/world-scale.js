// One metre and one vertical projection for measured close views.
export const MAP_METRES=1670;
export const CITY_HEIGHT=Math.cos(.8);
export const pixelsPerMetre=scale=>Math.max(0,Number.isFinite(scale)?scale:0)/MAP_METRES;
export const buildingRise=(height,scale,zoom)=>zoom>1.3?Math.max(0,height)*pixelsPerMetre(scale)*CITY_HEIGHT:0;
export const actorScale=(scale,zoom)=>zoom>=12?pixelsPerMetre(scale):Math.max(.8,pixelsPerMetre(scale));
