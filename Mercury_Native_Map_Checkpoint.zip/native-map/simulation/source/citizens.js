// Release O2 «Жители-личности» (Claude, 17.10.2026). Owner 16.10: «реальные граждане: имена, работа, потребности —
// задержанный должен быть личностью». Every participant of a call is a person of Meridian: name, age, home district,
// work, household, character and what is going on in their life. The city is fixed (a person is a pure function of
// their id), so no randomness enters saves; a save keeps only what happened to people the player met.
// Names after the Estonian and Russian name pools of a Pärnu-like town (roughly four in five Estonian names);
// jobs after the town's economy: retail, spa hotels and tourism, construction, wood industry, port, transport.
import {DISTRICT_IDS} from './calls.js';
import {districtName} from './fiction.js';
export const CITIZEN_BASE=1000,CITIZEN_COUNT=52000;
const EE={m:['Андрес','Маргус','Тармо','Прийт','Кристьян','Сийм','Расмус','Мартин','Михкель','Индрек','Рейн','Тоомас','Яан','Урмас','Кайдо','Рауль','Янек','Марко','Айвар','Эрик','Карл','Оскар','Хенри','Робин','Сандер'],
 f:['Кадри','Пирет','Кристийна','Лийс','Мария','Ану','Мерике','Тийна','Катрин','Хелен','Кертту','Трийн','Эве','Аннели','Марью','Лаура','София','Эмма','Мия','Ханна'],
 last:['Тамм','Саар','Сепп','Мяги','Каск','Кукк','Ребане','Ильвес','Пярн','Коппель','Лепп','Кыйв','Киви','Оя','Лилль','Раудсепп','Пыдер','Луйк','Вахер','Каллас','Метс','Кууск','Йыги','Лыхмус','Тедер']};
const RU={m:['Алексей','Сергей','Андрей','Дмитрий','Игорь','Владимир','Николай','Максим','Артём','Павел'],
 f:['Ольга','Наталья','Елена','Татьяна','Ирина','Светлана','Анастасия','Юлия','Марина','Екатерина'],
 last:['Иванов','Смирнов','Кузнецов','Попов','Васильев','Петров','Соколов','Михайлов','Новиков','Фёдоров','Волков','Алексеев','Лебедев','Семёнов','Егоров']};
// [job, places, weight]
const JOBS=[['продавец',['ТЦ «Меридиан»','супермаркет у рынка','магазин на Рюйтли'],10],['официант',['кафе у пляжа','ресторан гостиницы «Променад»'],5],
 ['администратор спа-отеля',['спа-отель «Ранна»','санаторий «Тервис»'],6],['строитель',['стройка в Раэкюла','ремонтная фирма «Кодуремонт»'],8],
 ['рабочий',['мебельная фабрика','лесопилка у реки'],7],['грузчик',['порт Меридиана'],4],['водитель',['автобусный парк','такси «Линн»','логистика «Балти»'],7],
 ['медсестра',['больница Меридиана'],4],['учитель',['гимназия Меридиана','основная школа Ülejõe'],4],['офисный работник',['городская управа','банк на Рюйтли','IT-фирма в порту'],8],
 ['повар',['столовая колледжа','ресторан у реки'],4],['автомеханик',['автосервис на Таллиннском шоссе'],4],['рыбак',['рыболовецкая артель'],2],
 ['студент',['колледж Меридиана'],4],['без работы',[''],6],['работает на себя',['своя мастерская','интернет-магазин'],3]];
const FEM={'грузчик':'кладовщица','рабочий':'работница','строитель':'отделочница','автомеханик':'приёмщица автосервиса','рыбак':'работница рыбного цеха','продавец':'продавщица','официант':'официантка','учитель':'учительница','студент':'студентка','водитель':'водитель'};
const JOB_TOTAL=JOBS.reduce((n,j)=>n+j[2],0);
export const TRAITS=Object.freeze({calm:'спокойный',temper:'вспыльчивый',drinks:'выпивает',debts:'в долгах',lonely:'одинокий',caring:'заботливый',distrust:'не доверяет полиции',social:'общительный',stubborn:'упрямый',honest:'честный',reckless:'лихач',anxious:'тревожный'});
const TRAIT_IDS=Object.keys(TRAITS);
const mix=(a,b,c=0)=>{let h=Math.imul((a|0)+0x9e37,2654435761)^Math.imul((b|0)+0x85eb,2246822519)^Math.imul((c|0)+0xc2b2,3266489917);h^=h>>>15;h=Math.imul(h,2246822519);h^=h>>>13;return h>>>0;};
const pick=(list,h)=>list[h%list.length];
// One person of the city, the same every time.
export function citizen(id){
 if(!Number.isInteger(id)||id<CITIZEN_BASE||id>=CITIZEN_BASE+CITIZEN_COUNT)return null;
 const h=mix(id,1),g=h%2?'f':'m',ru=(h>>>1)%5===0,pool=ru?RU:EE,first=pick(pool[g],h>>>3),last0=pick(pool.last,h>>>9),last=ru&&g==='f'?last0+'а':last0;
 const a=mix(id,2),age=a%100<8?3+a%13:a%100<14?16+a%4:a%100<82?20+(a>>>7)%45:65+(a>>>7)%25;
 const district=DISTRICT_IDS[mix(id,3)%DISTRICT_IDS.length];
 let job,place;if(age<7){job='детский сад';place='';}else if(age<16){job=`школьник, ${age-6} класс`;place='основная школа';}else if(age<20){job='учится в гимназии';place='гимназия Меридиана';}else if(age>=65&&mix(id,4)%5){job='пенсионер';place='';}
 else{let r=mix(id,5)%JOB_TOTAL;for(const j of JOBS){if((r-=j[2])<0){job=g==='m'?(j[0]==='медсестра'?'медбрат':j[0]):(FEM[j[0]]??j[0]);place=pick(j[1],mix(id,6));break;}}}
 const k=mix(id,7),kids=age>=24&&age<60?k%3:0,he=g==='m',kidsText=kids?(kids===1?'ребёнок':'двое детей'):'';
 const household=age<20?'живёт с родителями':age>=70?(k%2?(he?'живёт один, жена умерла':'живёт одна, муж умер'):(he?'живёт с женой':'живёт с мужем')):
  [he?'живёт один':'живёт одна',he?'живёт с подругой':'живёт с другом',he?'женат':'замужем','живёт с родителями',he?'женат':'замужем'][k%5]+(kids&&k%5!==3?', '+kidsText:'');
 const t=mix(id,8),traits=[TRAIT_IDS[t%TRAIT_IDS.length],TRAIT_IDS[(t>>>5)%TRAIT_IDS.length]].filter((x,i,arr)=>arr.indexOf(x)===i);
 return {id,first,last,name:`${first} ${last}`,gender:g,age,district,job,place,household,traits,russian:ru};}
// The age a role needs: a missing child is a child, a driver is an adult, an elderly person who wandered off is old.
function ageFits(c,role,variant){if(['missing-child','lost-child-mall'].includes(variant)&&role==='Пропавший человек')return c.age>=5&&c.age<=12;if(variant==='lost-at-concert'&&role==='Пропавший человек')return c.age>=13&&c.age<=16;
 if(['missing-elder','confused-person'].includes(variant)&&(role==='Пропавший человек'||role==='Участник'))return c.age>=70;
 if(['Водитель','Пострадавший','Пациент','Участник','Жилец','Заявитель','Свидетель','Сосед','Очевидец','Родственник','Прохожий','Человек в воде'].includes(role))return c.age>=18&&c.age<=85;return c.age>=18;}
// Traits that make sense for the main person of a call.
const WANT=Object.freeze({'noise-venue':['drinks','social','temper'],'noise-flat':['social','drinks','stubborn'],'drunk-person':['drinks','lonely'],'yard-company':['drinks','social'],
 'street-fight':['temper','drinks'],'fan-fight':['temper','social'],domestic:['temper','drinks','debts'],'restraining-order':['temper','stubborn'],
 shoplift:['debts','lonely'],'bike-theft':['debts'],'car-break':['debts'],'suspect-found':['debts','distrust'],'alarm-burglary':['debts'],
 'drunk-driver':['drinks','reckless'],'dangerous-driving':['reckless'],'no-licence':['stubborn','reckless'],'school-speeding':['reckless'],'vehicle-alert':['distrust'],'fuel-driveoff':['debts']});
// The person of a call: participant k of call i, living in the call's district for the main person.
export function citizenFor(i,k,role,district=null){const want=k===0?WANT[i.variant]:null,dist=k===0?district:null;let best=null;
 for(let n=0;n<160;n++){const id=CITIZEN_BASE+mix(i.id,k*7919+n,i.type??0)%CITIZEN_COUNT,c=citizen(id);if(!ageFits(c,role,i.variant))continue;if(!best)best=c;
  if(want&&!c.traits.some(t=>want.includes(t)))continue;if(dist&&c.district!==dist&&n<120)continue;return c;}
 return best??citizen(CITIZEN_BASE+mix(i.id,k)%CITIZEN_COUNT);}
// Why it happened — from the person's life, not a generic line.
export function motiveFor(variant,c){if(!c)return '';const t=c.traits,job=c.job==='без работы'?(c.gender==='f'?'осталась':'остался')+' без работы':c.job==='пенсионер'?'на пенсии':c.job.startsWith('работает')||c.job.startsWith('учится')||c.job.startsWith('школьник')||c.job==='детский сад'?c.job:'работает: '+c.job+(c.place?' ('+c.place+')':'');
 const M={'noise-venue':'празднует с друзьями после смены','noise-flat':t.includes('drinks')?'отмечает что-то не первый вечер подряд':'не думает о соседях после 23:00',
  'drunk-person':t.includes('lonely')?'пьёт один с тех пор, как остался без семьи':'перебрал после работы','yard-company':'сидит с компанией во дворе — больше негде',
  'street-fight':t.includes('temper')?'вспылил из-за пустяка':'ответил на оскорбление',domestic:t.includes('debts')?'ссора из-за денег и долгов':t.includes('drinks')?'ссора после выпивки':'накопившиеся обиды в семье',
  'restraining-order':'не может смириться с расставанием',shoplift:t.includes('debts')?'кончились деньги до зарплаты':'взял, «потому что никто не видит»',
  'bike-theft':'продаёт краденое, чтобы закрыть долг','car-break':'ищет, что можно быстро продать','drunk-driver':'«всего пару бокалов, тут недалеко»',
  'dangerous-driving':'опаздывает и не думает о других','no-licence':'лишён прав, но ездит на работу','fuel-driveoff':'денег на бензин не было',
  'missing-elder':'забывает дорогу домой — у семьи давно тревога','confused-person':'деменция, ушёл из дома незаметно','missing-child':'задержался у друзей, телефон сел',
  'phone-scam':'поверил звонку «из банка»'};
 return M[variant]?`${M[variant]}; ${job}`:job;}
export const citizenLine=c=>c?`${c.age} ${c.age%10===1&&c.age!==11?'год':c.age%10>=2&&c.age%10<=4&&(c.age<12||c.age>14)?'года':'лет'} · ${c.job}${c.place?' · '+c.place:''} · ${c.household} · ${districtName(c.district,'Меридиан')}`:'';
export const traitLine=c=>c?c.traits.map(t=>TRAITS[t]).join(', '):'';

// What happened to people the player met (the only part kept in a save).
export const PEOPLE=Object.freeze({limit:300,met:8,jailShifts:6,fineCourt:[150,300,600],jobLossRecords:3});
export const OUTCOME=Object.freeze({arrest:'задержан',warn:'отпущен с предупреждением',talk:'беседа на месте',report:'составлен протокол',fled:'ушёл до прибытия полиции',witness:'свидетель',helped:'получил помощь',hospital:'доставлен в больницу',rescued:'спасён',found:'найден и возвращён домой',notfound:'не найден вовремя'});
export function ensurePeople(s){if(!s.people||typeof s.people!=='object'||Array.isArray(s.people))s.people={};return s.people;}
export function personOf(s,id){return s?.people?.[id]??null;}
export function recordMet(s,id,entry){if(!citizen(id))return null;const p=ensurePeople(s),r=p[id]??={met:[],status:'free',until:0,fines:0,lostJob:false};
 r.met.unshift(entry);if(r.met.length>PEOPLE.met)r.met.length=PEOPLE.met;
 const keys=Object.keys(p);if(keys.length>PEOPLE.limit){const old=keys.filter(k=>p[k].status==='free').sort((a,b)=>(p[a].met[0]?.shift??0)-(p[b].met[0]?.shift??0));for(const k of old.slice(0,keys.length-PEOPLE.limit))delete p[k];}
 return r;}
export const arrests=r=>(r?.met??[]).filter(m=>m.outcome==='arrest').length;
// After a shift: the court decides on people held in custody; a third record or prison costs the job.
export function peopleAfterShift(s,shift){const lines=[];for(const [id,r] of Object.entries(s.people??{})){
 if(r.status==='custody'){const c=citizen(+id),n=arrests(r),h=mix(+id,shift,n);
  if(n>=3||h%10===0){r.status='jailed';r.until=shift+PEOPLE.jailShifts;lines.push(`Суд: ${c.name} — арест (${n}-е задержание).`);}
  else{const fine=PEOPLE.fineCourt[Math.min(PEOPLE.fineCourt.length-1,n-1)];r.status='free';r.fines+=fine;lines.push(`Суд: ${c.name} — штраф ${fine} €.`);}
  if((r.status==='jailed'||n>=PEOPLE.jobLossRecords)&&!r.lostJob&&!['без работы','пенсионер'].includes(c.job)&&c.age>=18){r.lostJob=true;lines.push(`${c.name} потерял${c.gender==='f'?'а':''} работу (${c.job}).`);}}
 else if(r.status==='jailed'&&shift>=r.until){r.status='free';lines.push(`${citizen(+id).name} вышел${citizen(+id).gender==='f'?'а':''} на свободу.`);}}
 return lines;}
export const STATUS_TEXT=Object.freeze({free:'на свободе',custody:'в изоляторе, ждёт суда',jailed:'отбывает арест'});
export function validPeople(p){if(p===undefined)return true;if(!p||typeof p!=='object'||Array.isArray(p)||Object.keys(p).length>PEOPLE.limit+20)return false;
 return Object.entries(p).every(([k,r])=>citizen(+k)&&r&&Array.isArray(r.met)&&r.met.length<=PEOPLE.met&&r.met.every(m=>m&&Number.isInteger(m.shift)&&Number.isInteger(m.call)&&typeof m.variant==='string'&&m.variant.length<40&&Object.hasOwn(OUTCOME,m.outcome)&&typeof m.role==='string'&&m.role.length<40)
  &&Object.hasOwn(STATUS_TEXT,r.status)&&Number.isInteger(r.until)&&Number.isInteger(r.fines)&&r.fines>=0&&typeof r.lostJob==='boolean');}
