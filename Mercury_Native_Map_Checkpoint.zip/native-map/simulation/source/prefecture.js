// Release M «Полиция как в ППА» (Claude, 16.10.2026). In the Estonian police the rapid response unit
// (kiirreageerijad) is not part of a patrol crew: it is a separate unit of the prefecture, on duty 24/7,
// and the prefecture command centre sends it to the most dangerous calls (a weapon, violence, detaining a
// dangerous person) and to support the criminal police. Patrols do not command it; they ask for it through
// the command centre and keep a safe distance until it arrives. A barricaded armed person or hostages are a
// task for K-Komando, the national special unit under the Central Criminal Police; the patrol and the rapid
// response unit hold the cordon until it arrives.
// Sources: ERR 632327 (kiirreageerijate arv kahekordistub), Järva Teataja 4368203, K-Commando (Wikipedia).
// No random draws: which violence calls are armed is a hash of the campaign seed and the call id.
import {WORLD_SECONDS_PER_TICK_SECOND} from './transport.js';
export const PREFECTURE=Object.freeze({
 gbrKmh:80,            // the rapid response car
 gbrMax:1,             // one rapid response team on duty for the city
 kkArrive:30,          // minutes: K-Komando comes from the capital
 kkKmh:110,
 armedEvery:4,         // every fourth violence call (by hash) is armed
 barricadeEvery:4,     // ... every fourth armed family conflict is a barricade
 hostageEvery:3,       // ... and every third barricade has a hostage
 holdCap:.4,           // a patrol alone at an armed call keeps distance and cannot detain
 barricadeCap:.6,      // a hostage: the cordon holds until K-Komando or the team acts itself
 barricadePace:.7,     // the team talks a barricaded man out and enters itself: slower work
 stormAfter:10,        // minutes on scene: with a threat to the hostage's life the team does not wait
 helpAfter:3,          // minutes: a patrol asked for backup and no second crew took it — the team comes
 lateCall:6,           // minutes: a call nobody took (all patrols busy) — the team works it as an extra patrol
 gbrPace:1.3,          // the rapid response team detains faster
 xp:6,                 // a patrol that waited for the team gets a little extra experience
 gbrXp:2               // a call of the rapid response team is worth twice a patrol call (fewer, harder calls)
});
export const GBR_VARIANTS=Object.freeze(new Set(['street-fight','fan-fight','domestic','restraining-order']));
// The team also takes arrests for the criminal police, pursuits of a car on a lookout and a burglary in progress.
export const GBR_SUPPORT=Object.freeze(new Set(['suspect-found','vehicle-alert','dangerous-driving','alarm-burglary']));
const BARRICADE_FROM=new Set(['domestic','restraining-order']);
// M1 (owner 16.10): the team works on its own — a barricaded man is its job; K-Komando only for a hostage, and
// with a threat to the hostage's life the team acts before K-Komando arrives. It also backs up patrols.
export const ARMED=Object.freeze({
 knife:Object.freeze({prefix:'Нож',brief:'Звонящий видит у одного из участников нож. Командный центр направил ГБР префектуры: патрулю держать дистанцию до её прибытия.'}),
 barricade:Object.freeze({prefix:'Вооружённый закрылся',brief:'Мужчина угрожает оружием и закрылся в квартире. Патрулю — оцепление; переговоры и задержание проводит ГБР префектуры.'}),
 hostage:Object.freeze({prefix:'Заложник',brief:'Вооружённый закрылся в квартире и удерживает человека. Патрулю и ГБР — оцепление; вызван K-Komando. При угрозе жизни ГБР действует сама, не дожидаясь его.'})
});
export const ARMED_IDS=Object.freeze(Object.keys(ARMED));
const mix=(a,b)=>{let h=Math.imul((a|0)+131,2246822519)^Math.imul((b|0)+29,3266489917);h^=h>>>13;return h>>>0;};
const minutes=x=>x*WORLD_SECONDS_PER_TICK_SECOND/60;
// Only police patrol campaigns on the PPA roster: the 112 desk, rescue and ambulance keep their calls.
export function makeArmed(s,i){if(!i||i.armed||!GBR_VARIANTS.has(i.variant))return null;if(mix(s.seed,i.id)%PREFECTURE.armedEvery!==0)return null;
 const h=mix(i.id,s.seed)>>>3,barricade=BARRICADE_FROM.has(i.variant)&&h%PREFECTURE.barricadeEvery===0;
 i.armed=!barricade?'knife':Math.floor(h/PREFECTURE.barricadeEvery)%PREFECTURE.hostageEvery===0?'hostage':'barricade';i.gbr=null;
 if(i.armed==='hostage'){i.kk=null;i.storm=(h>>>7)%2===0;}return i.armed;}
// The command centre sends the team to every armed call, to violence calls where the patrol asked for backup,
// and to any patrol call where backup was asked and no second crew has taken it for a few minutes.
export const backupLate=(i,now)=>Number.isFinite(now)&&!!i?.backupRequested&&(i.units?.length??0)<2&&i.type<6&&minutes(now-(i.backupAt??now))>=PREFECTURE.helpAfter;
// Every day the team also works as an extra patrol (ERR 632327): a call that waited with no free patrol.
export const waitingLate=i=>!!i&&i.state==='waiting'&&!(i.units?.length)&&i.type>0&&i.type<6&&minutes(i.age??0)>=PREFECTURE.lateCall;
export const gbrNeeded=(i,now)=>!!i&&!['resolved','missed'].includes(i.state)&&(!!ARMED[i.armed]||(GBR_VARIANTS.has(i.variant)&&!!i.backupRequested)||backupLate(i,now)||waitingLate(i));
export const gbrOnScene=i=>i?.gbr==='onscene';
export const kkOnScene=i=>i?.kk==='onscene';
// The team acts at a hostage call itself: life in danger and the team has been on scene long enough.
export const gbrStorms=(i,minuteNow)=>i?.armed==='hostage'&&!!i.storm&&gbrOnScene(i)&&Number.isFinite(i.gbrAt)&&minuteNow-i.gbrAt>=PREFECTURE.stormAfter;
// How far a patrol may get on its own: at an armed call it keeps distance, at a hostage call it holds the cordon.
export function prefectureCap(i,minuteNow=-1){if(!ARMED[i?.armed])return 1;if(!gbrOnScene(i))return PREFECTURE.holdCap;if(i.armed==='hostage'&&!kkOnScene(i)&&!gbrStorms(i,minuteNow))return PREFECTURE.barricadeCap;return 1;}
export const armedTitle=i=>ARMED[i?.armed]?.prefix??'';
export function prefectureWait(i){if(!ARMED[i?.armed])return null;if(!gbrOnScene(i))return 'Держим дистанцию: ждём ГБР префектуры.';if(i.armed==='hostage'&&!kkOnScene(i))return i.storm?'Оцепление держим. Угроза заложнику — ГБР готовится действовать сама.':'Оцепление держим, ждём K-Komando.';if(i.armed==='barricade')return 'Оцепление держим, ГБР ведёт переговоры.';return null;}
export function validArmed(i){
 if(i.stormed!==undefined&&!(i.stormed===true&&i.armed==='hostage'))return false;
 if(i.gbrAt!==undefined&&!(Number.isInteger(i.gbrAt)&&i.gbrAt>=0&&i.gbrAt<=10000))return false;
 if(i.armed===undefined)return i.gbr===undefined||i.gbr===null||['called','onscene','player'].includes(i.gbr);
 if(!ARMED[i.armed])return false;if(!(i.gbr===null||['called','onscene','player'].includes(i.gbr)))return false;
 if(i.armed==='hostage')return (i.kk===null||['called','onscene','cancelled'].includes(i.kk))&&typeof i.storm==='boolean';return i.kk===undefined&&i.storm===undefined;
}
