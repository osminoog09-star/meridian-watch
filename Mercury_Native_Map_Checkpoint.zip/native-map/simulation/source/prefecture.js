// Release M «Полиция как в ППА» (Claude, 16.10.2026). In the Estonian police the rapid response unit
// (kiirreageerijad) is not part of a patrol crew: it is a separate unit of the prefecture, on duty 24/7,
// and the prefecture command centre sends it to the most dangerous calls (a weapon, violence, detaining a
// dangerous person) and to support the criminal police. Patrols do not command it; they ask for it through
// the command centre and keep a safe distance until it arrives. A barricaded armed person or hostages are a
// task for K-Komando, the national special unit under the Central Criminal Police; the patrol and the rapid
// response unit hold the cordon until it arrives.
// Sources: ERR 632327 (kiirreageerijate arv kahekordistub), Järva Teataja 4368203, K-Commando (Wikipedia).
// No random draws: which violence calls are armed is a hash of the campaign seed and the call id.
export const PREFECTURE=Object.freeze({
 gbrKmh:80,            // the rapid response car
 gbrMax:1,             // one rapid response team on duty for the city
 kkArrive:30,          // minutes: K-Komando comes from the capital
 kkKmh:110,
 armedEvery:4,         // every fourth violence call (by hash) is armed
 barricadeEvery:4,     // ... and every fourth armed family conflict is a barricade
 holdCap:.4,           // a patrol alone at an armed call keeps distance and cannot detain
 barricadeCap:.6,      // the cordon holds, the detention is K-Komando's
 gbrPace:1.3,          // the rapid response team detains faster
 xp:6,                 // a patrol that waited for the team gets a little extra experience
 gbrXp:2               // a call of the rapid response team is worth twice a patrol call (fewer, harder calls)
});
export const GBR_VARIANTS=Object.freeze(new Set(['street-fight','fan-fight','domestic','restraining-order']));
// The team also takes arrests for the criminal police, pursuits of a car on a lookout and a burglary in progress.
export const GBR_SUPPORT=Object.freeze(new Set(['suspect-found','vehicle-alert','dangerous-driving','alarm-burglary']));
const BARRICADE_FROM=new Set(['domestic','restraining-order']);
export const ARMED=Object.freeze({
 knife:Object.freeze({prefix:'Нож',brief:'Звонящий видит у одного из участников нож. Командный центр направил ГБР префектуры: патрулю держать дистанцию до её прибытия.'}),
 barricade:Object.freeze({prefix:'Вооружённый закрылся',brief:'Мужчина угрожает оружием и закрылся в квартире, внутри может быть человек. Патрулю и ГБР — оцепление; задержание проводит K-Komando.'})
});
export const ARMED_IDS=Object.freeze(Object.keys(ARMED));
const mix=(a,b)=>{let h=Math.imul((a|0)+131,2246822519)^Math.imul((b|0)+29,3266489917);h^=h>>>13;return h>>>0;};
// Only police patrol campaigns on the PPA roster: the 112 desk, rescue and ambulance keep their calls.
export function makeArmed(s,i){if(!i||i.armed||!GBR_VARIANTS.has(i.variant))return null;if(mix(s.seed,i.id)%PREFECTURE.armedEvery!==0)return null;
 i.armed=BARRICADE_FROM.has(i.variant)&&(mix(i.id,s.seed)>>>3)%PREFECTURE.barricadeEvery===0?'barricade':'knife';i.gbr=null;if(i.armed==='barricade')i.kk=null;return i.armed;}
// The command centre sends the team to every armed call and to violence calls where the patrol asked for backup.
export const gbrNeeded=i=>!!i&&(!!ARMED[i.armed]||(GBR_VARIANTS.has(i.variant)&&!!i.backupRequested));
export const gbrOnScene=i=>i?.gbr==='onscene';
export const kkOnScene=i=>i?.kk==='onscene';
// How far a patrol may get on its own: at an armed call it keeps distance, at a barricade it holds the cordon.
export function prefectureCap(i){if(!ARMED[i?.armed])return 1;if(!gbrOnScene(i))return PREFECTURE.holdCap;if(i.armed==='barricade'&&!kkOnScene(i))return PREFECTURE.barricadeCap;return 1;}
export const armedTitle=i=>ARMED[i?.armed]?.prefix??'';
export function prefectureWait(i){if(!ARMED[i?.armed])return null;if(!gbrOnScene(i))return 'Держим дистанцию: ждём ГБР префектуры.';if(i.armed==='barricade'&&!kkOnScene(i))return 'Оцепление держим, ждём K-Komando.';return null;}
export function validArmed(i){
 if(i.gbrAt!==undefined&&!(Number.isInteger(i.gbrAt)&&i.gbrAt>=0&&i.gbrAt<=10000))return false;
 if(i.armed===undefined)return i.gbr===undefined||i.gbr===null||['called','onscene','player'].includes(i.gbr);
 if(!ARMED[i.armed])return false;if(!(i.gbr===null||['called','onscene','player'].includes(i.gbr)))return false;
 if(i.armed==='barricade')return i.kk===null||['called','onscene'].includes(i.kk);return i.kk===undefined;
}
