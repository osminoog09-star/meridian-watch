// Release O3 «Живой город» (Claude, 17.10.2026). Owner 16.10: «город должен стать реалистичным: реальные граждане,
// имена, работа, потребности — как в Sims». Every citizen of the registry (citizens.js) lives a day by their age,
// job, household and character: sleep, breakfast, the way to work or school, work, lunch, shops, a walk, friends,
// the bar, home. Needs (energy, hunger, company, rest, money) rise and fall through that day and explain what a
// person does now («идёт в магазин — закончились продукты»). All of it is a pure function of the person and the
// city clock: nothing is saved and the simulation is unchanged; the map shows the people who are outside near the
// camera, walking or driving along the real streets, and a tap opens their card.
import {citizen,CITIZEN_BASE,CITIZEN_COUNT} from './citizens.js';
import {byId,ROAD_NODES,roadRoute,point} from './geography.js';
import {DISTRICT_IDS} from './calls.js';
import {MAP_METRES} from './world-scale.js';
import {worldMinutes} from './transport.js';

export const CITYDAY=Object.freeze({pool:4000,visible:36,radius:.35,walkKmh:4.8,carKmh:32,carFrom:1200});
const mix=(a,b=0,c=0)=>{let h=Math.imul((a|0)+0x2545,2654435761)^Math.imul((b|0)+0x1f35,2246822519)^Math.imul((c|0)+0x0b3d,3266489917);h^=h>>>15;h=Math.imul(h,2246822519);h^=h>>>13;return (h>>>0)/4294967296;};
export const cityClock=elapsed=>{const m=17*60+worldMinutes(elapsed);return {minute:m%1440,day:Math.floor(m/1440)};};
export const weekend=day=>day%7>=5;

// Road nodes of each district: the nearest district anchor decides.
const anchors=DISTRICT_IDS.map(id=>({id,...point(byId(id))}));
const byDistrict=new Map(DISTRICT_IDS.map(id=>[id,[]]));
for(const n of ROAD_NODES){let best=anchors[0],d=Infinity;for(const a of anchors){const k=Math.hypot(a.x-n.x,a.y-n.y);if(k<d){d=k;best=a;}}byDistrict.get(best.id).push(n);}
const nodeIn=(district,h)=>{const list=byDistrict.get(district)??byDistrict.get('centre');return list[Math.floor(h*list.length)%list.length];};
const NIGHT_JOBS=/медбрат|медсестра|охранник|водитель|врач|пожарный|диспетчер|полицейск|оператор|сварщик/;
const kindOf=c=>c.age<=6?'child':c.age<=18?'pupil':/студент/.test(c.job)?'student':/пенсион/.test(c.job)?'pensioner':/без работы/.test(c.job)?'jobless':'worker';
// The places of a person: home, work (by the place of work: the centre most often), a shop and a park nearby,
// the friend they visit, the bar.
const placeCache=new Map();
function places(c){const hit=placeCache.get(c.id);if(hit)return hit;const v=placesOf(c);placeCache.set(c.id,v);if(placeCache.size>CITYDAY.pool+500)placeCache.delete(placeCache.keys().next().value);return v;}
function placesOf(c){const h=k=>mix(c.id,k);const home=nodeIn(c.district,h(1));const workDistrict=!c.place?c.district:h(2)<.45?'centre':DISTRICT_IDS[Math.floor(h(3)*DISTRICT_IDS.length)];
 return {home,work:nodeIn(workDistrict,h(4)),school:nodeIn(c.district,h(5)),shop:nodeIn(c.district,h(6)),park:nodeIn(h(7)<.5?'beach':c.district,h(8)),friend:nodeIn(DISTRICT_IDS[Math.floor(h(9)*DISTRICT_IDS.length)],h(10)),bar:nodeIn(h(11)<.6?'centre':'beach',h(12))};}
const ACT=Object.freeze({sleep:'спит',home:'дома',work:'на работе',school:'в школе',study:'на занятиях',shop:'в магазине',walk:'гуляет',visit:'в гостях',bar:'в баре',gym:'в спортзале',kindergarten:'в садике'});
const AT={work:'work',school:'school',study:'work',shop:'shop',walk:'park',visit:'friend',bar:'bar',gym:'shop',kindergarten:'school'};
// The day: a list of [start minute, activity]; trips are the moves between places with a different location.
const planCache=new Map();
export function dayPlan(c,day,{rain=false}={}){const key=c.id+'|'+day+'|'+(rain?1:0),hit=planCache.get(key);if(hit)return hit;const v=makePlan(c,day,rain);planCache.set(key,v);if(planCache.size>CITYDAY.pool*2+500)planCache.delete(planCache.keys().next().value);return v;}
function makePlan(c,day,rain){const k=kindOf(c),h=n=>mix(c.id,day,n),off=weekend(day),plan=[];const at=(m,a)=>plan.push([Math.round(m),a]);
 const social=c.traits?.includes('social'),lonely=c.traits?.includes('lonely'),drinks=c.traits?.includes('drinker')||c.traits?.includes('temper');
 const night=k==='worker'&&NIGHT_JOBS.test(c.job)&&mix(c.id,77)<.4&&(Math.floor(day/2)+c.id)%2===0;
 if(k==='child'){at(0,'sleep');at(7*60,'home');if(!off){at(7*60+45,'kindergarten');at(16*60+30,'home');}else{at(11*60,'walk');at(13*60,'home');}at(20*60,'sleep');return plan;}
 if(night){at(0,'work');at(7*60+30,'home');at(8*60+30,'sleep');at(15*60,'home');if(h(1)<.5)at(16*60,'shop');at(17*60,'home');at(18*60+20,'work');return plan;}
 const wake=k==='jobless'?9*60+h(2)*120:k==='pensioner'?6*60+30+h(2)*60:off?8*60+h(2)*120:6*60+h(2)*80;
 at(0,'sleep');at(wake,'home');
 if(!off&&['worker','pupil','student'].includes(k)){const start=k==='pupil'?8*60:k==='student'?9*60+h(3)*60:7*60+h(3)*120,end=k==='pupil'?14*60+h(4)*90:k==='student'?14*60+h(4)*120:start+8*60+30+h(4)*60;
  at(Math.max(wake+20,start-30),k==='pupil'?'school':k==='student'?'study':'work');at(end,'home');let t=end+30;
  if(h(5)<.45){at(t,'shop');t+=40+h(6)*30;at(t,'home');t+=30;}
  if(h(7)<(social?.4:.15)){at(t+40,h(8)<.5||k==='pupil'?'visit':'gym');at(t+40+90+h(9)*60,'home');}
  else if(!rain&&h(7)<.55&&k!=='worker'){at(t+30,'walk');at(t+30+50,'home');}}
 else{let t=wake+90+h(3)*60;if(h(4)<.75){at(t,'shop');t+=45;at(t,'home');}
  t=Math.max(t+60,13*60+h(5)*120);if(!rain&&h(6)<(k==='pensioner'?.7:.5)){at(t,'walk');at(t+60+h(7)*60,'home');}
  if(h(8)<(social||lonely?.45:.2)){at(17*60+h(9)*90,'visit');at(20*60+h(10)*60,'home');}}
 if(k!=='pupil'&&k!=='pensioner'&&c.age>=18&&h(11)<(off?.35:.1)+(drinks?.2:0)){at(20*60+30+h(12)*60,'bar');at(23*60+30,'home');}
 const bed=k==='pupil'?22*60+h(13)*40:k==='pensioner'?22*60:off?23*60+30+h(13)*50:22*60+30+h(13)*70;at(Math.min(bed,1439),'sleep');
 plan.sort((a,b)=>a[0]-b[0]);return plan;}

const routeCache=new Map();
let budget=Infinity;
function route(a,b){const key=a.id+'>'+b.id;let r=routeCache.get(key);if(!r){if(budget<=0)return null;budget--;const pts=[point(a),...roadRoute(a,b).map(p=>({x:p.x,y:p.y}))];let len=0;const acc=[0];for(let i=1;i<pts.length;i++){len+=Math.hypot(pts[i].x-pts[i-1].x,pts[i].y-pts[i-1].y);acc.push(len);}r={pts,acc,len};routeCache.set(key,r);if(routeCache.size>600)routeCache.delete(routeCache.keys().next().value);}return r;}
const along=(r,f)=>{const d=f*r.len;let i=1;while(i<r.acc.length-1&&r.acc[i]<d)i++;const a=r.pts[i-1],b=r.pts[i]??a,seg=(r.acc[i]-r.acc[i-1])||1,t=Math.max(0,Math.min(1,(d-r.acc[i-1])/seg));return {x:a.x+(b.x-a.x)*t,y:a.y+(b.y-a.y)*t,heading:Math.atan2(b.y-a.y,b.x-a.x)};};

// What a person does at a minute: the activity, or a trip (on foot or by car) between two places.
export function activityAt(c,minute,day,opts={}){const plan=dayPlan(c,day,opts),p=places(c);let cur=plan[0],prev=null;for(const e of plan){if(e[0]<=minute){prev=cur;cur=e;}else break;}
 const loc=a=>p[AT[a]]??p.home,from=prev&&prev!==cur?loc(prev[1]):loc(cur[1]),to=loc(cur[1]);
 if(from.id!==to.id&&minute>=cur[0]){const straight=Math.hypot(from.x-to.x,from.y-to.y)*MAP_METRES,car=straight>CITYDAY.carFrom&&c.age>=18&&c.age<=78&&mix(c.id,31)<.65,kmh=car?CITYDAY.carKmh:CITYDAY.walkKmh,minutes=Math.max(3,straight*1.3/1000/kmh*60);
  if(minute<cur[0]+minutes)return {activity:cur[1],trip:true,car,from,to,start:cur[0],minutes,until:cur[0]+minutes,progress:(minute-cur[0])/minutes,text:`${car?'едет':'идёт'} ${tripText(cur[1])}`};}
 const next=plan.find(e=>e[0]>minute);return {activity:cur[1],trip:false,at:to,until:next?next[0]:1440,text:ACT[cur[1]]??cur[1]};}
const tripText=a=>({home:'домой',work:'на работу',school:'в школу',study:'на занятия',shop:'в магазин',walk:'на прогулку',visit:'в гости',bar:'в бар',gym:'в спортзал',kindergarten:'в садик'})[a]??'';

// Needs, 0–100 (100 = all is well), from the day so far.
export function needsAt(c,minute,day,opts={}){const plan=dayPlan(c,day,opts),k=kindOf(c);let slept=90,lastMeal=-300,company=50,fun=50,wake=plan.find(e=>e[1]!=='sleep')?.[0]??420;
 for(let i=0;i<plan.length;i++){const [t,a]=plan[i],end=Math.min(minute,plan[i+1]?.[0]??1440);if(t>minute)break;const span=Math.max(0,end-t);
  if(a==='sleep'&&t===0)slept=span;if(a!=='sleep'){for(const m of [Math.max(wake+30,7*60),12*60+30,19*60])if(m>=t&&m<end)lastMeal=Math.max(lastMeal,m);}
  if(['visit','bar'].includes(a))company=Math.min(100,company+span/2);if(['work','school','study'].includes(a))company=Math.min(100,company+span/12);if(['walk','visit','bar','gym'].includes(a))fun=Math.min(100,fun+span/2);if(['work','study'].includes(a))fun=Math.max(0,fun-span/20);}
 if(c.traits?.includes('lonely'))company=Math.max(0,company-25);
 const awake=Math.max(0,minute-wake),energy=Math.max(0,Math.min(100,Math.min(100,slept/4.8)-awake/18)),hunger=Math.max(0,Math.min(100,100-Math.max(0,minute-Math.max(lastMeal,minute<wake?minute:lastMeal))/5)),money=k==='jobless'?25:k==='pensioner'?45:k==='pupil'||k==='child'?70:/директор|врач|программист|юрист/.test(c.job)?85:60;
 return {energy:Math.round(energy),hunger:Math.round(hunger),company:Math.round(company),fun:Math.round(fun),money};}
export const NEED_TEXT=Object.freeze({energy:'Бодрость',hunger:'Сытость',company:'Общение',fun:'Отдых',money:'Деньги'});
// Why a person does what they do: the lowest need, in words.
export function motiveText(c,act,needs){const why={shop:needs.hunger<50?'закончились продукты':'нужно в магазин',walk:needs.fun<50?'хочет развеяться':'дышит воздухом',visit:needs.company<50?'соскучился по друзьям':'зовут в гости',bar:needs.money<40?'тратит последние деньги':'хочет отдохнуть',sleep:'устал за день',work:needs.money<50?'нужны деньги':'по графику',home:needs.energy<30?'еле держится на ногах':'отдыхает дома'}[act.activity];return why??'';}

const people=[],memo=[],boxes=[];
const bounds=c=>boxes[c.id-CITIZEN_BASE]??(boxes[c.id-CITIZEN_BASE]=(v=>[Math.min(...v.map(n=>n.x)),Math.min(...v.map(n=>n.y)),Math.max(...v.map(n=>n.x)),Math.max(...v.map(n=>n.y))])(Object.values(places(c))));
const segment=(p,a,b)=>{const dx=b.x-a.x,dy=b.y-a.y,l=dx*dx+dy*dy||1,t=Math.max(0,Math.min(1,((p.x-a.x)*dx+(p.y-a.y)*dy)/l));return Math.hypot(a.x+dx*t-p.x,a.y+dy*t-p.y);};const person=k=>people[k]??(people[k]=citizen(CITIZEN_BASE+k));
// People outside near the camera: walkers and drivers on the streets, for the map.
export function streetLife(elapsed,focus,{rain=false,limit=CITYDAY.visible,radius=CITYDAY.radius,routes=2}={}){budget=routes;if(!focus||!Number.isFinite(focus.x))return [];const {minute,day}=cityClock(elapsed),out=[];
 for(let k=0;k<CITYDAY.pool;k++){const c=person(k);if(!c)continue;const box=bounds(c);if(focus.x<box[0]-radius||focus.x>box[2]+radius||focus.y<box[1]-radius||focus.y>box[3]+radius)continue;let a=memo[k];if(!a||a.day!==day||a.rain!==rain||minute>=a.until||minute<a.since){a=activityAt(c,minute,day,{rain});a.day=day;a.rain=rain;a.since=minute;memo[k]=a;}if(a.trip)a.progress=(minute-a.start)/a.minutes;let pos=null;
  if(a.trip){if(segment(focus,a.from,a.to)>radius*1.3)continue;const r=route(a.from,a.to);if(!r)continue;pos=along(r,a.progress);}
  else if(a.activity==='walk'){if(Math.hypot(a.at.x-focus.x,a.at.y-focus.y)>radius)continue;const r=route(a.at,places(c).shop);if(!r)continue;const f=Math.min(1,.0035/(r.len||1))*(.5-.5*Math.cos(2*Math.PI*(minute+c.id%40)/40));pos=along(r,f);}
  else continue;
  const d=Math.hypot(pos.x-focus.x,pos.y-focus.y);if(d>radius)continue;out.push({id:c.id,name:c.name,x:pos.x,y:pos.y,heading:pos.heading,car:!!a.car&&a.trip,status:a.text,d});}
 return out.sort((a,b)=>a.d-b.d).slice(0,limit);}
/* Performance (audit 17.10: routing walkers every frame cost 50+ ms in QuickJS on the phone): a plan of the people
   near the camera keeps each person's route; positions between plans are cheap (no routing). */
export function streetPlan(elapsed,focus,{rain=false,limit=CITYDAY.visible,radius=CITYDAY.radius,routes=1}={}){budget=routes;if(!focus||!Number.isFinite(focus.x))return [];const {minute,day}=cityClock(elapsed),out=[];
 for(let k=0;k<CITYDAY.pool;k++){const c=person(k);if(!c)continue;const box=bounds(c);if(focus.x<box[0]-radius||focus.x>box[2]+radius||focus.y<box[1]-radius||focus.y>box[3]+radius)continue;let a=memo[k];if(!a||a.day!==day||a.rain!==rain||minute>=a.until||minute<a.since){a=activityAt(c,minute,day,{rain});a.day=day;a.rain=rain;a.since=minute;memo[k]=a;}
  let r=null,walk=false;if(a.trip){if(segment(focus,a.from,a.to)>radius*1.3)continue;r=route(a.from,a.to);}else if(a.activity==='walk'){if(Math.hypot(a.at.x-focus.x,a.at.y-focus.y)>radius)continue;r=route(a.at,places(c).shop);walk=true;}else continue;if(!r)continue;
  const e={id:c.id,name:c.name,car:!!a.car&&a.trip,status:a.text,r,walk,start:a.start??0,minutes:a.minutes??1,until:a.until,day,seed:c.id%40};const p=planPosition(e,minute);const d=Math.hypot(p.x-focus.x,p.y-focus.y);if(d>radius*1.2)continue;e.d=d;out.push(e);}
 return out.sort((a,b)=>a.d-b.d).slice(0,limit);}
export function planPosition(e,minute){if(e.walk){const f=Math.min(1,.0035/(e.r.len||1))*(.5-.5*Math.cos(2*Math.PI*(minute+e.seed)/40));return along(e.r,f);}return along(e.r,Math.max(0,Math.min(1,(minute-e.start)/e.minutes)));}
/* true when the last streetLife ran out of its route budget: call again to fill the street */
export const streetPending=()=>budget<=0;
export const validCityday=()=>true;
