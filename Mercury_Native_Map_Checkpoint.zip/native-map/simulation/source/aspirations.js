// Release S1 «Мечта» (Claude, 17.10.2026). Roadmap S, owner 16.10: «долгая цель, смысл играть месяцами». Like the
// aspirations of The Sims: the player picks what the hero lives for, sees the way there, and when it comes true the
// hero is happier (stress and debt of sleep go down), the city paper writes about it and the next dream can be chosen.
import {owns} from './service2.js';
import {skillLevel} from './promotion.js';
const pct=v=>Math.max(0,Math.min(1,v));
export const ASPIRATIONS=Object.freeze({
 commissar:Object.freeze({label:'Дослужиться до высшего звания',about:'С самых низов — до комиссара (или высшего звания своей службы).',progress:s=>pct((s.rank??0)/4),done:s=>(s.rank??0)>=4}),
 flat:Object.freeze({label:'Своя квартира',about:'Перестать снимать: первый взнос 15 000 € и своя квартира.',progress:s=>owns(s.life,'apartment')?1:pct((s.life?.money??0)/15000),done:s=>owns(s.life,'apartment')}),
 savings:Object.freeze({label:'Подушка безопасности',about:'10 000 € на счёте — на чёрный день.',progress:s=>pct((s.life?.money??0)/10000),done:s=>(s.life?.money??0)>=10000}),
 master:Object.freeze({label:'Мастер своего дела',about:'Довести любой навык до 8 из 10.',progress:s=>pct(Math.max(0,...Object.values(s.life?.skills??{}).map(skillLevel))/8),done:s=>Math.max(0,...Object.values(s.life?.skills??{}).map(skillLevel))>=8}),
 clean:Object.freeze({label:'Год без единого замечания',about:'Двенадцать месяцев подряд без выговоров и опозданий по три за месяц.',progress:s=>{const l=s.life??{},from=Math.max(l.breachMonth??0,l.aspiration?.month??0);return pct(((l.months??0)-from)/12);},done:s=>{const l=s.life??{},from=Math.max(l.breachMonth??0,l.aspiration?.month??0);return (l.months??0)-from>=12;}}),
 fit:Object.freeze({label:'Лучшая форма в отделе',about:'Физподготовка 90 и выше.',progress:s=>pct((s.life?.fitness??0)/90),done:s=>(s.life?.fitness??0)>=90})
});
export const ASPIRATION_IDS=Object.freeze(Object.keys(ASPIRATIONS));
export const DREAM=Object.freeze({stress:-25,sleep:-15});
export function chooseAspiration(s,id){const l=s.life;if(s.mode!=='career'||!l)return {ok:false,message:'Мечта — в карьере.'};const a=ASPIRATIONS[id];if(!a)return {ok:false,message:'Нет такой мечты.'};
 if((l.dreams??[]).includes(id))return {ok:false,message:'Это уже сбылось.'};l.aspiration={id,shift:s.shift,month:l.months??0};return {ok:true,message:`Мечта: ${a.label}.`};}
// After a shift: has the dream come true?
export function checkAspiration(s){const l=s.life,a=l?.aspiration&&ASPIRATIONS[l.aspiration.id];if(!a||!a.done(s))return null;
 l.dreams=[...(l.dreams??[]),l.aspiration.id].slice(-ASPIRATION_IDS.length);l.aspiration=null;l.stress=Math.max(0,(l.stress??0)+DREAM.stress);l.sleepDebt=Math.max(0,(l.sleepDebt??0)+DREAM.sleep);return a;}
export const validAspiration=l=>(l?.aspiration===undefined||l.aspiration===null||(ASPIRATION_IDS.includes(l.aspiration.id)&&Number.isInteger(l.aspiration.shift)&&Number.isInteger(l.aspiration.month)))&&(l?.dreams===undefined||Array.isArray(l.dreams)&&l.dreams.every(id=>ASPIRATION_IDS.includes(id)));
