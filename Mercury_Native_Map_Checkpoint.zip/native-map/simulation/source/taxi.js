// Release J1 «Такси» (Claude, 18.10.2026). Owner 16.10: «таксистом — как работа»; roadmap 4 J1: a full job, not a side
// evening. The driver works a 12-hour shift in an app (Bolt / Forus-like): orders appear with the pickup, the
// destination and the estimated fare; the driver accepts one, drives to the passenger, waits for them to board, drives
// them across Meridian and gets the fare minus the app commission, a rating and sometimes a tip. The people are the
// town's: a pensioner to the clinic, a drunk group from a bar at night, a runner who leaves without paying (the police
// get the report), a passenger who feels unwell (the hospital). Prices of a small Estonian town in 2026 (Pärnu: start
// about 2.5 €, about 0.75 €/km and 0.2 €/min; the app keeps about a fifth). The rank of a taxi driver is the class of
// orders he gets, earned by rides and rating; no attestation and no salary — he lives on fares.
import {ROAD_NODES} from './geography.js';
import {MAP_METRES} from './world-scale.js';
import {WORLD_SECONDS_PER_TICK_SECOND} from './transport.js';
export const TAXI_SERVICE='taxi';
export const isTaxi=s=>s?.agency===TAXI_SERVICE;
export const TAXI=Object.freeze({start:2.5,perKm:.75,perMin:.2,minimum:4,cut:.2,fuelPerKm:.09,open:4,expire:30,board:2,waitLate:8,gap:[22,38],nightGap:[28,46],tip:.18});
export const TAXI_RANKS=Object.freeze(['Водитель такси','Водитель с высоким рейтингом','Водитель комфорт-класса','Старший водитель парка','Своё такси (лицензия)']);
export const TAXI_PERMISSIONS=Object.freeze(['Заказы эконом','Приоритет заказов','Комфорт-заказы и аэропорт','Наставник новых водителей','Свой парк и тариф']);
// Rank by rides and rating: the app gives better orders to drivers it trusts.
export const TAXI_LADDER=Object.freeze([{rides:0,rating:0},{rides:40,rating:4.6},{rides:120,rating:4.7},{rides:260,rating:4.8},{rides:450,rating:4.85}]);
const tickMin=t=>t*WORLD_SECONDS_PER_TICK_SECOND/60;
const minTicks=m=>m*60/WORLD_SECONDS_PER_TICK_SECOND;
const hash=(a,b)=>{let h=Math.imul((a|0)+0x6b43,2654435761)^Math.imul((b|0)+0x2f1d,2246822519);h^=h>>>15;h=Math.imul(h,2246822519);return ((h^h>>>13)>>>0)/4294967296;};
// Who rides: a short line about the passenger and what happens on the way.
export const PASSENGERS=Object.freeze([
 {kind:'normal',who:'Пенсионерка с сумкой',to:'в поликлинику',weight:5},
 {kind:'normal',who:'Студентка колледжа',to:'на занятия',weight:5},
 {kind:'normal',who:'Мужчина в рабочей куртке',to:'на смену в порт',weight:4},
 {kind:'normal',who:'Семья с чемоданами',to:'на автовокзал',weight:3},
 {kind:'normal',who:'Турист из Финляндии',to:'в спа-отель',weight:3},
 {kind:'night',who:'Компания после бара',to:'домой',weight:3,night:true},
 {kind:'drunk',who:'Сильно выпивший мужчина',to:'«куда-нибудь домой»',weight:2,night:true},
 {kind:'runner',who:'Парень в капюшоне',to:'к гаражам',weight:1},
 {kind:'medical',who:'Пожилой мужчина, держится за грудь',to:'«домой, отлежусь»',weight:1},
 {kind:'far',who:'Бизнесмен с ноутбуком',to:'в аэропорт',weight:1,far:true}
]);
const NAMES=['Айно','Тийу','Кристьян','Марек','Ольга','Хенри','Лийза','Сергей','Карин','Пеэтер','Вера','Рауль','Майя','Индрек'];
export function newTaxi(){return {orders:[],next:4,seq:1,stats:{rides:0,earned:0,km:0,ratingSum:0,ratings:0,tips:0,unpaid:0},shift:{rides:0,earned:0,km:0}};}
export function ensureTaxi(s){if(!isTaxi(s))return null;if(!s.taxi||typeof s.taxi!=='object')s.taxi=newTaxi();return s.taxi;}
export const taxiRating=t=>t?.stats?.ratings?Math.round(t.stats.ratingSum/t.stats.ratings*100)/100:5;
export function taxiRank(t){const r=taxiRating(t),n=t?.stats?.rides??0;let k=0;for(let i=1;i<TAXI_LADDER.length;i++)if(n>=TAXI_LADDER[i].rides&&r>=TAXI_LADDER[i].rating)k=i;return k;}
const distKm=(a,b)=>Math.hypot(a.x-b.x,a.y-b.y)*MAP_METRES*1.3/1000;
export function estimateFare(km,minutes){return Math.max(TAXI.minimum,Math.round((TAXI.start+TAXI.perKm*km+TAXI.perMin*minutes)*100)/100);}
// A new order: a pickup and a destination on the road graph, a passenger, the estimate.
export function makeOrder(s,night=false){const t=ensureTaxi(s),k=t.seq++,h=n=>hash(s.seed+k*31,n);
 const pool=PASSENGERS.filter(p=>!p.night||night),total=pool.reduce((n,p)=>n+p.weight,0);let r=h(1)*total,pass=pool[0];for(const p of pool){r-=p.weight;if(r<=0){pass=p;break;}}
 const from=ROAD_NODES[Math.floor(h(2)*ROAD_NODES.length)];let to=ROAD_NODES[Math.floor(h(3)*ROAD_NODES.length)];
 for(let i=4;i<12&&distKm(from,to)<(pass.far?3:.7);i++)to=ROAD_NODES[Math.floor(h(i)*ROAD_NODES.length)];
 const km=Math.round(distKm(from,to)*(pass.far?2.2:1)*10)/10,minutes=Math.round(km/28*60)+3;
 return {id:k,from:{x:from.x,y:from.y},to:{x:to.x,y:to.y},kind:pass.kind,who:`${pass.who} (${NAMES[Math.floor(h(5)*NAMES.length)]})`,where:pass.to,km,fare:estimateFare(km,minutes),expires:s.time+minTicks(TAXI.expire),created:s.time};}
// Every tick: new orders from the app, old ones expire.
export function taxiTick(s,dt,{night=false,load=1}={}){const t=ensureTaxi(s);if(!t)return;t.next-=dt;
 t.orders=t.orders.filter(o=>o.expires>s.time);
 if(t.next<=0){if(t.orders.length<TAXI.open)t.orders.push(makeOrder(s,night));const g=night?TAXI.nightGap:TAXI.gap;t.next=minTicks((g[0]+hash(s.seed,t.seq)*(g[1]-g[0]))/Math.max(.5,load));}}
// The driver takes an order.
export function acceptOrder(s,u,id){const t=ensureTaxi(s);if(!t||!u)return {ok:false,message:'Заказы — в работе такси.'};if(u.ride)return {ok:false,message:'Сначала довезите пассажира.'};
 const o=t.orders.find(x=>x.id===id);if(!o)return {ok:false,message:'Заказ уже снят.'};t.orders=t.orders.filter(x=>x!==o);
 u.ride={...o,phase:'pickup',accepted:s.time,timer:0};return {ok:true,message:`Заказ принят: ${o.who}, ${o.km} км, ~${o.fare.toFixed(2)} €.`};}
export function declineOrder(s,id){const t=ensureTaxi(s);if(!t)return {ok:false,message:'Нет заказов.'};const before=t.orders.length;t.orders=t.orders.filter(x=>x.id!==id);return before>t.orders.length?{ok:true,message:'Заказ пропущен.'}:{ok:false,message:'Заказ уже снят.'};}
// The ride, step by step. route(u,p) sets the route; at(u,p) tells whether the car is there; returns lines for the log.
export function taxiUnit(s,u,dt,{route,at,auto=true}){const t=ensureTaxi(s);const lines=[];if(!t)return {lines};
 const r=u.ride;
 if(!r){if(auto&&!u.route?.length&&t.orders.length){const near=[...t.orders].sort((a,b)=>Math.hypot(a.from.x-u.x,a.from.y-u.y)-Math.hypot(b.from.x-u.x,b.from.y-u.y))[0];const res=acceptOrder(s,u,near.id);if(res.ok){route(u,near.from);lines.push(res.message);}}return {lines};}
 if(r.phase==='pickup'){if(!u.route?.length&&!at(u,r.from))route(u,r.from);if(at(u,r.from)&&!u.route?.length){r.phase='board';r.timer=minTicks(TAXI.board);r.waited=Math.round(tickMin(s.time-r.accepted));lines.push(`Подъехали: ${r.who}${r.waited>TAXI.waitLate?` — ожидание ${r.waited} мин, оценка будет ниже`:''}.`);}return {lines};}
 if(r.phase==='board'){r.timer-=dt;if(r.timer<=0){r.phase='ride';r.start=s.time;
   if(r.kind==='medical'){r.to={...HOSPITAL_POINT()};r.km=Math.round(distKm(r.from,r.to)*10)/10;r.where='в больницу — пассажиру плохо';lines.push('Пассажиру плохо: бледный, держится за грудь. Едем в больницу, звоним 112 по дороге.');}
   route(u,r.to);lines.push(`Поехали ${r.where}.`);}return {lines};}
 if(r.phase==='ride'){if(!u.route?.length&&!at(u,r.to))route(u,r.to);if(!u.route?.length&&at(u,r.to)){const minutes=Math.max(1,Math.round(tickMin(s.time-r.start))),km=Math.max(.5,r.km);
   let fare=estimateFare(km,minutes),paid=fare,tip=0,rating=5,h=hash(r.id,s.seed);
   if((r.waited??0)>TAXI.waitLate)rating-=1;if(r.kind==='drunk'){rating-=h<.3?1:0;}if(r.kind==='medical')rating=5;
   if(r.kind==='runner'&&h<.7){paid=0;t.stats.unpaid++;lines.push(`Пассажир убежал, не заплатив ${fare.toFixed(2)} €. Сообщили в полицию: приметы и маршрут.`);}
   else if(h>1-TAXI.tip&&rating>=5){tip=Math.round((1+h*4)*2)/2;}
   const net=Math.round((paid*(1-TAXI.cut)+tip-km*TAXI.fuelPerKm)*100)/100;
   t.stats.rides++;t.stats.earned=Math.round((t.stats.earned+net)*100)/100;t.stats.km=Math.round((t.stats.km+km)*10)/10;t.stats.tips=Math.round((t.stats.tips+tip)*100)/100;
   if(paid>0){t.stats.ratingSum+=Math.max(1,rating);t.stats.ratings++;}
   t.shift.rides++;t.shift.earned=Math.round((t.shift.earned+net)*100)/100;t.shift.km=Math.round((t.shift.km+km)*10)/10;
   if(paid>0)lines.push(`Довезли: ${km} км, ${minutes} мин, ${fare.toFixed(2)} €${tip?` + чаевые ${tip} €`:''}. Вам после комиссии и бензина: ${net.toFixed(2)} €. Оценка ${Math.max(1,rating)}★.`);
   u.ride=null;return {lines,net,kind:r.kind,paid:paid>0};}
  return {lines};}
 return {lines};}
let hospitalPoint=null;
export const setTaxiHospital=p=>{hospitalPoint=p;};
const HOSPITAL_POINT=()=>hospitalPoint??{x:3.24,y:2.45};
// What the driver is doing, for the crew card.
export function taxiReason(s,u){const t=s.taxi,r=u?.ride;if(!r)return t?.orders?.length?`Свободны. В приложении заказов: ${t.orders.length} — примите во вкладке «Заказы».`:'Свободны: ждём заказ в приложении.';
 return r.phase==='pickup'?`Заказ №${r.id}: едем за пассажиром (${r.who}).`:r.phase==='board'?`Пассажир садится: ${r.who}.`:`Везём ${r.where}: ${r.who}, ~${r.fare.toFixed(2)} €.`;}
export function validTaxi(s){const t=s.taxi;if(t===undefined)return true;if(!isTaxi(s)||!t||typeof t!=='object'||!Array.isArray(t.orders)||t.orders.length>8||!Number.isFinite(t.next)||!Number.isInteger(t.seq))return false;
 const st=t.stats,n=(x,a,b)=>Number.isFinite(x)&&x>=a&&x<=b;return !!st&&n(st.rides,0,1e6)&&n(st.earned,-1e6,1e8)&&n(st.ratingSum,0,5e6)&&n(st.ratings,0,1e6)&&t.orders.every(o=>o&&Number.isInteger(o.id)&&n(o.km,0,200)&&n(o.fare,0,1000)&&typeof o.who==='string');}
