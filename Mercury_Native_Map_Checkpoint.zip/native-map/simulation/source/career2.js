// Release C «Карьера и отделение 2.0» (Claude, 12.10.2026). A long campaign with understandable growth.
//  · Задача смены: a career officer from the rank «Сержант» (runs the shift, PPA «välijuht») or the chief
//    sets the focus of the shift at the briefing: balanced, prevention, fast response or road safety.
//  · Аттестация: every six months the officer gets a service review (PPA development interview) with a
//    grade, a premium and consequences.
//  · Жизнь вне службы: from time to time a real-life situation needs a decision (a sick child, a broken
//    car, a wedding, a side job that needs the employer's permission, a «favour» for a neighbour).
//  · Мэрия: at every month close the chief meets the city: ask for money, promise results, or report.
//  · Моральный дух: department morale from stress, fatigue, complaints and support; at very low morale
//    exhausted officers resign — the PPA really is short of front-line staff (ERR: 200–300 people).
//  · Рынок кандидатов: new applicants every month, not a fixed list.
//  · Полицейский года: the year closes with a summary and an award.
// All draws are hashes of seed and shift/month (no rng). Roster campaigns only.
import {DISTRICT_IDS} from './calls.js';
const hash=(a,b)=>{let h=Math.imul((a|0)+613,2654435761)^Math.imul((b|0)+59,1597334677);h^=h>>>15;h=Math.imul(h,2246822519);return ((h^h>>>13)>>>0)/4294967296;};
// ── Задача смены ───────────────────────────────────────────────────────────────────────────────
export const FOCUS=Object.freeze({
 balanced:{label:'Обычный режим',about:'Экипажи берут вызовы и в спокойное время работают между вызовами.',task:1},
 prevention:{label:'Профилактика',about:'Больше пеших обходов и разговоров с жителями: доверие районов растёт быстрее, мелких нарушений меньше.',task:2,prefer:'foot-patrol',district:1.3},
 response:{label:'Быстрое реагирование',about:'Никаких заданий между вызовами: все экипажи свободны для вызовов, отклик быстрее.',task:0},
 traffic:{label:'Безопасность дорог',about:'Рейды на трезвость и контроль скорости: меньше пьяных водителей и ДТП в эту смену.',task:2,prefer:'traffic',prevent:{'drunk-driver':.75,crash:.85,'dangerous-driving':.75}}
});
export const FOCUS_IDS=Object.freeze(Object.keys(FOCUS));
export const FOCUS_RANK=3;// «Сержант» (game rank 3) leads the shift
export const canSetFocus=(s)=>s?.schedule==='ppa'&&(s.mode==='chief'||(s.rank??0)>=FOCUS_RANK);
// ── Аттестация (каждые 6 месяцев) ─────────────────────────────────────────────────────────────
export const ATTEST=Object.freeze({every:6,limit:6,grades:{A:{min:90,xp:200,money:300,label:'Отлично — рекомендован к повышению'},B:{min:75,xp:100,money:150,label:'Хорошо'},C:{min:60,xp:0,money:0,label:'Удовлетворительно'},D:{min:0,xp:0,money:0,stress:15,label:'Неудовлетворительно — план исправления'}}});
export function attestation({resolved=0,missed=0,founded=0,coursesOk=true,bond=50,awards=0}){const rate=resolved+missed?resolved/(resolved+missed):1;
 const score=Math.round(rate*60+(founded===0?15:Math.max(0,15-founded*5))+(coursesOk?10:0)+(bond>=60?5:0)+Math.min(10,awards*5));
 const grade=score>=90?'A':score>=75?'B':score>=60?'C':'D';return {score,grade,rate:Math.round(rate*100)};}
// ── Жизнь вне службы ───────────────────────────────────────────────────────────────────────────
// fx: money (€), stress, sleep, bond, health (paid health days used), xp, integrity (true = an
// integrity breach — internal control finds out).
export const LIFE_EVENTS=Object.freeze({
 'kid-sick':{title:'Заболел ребёнок',text:'Утром температура 39. Садик не примет, а жена тоже на смене.',options:[
  {id:'health',label:'Взять день здоровья',fx:{health:1,stress:-5},hint:'оплачиваемый, если остались'},
  {id:'grandma',label:'Попросить бабушку посидеть',fx:{stress:8,money:-20},hint:'поедешь на смену нервным'}]},
 'car-broke':{title:'Сломалась своя машина',text:'Коробка передач. Мастер просит 320 €.',options:[
  {id:'repair',label:'Отремонтировать',fx:{money:-320}},
  {id:'bus',label:'Пока ездить на автобусе',fx:{stress:6,sleep:8},hint:'дольше дорога на смену'}]},
 wedding:{title:'Свадьба друга',text:'Лучший друг женится в твои выходные, зовёт свидетелем.',options:[
  {id:'go',label:'Пойти',fx:{money:-150,stress:-20,sleep:10}},
  {id:'skip',label:'Отказаться: нужно отдохнуть',fx:{stress:6,sleep:-10}}]},
 'side-job':{title:'Подработка',text:'Знакомый предлагает выходные охранником в клубе за 200 €.',options:[
  {id:'permit',label:'Спросить разрешение начальства и взять',fx:{money:200,sleep:15,stress:5},hint:'законно: побочная работа — только с разрешения'},
  {id:'quiet',label:'Взять без разрешения',fx:{money:200,sleep:15,integrity:true},hint:'нарушение служебной дисциплины'},
  {id:'no',label:'Отказаться',fx:{}}]},
 favour:{title:'«По-дружески»',text:'Сосед просит «потерять» протокол на его сына: «Мы же свои люди».',options:[
  {id:'refuse',label:'Отказать: закон для всех один',fx:{stress:4,xp:20}},
  {id:'agree',label:'Помочь соседу',fx:{integrity:true,stress:-2}}]},
 'course-offer':{title:'Место на курсе',text:'Освободилось место на курсе переговоров — можно пройти день вне очереди.',options:[
  {id:'take',label:'Пойти на курс',fx:{course:'negotiation',sleep:8}},
  {id:'no',label:'Не сейчас',fx:{}}]},
 'old-friend':{title:'Старый друг из академии',text:'Однокурсник зовёт на рыбалку: давно не виделись.',options:[
  {id:'go',label:'Поехать',fx:{stress:-15,money:-30}},
  {id:'no',label:'Дома дела',fx:{}}]}
});
export const LIFE_EVENT_IDS=Object.freeze(Object.keys(LIFE_EVENTS));
export const LIFE_EVENT_EVERY=6;// about one situation per six shifts
export const lifeEventFor=(seed,shift)=>hash(seed,shift*7)<1/LIFE_EVENT_EVERY?LIFE_EVENT_IDS[Math.floor(hash(shift,seed)*LIFE_EVENT_IDS.length)]:null;
export const INTEGRITY=Object.freeze({xp:-150,stress:15,trust:-2});
// ── Мэрия (начальник, каждый месяц) ───────────────────────────────────────────────────────────
export const COUNCIL=Object.freeze({
 ask:{label:'Просить больше денег',about:'При доверии города от 80% — +1500 к бюджету, иначе только +400 и недовольство мэрии.',high:80,big:1500,small:400},
 promise:{label:'Пообещать меньше срывов',about:'Если в следующем месяце сорванных вызовов будет вдвое меньше лимита плана — +1800, иначе доверие −3.',reward:1800,penalty:-3},
 report:{label:'Просто отчитаться',about:'Спокойная встреча: +300 и немного доверия.',money:300,trust:1}
});
export const COUNCIL_IDS=Object.freeze(Object.keys(COUNCIL));
// ── Моральный дух ──────────────────────────────────────────────────────────────────────────────
export function morale(s){const os=s.officers??[];if(!os.length)return 70;const avg=k=>os.reduce((n,o)=>n+(o[k]??0),0)/os.length;
 let m=100-avg('stress')*.75-avg('fatigue')*.2-(s.stats?.monthFounded??0)*6+((s.upgrades??[]).includes('restroom')?6:0)+((s.upgrades??[]).includes('training')?4:0)+(s.policy==='strict'?-5:s.policy==='prevention'?3:0);return Math.round(Math.max(0,Math.min(100,m)));}
export const MORALE=Object.freeze({quit:35,quitStress:85,good:70,goodPace:1.04,quitGap:12});/* quitGap: at most one resignation per ~two months of shifts */
// ── Рынок кандидатов ───────────────────────────────────────────────────────────────────────────
const FIRST=['Карл','Мирья','Олег','Пирет','Антон','Лаура','Сергей','Кадри','Райво','Анастасия','Тынис','Дарья'],LAST=['Сааг','Пыльд','Ковалев','Мянд','Ильвес','Петрова','Раудсепп','Кузнецов','Тамм','Лаур'];
const SPEC=['Переговоры','Вождение','Дорожная полиция','Патрулирование','Поиск','Проверка обстоятельств'];
export function newCandidates(seed,monthKey,taken,count=3){const out=[];for(let k=0;k<count;k++){const r=hash(seed+monthKey*13,k),name=`${FIRST[Math.floor(r*FIRST.length)]} ${LAST[Math.floor(hash(monthKey,k+seed)*LAST.length)]}`;if(taken.has(name))continue;taken.add(name);
 const skill=Math.round((.62+hash(k,monthKey)*.3)*100)/100;out.push({id:1000+(monthKey%1000)*10+k,name,specialty:SPEC[Math.floor(hash(seed,monthKey+k)*SPEC.length)],skill,fee:Math.round(150+skill*300),salary:Math.round(25+skill*30)});}return out;}
// ── Валидация ──────────────────────────────────────────────────────────────────────────────────
const int=x=>Number.isInteger(x)&&x>=0&&x<1e7;
export function validCareer2(s){const l=s.life;
 if(s.shiftFocus!==undefined&&!Object.hasOwn(FOCUS,s.shiftFocus))return false;
 if(s.council!==undefined&&!(s.council&&Object.hasOwn(COUNCIL_IDS.reduce((o,k)=>(o[k]=1,o),{pending:1}),s.council.choice??'pending')&&int(s.council.month)&&typeof s.council.label==='string'&&s.council.label.length<=30))return false;
 if(s.lastQuit!==undefined&&!int(s.lastQuit))return false;
 if(s.stats?.ownFounded!==undefined&&!int(s.stats.ownFounded))return false;
 if(s.promise!==undefined&&!(s.promise&&int(s.promise.month)&&int(s.promise.limit)))return false;
 if(l?.event!==undefined&&l.event!==null&&!(Object.hasOwn(LIFE_EVENTS,l.event.id)&&int(l.event.shift)))return false;
 if(l?.attestations!==undefined&&!(Array.isArray(l.attestations)&&l.attestations.length<=ATTEST.limit&&l.attestations.every(a=>a&&['A','B','C','D'].includes(a.grade)&&int(a.score)&&typeof a.label==='string'&&a.label.length<=30)))return false;
 return true;}
export {DISTRICT_IDS};
