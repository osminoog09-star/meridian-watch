// R16 «Напарник» (Claude, 11.10.2026). A rookie rides with a field training officer; once the probation
// ends (rank «Патрульный»), the mentor leaves and the department pairs the player with a regular
// partner who has a character of their own. The pair has a bond: good shifts together build it, failed
// calls and founded complaints wear it down, an evening out together helps. A strong bond makes the
// crew work a little faster; a broken one ends with a transfer request. Career roster campaigns only.
// Names are fictional. No rng: the next partner is picked by a hash of the seed and the shift.
export const MENTOR=Object.freeze({name:'Алексей Морозов',trait:'mentor'});
export const TRAITS=Object.freeze({
 mentor:{label:'Наставник',about:'Ведёт стажировку: подсказывает и разбирает решения.'},
 calm:{label:'Спокойный переговорщик',about:'Разговоры, конфликты и семейные вызовы идут на 10% быстрее.',types:[0,4]},
 driver:{label:'Водитель-ас',about:'Остановки, погони и дорожные вызовы на 10% быстрее.',types:[1,5]},
 sharp:{label:'Глазастый',about:'Поиск людей и кражи на 10% быстрее.',types:[2,3]},
 steady:{label:'По инструкции',about:'Всё оформляет без ошибок: жалоб на экипаж на 30% меньше.',complaints:.7}
});
export const PARTNERS=Object.freeze([
 {name:'Кристина Сепп',trait:'calm'},{name:'Марко Кукк',trait:'driver'},{name:'Ольга Мяги',trait:'sharp'},
 {name:'Тимур Лаас',trait:'steady'},{name:'Яна Орлова',trait:'calm'},{name:'Рейн Каск',trait:'driver'}
]);
export const BOND=Object.freeze({start:50,newPartner:40,perCall:.4,callsCap:6,missed:-1,missedCap:-5,founded:-8,activity:12,strong:75,weak:25,transfer:15,strongPace:1.06,weakPace:.94,traitPace:1.1,probation:12});
const clamp=v=>Math.max(0,Math.min(100,v));
export const RESCUE_MENTOR=Object.freeze({name:'Тарас Кульбок',trait:'mentor'});/* Release H: the team leader who takes the trainee rescuer */
export const EMS_MENTOR=Object.freeze({name:'Мерле Таль',trait:'mentor'});/* Release I: the senior of the brigade who takes the trainee */
export const DISPATCH_MENTOR=Object.freeze({name:'Сирье Кукк',trait:'mentor'});/* Release J: the senior operator next to the trainee */
export const mentorOf=life=>life?.agency==='rescue'?RESCUE_MENTOR:life?.agency==='ems'?EMS_MENTOR:life?.agency==='dispatch'?DISPATCH_MENTOR:MENTOR;/* J2: the service's mentor, also before the partner record exists */
export function ensurePartner(life){if(!life)return null;if(!life.partner||typeof life.partner!=='object'){const m=mentorOf(life);life.partner={name:m.name,trait:m.trait,bond:BOND.start,since:1,low:0};}return life.partner;}
export const nextPartner=(seed,shift,current)=>{const list=PARTNERS.filter(p=>p.name!==current);let h=Math.imul((seed|0)+71,2654435761)^Math.imul((shift|0)+3,40503);h^=h>>>15;return list[(h>>>0)%list.length];};
// Pace of the player's own crew: bond and the partner's trait.
export function partnerPace(p,type){if(!p)return 1;let f=p.bond>=BOND.strong?BOND.strongPace:p.bond<BOND.weak?BOND.weakPace:1;if(TRAITS[p.trait]?.types?.includes(type))f*=BOND.traitPace;return f;}
export const partnerComplaints=p=>TRAITS[p?.trait]?.complaints??1;
// After a shift: calls closed by the player's crew (gain shrinks as the bond grows), failed calls of the
// shift, founded complaints against the crew.
export function bondAfterShift(p,{calls=0,missed=0,founded=0}){const d=Math.min(BOND.callsCap,calls*BOND.perCall)*(1-p.bond/100)*2+Math.max(BOND.missedCap,missed*BOND.missed)+founded*BOND.founded;p.bond=Math.round(clamp(p.bond+d)*10)/10;p.low=p.bond<BOND.transfer?(p.low??0)+1:0;return d;}
export function validPartner(p){return p===undefined||!!p&&typeof p==='object'&&typeof p.name==='string'&&p.name.length>0&&p.name.length<=40&&Object.hasOwn(TRAITS,p.trait)&&Number.isFinite(p.bond)&&p.bond>=0&&p.bond<=100&&Number.isInteger(p.since)&&p.since>0&&Number.isInteger(p.low??0)&&(p.low??0)>=0;}
export const clampBond=clamp;
