// R19 «План на месяц» (Claude, 11.10.2026). At the start of each calendar month the prefecture sets the
// department three goals (the chief) or the commander sets them for the officer (career): keep failed
// calls down, raise trust in the weakest district, plus one more — closed calls, drunk drivers taken off
// the road, no founded complaints, or city-wide trust. Progress is visible during the month; each met
// goal pays a bonus at month end (budget for the chief, experience and a premium for the officer).
// Deterministic: the extra goal is a hash of the month. Roster campaigns only.
import {monthOf} from './history.js';
import {districtName} from './fiction.js';
export const GOALS=Object.freeze({
 missed:{label:t=>`Сорванных вызовов не больше ${t}`,lower:true},
 district:{label:(t,d)=>`Доверие района «${districtName(d)}» — ${t}% к концу месяца`},
 calls:{label:t=>`Закрыть не меньше ${t} вызовов`},
 drunk:{label:t=>`Снять с дороги ${t} пьяных водителей на рейдах`},
 clean:{label:()=>'Ни одной обоснованной жалобы',flag:true},
 trust:{label:t=>`Доверие города не ниже ${t}% к концу месяца`}
});
export const GOAL_REWARD=Object.freeze({budget:600,xp:30,money:80});
const EXTRA=['calls','drunk','clean','trust'];
const mix=k=>{let h=Math.imul((k|0)+29,2654435761);h^=h>>>15;h=Math.imul(h,2246822519);return ((h^h>>>13)>>>0);};
export function makeGoals(s,index){const m=monthOf(index),chief=s.mode==='chief',d=Object.entries(s.districts??{}).sort((a,b)=>a[1]-b[1])[0];
 // R21: the chief's limit and call target grow with the crews on the line; the officer's plan is tighter.
 const crews=Math.max(2,(s.units??[]).length),list=[{id:'missed',target:chief?crews*4:3}];if(d)list.push({id:'district',target:Math.min(90,Math.round(d[1]+8)),district:d[0]});
 const extra=EXTRA[mix(m.key)%EXTRA.length];list.push({id:extra,target:extra==='calls'?(chief?crews*130:300):extra==='drunk'?6:extra==='trust'?88:1});
 return {month:m.key,label:m.label,list};}
export const goalLabel=g=>GOALS[g.id]?.label(g.target,g.district)??g.id;
// Current value of a goal: month records of the shift log plus the shift in progress (if `live`).
export function goalValue(s,g,month,{live=true}={}){const recs=(s.shiftLog??[]).filter(r=>r.month===month),cur=live&&monthOf(s.shift-1).key===month;
 const sum=k=>recs.reduce((n,r)=>n+(r[k]??0),0);
 if(g.id==='missed')return sum('missed')+(cur?s.missed:0);
 if(g.id==='calls')return sum('resolved')+(cur?s.resolved:0);
 if(g.id==='drunk')return sum('drunk')+(cur?(s.tasksDone??[]).filter(t=>t.done&&t.task==='breath-check').reduce((n,t)=>n+(t.found??0),0):0);
 if(g.id==='clean')return s.stats?.monthFounded??0;
 if(g.id==='district')return Math.round(s.districts?.[g.district]??0);
 if(g.id==='trust')return Math.round(s.trust);return 0;}
export function goalMet(g,value){return g.id==='clean'?value===0:GOALS[g.id]?.lower?value<=g.target:value>=g.target;}
const int=x=>Number.isInteger(x)&&x>=0&&x<1e7;
export const validGoals=s=>s.goals===undefined||!!s.goals&&int(s.goals.month)&&typeof s.goals.label==='string'&&s.goals.label.length<=30&&Array.isArray(s.goals.list)&&s.goals.list.length<=4&&s.goals.list.every(g=>g&&Object.hasOwn(GOALS,g.id)&&int(g.target)&&(g.district===undefined||typeof g.district==='string'&&g.district.length<=20));
