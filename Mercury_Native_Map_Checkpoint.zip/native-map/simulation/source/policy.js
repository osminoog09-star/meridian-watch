// 0.6.2 «Правила отделения» (Claude, 11.10.2026). The chief picks one standing order and one priority
// district. Each rule changes real behaviour (who is detained, how often trouble returns, which call
// automatic crews take first, what the shift costs) and is explained in the department panel.
// Career mode has no chief: rules stay at the default and nothing changes.
import {DISTRICT_IDS} from './calls.js';
export const POLICIES=Object.freeze({
 balanced:Object.freeze({label:'Обычный порядок',about:'Экипажи решают по обстановке: задерживают при серьёзном нарушении, иначе отпускают с предупреждением. Без бонусов и доплат.',custody:null,followUp:1,cost:0,warnDistrict:0}),
 strict:Object.freeze({label:'Нулевая терпимость',about:'Участников всех подходящих вызовов задерживают. Повторных вызовов меньше (×0.7), но экипажи дольше заняты перевозкой, а оформление стоит 120 за смену.',custody:'arrest',followUp:.7,cost:120,warnDistrict:0}),
 prevention:Object.freeze({label:'Профилактика',about:'Участников отпускают с предупреждением: экипажи быстрее свободны, доверие района растёт (+1 за каждое предупреждение), но повторных вызовов больше (×1.3).',custody:'warn',followUp:1.3,cost:0,warnDistrict:1})
});
export const POLICY_IDS=Object.freeze(Object.keys(POLICIES));
export const PRIORITY_RULES=Object.freeze({cost:60,districtBonus:1});
const chief=s=>s?.mode==='chief';
export const policyOf=s=>POLICIES[chief(s)&&Object.hasOwn(POLICIES,s.policy)?s.policy:'balanced'];
export const priorityOf=s=>chief(s)&&DISTRICT_IDS.includes(s.priorityDistrict)?s.priorityDistrict:null;
export function policyCost(s){if(!chief(s))return 0;return policyOf(s).cost+(priorityOf(s)?PRIORITY_RULES.cost:0);}
export function validPolicy(s){return (s.policy===undefined||Object.hasOwn(POLICIES,s.policy))&&(s.priorityDistrict===undefined||s.priorityDistrict===null||DISTRICT_IDS.includes(s.priorityDistrict));}
