// R17 «Город пишет» (Claude, 11.10.2026): the city's media react to what the police do. Notable calls,
// rescues, checkpoints, founded complaints, holidays and awards become short headlines in the local
// news («Вестник Меридиана», «Меридиан Online», city radio). Only atmosphere: trust is already counted
// by the call itself. Template choice is a hash of the call id (no rng). Roster campaigns only.
export const NEWS_LIMIT=16;
export const MEDIA=Object.freeze(['Вестник Меридиана','Меридиан Online','Радио «Маяк Меридиана»','Портал «Наш район»']);
const hash=(a,b=0)=>{let h=Math.imul((a|0)+59,2654435761)^Math.imul((b|0)+17,1597334677);h^=h>>>15;h=Math.imul(h,2246822519);h^=h>>>13;return (h>>>8);};
const pick=(list,a,b)=>list[hash(a,b)%list.length];
// Call outcomes worth a headline. {d} = district name, {m} = minutes the call took.
const CALLS=Object.freeze({
 'missing-child':{good:['Мальчик, не вернувшийся с тренировки, найден: патруль привёл его домой ({d})','Пропавший ребёнок найден за {m} мин — мать благодарит полицию'],bad:['Поиски ребёнка ({d}) затянулись до ночи']},
 'missing-elder':{good:['Пожилой мужчина, ушедший из дома, найден патрулём ({d})','Полиция нашла пропавшего пенсионера: «он просто заблудился»'],bad:['Родственники пропавшего пенсионера ({d}) жалуются на медленные поиски']},
 'lost-child-mall':{good:['Туристка нашла сына в торговом центре с помощью полиции','Патруль за {m} мин нашёл потерявшегося в ТЦ малыша']},
 'thin-ice':{good:['Полиция и спасатели вывели рыбаков с тонкого льда','Рыбаки на льду: всё обошлось, но полиция напоминает о запрете'],bad:['Рыбаков со льда снимали слишком долго — спасатели недовольны']},
 'phone-scam':{good:['Курьер телефонных мошенников задержан у дома пенсионерки ({d})','«Звонок из банка» не сработал: полиция встретила курьера'],bad:['Курьер мошенников скрылся до приезда полиции ({d})']},
 'street-fight':{good:['Драка остановлена ({d}), задержанные доставлены в участок'],bad:['Жители ({d}): полиция приехала, когда драка уже закончилась']},
 'domestic':{bad:['Соседи: на крики за стеной полиция не успела ({d})']},
 'restraining-order':{good:['Нарушитель запрета на приближение задержан у двери бывшей партнёрши'],bad:['«Запрет суда не защитил, полиция опоздала» — жительница ({d})']},
 'drunk-driver':{good:['Пьяный водитель остановлен до того, как стал причиной ДТП'],bad:['Машина, вилявшая по полосам ({d}), так и не была остановлена']},
 'dangerous-driving':{good:['Гонщик, обгонявший по встречной, остановлен патрулём'],bad:['Опасный водитель ушёл от патруля ({d})']},
 'school-speeding':{good:['У школы ({d}) остановлен водитель, превысивший скорость: родители довольны']},
 'beach-party':{good:['Ночная вечеринка с костром на пляже прекращена после жалоб жильцов']},
 'fire-smoke':{good:['Дым в жилом доме ({d}): полиция оцепила подъезд, спасатели вывели жильцов']},
 'crash':{bad:['ДТП на перекрёстке ({d}): место происшествия долго не было оцеплено']},
 'fan-fight':{good:['Драку болельщиков у стадиона остановили два экипажа полиции'],bad:['После матча фанаты дрались у стадиона — полиция не успела']},
 'tree-down':{good:['Шторм: упавшее дерево ({d}) убрано, полиция перекрывала дорогу']},
 'alarm-burglary':{good:['Без света, но не без полиции: взломщик задержан у магазина ({d})'],bad:['Пока не было света, магазин ({d}) обокрали']},
 'lost-at-concert':{good:['На концерте потерялась девочка-подросток — полиция нашла её за {m} мин']}
});
export function callNews(i,success,{district='городе',minutes=0}={}){const set=CALLS[i?.variant];const list=set?.[success?'good':'bad'];if(!list)return null;
 // Ordinary good outcomes make the news only sometimes; failures and rare calls always.
 if(success&&['street-fight','drunk-driver','dangerous-driving','fire-smoke','beach-party','school-speeding'].includes(i.variant)&&hash(i.id,9)%3!==0)return null;
 return {title:pick(list,i.id,1).replace('{d}',district).replace('{m}',String(Math.max(1,Math.round(minutes)))),tone:success?'good':'bad',media:pick(MEDIA,i.id,2)};}
export const checkpointNews=(found,seed)=>found>=2?{title:`Рейд «Трезвый водитель»: за вечер сняты с руля ${found} водителя`,tone:'good',media:pick(MEDIA,seed,3)}:null;
export const complaintNews=(incident)=>({title:'Проверка подтвердила жалобу на действия патруля',tone:'bad',media:pick(MEDIA,incident,4)});
export const holidayNews=(label,shift)=>({title:`${label}: полиция Меридиана усиливает патрули`,tone:'neutral',media:pick(MEDIA,shift,5)});
export const awardNews=(label,shift)=>({title:`Отделение отмечено: ${label.toLowerCase()}`,tone:'good',media:pick(MEDIA,shift,6)});
// At most a few good call stories per shift; failures always get written about.
export const NEWS_PER_SHIFT=4;
export const newsRoom=(s,item)=>!!item&&(item.tone!=='good'||(s.news??[]).filter(n=>n.shift===s.shift&&n.tone==='good').length<NEWS_PER_SHIFT);
export function pushNews(s,item,extra={}){if(!item)return;if(!Array.isArray(s.news))s.news=[];s.news.unshift({shift:s.shift,time:s.time,...item,...extra});if(s.news.length>NEWS_LIMIT)s.news.length=NEWS_LIMIT;}
export const validNews=s=>s.news===undefined||Array.isArray(s.news)&&s.news.length<=NEWS_LIMIT&&s.news.every(n=>n&&Number.isInteger(n.shift)&&Number.isFinite(n.time)&&typeof n.title==='string'&&n.title.length<=160&&['good','bad','neutral'].includes(n.tone)&&MEDIA.includes(n.media));
