// Release O «Мой персонаж» (Claude, 16.10.2026). Owner 16.10: «создать персонажа — как выглядит, возраст, имя и фамилия;
// дальше карьера с низов; начальник доступен потом, сразу не выбрать». The hero is the player's own person:
// name, age and look are shown in the personal file and drawn on the player's own crew; age and build set the
// starting fitness. A chief campaign opens only after a career hero reaches the top rank.
// PPA hires from 18; most cadets start the academy at 19–30 (karjaar.politsei.ee); 45 is a late career change.
export const HERO=Object.freeze({
 minAge:19,maxAge:45,nameMax:24,
 genders:Object.freeze({m:'Мужчина',f:'Женщина'}),
 skins:Object.freeze(['#f1d3bc','#d6b99c','#b88a68','#7d5640']),
 hairColors:Object.freeze(['#2b2420','#574739','#8a6a45','#c9a46a','#b4b2ad']),
 hairColorNames:Object.freeze(['Чёрные','Каштановые','Русые','Светлые','Седые']),
 hairs:Object.freeze({short:'Короткие',long:'Длинные',bun:'Собранные',shaved:'Под ноль'}),
 builds:Object.freeze({slim:'Худощавое',average:'Среднее',strong:'Крепкое'}),
 chiefRank:4
});
const FIRST={m:['Андрес','Мартин','Кристьян','Сийм','Райнер','Тоомас','Денис','Артём','Максим','Карл'],f:['Кристийна','Лийс','Анна','Кадри','Мария','Хелен','Ольга','Екатерина','Кертту','Эва']};
const LAST=['Тамм','Саар','Сепп','Мяги','Каск','Кукк','Ребане','Ильвес','Пярн','Кивимяэ','Лаур','Орлов','Смирнов','Иванов','Петров','Вийк'];
const mix=(a,b)=>{let h=Math.imul((a|0)+71,2654435761)^Math.imul((b|0)+5,1597334677);h^=h>>>15;return h>>>0;};
// A ready suggestion for the creator (the player edits it); the same seed gives the same suggestion.
export function suggestHero(seed=7182,k=0){const g=mix(seed,k)%2?'f':'m',h=mix(k,seed);
 return {first:FIRST[g][h%FIRST[g].length],last:LAST[(h>>>4)%LAST.length],gender:g,age:22+(h>>>8)%9,skin:(h>>>12)%2,hair:g==='f'?((h>>>14)%2?'long':'bun'):'short',hairColor:(h>>>16)%4,build:'average',beard:false,glasses:false};}
const clean=t=>String(t??'').replace(/[<>&"`\u0000-\u001f]/g,'').replace(/\s+/g,' ').trim().slice(0,HERO.nameMax);
// Turns the creator's form into a hero, or returns the reason it cannot.
export function makeHero(raw){if(!raw||typeof raw!=='object')return {ok:false,message:'Нет данных персонажа.'};
 const first=clean(raw.first),last=clean(raw.last),age=Math.round(Number(raw.age));
 if(first.length<2)return {ok:false,message:'Введите имя (от 2 букв).'};if(last.length<2)return {ok:false,message:'Введите фамилию (от 2 букв).'};
 if(!(age>=HERO.minAge&&age<=HERO.maxAge))return {ok:false,message:`Возраст — от ${HERO.minAge} до ${HERO.maxAge} лет.`};
 const gender=Object.hasOwn(HERO.genders,raw.gender)?raw.gender:'m',hero={first,last,gender,age,
  skin:Number.isInteger(+raw.skin)&&+raw.skin>=0&&+raw.skin<HERO.skins.length?+raw.skin:1,
  hair:Object.hasOwn(HERO.hairs,raw.hair)?raw.hair:'short',
  hairColor:Number.isInteger(+raw.hairColor)&&+raw.hairColor>=0&&+raw.hairColor<HERO.hairColors.length?+raw.hairColor:1,
  build:Object.hasOwn(HERO.builds,raw.build)?raw.build:'average',beard:gender==='m'&&!!raw.beard,glasses:!!raw.glasses};
 return {ok:true,hero};}
export function validHero(h){if(h===undefined)return true;const r=makeHero(h);return r.ok&&JSON.stringify(r.hero)===JSON.stringify(h);}
export const heroName=h=>h?`${h.first} ${h.last}`:'';
// Younger and stronger recruits start fitter; the academy keeps everyone above the entry standard.
export const heroFitness=h=>Math.max(50,Math.min(75,55+(h?.build==='strong'?8:h?.build==='slim'?2:0)-Math.max(0,(h?.age??25)-30)*0.6|0));
export const heroLook=h=>h?{skin:HERO.skins[h.skin],hair:h.hair==='shaved'?HERO.skins[h.skin]:HERO.hairColors[h.hairColor]}:null;
export const heroSummary=h=>h?`${heroName(h)}, ${h.age} ${h.age%10===1&&h.age!==11?'год':h.age%10>=2&&h.age%10<=4&&(h.age<12||h.age>14)?'года':'лет'} · ${HERO.builds[h.build].toLowerCase()} телосложение · волосы: ${HERO.hairs[h.hair].toLowerCase()}${h.hair==='shaved'?'':', '+HERO.hairColorNames[h.hairColor].toLowerCase()}${h.beard?' · борода':''}${h.glasses?' · очки':''}`:'';
// A chief campaign opens after a career hero reached the top rank of the service.
export const chiefUnlocked=s=>s?.mode==='career'&&(s.rank??0)>=HERO.chiefRank;
