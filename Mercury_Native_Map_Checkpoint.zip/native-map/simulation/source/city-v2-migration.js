import {RESIDENTS,PLACES} from './population.js';
import {nearestRoad,point,roadRoute,byId} from './geography.js';
// Preserve people, career, finances and outcomes. Only map-dependent positions/routes change.
export function migrateCityV2Population(s,bases){
 const snap=p=>Object.assign(p,point(nearestRoad(p)));
 for(const i of s.incidents)for(const a of i.scene?.participants??[]){const goal=a.route?.at(-1);snap(a);a.route=goal?roadRoute(a,nearestRoad(goal)):[];}
 for(const u of s.units){
  delete u.foot;u.currentSpeedKmh=0;
  if(u.ride){snap(u.ride.from);snap(u.ride.to);u.route=roadRoute(u,u.ride.phase==='ride'?u.ride.to:u.ride.from);}
  const home=u.transport?.hospital?bases.HOSPITAL:bases.HQ;
  if(u.status==='transporting')u.route=roadRoute(u,home);
  if(u.status==='handover')Object.assign(u,point(home));
  if(u.ride?.phase==='board'){Object.assign(u,point(u.ride.from));u.route=[];}
 }
 for(const o of s.taxi?.orders??[]){snap(o.from);snap(o.to);}

 for(const r of s.population?.residents??[]){
  const profile=RESIDENTS.find(p=>p.id===r.id);if(!profile)continue;
  const busy=['incident','recovering'].includes(r.status),destination=busy?r.resumeStatus:['work','toWork'].includes(r.status)?'work':'home';
  const at=PLACES.get(profile[destination]).access;Object.assign(r,point(at));r.route=[];r.visit=null;
  if(!busy)r.status=destination;
  // Linked resident and participant must still occupy the same location after relocation.
  if(r.incidentId!==null){const i=s.incidents.find(i=>i.id===r.incidentId);if(i){Object.assign(i,point(at));for(const a of i.scene?.participants??[])if(a.residentId===r.id)Object.assign(a,point(at));for(const u of s.units)if(u.incident===i.id){u.route=[];if(['working','decision'].includes(u.status))Object.assign(u,point(i));else u.route=roadRoute(u,i);}}}
 }
 // Resident links may relocate an incident: rebuild service targets afterwards.
 for(const a of s.services??[]){
  const incident=s.incidents.find(i=>i.id===a.incident);
  const home=a.kind==='ambulance'?bases.HOSPITAL:a.kind==='rescue'?bases.FIRE_STATION:a.kind==='gbr'?bases.GBR_BASE:a.kind==='kk'?bases.KK_BASE:bases.HQ;
  snap(a);a.route=[];
  if(incident)a.target=point(incident);
  if(['onscene','working','treating','securing','cordon'].includes(a.status)&&incident)Object.assign(a,point(incident));
  else if(a.status==='handover')Object.assign(a,point(home));
  else if(['transporting','returning'].includes(a.status))a.route=roadRoute(a,home);
  else if(a.status==='responding'&&incident)a.route=roadRoute(a,incident);
 }

}
