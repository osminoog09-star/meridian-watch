// Claude 16.10: regenerate simulation/service-save-fixtures.json from the APK game source: node simulation/make-service-saves.mjs <path to claude/release-j dist> simulation/service-save-fixtures.json
import fs from 'node:fs';
const dist=process.argv[2],out=process.argv[3];
const sim=await import(dist+'/sim.js');const {NODES}=await import(dist+'/geography.js');
const saves=[];
for(const [mode,service,ticks] of [['career','rescue',900],['career','ems',900],['career','dispatch',900],['chief','ems',600],['chief','rescue',600],['career',undefined,900],['chief','dispatch',900]]){
 const s=sim.createGame(mode,7182,{schedule:'ppa',service});
 if(mode==='chief'&&service==='dispatch')sim.hireOperator(s,s.desk.candidates[0].id);
 else if(mode==='chief'){const c=s.candidates[0];sim.hireOfficer(s,c.id);sim.createPatrol(s,s.officers[0].id,null,s.vehicles[0].id);}
 for(let k=0;k<ticks;k++)sim.tick(s,.5);
 const v={rescue:'fire-flat',ems:'ems-arrest'}[service];if(v&&mode==='career'){const u=s.units[0];const n=NODES.reduce((a,b)=>Math.hypot(b.x-u.x,b.y-u.y)<Math.hypot(a.x-u.x,a.y-u.y)&&Math.hypot(b.x-u.x,b.y-u.y)>.004?b:a);sim.spawnIncident(s,null,{variant:v,point:{x:n.x,y:n.y}});for(let k=0;k<(service==='rescue'?30:160);k++)sim.tick(s,.5);}
 const save=sim.serialize(s);sim.deserialize(save);
 saves.push({mode,service:service??'police',time:s.time,incidents:s.incidents.length,save});
 console.log(mode,service??'police','time',s.time.toFixed(1),'incidents',s.incidents.length,'bytes',save.length,'desk',!!s.desk,'fires',s.incidents.filter(i=>i.fire).length,'patients',s.incidents.filter(i=>i.patient).length);
}
fs.writeFileSync(out,JSON.stringify(saves));
