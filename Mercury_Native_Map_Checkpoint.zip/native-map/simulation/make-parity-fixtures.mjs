import fs from 'node:fs';
import {dispatch} from './core-entry.js';
const oldFixtures=JSON.parse(fs.readFileSync(new URL('./parity-fixtures.json',import.meta.url))).filter(f=>f.version);
const fixtures=[];
for(const mode of ['career','chief'])for(const scheduled of [false,true])for(const seed of [7182,123,9001]){
 const requests=[{op:'create',mode,seed,options:scheduled?{schedule:'ppa'}:{}}];dispatch(requests[0]);
 if(mode==='chief'){
  let s=JSON.parse(dispatch({op:'state'}));let hire={op:'command',name:'hireOfficer',args:[s.candidates[0].id]};dispatch(hire);requests.push(hire);s=JSON.parse(dispatch({op:'state'}));let patrol={op:'command',name:'createPatrol',args:[s.officers[0].id,null,s.vehicles[0].id]};dispatch(patrol);requests.push(patrol);
 }
 const initial=dispatch({op:'save'});requests.push({op:'load',save:initial});dispatch(requests.at(-1));
 for(let i=0;i<300;i++){const q={op:'tick',dt:[.1,.25,.5][i%3]};dispatch(q);requests.push(q);}
 fixtures.push({mode,scheduled,seed,requests,expected:JSON.parse(dispatch({op:'save'}))});
}
for(const mode of ['career','chief'])for(const speed of [1,2,4,10,30,60]){
 const requests=[{op:'create',mode,seed:7182,options:{schedule:'ppa'}}];dispatch(requests[0]);
 if(mode==='chief'){
  let s=JSON.parse(dispatch({op:'state'}));let hire={op:'command',name:'hireOfficer',args:[s.candidates[0].id]};dispatch(hire);requests.push(hire);s=JSON.parse(dispatch({op:'state'}));let patrol={op:'command',name:'createPatrol',args:[s.officers[0].id,null,s.vehicles[0].id]};dispatch(patrol);requests.push(patrol);
 }
 for(let i=0;i<300;i++){const q={op:'tick',dt:.1};dispatch(q);requests.push(q);}
 for(let i=0;i<180;i++){const q={op:'frame',seconds:1/60,speed};dispatch(q);requests.push(q);}
 fixtures.push({mode,scheduled:true,seed:7182,speed,requests,expected:JSON.parse(dispatch({op:'save'}))});
}
for(const old of oldFixtures){for(const request of old.requests)dispatch(request);fixtures.push({...old,expected:JSON.parse(dispatch({op:'save'}))});}
fs.writeFileSync(new URL('./parity-fixtures.json',import.meta.url),JSON.stringify(fixtures));console.log(fixtures.length);
