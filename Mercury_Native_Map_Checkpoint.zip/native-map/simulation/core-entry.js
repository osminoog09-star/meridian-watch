import * as sim from './source/sim.js';
import {GAME_SPEEDS,stepFor,createSimulationClock} from './source/transport.js';
import {onlookersFor} from './source/onlookers.js';
import {currentStage,optionOpen} from './source/dialogues.js';
let state=null;
let clock=createSimulationClock({worldRate:1});
export function dispatch(request){
 switch(request.op){
 case 'create':clock.reset();state=sim.createGame(request.mode??'career',request.seed??7182,request.options??{schedule:'ppa'});break;
 case 'load':clock.reset();state=sim.deserialize(request.save);break;
 case 'frame':return JSON.stringify(clock.advance(request.seconds,request.speed,dt=>sim.tick(state,dt)));
 case 'tick':if(!state)throw Error('No campaign');sim.tick(state,request.dt);break;
 case 'nextShift':state=sim.nextShift(state,request.options??{});break;
 case 'command':if(!state||typeof sim[request.name]!=='function'||['createGame','deserialize','tick','nextShift','serialize'].includes(request.name))throw Error('Invalid campaign command');return JSON.stringify(sim[request.name](state,...(request.args??[]))??null);
 case 'view':return JSON.stringify({time:state.time,absoluteMinute:sim.cityAbsoluteMinute(state),shift:state.shift,ended:state.ended,mode:state.mode,budget:state.budget,rank:state.rank,sun:sim.sunOf(state),weather:sim.shiftWeather(state),units:state.units.map(u=>({id:u.id,x:u.x,y:u.y,status:u.status,incident:u.incident,target:u.route?.[0],people:u.people,heading:u.heading})),incidents:state.incidents.filter(i=>!['resolved','missed'].includes(i.state)).map(i=>({id:i.id,x:i.x,y:i.y,state:i.state,name:sim.callName(i),options:sim.TYPES[i.type].options,talk:i.talk,dialogue:currentStage(i)?{...currentStage(i),options:currentStage(i).options.map(o=>({...o,open:optionOpen(i,o)}))}:null})),onlookers:state.incidents.flatMap(i=>onlookersFor(i,{minute:sim.cityAbsoluteMinute(state),weather:sim.shiftWeather(state).kind,event:sim.shiftWeather(state).event?.id})),life:state.life,goals:state.goals,news:state.news});
 case 'save':return sim.serialize(state);
 case 'state':return sim.serialize(state);
 case 'speeds':return JSON.stringify(GAME_SPEEDS.map(speed=>({speed,step:stepFor(1,speed)})));
 default:throw Error('Unknown native operation');
 }
 return JSON.stringify({ok:true,time:state.time,shift:state.shift,ended:state.ended});
}
export function call(raw){return dispatch(JSON.parse(raw));}
