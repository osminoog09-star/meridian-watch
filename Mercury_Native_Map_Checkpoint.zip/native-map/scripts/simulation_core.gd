extends RefCounted
var runtime: RefCounted
func initialize() -> bool:
 if not ClassDB.class_exists("QuickJS"):
  push_error("QuickJS native extension is unavailable on this platform")
  return false
 runtime = ClassDB.instantiate("QuickJS")
 return runtime.load_file("res://simulation/game-core.js")
func invoke(request: Dictionary) -> Variant:
 var raw: String = runtime.eval("MercuryCore.call("+JSON.stringify(JSON.stringify(request))+")")
 if not runtime.get_error().is_empty():
  push_error(runtime.get_error())
  return null
 return JSON.parse_string(raw)
func serialize() -> String:
 return runtime.eval("MercuryCore.call('{\"op\":\"save\"}')")
func state() -> Dictionary:
 return invoke({"op":"state"})
