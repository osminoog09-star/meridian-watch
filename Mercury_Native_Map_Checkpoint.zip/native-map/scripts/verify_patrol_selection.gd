extends SceneTree
var failed := false
func check(ok: bool,message: String) -> void:
 if not ok:
  failed = true
  push_error(message)
func patrol(nodes: Array) -> Dictionary:
 for item in nodes:
  if item.get("tag")=="button" and str(item.get("text","")).begins_with("Патруль 02"):
   return item
  var found := patrol(item.get("children",[]))
  if not found.is_empty():
   return found
 return {}
func _initialize() -> void:
 call_deferred("verify")
func verify() -> void:
 var scene = load("res://main.tscn").instantiate()
 root.add_child(scene)
 for i in range(6):
  await process_frame
 scene.set_process(false)
 scene.set_process_unhandled_input(false)
 var campaign = scene.campaign
 for width in [360,740]:
  root.size = Vector2i(width,900)
  campaign.initialize({})
  campaign.store.path = "user://patrol-selection-test.json"
  for id in ["startCareer","closeModal"]:
   campaign.action({"op":"event","domId":id,"event":"click"})
  # Claude 17.10 (Release R1): a young officer sees only the own patrol; other crews from senior constable — promote the save.
  check(patrol(campaign.snapshot.tree).is_empty(),"A young officer must see only the own patrol")
  var storage: Dictionary = campaign.snapshot.get("storage",{}).duplicate()
  for key in storage.keys():
   var text := str(storage[key])
   if text.contains("\"mode\":\"career\""):
    storage[key] = text.replace("\"rank\":0,","\"rank\":2,")
  campaign.initialize(storage)
  campaign.store.path = "user://patrol-selection-test.json"
  campaign.action({"op":"event","domId":"continueBtn","event":"click"})
  campaign.action({"op":"pick","hit":{"kind":"unit","id":1}})
  var retained := patrol(campaign.snapshot.tree)
  check(not retained.is_empty(),"Patrol button missing")
  if retained.is_empty():
   break
  # The real Godot button retains its original callback across source refreshes.
  var button: Button = scene.native_ui.widget(retained)
  scene.native_ui.hide()
  root.add_child(button)
  button.position = Vector2(20,100)
  button.size = Vector2(width-40,200)
  for i in range(90):
   campaign.advance(1.0/30)
  check(patrol(campaign.snapshot.tree).get("id")!=retained.get("id"),"Fixture did not replace DOM")
  await process_frame
  for pressed in [true,false]:
   var event := InputEventMouseButton.new()
   event.button_index = MOUSE_BUTTON_LEFT
   event.position = button.get_global_rect().get_center()
   event.global_position = event.position
   event.pressed = pressed
   root.push_input(event)
   await process_frame
  check(int(campaign.snapshot.status.selectedUnit)==2,"Godot button failed to select patrol at width "+str(width))
  campaign.action({"op":"event","domId":"followUnit","event":"click"})
  var follows := false
  for command in campaign.snapshot.map:
   if command.op=="follow" and int(command.value)==2:
    follows = true
  check(follows,"Wrong patrol sent to follow camera")
  button.queue_free()
  await process_frame
 print("Godot retained patrol button / viewport input / follow ","FAILED" if failed else "PASSED")
 quit(1 if failed else 0)
