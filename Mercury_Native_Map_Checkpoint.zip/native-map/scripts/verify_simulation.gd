extends SceneTree
const Save = preload("res://scripts/campaign_save.gd")
const Core = preload("res://scripts/simulation_core.gd")
var differences: Array = []
func compare(a: Variant,b: Variant,path: String) -> void:
 if differences.size()>20:
  return
 if typeof(a)==TYPE_DICTIONARY and typeof(b)==TYPE_DICTIONARY:
  if a.size()!=b.size():
   differences.append(path+" key count")
  for key in a:
   if not b.has(key):
    differences.append(path+" missing "+key)
   else:
    compare(a[key],b[key],path+"."+key)
 elif typeof(a)==TYPE_ARRAY and typeof(b)==TYPE_ARRAY:
  if a.size()!=b.size():
   differences.append(path+" array size")
  else:
   for index in range(a.size()):
    compare(a[index],b[index],path+"["+str(index)+"]")
 elif (typeof(a)==TYPE_FLOAT or typeof(a)==TYPE_INT) and (typeof(b)==TYPE_FLOAT or typeof(b)==TYPE_INT):
  if absf(float(a)-float(b))>0.00000001:
   differences.append(path+" numeric difference "+str(a)+" != "+str(b))
 elif a!=b:
  differences.append(path+" value difference")
func _initialize() -> void:
 var core = Core.new()
 if not core.initialize():
  quit(1)
  return
 var fixtures = JSON.parse_string(FileAccess.get_file_as_string("res://simulation/parity-fixtures.json"))
 var passed := 0
 var began := Time.get_ticks_msec()
 for fixture in fixtures:
  for request in fixture.requests:
   if core.invoke(request)==null:
    push_error("Native call failed")
    quit(2)
    return
  differences.clear()
  compare(core.state(),fixture.expected,"state")
  if not differences.is_empty():
   print(JSON.stringify({"fixture":fixture.seed,"mode":fixture.mode,"differences":differences}))
   quit(3)
   return
  passed += 1
 var store = Save.new()
 store.path = "user://mercury-native-verification.json"
 var snapshot: String = core.serialize()
 if store.write_save(snapshot)!=OK or store.read_save()!=snapshot:
  quit(4)
  return
 core.invoke({"op":"tick","dt":0.5})
 var newer: String = core.serialize()
 if store.write_save(newer)!=OK:
  quit(5)
  return
 FileAccess.open(store.path,FileAccess.WRITE).store_string("truncated")
 if store.read_save()!=snapshot:
  quit(6)
  return
 if store.write_save(newer)!=OK:
  quit(7)
  return
 FileAccess.open(store.path,FileAccess.WRITE).store_string("truncated again")
 if store.read_save()!=snapshot:
  quit(8)
  return
 core.invoke({"op":"load","save":store.read_save()})
 var tick_times: Array[float] = []
 for tick in range(2000):
  var started := Time.get_ticks_usec()
  core.invoke({"op":"tick","dt":0.1})
  tick_times.append((Time.get_ticks_usec()-started)/1000.0)
 tick_times.sort()
 var result := {"native_quickjs_fixtures":passed,"save_backup_recovery":true,"headless_tick_p95_ms":tick_times[1899],"headless_tick_median_ms":tick_times[999],"direct_ticks_per_fixture":300,"accelerated_frame_cases":12,"old_save_cases":12,"frames_per_speed_case":180,"elapsed_ms":Time.get_ticks_msec()-began,"campaigns":"career/chief, legacy/scheduled, three seeds","full_state_parity_tolerance":0.00000001}
 FileAccess.open("res://simulation/verification.json",FileAccess.WRITE).store_string(JSON.stringify(result,"  "))
 print(JSON.stringify(result))
 quit(0)
