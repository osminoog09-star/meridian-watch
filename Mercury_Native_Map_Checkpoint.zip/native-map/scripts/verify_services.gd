extends SceneTree
# Claude 15.10: Claude's services F–J are part of the native game — the start screen offers Полиция / Спасатели /
# Скорая / 112; each career starts through the real native UI, runs a stretch of the shift at speed without
# runtime errors, and its crews are of the right service (112: the city's crews of three services, no own crew).
var failed := false
func _initialize() -> void:
 call_deferred("verify")
func find_text(nodes: Array,text: String) -> Dictionary:
 for node in nodes:
  if node.get("tag")=="button" and str(node.get("text","")).strip_edges()==text:
   return node
  var found := find_text(node.get("children",[]),text)
  if not found.is_empty():
   return found
 return {}
func check(ok: bool,message: String) -> void:
 if not ok:
  failed = true
  push_error(message)
func verify() -> void:
 for spec in [["Спасатели","rescue"],["Скорая","ems"],["112","dispatch"]]:
  var scene = load("res://main.tscn").instantiate()
  root.add_child(scene)
  for i in range(6):
   await process_frame
  scene.set_process(false)
  var c = scene.campaign
  c.initialize({})
  c.store.path = "user://services-test.json"
  var pick := find_text(c.snapshot.get("tree",[]),spec[0])
  check(not pick.is_empty(),"start screen has no «%s» service button" % spec[0])
  c.action({"op":"event","id":pick.get("id"),"domId":pick.get("domId"),"target":pick.get("target"),"event":"click"})
  c.action({"op":"event","domId":"startCareer","event":"click"})
  for i in range(3):
   c.action({"op":"event","domId":"closeModal","event":"click"})
  var state = c.invoke({"op":"state"})
  check(typeof(state)==TYPE_DICTIONARY and state.get("agency")==spec[1],"%s: campaign agency %s" % [spec[1],str(state.get("agency") if typeof(state)==TYPE_DICTIONARY else state)])
  for frame in range(900):
   c.advance(1.0/30.0)
   if frame%30==0:
    scene._process(1.0/30.0)
  state = c.invoke({"op":"state"})
  check(typeof(state)==TYPE_DICTIONARY and state.get("time",0)>0,"%s: the shift did not run" % spec[1])
  if typeof(state)==TYPE_DICTIONARY:
   var agencies := {}
   for u in state.get("units",[]):
    agencies[u.get("agency",state.get("agency"))] = true
   if spec[1]=="dispatch":
    check(agencies.has("ems") and agencies.has("rescue") and agencies.has("police") and state.get("desk")!=null,"112: city crews of three services and the desk expected, got %s" % str(agencies.keys()))
   else:
    check(agencies.keys()==[spec[1]],"%s: crews of the service expected, got %s" % [spec[1],str(agencies.keys())])
  check(c.runtime.get_error().is_empty(),"%s: runtime error %s" % [spec[1],c.runtime.get_error()])
  scene.queue_free()
  await process_frame
 # Release L: the head of the 112 centre — start through the native UI, open the centre screen, hire an operator.
 var scene = load("res://main.tscn").instantiate()
 root.add_child(scene)
 for i in range(6):
  await process_frame
 scene.set_process(false)
 var c = scene.campaign
 c.initialize({"mercury-chief-unlocked":"{\"police\": {\"first\": \"Анна\", \"last\": \"Тамм\", \"gender\": \"f\", \"age\": 41, \"skin\": 1, \"hair\": \"bun\", \"hairColor\": 1, \"build\": \"average\", \"beard\": false, \"glasses\": false}, \"rescue\": {\"first\": \"Анна\", \"last\": \"Тамм\", \"gender\": \"f\", \"age\": 41, \"skin\": 1, \"hair\": \"bun\", \"hairColor\": 1, \"build\": \"average\", \"beard\": false, \"glasses\": false}, \"ems\": {\"first\": \"Анна\", \"last\": \"Тамм\", \"gender\": \"f\", \"age\": 41, \"skin\": 1, \"hair\": \"bun\", \"hairColor\": 1, \"build\": \"average\", \"beard\": false, \"glasses\": false}, \"dispatch\": {\"first\": \"Анна\", \"last\": \"Тамм\", \"gender\": \"f\", \"age\": 41, \"skin\": 1, \"hair\": \"bun\", \"hairColor\": 1, \"build\": \"average\", \"beard\": false, \"glasses\": false}}"})  # Release O: the chief is earned in a career
 c.store.path = "user://services-test.json"
 var pick := find_text(c.snapshot.get("tree",[]),"112")
 c.action({"op":"event","id":pick.get("id"),"domId":pick.get("domId"),"target":pick.get("target"),"event":"click"})
 c.action({"op":"event","domId":"startChief","event":"click"})
 for i in range(3):
  c.action({"op":"event","domId":"closeModal","event":"click"})
 var state = c.invoke({"op":"state"})
 check(typeof(state)==TYPE_DICTIONARY and state.get("agency")=="dispatch" and state.get("mode")=="chief" and state.get("units",[]).size()==8,"112 chief: city crews and the centre")
 c.action({"op":"event","domId":"departmentBtn","event":"click"})
 var tree_text := JSON.stringify(c.snapshot.get("tree",[]))
 check(tree_text.contains("Линия 112 под вашим началом") and tree_text.contains("Смена в цифрах"),"112 chief: the centre screen")
 var hire := {}
 var stack: Array = c.snapshot.get("tree",[]).duplicate()
 while not stack.is_empty():
  var node = stack.pop_back()
  if node.get("tag")=="button" and str(node.get("text","")).strip_edges()=="Нанять":
   hire = node
   break
  stack.append_array(node.get("children",[]))
 check(not hire.is_empty(),"112 chief: a candidate to hire")
 if not hire.is_empty():
  c.action({"op":"event","id":hire.get("id"),"event":"click"})
  state = c.invoke({"op":"state"})
  check(state.get("desk",{}).get("colleagues",[]).size()==3,"112 chief: the hired operator is on the line")
 check(c.runtime.get_error().is_empty(),"112 chief: runtime error "+c.runtime.get_error())
 scene.queue_free()
 await process_frame
 print("Services: rescue, ambulance and 112 careers start and run in the native UI; the head of the 112 centre hires an operator")
 quit(1 if failed else 0)
