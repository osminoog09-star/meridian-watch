extends RefCounted
# Claude 17.10 (Release U «Удобный экран»): owner 16.10 — «управление, экраны — всё неудобно». The header is one compact row
# (time, weather, trust, budget, done) so the map gets the screen; help and settings live in «☰ Меню».
static func header(ui: Control, tree: Array) -> PanelContainer:
 var panel := PanelContainer.new()
 panel.name = "ShiftHeader"
 panel.position = Vector2(8,8)
 panel.size.x = maxf(280,ui.size.x-16)
 panel.add_theme_stylebox_override("panel",ui.panel_style("111d25cc","2a3943",4))
 var stats := HBoxContainer.new()
 stats.add_theme_constant_override("separation",6)
 var weather_text: String = ui.text_of(ui.find_node(tree,"weather"))
 for spec in [["clock",""],["trust","доверие"],["budget","бюджет"],["resolved","готово"]]:
  var column := VBoxContainer.new()
  column.size_flags_horizontal = Control.SIZE_EXPAND_FILL
  column.add_theme_constant_override("separation",0)
  var value: Label = ui.label(ui.text_of(ui.find_node(tree,spec[0])))
  value.name = spec[0]
  value.add_theme_font_size_override("font_size",18 if spec[0]=="clock" else 15)
  value.autowrap_mode = TextServer.AUTOWRAP_OFF
  column.add_child(value)
  var caption: Label
  if spec[0]=="clock":
   # the weather icon and temperature under the clock; the full line is the tooltip
   caption = ui.label(weather_text.split(" · ")[0] if not weather_text.is_empty() else "")
   caption.name = "ShiftWeather"
   caption.tooltip_text = weather_text
  else:
   caption = ui.label(spec[1])
  caption.add_theme_font_size_override("font_size",10)
  caption.add_theme_color_override("font_color",Color("879ca9"))
  caption.autowrap_mode = TextServer.AUTOWRAP_OFF
  caption.clip_text = true
  column.add_child(caption)
  if spec[0]=="clock":
   ui.native_fps = ui.label("%.0f FPS" % ui.frame_report.get("fps",0))
   ui.native_fps.name = "NativeFPS"
   ui.native_fps.add_theme_font_size_override("font_size",9)
   ui.native_fps.add_theme_color_override("font_color",Color("5f7480"))
   column.add_child(ui.native_fps)
  stats.add_child(column)
 panel.add_child(stats)
 return panel
# One line of radio; tapping it opens the journal.
static func radio(ui: Control,tree: Array) -> Button:
 var line := Button.new()
 line.name = "RadioText"
 line.text = ui.text_of(ui.find_node(tree,"radioText"))
 line.tooltip_text = line.text
 line.alignment = HORIZONTAL_ALIGNMENT_LEFT
 line.autowrap_mode = TextServer.AUTOWRAP_OFF
 line.clip_text = true
 line.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS
 line.flat = true
 line.size_flags_horizontal = Control.SIZE_EXPAND_FILL
 line.custom_minimum_size = Vector2(80,48)
 line.add_theme_font_size_override("font_size",12)
 line.pressed.connect(func(): ui.event({"domId":"journalBtn"},"click"))
 return line
