extends RefCounted
static func header(ui: Control, tree: Array) -> PanelContainer:
 var panel := PanelContainer.new()
 panel.name = "ShiftHeader"
 panel.position = Vector2(8,8)
 panel.size.x = maxf(280,ui.size.x-16)
 panel.add_theme_stylebox_override("panel",ui.panel_style("111d25","2a3943",6))
 var box := VBoxContainer.new()
 var title := HBoxContainer.new()
 var brand: Label = ui.label("MERCURY RESPONSE")
 brand.add_theme_color_override("font_color",Color("77dacb"))
 title.add_child(brand)
 for id in ["helpBtn","settingsBtn"]:
  var item: Dictionary = ui.find_node(tree,id)
  if not item.is_empty():
   var button: Button = ui.widget(item)
   button.text = "?" if id=="helpBtn" else "⚙"
   button.tooltip_text = ui.text_of(item)
   button.size_flags_horizontal = Control.SIZE_SHRINK_END
   title.add_child(button)
 box.add_child(title)
 var stats := HBoxContainer.new()
 stats.add_theme_constant_override("separation",8)
 for spec in [["clock","ВРЕМЯ"],["trust","ДОВЕРИЕ"],["budget","БЮДЖЕТ"],["resolved","ЗАВЕРШЕНО"]]:
  var column := VBoxContainer.new()
  column.size_flags_horizontal = Control.SIZE_EXPAND_FILL
  var caption: Label = ui.label(spec[1])
  caption.add_theme_font_size_override("font_size",9)
  caption.add_theme_color_override("font_color",Color("879ca9"))
  column.add_child(caption)
  var value: Label = ui.label(ui.text_of(ui.find_node(tree,spec[0])))
  value.name = spec[0]
  value.add_theme_font_size_override("font_size",16)
  column.add_child(value)
  if spec[0]=="clock":
   ui.native_fps = ui.label("%.0f FPS" % ui.frame_report.get("fps",0))
   ui.native_fps.name = "NativeFPS"
   ui.native_fps.add_theme_font_size_override("font_size",10)
   column.add_child(ui.native_fps)
  stats.add_child(column)
 box.add_child(stats)
 panel.add_child(box)
 return panel
static func radio(ui: Control,tree: Array) -> HBoxContainer:
 var row := HBoxContainer.new()
 var message: Label = ui.label(ui.text_of(ui.find_node(tree,"radioText")))
 message.name = "RadioText"
 message.max_lines_visible = 2
 message.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS
 message.tooltip_text = message.text
 message.add_theme_font_size_override("font_size",12)
 row.add_child(message)
 var journal := Button.new()
 journal.text = "Журнал"
 journal.custom_minimum_size = Vector2(52,52)
 journal.pressed.connect(func(): ui.event({"domId":"journalBtn"},"click"))
 row.add_child(journal)
 return row
