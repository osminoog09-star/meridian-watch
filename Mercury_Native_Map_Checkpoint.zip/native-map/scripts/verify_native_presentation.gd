extends SceneTree
const RichButton = preload("res://scripts/native_rich_button.gd")
func _initialize() -> void:
 call_deferred("verify")
func require(value: bool, message: String) -> void:
 if not value:
  push_error(message)
  quit(1)
func descendants(node: Node) -> Array:
 var all: Array = [node]
 for child in node.get_children():
  all.append_array(descendants(child))
 return all
func verify() -> void:
 var scene = load("res://main.tscn").instantiate()
 root.add_child(scene)
 await process_frame
 var ui = scene.native_ui
 for width in [360,740]:
  root.size = Vector2i(width,800)
  ui.signature = ""
  ui.refresh()
  for i in range(8):
   await process_frame
  var cards := 0
  for item in descendants(ui.root):
   if item is RichButton:
    cards += 1
    require(item.size.x<=width-24,"Card exceeds viewport")
    require(item.size.y>=item.content.get_combined_minimum_size().y+23,"Card clips wrapped description")
  require(cards>=2,"Start choices lost rich content")
 var meter = ui.widget({"tag":"div","classes":"meter","children":[{"tag":"i","style":"width:63%"}]})
 require(meter is ProgressBar and meter.value==63,"Progress not preserved")
 meter.free()
 var details = ui.widget({"tag":"details","id":"test-section","children":[{"tag":"summary","text":"История"},{"tag":"p","text":"Запись"}]})
 require(not details.get_child(1).visible,"Details expanded unexpectedly")
 details.get_child(0).toggled.emit(true)
 require(details.get_child(1).visible,"Details toggle broken")
 details.free()
 scene.campaign.action({"op":"event","domId":"startCareer","event":"click"})
 scene.campaign.action({"op":"event","domId":"closeModal","event":"click"})
 scene.campaign.action({"op":"event","domId":"mobileMenu","event":"click"})
 ui.signature = ""
 ui.refresh()
 require(ui.mouse_filter==Control.MOUSE_FILTER_STOP,"Modal leaks map clicks")
 print("Native presentation: 360/740 card wrapping, progress, disclosure, modal input passed")
 quit(0)
