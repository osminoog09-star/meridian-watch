extends SceneTree
func _initialize() -> void:
 verify.call_deferred()
func verify() -> void:
 var effect = load("res://scripts/weather_effects.gd").new()
 root.add_child(effect)
 for kind in ["clear","rain","snow","wind","fog","ice"]:
  effect.configure({"kind":kind},Vector3(400,0,-200),300)
  effect.animate(1.0/30)
  assert(effect.active_count<=effect.CAPACITY)
  assert(effect.instances.visible_instance_count==effect.active_count)
  for i in range(effect.active_count):
   var transform: Transform3D = effect.instances.get_instance_transform(i)
   assert(transform.origin.is_finite())
 effect.configure({"kind":"wind","event":{"id":"storm"}},Vector3.ZERO,200)
 assert(effect.storm and effect.active_count==192)
 effect.configure({"kind":"rain"},Vector3.ZERO,200,false)
 assert(effect.active_count==0)
 print("Native weather: 6 kinds, storm, finite transforms, bounded capacity and disabled effects passed")
 quit(0)
