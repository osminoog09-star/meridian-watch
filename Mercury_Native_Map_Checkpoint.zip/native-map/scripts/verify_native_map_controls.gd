extends SceneTree
var failed := false
func check(ok: bool,message: String) -> void:
 if not ok:
  failed = true
  push_error(message)
func _initialize() -> void:
 call_deferred("verify")
func verify() -> void:
 var scene = load("res://main.tscn").instantiate()
 root.add_child(scene)
 for i in range(6):
  await process_frame
 scene.set_process(false)
 scene.campaign.initialize({})
 scene.campaign.store.path = "user://native-map-control-test.json"
 for id in ["startCareer","closeModal","followUnit"]:
  scene.campaign.action({"op":"event","domId":id,"event":"click"})
 scene.apply_native_camera_commands()
 check(scene.following,"follow button")
 scene.campaign.action({"op":"event","domId":"cityView","event":"click"})
 scene.apply_native_camera_commands()
 check(not scene.following and scene.distance==650,"city must leave follow mode")
 scene.campaign.action({"op":"event","domId":"fullscreenBtn","event":"click"})
 check(scene.campaign.snapshot.bodyClasses.contains("native-fullscreen"),"fullscreen button")
 scene.native_ui.signature = ""
 scene.native_ui.refresh()
 scene.native_ui.sync_hud()
 check(not scene.native_ui.get_node("ShiftTransport").visible,"fullscreen hides transport")
 scene.campaign.action({"op":"event","domId":"fullscreenBtn","event":"click"})
 check(not scene.campaign.snapshot.bodyClasses.contains("native-fullscreen"),"fullscreen exits")
 for quality in ["simple","eco","models"]:
  scene.campaign.action({"op":"event","domId":"settingsBtn","event":"click"})
  scene.campaign.action({"op":"event","domId":"settingsGraphics","event":"change","value":quality})
  scene.campaign.action({"op":"event","domId":"applyAudio","event":"click"})
  scene.apply_native_camera_commands()
  check(scene.live_actors.quality==quality,"graphics preference ignored")
  check(scene.sun_light.shadow_enabled==(quality=="models"),"shadow quality")
  check(scene.city_stream.detail_enabled==(quality=="models"),"city detail")
 scene.campaign.snapshot["map"] = [{"op":"resolution","value":1}]
 scene.apply_native_camera_commands()
 check(is_equal_approx(scene.get_viewport().scaling_3d_scale,0.5),"adaptive scale conversion")
 for id in ["residentsBtn","walkingPathsBtn","toggleWalking"]:
  scene.campaign.action({"op":"event","domId":id,"event":"click"})
 scene.apply_native_camera_commands()
 check(scene.walking_overlay.visible,"walking toggle")
 var network = JSON.parse_string(FileAccess.get_file_as_string("res://assets/walking.json"))
 var edge = network.segments[0]
 for id in [edge.a,edge.b]:
  var point = network.nodes[id]
  scene.campaign.action({"op":"walking-pick","point":{"x":point[0],"y":point[1]}})
  scene.apply_native_camera_commands()
 check(scene.walking_overlay.route.mesh.get_surface_count()==1,"walking A to B route")
 print("Native map controls ","FAILED" if failed else "PASSED")
 quit(1 if failed else 0)
