extends RefCounted
const CAPACITY := 600
var samples: Array[float] = []
var stalls := 0
func add(delta: float) -> void:
 samples.append(delta*1000.0)
 if samples.size()>CAPACITY:
  samples.pop_front()
 if delta>0.1:
  stalls += 1
func report() -> Dictionary:
 if samples.is_empty():
  return {}
 var ordered := samples.duplicate()
 ordered.sort()
 var sum := 0.0
 for value in samples:
  sum += value
 return {"fps":1000.0/(sum/samples.size()),"p95_ms":ordered[int((ordered.size()-1)*0.95)],"worst_ms":ordered[-1],"stalls_gt100ms":stalls,"static_memory_bytes":int(Performance.get_monitor(Performance.MEMORY_STATIC)),"render_objects":int(Performance.get_monitor(Performance.RENDER_TOTAL_OBJECTS_IN_FRAME)),"draw_calls":int(Performance.get_monitor(Performance.RENDER_TOTAL_DRAW_CALLS_IN_FRAME)),"samples":samples.size()}
