extends SceneTree
# Claude 17.10 (Release U3): owner — «карточка Оперативный центр мигает, дрожит». While the game runs the «Экипажи»
# screen must keep its widgets (texts update in place); it is rebuilt only when its structure changes.
var failed := false
func _initialize() -> void:
 call_deferred("verify")
func frames(n: int) -> void:
 for i in range(n):
  await process_frame
func verify() -> void:
 root.size = Vector2i(369,905)
 var scene = load("res://main.tscn").instantiate()
 root.add_child(scene)
 await frames(8)
 scene.campaign.initialize({})
 scene.campaign.store.path = "user://no-flicker.json"
 for id in ["startCareer","closeModal"]:
  scene.campaign.action({"op":"event","domId":id,"event":"click"})
 await frames(30)
 var ui = scene.native_ui
 # open «Экипажи» through the bottom tab like a finger would
 var nav: Dictionary = ui.find_class(scene.campaign.snapshot.get("tree",[]),"mobile-nav")
 if nav.get("children",[]).size()>1:
  ui.event(nav.children[1],"click")
 var speeds: Array = ui.collect_speed_nodes(scene.campaign.snapshot.get("tree",[]))
 if not speeds.is_empty():
  ui.event(speeds[speeds.size()-1],"click")
 await frames(20)
 var first: Node = ui.root.get_child(0) if ui.root.get_child_count()>0 else null
 var rebuilds := 0
 var clock_before: String = ui.get_node("ShiftHeader").find_child("clock",true,false).text
 for k in range(240):
  await process_frame
  var now: Node = ui.root.get_child(0) if ui.root.get_child_count()>0 else null
  if now!=first:
   rebuilds += 1
   first = now
 var clock_after: String = ui.get_node("ShiftHeader").find_child("clock",true,false).text
 print("rebuilds in 240 frames: ",rebuilds,"; clock ",clock_before," → ",clock_after)
 if clock_before==clock_after:
  push_error("the game did not run")
  failed = true
 if rebuilds>2:
  push_error("the crews screen is rebuilt while only texts change")
  failed = true
 print("No flicker ","FAILED" if failed else "PASSED")
 quit(1 if failed else 0)
