extends SceneTree
func _initialize() -> void:
 var runtime = ClassDB.instantiate("QuickJS")
 var params := {"active":true,"master":0.8,"beds":[{"level":0.3,"hz":800}],"tones":[{"hz":80,"level":0.2,"cutoff":900,"wave":[0,1,0.72,0.46]},{"hz":1100,"level":0.2,"pan":0.5,"wave":[0,1,0.04,0.34]}],"shots":[{"noise":true,"hz":1350,"length":0.5,"level":0.5,"shape":[[0.01,1],[0.4,0.4],[0.5,0]]}],"room":{"wet":0.3,"decay":1.1,"pre":0.012}}
 var peak := 0.0
 var energy := 0.0
 var start := Time.get_ticks_usec()
 var render_us := 0
 for index in range(100):
  var render_start := Time.get_ticks_usec()
  var buffer: PackedVector2Array = runtime.render_audio(params,1024,22050)
  render_us += Time.get_ticks_usec()-render_start
  params.shots = []
  if buffer.size()!=1024:
   quit(1)
   return
  for frame in buffer:
   if not is_finite(frame.x) or not is_finite(frame.y):
    quit(2)
    return
   peak = maxf(peak,maxf(absf(frame.x),absf(frame.y)))
   energy += frame.x*frame.x+frame.y*frame.y
 var elapsed := (Time.get_ticks_usec()-start)/1000.0
 if peak>0.95 or energy<0.01:
  quit(3)
  return
 var silent: PackedVector2Array = runtime.render_audio({"active":false,"master":0},1024,22050)
 for sample in silent:
  if sample!=Vector2.ZERO:
   quit(4)
   return
 print(JSON.stringify({"native_audio_samples":102400,"peak":peak,"rms":sqrt(energy/204800),"render_and_validation_ms":elapsed,"render_only_ms":render_us/1000.0,"silence_when_disabled":true}))
 quit(0)
