extends Node3D
# Claude-derived presentation poses; bounded reused native meshes, no save mutation.
const MAX_PEOPLE := 180
var bodies: Array[MeshInstance3D] = []
var phones: Array[MeshInstance3D] = []
var normal := StandardMaterial3D.new()
var witness := StandardMaterial3D.new()
var glow := StandardMaterial3D.new()
func _ready() -> void:
 normal.albedo_color = Color("7f8c9b")
 witness.albedo_color = Color("d9b25f")
 glow.albedo_color = Color("cde8ff")
 glow.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
 var body := CapsuleMesh.new()
 body.radius = 0.22
 body.height = 1.65
 var phone := BoxMesh.new()
 phone.size = Vector3(0.08,0.14,0.02)
 for index in range(MAX_PEOPLE):
  var person := MeshInstance3D.new()
  person.mesh = body
  person.material_override = normal
  person.visible = false
  add_child(person)
  bodies.append(person)
  var display := MeshInstance3D.new()
  display.mesh = phone
  display.material_override = glow
  display.visible = false
  add_child(display)
  phones.append(display)
func refresh(poses: Array,focus: Vector3,distance: float,night: bool) -> void:
 var count := 0
 # Cull before assigning the fixed pool. Far-away crowds consume no render objects.
 for pose in poses:
  var position := Vector3((float(pose.x)-1.55)*1670,0.825,(float(pose.y)-2.52)*1670)
  position.y += preload("res://scripts/road_elevation.gd").height_at(position)
  if position.distance_to(focus)>maxf(150,distance*1.5):
   continue
  if count>=MAX_PEOPLE:
   break
  var person := bodies[count]
  person.position = position
  person.rotation.y = -float(pose.facing)
  person.material_override = witness if pose.role=="witness" else normal
  person.visible = true
  var display := phones[count]
  display.position = position+Vector3(0.25,0.45,0)
  display.visible = night and pose.role=="filming"
  count += 1
 for index in range(count,MAX_PEOPLE):
  bodies[index].visible = false
  phones[index].visible = false
