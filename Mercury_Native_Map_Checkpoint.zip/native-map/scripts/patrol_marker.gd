extends Control
var camera: Camera3D
var patrol: Node3D
func _ready() -> void:
 mouse_filter = Control.MOUSE_FILTER_IGNORE
 set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
func _process(_delta: float) -> void:
 queue_redraw()
func _draw() -> void:
 if not is_instance_valid(camera) or not is_instance_valid(patrol) or camera.is_position_behind(patrol.position):
  return
 var centre := camera.unproject_position(patrol.position+Vector3.UP*1.5)
 var front := camera.unproject_position(patrol.position+patrol.transform.basis.x*4.6+Vector3.UP*1.5)
 if centre.distance_to(front)>=14:
  return
 var direction := (front-centre).normalized()
 var side := Vector2(-direction.y,direction.x)
 draw_colored_polygon(PackedVector2Array([centre+direction*10,centre-direction*7+side*6,centre-direction*4,centre-direction*7-side*6]),Color("4a9dff"))
