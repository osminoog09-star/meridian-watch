extends SceneTree
var failed := false
func check(ok: bool,message: String) -> void:
 if not ok:
  failed = true
  push_error(message)
func _initialize() -> void:
 call_deferred("verify")
func verify() -> void:
 var scene = load("res://main.tscn").instantiate()
 root.add_child(scene)
 for i in range(12):
  await process_frame
 scene.set_process(false)
 scene.night_effects.configure(scene.city_stream,Vector3.ZERO,90,true,true)
 check(scene.night_effects.visible,"night details enabled")
 check(scene.night_effects.windows.multimesh.visible_instance_count<=192,"window cap")
 check(scene.night_effects.bulbs.multimesh.visible_instance_count<=48,"lamp cap")
 scene.night_effects.configure(scene.city_stream,Vector3.ZERO,90,false,true)
 check(not scene.night_effects.windows.visible and not scene.night_effects.bulbs.visible,"day lights off")
 scene.fireworks.configure(true,false)
 scene.fireworks.animate(0.033)
 check(scene.fireworks.multimesh.visible_instance_count==128,"firework pool")
 for index in range(128):
  check(scene.fireworks.multimesh.get_instance_transform(index).origin.is_finite(),"finite spark")
 scene.fireworks.configure(true,true)
 check(scene.fireworks.multimesh.visible_instance_count==0,"calm disables fireworks")
 scene.fireworks.configure(false,false)
 check(scene.fireworks.multimesh.visible_instance_count==0,"holiday off")
 for kind in ["ambulance","rescue"]:
  var mesh = scene.live_actors.model(kind)
  check(mesh.get_surface_count()>0 and mesh.get_aabb().size.y>2,"distinct service body")
 var bridges = JSON.parse_string(FileAccess.get_file_as_string("res://assets/bridges.json"))
 for bridge in bridges:
  var point := Vector3((bridge.a[0]+bridge.b[0])*0.5,0,(bridge.a[1]+bridge.b[1])*0.5)
  check(is_equal_approx(preload("res://scripts/road_elevation.gd").height_at(point),2.5),"bridge deck height")
 print("Native effects ","FAILED" if failed else "PASSED","; bridge segments ",bridges.size())
 quit(1 if failed else 0)
