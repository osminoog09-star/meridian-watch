extends AudioStreamPlayer
var controller: RefCounted
var map: Node3D
var elapsed := 0.0
var parameter_elapsed := 1.0
var parameters: Dictionary = {"active":false,"master":0}
var playback: AudioStreamGeneratorPlayback
var sample_rate := 22050
func _ready() -> void:
 var generator := AudioStreamGenerator.new()
 generator.mix_rate = sample_rate
 generator.buffer_length = 0.15
 stream = generator
 play()
 playback = get_stream_playback()
func _process(delta: float) -> void:
 if controller==null or not controller.initialized or not controller.runtime.has_method("render_audio"):
  return
 elapsed += delta
 parameter_elapsed += delta
 if parameter_elapsed>=0.1:
  var scene := {"x":map.focus.x/1670.0+1.55,"y":map.focus.z/1670.0+2.52,"zoom":clampf(6500.0/map.distance,0.2,80)}
  var raw = controller.runtime.eval("MercuryUI.call("+JSON.stringify(JSON.stringify({"op":"audio","time":elapsed,"scene":scene}))+ ")")
  var result = JSON.parse_string(str(raw))
  if typeof(result)==TYPE_DICTIONARY:
   parameters = result
  parameter_elapsed = 0
 var available: int = playback.get_frames_available()
 if available>0:
  var frames: int = mini(8192,available)
  var buffer: PackedVector2Array = controller.runtime.render_audio(parameters,frames,sample_rate)
  playback.push_buffer(buffer)
  parameters["shots"] = []
func _notification(what: int) -> void:
 if what==NOTIFICATION_APPLICATION_PAUSED:
  stream_paused = true
 elif what==NOTIFICATION_APPLICATION_RESUMED:
  stream_paused = false
