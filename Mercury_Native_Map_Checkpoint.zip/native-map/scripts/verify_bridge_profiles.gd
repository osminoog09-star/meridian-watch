extends SceneTree
const Elevation = preload("res://scripts/road_elevation.gd")
var failed := false
var errors := 0
func check(ok: bool,message: String) -> void:
 if not ok:
  failed = true
  errors += 1
  if errors<=12:
   push_error(message)
func _initialize() -> void:
 var data: Dictionary = JSON.parse_string(FileAccess.get_file_as_string("res://assets/bridge-profiles.json"))
 var city: Dictionary = JSON.parse_string(FileAccess.get_file_as_string("res://assets/city.json"))
 var found := 0
 var samples := 0
 for chunk in city.chunks:
  for road in chunk.roads:
   var key := Elevation.road_key(road)
   if not data.profiles.has(key):
    continue
   found += 1
   var pieces: Array = Elevation.road_profile(road)
   check(Vector2(pieces[0].a[0],pieces[0].a[1]).distance_to(Vector2(road.a[0],road.a[1]))<0.00001,"source start unchanged")
   check(Vector2(pieces[-1].b[0],pieces[-1].b[1]).distance_to(Vector2(road.b[0],road.b[1]))<0.00001,"source end unchanged")
   for i in range(pieces.size()):
    var p: Dictionary = pieces[i]
    var a := Vector2(p.a[0],p.a[1])
    var b := Vector2(p.b[0],p.b[1])
    check(absf(p.hb-p.ha)<=a.distance_to(b)*2.5/40.0+0.0002,"ramp slope bounded")
    if i>0:
     check(absf(p.ha-pieces[i-1].hb)<0.000001,"piece height continuous")
    for t in [0.0,0.1,0.5,0.9,1.0]:
     var position := a.lerp(b,t)
     var actual := Elevation.height_at(Vector3(position.x,0,position.y),atan2(b.y-a.y,b.x-a.x))
     var expected := lerpf(p.ha,p.hb,t)
     check(absf(actual-expected)<0.0002,"road/actor height agrees "+key+" t="+str(t)+" "+str(actual)+" != "+str(expected))
     samples += 1
 check(found==data.profiles.size(),"all generated road keys resolve")
 var geometry = preload("res://scripts/city_geometry.gd").new()
 var st := SurfaceTool.new()
 st.begin(Mesh.PRIMITIVE_TRIANGLES)
 var example: Dictionary = city.chunks[0].roads[0]
 # Controlled straight ramp checks the generated mesh includes both endpoint heights.
 geometry.road_piece(st,example,{"a":[0,0],"b":[40,0],"ha":0.0,"hb":2.5})
 var mesh: Mesh = st.commit()
 var bounds := mesh.get_aabb()
 check(bounds.position.y<0.11 and bounds.end.y>2.59,"ramp mesh spans ground and deck")
 print("Bridge road/actor profiles ","FAILED" if failed else "PASSED","; roads ",found,"; samples ",samples,"; errors ",errors)
 quit(1 if failed else 0)
