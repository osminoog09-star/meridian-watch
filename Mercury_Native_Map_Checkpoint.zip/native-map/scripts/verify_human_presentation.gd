extends SceneTree
var failed := false
func check(ok: bool,message: String) -> void:
 if not ok:
  failed = true
  push_error(message)
func _initialize() -> void:
 call_deferred("verify")
func verify() -> void:
 var models: Dictionary = JSON.parse_string(FileAccess.get_file_as_string("res://assets/actor-models.json"))
 var fixtures: Array = JSON.parse_string(FileAccess.get_file_as_string("res://ui/human-fixtures.json"))
 var skins = preload("res://scripts/human_skin.gd").new()
 var total := 0
 for fixture in fixtures:
  var meshes: Dictionary = skins.parts(models[fixture.kind],fixture.kind,fixture.style.palette)
  for group in fixture.counts:
   var arrays: Array = meshes[group].surface_get_arrays(0)
   check(arrays[Mesh.ARRAY_INDEX].size()==int(fixture.counts[group]),"source face count "+group)
  for sample in fixture.samples:
   var p := Vector3(sample.point[0],sample.point[1],sample.point[2])
   var expected := Vector3(sample.expected[0],sample.expected[1],sample.expected[2])
   check((skins.pose_transform(sample.group,sample.pose,sample.phase)*p).distance_to(expected)<0.000001,"source pose "+sample.group+" "+sample.pose)
   total += 1
  var actor := MeshInstance3D.new()
  root.add_child(actor)
  skins.apply(actor,models[fixture.kind],fixture.kind,fixture.style,"assist",0.6,true,true)
  check(actor.mesh==null and actor.get_node("Human_body").visible,"near articulated model")
  skins.apply(actor,models[fixture.kind],fixture.kind,fixture.style,"idle",0,false,false)
  check(actor.mesh==meshes.whole and not actor.get_node("Human_body").visible,"far one-mesh LOD without old limbs")
  actor.free()
 var live = preload("res://scripts/live_actors.gd").new()
 root.add_child(live)
 var person := {"id":"f1","x":1.55,"y":2.52,"heading":0,"walking":true,"pose":"idle","nativeStyle":fixtures[0].style}
 var view := {"units":[{"id":1,"crew":[person]}],"vehicles":[]}
 live.refresh(view,1,Vector3.ZERO,50)
 person.x += 0.0002
 live.refresh(view,1,Vector3.ZERO,50)
 var phase: float = live.walk_state["crew-1-1"].phase
 check(phase>0,"walking follows actual distance")
 live.refresh(view,1,Vector3.ZERO,50)
 check(live.walk_state["crew-1-1"].phase==phase,"stationary/paused view freezes walking")
 person.walking = false
 person.pose = "radio"
 live.refresh(view,1,Vector3.ZERO,50)
 check(live.walk_state["crew-1-1"].phase==0,"stationary crew pose resets gait")
 live.set_quality("simple")
 live.refresh(view,1,Vector3.ZERO,50)
 check(not live.people[0].get_node("Human_leftLeg").visible,"simple quality hides articulated pool")
 live.refresh({},1,Vector3.ZERO,50)
 check(live.walk_state.is_empty() and not live.people[0].visible,"leaving actors clear bounded gait state")
 live.free()
 var crowd = preload("res://scripts/onlookers.gd").new()
 root.add_child(crowd)
 crowd.refresh([{"id":"crowd","x":1.55,"y":2.52,"facing":1.2,"role":"filming","nativeStyle":fixtures[1].style}],Vector3.ZERO,50,true)
 check(crowd.bodies[0].get_node("Human_leftForearm").visible and crowd.phones[0].visible,"native crowd uses source human model and phone")
 check(crowd.phones[0].position.is_finite(),"phone transform finite")
 crowd.refresh([],Vector3.ZERO,50,true)
 check(not crowd.bodies[0].visible and not crowd.phones[0].visible,"crowd pool clears")
 crowd.free()
 print("Native original human vertices/LOD/gait/pool ","FAILED" if failed else "PASSED","; samples ",total)
 quit(1 if failed else 0)
