extends SceneTree
var failed := false
func _initialize() -> void:
 call_deferred("verify")
func check(value: bool,message: String) -> void:
 if not value:
  failed = true
  push_error(message)
func settle() -> void:
 for i in range(8):
  await process_frame
func verify() -> void:
 var scene = load("res://main.tscn").instantiate()
 root.size = Vector2i(360,640)
 root.add_child(scene)
 await settle()
 var ui = scene.native_ui
 var campaign = scene.campaign
 campaign.action({"op":"event","domId":"startCareer","event":"click"})
 campaign.action({"op":"event","domId":"closeModal","event":"click"})
 campaign.action({"op":"event","domId":"settingsBtn","event":"click"})
 ui.signature = ""
 ui.refresh()
 await settle()
 var scroll = ui.scroll
 check(scroll.get_v_scroll_bar().max_value>scroll.size.y+150,"Settings fixture must overflow")
 scroll.scroll_vertical = 150
 var first = ui.root.get_child(0)
 var touch := InputEventScreenTouch.new()
 touch.index = 0
 touch.position = scroll.get_global_rect().get_center()
 touch.pressed = true
 scroll._input(touch)
 ui.signature = ""
 ui.refresh()
 check(ui.root.get_child(0)==first,"Refresh interrupted touch")
 touch.pressed = false
 scroll._input(touch)
 scroll.last_motion = Time.get_ticks_msec()
 ui.refresh()
 check(ui.root.get_child(0)==first,"Refresh interrupted inertia")
 scroll.last_motion = -1000
 ui.refresh()
 await settle()
 check(scroll.scroll_vertical==150,"Same-page refresh lost position")
 var close_y: float = ui.modal_close.position.y
 scroll.scroll_vertical = 220
 check(ui.modal_close.position.y==close_y,"Close action moved with content")
 scroll.last_motion = -1000
 campaign.action({"op":"event","domId":"closeModal","event":"click"})
 campaign.action({"op":"event","domId":"mobileMenu","event":"click"})
 ui.signature = ""
 ui.refresh()
 await settle()
 check(scroll.scroll_vertical==0,"New menu inherited settings offset")
 campaign.action({"op":"event","domId":"settingsBtn","event":"click"})
 ui.signature = ""
 ui.refresh()
 await settle()
 check(scroll.scroll_vertical==220,"Returning to settings lost position")
 check(scroll.horizontal_scroll_mode==ScrollContainer.SCROLL_MODE_DISABLED,"Unwanted horizontal panning")
 print("Scroll regression: touch/inertia, per-page restoration and fixed close ","FAILED" if failed else "PASSED")
 quit(1 if failed else 0)
