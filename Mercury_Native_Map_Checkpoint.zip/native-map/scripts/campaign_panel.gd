extends PanelContainer
const STATUS = {"patrol":"Патрулирование","idle":"Свободен","responding":"На вызов","decision":"Нужно решение","working":"На месте","returning":"В участок","resting":"Отдых","transporting":"Доставка","handover":"Передача","servicing":"Обслуживание","briefing":"Инструктаж","break":"Обед","reports":"Рапорты","proactive":"Задание патруля"}
var controller: RefCounted
var selected_unit := 1
var signature := ""
var box := VBoxContainer.new()
func _ready() -> void:
 custom_minimum_size = Vector2(240,0)
 position = Vector2(16,250)
 var scroller := ScrollContainer.new()
 scroller.custom_minimum_size = Vector2(240,300)
 scroller.add_child(box)
 add_child(scroller)
func button(text: String,action: Callable) -> void:
 var control := Button.new()
 control.text = text
 control.tooltip_text = text
 control.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS
 control.custom_minimum_size = Vector2(52,52)
 control.pressed.connect(action)
 box.add_child(control)
func refresh(view: Dictionary) -> void:
 var next_signature := JSON.stringify({"units":view.units.map(func(u): return [u.id,u.status,u.incident]),"calls":view.incidents.map(func(i): return [i.id,i.state]),"ended":view.ended,"dialogues":view.incidents.map(func(i): return [i.id,i.get("talk"),i.get("dialogue")])})
 if next_signature==signature:
  return
 signature = next_signature
 for child in box.get_children():
  box.remove_child(child)
  child.queue_free()
 var heading := Label.new()
 heading.text = "Экипажи и вызовы"
 box.add_child(heading)
 for unit in view.units:
  var id: int = int(unit.id)
  button("Экипаж %02d · %s" % [id,str(STATUS.get(unit.status,"На службе"))],func():
   selected_unit = id
   signature = "")
 for incident in view.incidents:
  var id: int = int(incident.id)
  button(str(incident.name),func():
   controller.command("assign",[selected_unit,id])
   signature = "")
 var current_unit: Dictionary = {}
 for unit in view.units:
  if int(unit.id)==selected_unit:
   current_unit = unit
 if current_unit.get("status") in ["decision","working"]:
  for incident in view.incidents:
   if incident.id==current_unit.incident:
    if typeof(incident.get("dialogue"))==TYPE_DICTIONARY:
     var stage: Dictionary = incident.dialogue
     var description := Label.new()
     description.text = str(stage.get("title",stage.get("label","Разговор на месте")))
     description.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
     box.add_child(description)
     for option in stage.options:
      var choice: String = str(option.id)
      button(str(option.get("label",option.get("text",choice))),func():
       controller.command("chooseTalk",[selected_unit,choice])
       signature = "")
      box.get_child(box.get_child_count()-1).disabled = not option.open
     continue
    if current_unit.get("status")!="decision":
     continue
    for option in incident.options:
     var choice = option[1]
     button(str(option[0]),func():
      controller.command("decide",[selected_unit,choice])
      signature = "")
 button("Отдых экипажа",func(): controller.command("rest",[selected_unit]))
 button("Сохранить",func(): controller.save())
 if view.ended:
  button("Следующая смена",func():
   controller.core.invoke({"op":"nextShift"})
   controller.save()
   signature = "")
