extends SceneTree
# Claude 17.10 (Release G4) bench: time to build the 60 busiest city tiles at full detail.
func _initialize() -> void:
 var data = JSON.parse_string(FileAccess.get_file_as_string("res://assets/city.json"))
 var tiles: Array = data.chunks
 tiles.sort_custom(func(a,b): return a.buildings.size()+a.roads.size()>b.buildings.size()+b.roads.size())
 var g = preload("res://scripts/city_geometry.gd").new()
 var mat := ShaderMaterial.new()
 var t0 := Time.get_ticks_usec()
 var tris := 0
 for i in range(60):
  var before: int = g.triangles
  var m: MeshInstance3D = g.chunk(tiles[i],mat,0)
  tris += g.triangles-before
  m.free()
 print("60 tiles ms ",(Time.get_ticks_usec()-t0)/1000," triangles ",tris)
 quit(0)
