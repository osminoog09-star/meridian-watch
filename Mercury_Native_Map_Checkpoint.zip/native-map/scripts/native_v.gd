extends RefCounted
# Claude 17.10.2026 (Release V «Новый интерфейс»). Owner 17.10: «переработай интерфейс полностью — сейчас куча всего,
# информации много, а толку от неё ноль, и он перегружен». What the research says (mobile game HUD guides, reviews of
# 911 Operator / Emergency HQ / Police Simulator): the map is the game; show only what the player's role needs now;
# one clear next action under the thumb; details on demand (progressive disclosure); few, large, labelled controls;
# selection and state always visible. So the screen is:
#   · a thin top bar — time and weather, the player's rank (or trust and budget for a chief), pause and speed;
#   · one context card at the bottom — your patrol and what it is doing, or the call you are working with its main
#     action first, or a new call to take; the last radio line under it (tap → the journal);
#   · four tabs — Патруль, Вызовы (with a counter), Рация, Меню; a tab tapped again returns to the map;
#   · two map buttons — «◎» (to my car) and «⋯» (the camera views, folded away).
# Shift numbers nobody acts on during play (resolved count, FPS, fuel and wear) moved to the report and the patrol sheet.
const RANKS := ["Главный констебль","Старший констебль","Младший констебль","Констебль","Комиссар"]
const SHORT := {"Главный констебль":"Гл. констебль","Старший констебль":"Ст. констебль","Младший констебль":"Мл. констебль","Констебль":"Констебль","Комиссар":"Комиссар"}
static func chip(ui: Control,text: String,color := "1c2c36",border := "33505c") -> PanelContainer:
 var p := PanelContainer.new()
 p.add_theme_stylebox_override("panel",ui.panel_style(color,border,6))
 var l: Label = ui.label(text)
 l.autowrap_mode = TextServer.AUTOWRAP_OFF
 l.add_theme_font_size_override("font_size",13)
 p.add_child(l)
 return p
static func flat_button(ui: Control,text: String,min_size := Vector2(44,44),font := 14) -> Button:
 var b := Button.new()
 b.text = text
 b.custom_minimum_size = min_size
 b.add_theme_font_size_override("font_size",font)
 b.autowrap_mode = TextServer.AUTOWRAP_OFF
 b.focus_mode = Control.FOCUS_NONE
 return b
static func rank_of(text: String) -> String:
 for r in RANKS:
  if text.contains(r):
   return r
 return ""
static func header(ui: Control,tree: Array) -> PanelContainer:
 var panel := PanelContainer.new()
 panel.name = "ShiftHeader"
 panel.position = Vector2(ui.wide_left()+8,8)
 panel.size.x = minf(maxf(280,ui.size.x-ui.wide_left()-16),640)
 panel.add_theme_stylebox_override("panel",ui.panel_style("0f1a21d9","25363f",6))
 var box := VBoxContainer.new()
 box.add_theme_constant_override("separation",4)
 var row := HBoxContainer.new()
 row.add_theme_constant_override("separation",8)
 var clock: Label = ui.label(ui.text_of(ui.find_node(tree,"clock")))
 clock.name = "clock"
 clock.autowrap_mode = TextServer.AUTOWRAP_OFF
 clock.size_flags_horizontal = Control.SIZE_SHRINK_BEGIN
 clock.add_theme_font_size_override("font_size",20)
 row.add_child(clock)
 var weather_text: String = ui.text_of(ui.find_node(tree,"weather"))
 var short_weather: PackedStringArray = weather_text.split(" · ")[0].split(" ",false) if not weather_text.is_empty() else PackedStringArray()
 var weather: Label = ui.label(" ".join(short_weather.slice(0,2)))
 weather.name = "ShiftWeather"
 weather.tooltip_text = weather_text
 weather.autowrap_mode = TextServer.AUTOWRAP_OFF
 weather.size_flags_horizontal = Control.SIZE_SHRINK_BEGIN
 weather.add_theme_color_override("font_color",Color("9fb4c0"))
 weather.add_theme_font_size_override("font_size",13)
 row.add_child(weather)
 var rank := rank_of(ui.text_of(ui.find_node(tree,"identity")))
 var role: Label
 if not rank.is_empty():
  role = ui.label(SHORT.get(rank,rank))
  role.name = "ShiftRank"
 else:
  role = ui.label(ui.text_of(ui.find_node(tree,"trust"))+" доверие · "+ui.text_of(ui.find_node(tree,"budget"))+" €")
  role.name = "trust"
 role.autowrap_mode = TextServer.AUTOWRAP_OFF
 role.clip_text = true
 role.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS
 role.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
 role.size_flags_horizontal = Control.SIZE_EXPAND_FILL
 role.add_theme_font_size_override("font_size",13)
 role.add_theme_color_override("font_color",Color("77dacb"))
 row.add_child(role)
 var pause: Dictionary = ui.find_node(tree,"pauseBtn")
 if not pause.is_empty():
  var p: Button = ui.widget(pause)
  p.custom_minimum_size = Vector2(44,40)
  p.size_flags_horizontal = Control.SIZE_SHRINK_END
  ui._tight(p)
  row.add_child(p)
 var speeds: Array = ui.collect_speed_nodes(tree)
 if not speeds.is_empty():
  var current := 0
  for k in range(speeds.size()):
   if str(speeds[k].get("classes","")).split(" ").has("active"):
    current = k
  var speed := flat_button(ui,ui.text_of(speeds[current])+" ▸",Vector2(58,40),14)
  speed.name = "SpeedCycle"
  speed.tooltip_text = "Скорость игры: нажмите для следующей"
  speed.size_flags_horizontal = Control.SIZE_SHRINK_END
  ui._tight(speed)
  speed.set_meta("next",speeds[(current+1)%speeds.size()])
  speed.pressed.connect(func(): ui.event(speed.get_meta("next"),"click"))
  row.add_child(speed)
 box.add_child(row)
 # the shift's progress as a thin line under the bar
 var shift := ProgressBar.new()
 shift.name = "ShiftProgress"
 shift.show_percentage = false
 shift.custom_minimum_size = Vector2(60,3)
 var style: String = ui.find_node(tree,"shiftBar").get("style","")
 for part in style.split(";"):
  if part.strip_edges().begins_with("width:"):
   shift.value = clampf(part.get_slice(":",1).replace("%","").to_float(),0,100)
 box.add_child(shift)
 ui.native_fps = null
 panel.add_child(box)
 return panel
# The context card: the call in work, or a new call, or your patrol.
static func context(ui: Control,tree: Array) -> VBoxContainer:
 var box := VBoxContainer.new()
 box.name = "ContextCard"
 box.add_theme_constant_override("separation",6)
 var status: Dictionary = ui.controller.snapshot.get("status",{})
 var detail: Dictionary = ui.find_node(tree,"callDetail")
 var has_call: bool = status.get("selectedCall")!=null and not ui.find_tag(detail,"h3").is_empty()
 var tab := str(status.get("tab","map"))
 if has_call and tab!="calls":
  var title: Label = ui.label(ui.text_of(ui.find_tag(detail,"h3")))
  title.add_theme_font_size_override("font_size",17)
  box.add_child(title)
  var place: Dictionary = ui.find_class([detail],"incident-location")
  var phase := ""
  var scene: Dictionary = ui.find_class([detail],"scene-card")
  if not scene.is_empty():
   phase = ui.text_of(ui.find_tag(scene,"strong"))
  var line: Label = ui.label((ui.text_of(place) if not place.is_empty() else "")+(" · "+phase if not phase.is_empty() else ""))
  line.add_theme_font_size_override("font_size",12)
  line.add_theme_color_override("font_color",Color("9fb4c0"))
  box.add_child(line)
  var actions: Array = []
  ui.collect_actions(detail,actions)
  var shown := 0
  for node in actions:
   if shown>=2:
    break
   var b = ui.widget(node)
   if b is Button:
    b.custom_minimum_size.y = 52
    b.add_theme_font_size_override("font_size",15)
    if shown==0:
     b.add_theme_stylebox_override("normal",ui.panel_style("1f4a48","77dacb",8))
    box.add_child(b)
    shown += 1
  var more := flat_button(ui,"Подробнее о вызове ›",Vector2(0,40),13)
  more.name = "CallMore"
  more.flat = true
  more.alignment = HORIZONTAL_ALIGNMENT_LEFT
  more.add_theme_color_override("font_color",Color("77dacb"))
  var calls_tab := nav_node(ui,tree,"calls")
  more.pressed.connect(func(): ui.call_details_open = true; ui.event(calls_tab,"click"))
  box.add_child(more)
 else:
  # a call waiting for a crew, under the thumb: the list of calls is built only on its tab, so the map view tells
  var waiting := 0
  for incident in ui.controller.snapshot.get("view",{}).get("incidents",[]):
   if str(incident.get("state",""))=="waiting":
    waiting += 1
  if waiting>0 and tab=="map":
   var take := flat_button(ui,"● "+("Новый вызов ждёт экипаж" if waiting==1 else "Вызовов ждут экипаж: "+str(waiting))+" ›",Vector2(0,48),14)
   take.name = "NewCallChip"
   take.alignment = HORIZONTAL_ALIGNMENT_LEFT
   take.add_theme_stylebox_override("normal",ui.panel_style("3a2a1c","efa66b",8))
   take.add_theme_color_override("font_color",Color("ffd9b8"))
   var calls_node := nav_node(ui,tree,"calls")
   take.pressed.connect(func(): ui.event(calls_node,"click"))
   box.add_child(take)
  var unit := own_unit(ui,tree)
  if not unit.is_empty():
   var name_row := HBoxContainer.new()
   var name: Label = ui.label(ui.text_of(ui.find_tag(unit,"strong")))
   name.add_theme_font_size_override("font_size",15)
   name.size_flags_horizontal = Control.SIZE_SHRINK_BEGIN
   name.autowrap_mode = TextServer.AUTOWRAP_OFF
   name_row.add_child(name)
   var state: Label = ui.label(ui.text_of(ui.find_tag(unit,"small")).split(" · ")[0])
   state.add_theme_color_override("font_color",Color("77dacb"))
   state.add_theme_font_size_override("font_size",13)
   state.autowrap_mode = TextServer.AUTOWRAP_OFF
   state.clip_text = true
   state.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS
   name_row.add_child(state)
   box.add_child(name_row)
   var reason: Label = ui.label(ui.text_of(ui.find_class([unit],"unit-reason")))
   reason.add_theme_font_size_override("font_size",12)
   reason.add_theme_color_override("font_color",Color("b9c8cf"))
   reason.max_lines_visible = 2
   reason.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS
   box.add_child(reason)
 var radio: Button = preload("res://scripts/native_hud.gd").radio(ui,tree)
 radio.text = "📻 "+radio.text
 radio.custom_minimum_size.y = 34
 radio.add_theme_color_override("font_color",Color("9fb4c0"))
 box.add_child(radio)
 return box
static func own_unit(ui: Control,tree: Array) -> Dictionary:
 var units: Dictionary = ui.find_node(tree,"units")
 for child in units.get("children",[]):
  var data: Dictionary = child.get("target",{}).get("data",{}) if typeof(child.get("target"))==TYPE_DICTIONARY else {}
  if str(data.get("data-unit",""))=="1":
   return child
 return units.get("children",[{}])[0] if not units.get("children",[]).is_empty() else {}
static func first_waiting_call(ui: Control,tree: Array) -> Dictionary:
 return waiting_in(ui,ui.find_node(tree,"calls"))
static func waiting_in(ui: Control,node: Dictionary) -> Dictionary:
 if node.get("tag")=="button" and str(node.get("classes","")).contains("call") and ui.text_of(node).contains("Ожидает"):
  return node
 for child in node.get("children",[]):
  var f := waiting_in(ui,child)
  if not f.is_empty():
   return f
 return {}
static func waiting_title(ui: Control,node: Dictionary) -> String:
 var strong: Dictionary = ui.find_tag(node,"strong")
 return ui.text_of(strong) if not strong.is_empty() else ui.text_of(node).left(40)
static func nav_node(ui: Control,tree: Array,tab: String) -> Dictionary:
 var nav: Dictionary = ui.find_class(tree,"mobile-nav")
 for child in nav.get("children",[]):
  var data = child.get("target",{}).get("data",{}) if typeof(child.get("target"))==TYPE_DICTIONARY else {}
  if typeof(data)==TYPE_DICTIONARY and str(data.get("data-tab-button",""))==tab:
   return child
 return {}
# Four tabs; the open one closes back to the map.
static func nav(ui: Control,tree: Array) -> HBoxContainer:
 var row := HBoxContainer.new()
 row.name = "MainTabs"
 row.add_theme_constant_override("separation",4)
 var tab := str(ui.controller.snapshot.get("status",{}).get("tab","map"))
 var calls_node := nav_node(ui,tree,"calls")
 var count: String = ui.text_of(calls_node).replace("Вызовы","").replace("·","").strip_edges()
 var map_node := nav_node(ui,tree,"map")
 var specs := [["units","Патруль",nav_node(ui,tree,"units")],["calls","Вызовы"+(" "+count if not count.is_empty() else ""),calls_node],["radio","Рация",{"domId":"journalBtn"}],["menu","Меню",ui.find_node(tree,"mobileMenu")]]
 for spec in specs:
  var b := flat_button(ui,spec[1],Vector2(0,48),13)
  b.name = "Tab_"+spec[0]
  b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
  ui._tight(b)
  var active: bool = spec[0]==tab
  if active:
   b.add_theme_stylebox_override("normal",ui.panel_style("20383b","77dacb",4))
  if spec[0]=="calls" and not count.is_empty():
   b.add_theme_color_override("font_color",Color("efa66b"))
  var target: Dictionary = map_node if active else spec[2]
  b.pressed.connect(func(): ui.event(target,"click"))
  row.add_child(b)
 return row
# «◎» to my car and «⋯» for the camera views.
static func map_tools(ui: Control,tree: Array) -> ScrollContainer:
 var column := VBoxContainer.new()
 column.add_theme_constant_override("separation",6)
 column.alignment = BoxContainer.ALIGNMENT_END
 var short := {"chaseView":"Сзади","tiltView":"Наклон","rotateRight":"⟳ Поворот","resetView":"Весь город"}
 if ui.camera_menu_open:
  for id in ["chaseView","tiltView","rotateRight","resetView"]:
   var node: Dictionary = ui.find_node(tree,id)
   if node.is_empty():
    continue
   var item = ui.widget(node)
   if item is Button:
    item.text = short[id]
    item.custom_minimum_size = Vector2(104,44)
    item.add_theme_font_size_override("font_size",13)
    item.autowrap_mode = TextServer.AUTOWRAP_OFF
    item.add_theme_stylebox_override("normal",ui.panel_style("15222be6","3b5563",4))
    column.add_child(item)
 var follow: Dictionary = ui.find_node(tree,"followUnit")
 if not follow.is_empty():
  var me = ui.widget(follow)
  if me is Button:
   me.text = "◎"
   me.tooltip_text = "К моей машине"
   me.custom_minimum_size = Vector2(52,52)
   me.add_theme_font_size_override("font_size",22)
   me.add_theme_stylebox_override("normal",ui.panel_style("15222be6","3b5563",26))
   me.size_flags_horizontal = Control.SIZE_SHRINK_END
   column.add_child(me)
 var more := flat_button(ui,"✕" if ui.camera_menu_open else "⋯",Vector2(52,52),22)
 more.name = "CameraMenu"
 more.tooltip_text = "Виды камеры"
 more.size_flags_horizontal = Control.SIZE_SHRINK_END
 more.add_theme_stylebox_override("normal",ui.panel_style("15222be6","3b5563",26))
 more.pressed.connect(func(): ui.camera_menu_open = not ui.camera_menu_open; ui.signature = ""; ui.structure_key = ""; ui.refresh())
 column.add_child(more)
 var scroll := ScrollContainer.new()
 scroll.name = "MapControls"
 scroll.position = Vector2(maxf(8,ui.size.x-120),140)
 scroll.size = Vector2(112,maxf(52,ui.size.y-280))
 scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
 scroll.mouse_filter = Control.MOUSE_FILTER_IGNORE
 column.size_flags_horizontal = Control.SIZE_EXPAND_FILL
 scroll.add_child(column)
 return scroll
# «Патруль» (Release V2): who I am, my car in three lines, the switch «сам принимает вызовы», rest and the patrol tasks.
static func patrol_sheet(ui: Control,tree: Array) -> VBoxContainer:
 var box := VBoxContainer.new()
 box.name = "PatrolSheet"
 box.add_theme_constant_override("separation",8)
 var identity: Dictionary = ui.find_node(tree,"identity")
 var who: Label = ui.label(ui.text_of(ui.find_tag(identity,"strong")))
 who.add_theme_font_size_override("font_size",16)
 box.add_child(who)
 var xp: Dictionary = ui.find_class([identity],"xpbar")
 if not xp.is_empty():
  box.add_child(ui.widget(xp))
 var next: Label = ui.label(ui.text_of(ui.find_tag(identity,"small")))
 next.add_theme_font_size_override("font_size",12)
 next.add_theme_color_override("font_color",Color("9fb4c0"))
 box.add_child(next)
 var unit := own_unit(ui,tree)
 if not unit.is_empty():
  var card := VBoxContainer.new()
  card.add_theme_constant_override("separation",4)
  var head := HBoxContainer.new()
  var name: Label = ui.label(ui.text_of(ui.find_tag(unit,"strong")))
  name.add_theme_font_size_override("font_size",15)
  name.size_flags_horizontal = Control.SIZE_SHRINK_BEGIN
  name.autowrap_mode = TextServer.AUTOWRAP_OFF
  head.add_child(name)
  var state: Label = ui.label(ui.text_of(ui.find_tag(unit,"small")).split(" · ")[0])
  state.add_theme_color_override("font_color",Color("77dacb"))
  state.autowrap_mode = TextServer.AUTOWRAP_OFF
  head.add_child(state)
  card.add_child(head)
  var reason: Label = ui.label(ui.text_of(ui.find_class([unit],"unit-reason")))
  reason.add_theme_font_size_override("font_size",13)
  reason.add_theme_color_override("font_color",Color("b9c8cf"))
  card.add_child(reason)
  # fatigue and fuel as two short bars in one row
  var bars := HBoxContainer.new()
  bars.add_theme_constant_override("separation",12)
  for spec in [["fatigue","Усталость"],["car-state","Топливо"]]:
   var part: Dictionary = ui.find_class([unit],spec[0])
   var meter: Dictionary = ui.find_class([part],"meter")
   if meter.is_empty():
    continue
   var col := VBoxContainer.new()
   col.size_flags_horizontal = Control.SIZE_EXPAND_FILL
   var cap: Label = ui.label(spec[1])
   cap.add_theme_font_size_override("font_size",11)
   cap.add_theme_color_override("font_color",Color("879ca9"))
   col.add_child(cap)
   col.add_child(ui.widget(meter))
   bars.add_child(col)
  card.add_child(bars)
  var frame := PanelContainer.new()
  frame.add_theme_stylebox_override("panel",ui.panel_style("1a2a33","33505c",10))
  frame.add_child(card)
  box.add_child(frame)
 for id in ["autoSetting","restBtn"]:
  var node: Dictionary = ui.find_node(tree,id)
  if node.is_empty():
   continue
  if id=="autoSetting":
   var check := CheckButton.new()
   check.text = "Сами принимаем вызовы"
   check.button_pressed = bool(node.get("checked",false))
   check.custom_minimum_size.y = 48
   check.toggled.connect(func(on): ui.event(node,"change",null,on))
   box.add_child(check)
  else:
   var b = ui.widget(node)
   if b is Button:
    b.custom_minimum_size.y = 48
    box.add_child(b)
 var work: Dictionary = ui.find_class(tree,"patrol-work")
 if not work.is_empty():
  var cap: Label = ui.label("Работа патруля")
  cap.add_theme_font_size_override("font_size",12)
  cap.add_theme_color_override("font_color",Color("879ca9"))
  box.add_child(cap)
  for child in work.get("children",[]):
   if child.get("tag")=="button":
    var b = ui.widget(child)
    if b is Button:
     b.custom_minimum_size.y = 46
     box.add_child(b)
 var file: Dictionary = ui.find_node(tree,"serviceBtn")
 if not file.is_empty():
  var b = ui.widget(file)
  if b is Button:
   b.text = "Личное дело ›"
   b.flat = true
   b.alignment = HORIZONTAL_ALIGNMENT_LEFT
   b.add_theme_color_override("font_color",Color("77dacb"))
   box.add_child(b)
 return box
