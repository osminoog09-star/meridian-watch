extends Node3D
const Geometry = preload("res://scripts/city_geometry.gd")
var tiles: Array = []
var detail_enabled := true
var cache: Dictionary = {}
var queue: Array = []
var material := StandardMaterial3D.new()
var geometry = Geometry.new()
var current_focus := Vector3.ZERO
var current_distance := 650.0
func _ready() -> void:
 var data = JSON.parse_string(FileAccess.get_file_as_string("res://assets/city.json"))
 tiles = data.chunks
 material.vertex_color_use_as_albedo = true
 material.roughness = 0.9
 request_view(current_focus,current_distance)
func request_view(focus: Vector3,distance: float) -> void:
 current_focus = focus
 current_distance = distance
 var desired: Dictionary = {}
 queue.clear()
 for tile in tiles:
  var parts: PackedStringArray = str(tile.key).split(",")
  var centre := Vector3((int(parts[0])+0.5)*250,0,(int(parts[1])+0.5)*250)
  var separation := centre.distance_to(focus)
  if separation>distance*1.5+180:
   continue
  var lod := 0 if detail_enabled and distance<350 and separation<450 else 1
  desired[tile.key] = lod
  if not cache.has(tile.key) or cache[tile.key].lod!=lod:
   queue.append({"tile":tile,"lod":lod,"distance":separation})
 for key in cache.keys():
  if not desired.has(key):
   cache[key].node.queue_free()
   cache.erase(key)
 queue.sort_custom(func(a,b): return a.distance<b.distance)
func _process(_delta: float) -> void:
 # One mesh job per frame; changing view cancels obsolete queued work.
 if queue.is_empty():
  return
 var job: Dictionary = queue.pop_front()
 var mesh: MeshInstance3D = geometry.chunk(job.tile,material,job.lod)
 if cache.has(job.tile.key):
  cache[job.tile.key].node.queue_free()
 cache[job.tile.key] = {"node":mesh,"lod":job.lod}
 add_child(mesh)
