extends SceneTree
var failed := false
func check(ok: bool,message: String) -> void:
 if not ok:
  failed = true
  push_error(message)
func _initialize() -> void:
 call_deferred("verify")
func verify() -> void:
 var light = preload("res://scripts/vehicle_lighting.gd").new()
 root.add_child(light)
 var fixture = JSON.parse_string(FileAccess.get_file_as_string("res://ui/vehicle-lighting-fixtures.json"))
 var lighting := {"darkness":0.55,"headlights":fixture.headlights}
 var sources: Array = []
 for i in range(20):
  sources.append({"transform":Transform3D(Basis(Vector3.UP,PI/2),Vector3(i*5,2.5,0)),"kind":"police","model":"sedan","style":{"activePalette":{"beaconB":"#f47c72"},"flashPalette":{"beaconA":"#8bddff"}},"emergency":true})
 light.refresh(sources,lighting,Vector3.ZERO,100,true,"models",0.1)
 check(light.rigs.size()==4,"Fixed light pool")
 for i in range(4):
  var rig: Node3D = light.rigs[i]
  check(rig.visible and rig.position==sources[i].transform.origin,"Closest cars keep authoritative transform")
  for side in range(2):
   var lamp: SpotLight3D = rig.get_node("Head"+str(side))
   var spec = fixture.headlights.sedan[side]
   check(lamp.position.is_equal_approx(Vector3(spec.origin[0],spec.height,spec.origin[1])),"Original emitter positions")
   check(lamp.visible and not lamp.shadow_enabled and lamp.light_energy>0,"Night headlights without shadow maps")
   check((-lamp.global_basis.z).y<0,"Headlights point down towards road")
  check(rig.get_node("Beacon0").visible and not rig.get_node("Beacon1").visible,"Alternating beacon phase A")
 light.refresh(sources,lighting,Vector3.ZERO,100,true,"models",0.6)
 check(not light.rigs[0].get_node("Beacon0").visible and light.rigs[0].get_node("Beacon1").visible,"Alternating phase B")
 check(light.rigs[0].get_node("Beacon1").light_color.is_equal_approx(Color("f47c72")),"Original red palette")
 lighting.darkness = 0.0
 light.refresh(sources,lighting,Vector3.ZERO,100,true,"models",0.6)
 check(not light.rigs[0].get_node("Head0").visible,"Day headlights off")
 check(light.rigs[0].get_node("Beacon1").visible,"Emergency lights work in daytime")
 for source in sources:
  source.emergency = false
 light.refresh(sources,lighting,Vector3.ZERO,100,true,"models",0.6)
 check(not light.rigs[0].visible,"No stale emergency illumination")
 lighting.darkness = 0.55
 for quality in ["eco","simple"]:
  light.refresh(sources,lighting,Vector3.ZERO,100,true,quality)
  check(light.rigs.filter(func(r):return r.visible).size()==(2 if quality=="eco" else 0),"Quality budget")
 for distance in [100,500]:
  light.refresh(sources,lighting,Vector3.ZERO,distance,false,"models")
  check(light.rigs.all(func(r):return not r.visible),"Settings disable all lights")
 light.refresh(sources,lighting,Vector3.ZERO,500,true,"models")
 check(light.rigs.all(func(r):return not r.visible),"Overview culls lights")
 light.refresh([],lighting,Vector3.ZERO,100,true,"models")
 check(light.rigs.all(func(r):return not r.visible),"Empty campaign clears lights")
 var actors = preload("res://scripts/live_actors.gd").new()
 root.add_child(actors)
 var view := {"lighting":lighting,"units":[],"services":[{"id":1,"kind":"ambulance","status":"responding","x":1.55,"y":2.52,"heading":0}],"residents":[],"incidents":[]}
 actors.refresh(view,-1,Vector3.ZERO,100)
 check(actors.vehicle_lights.rigs[0].visible,"Live service reaches lighting pool")
 check(actors.vehicle_lights.rigs[0].get_node("Head0").visible,"Ambulance gets two headlights")
 check(is_equal_approx(actors.vehicle_lights.rigs[0].get_node("Beacon0").position.y,2.15),"Service roof beacon height")
 view.services[0].kind = "rescue"
 actors.refresh(view,-1,Vector3.ZERO,100)
 check(actors.vehicle_lights.rigs[0].visible,"Rescue gets native illumination")
 actors.flashes_enabled = false
 actors.refresh(view,-1,Vector3.ZERO,100)
 check(actors.vehicle_lights.rigs[0].get_node("Head0").visible,"Calm retains steady headlights")
 check(not actors.vehicle_lights.rigs[0].get_node("Beacon0").visible and not actors.vehicle_lights.rigs[0].get_node("Beacon1").visible,"Calm suppresses emergency flashes")
 actors.lights_enabled = false
 actors.refresh(view,-1,Vector3.ZERO,100)
 check(actors.vehicle_lights.rigs.all(func(r):return not r.visible),"Actor setting disables all vehicle lights")
 print("Native vehicle illumination ","FAILED" if failed else "PASSED")
 quit(1 if failed else 0)
