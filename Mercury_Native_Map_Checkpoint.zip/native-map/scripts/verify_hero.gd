extends SceneTree
# Claude 16.10 (Release O «Мой персонаж»): the native start screen shows the hero; the creator takes a name, a surname
# and an age; the career starts from the bottom with that person; the chief scenario is closed until a career earns it;
# the player's own officer wears the hero's look (checked in ui/test-hero-style.mjs).
const Controller = preload("res://scripts/native_ui_controller.gd")
var failed := false
func check(ok: bool,message: String) -> void:
 if not ok:
  failed = true
  push_error(message)
func find(nodes: Array,pred: Callable) -> Dictionary:
 for item in nodes:
  if pred.call(item):
   return item
  var f := find(item.get("children",[]),pred)
  if not f.is_empty():
   return f
 return {}
func _initialize() -> void:
 var ui = Controller.new()
 if not ui.initialize({}):
  quit(1)
  return
 ui.store.path = "user://hero-verification.json"
 var tree: Array = ui.snapshot.get("tree",[])
 check(not find(tree,func(x): return x.get("domId")=="editHero").is_empty(),"the start screen shows the hero")
 var chief := find(tree,func(x): return x.get("domId")=="startChief")
 check(not chief.is_empty() and chief.get("disabled",false),"the chief scenario is closed without a career")
 ui.action({"op":"event","domId":"editHero","event":"click"})
 for pair in [["heroFirst","Яна"],["heroLast","Ребане"],["heroAge",24]]:
  ui.action({"op":"event","domId":pair[0],"event":"input","value":pair[1]})
 check(JSON.stringify(ui.snapshot.get("tree",[])).contains("Яна Ребане"),"the creator shows the new name")
 ui.action({"op":"event","domId":"heroStart","event":"click"})
 ui.action({"op":"event","domId":"closeModal","event":"click"})
 var text := JSON.stringify(ui.snapshot.get("tree",[]))
 check(text.contains("Яна Ребане"),"the career shows the hero's name")
 print("Hero: start screen, creator, career with the hero, chief closed ","FAILED" if failed else "PASSED")
 quit(1 if failed else 0)
