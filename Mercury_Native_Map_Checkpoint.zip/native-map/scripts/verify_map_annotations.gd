extends SceneTree
var failed := false
func check(ok: bool,message: String) -> void:
 if not ok:
  failed = true
  push_error(message)
func _initialize() -> void:
 call_deferred("verify")
func verify() -> void:
 root.size = Vector2i(740,724)
 var camera := Camera3D.new()
 root.add_child(camera)
 camera.position = Vector3(0,150,200)
 camera.look_at(Vector3.ZERO)
 var annotations = preload("res://scripts/map_annotations.gd").new()
 annotations.camera = camera
 root.add_child(annotations)
 var point := {"x":1.55,"y":2.52}
 var unit := {"id":1,"x":1.55,"y":2.52,"heading":0,"route":[{"x":1.56,"y":2.52}],"crew":[]}
 annotations.view = {"units":[unit],"incidents":[{"id":2,"state":"waiting","anchor":point},{"id":3,"state":"resolved","anchor":point}]}
 annotations.selected_unit = 1
 await process_frame
 annotations.rebuild()
 check(annotations.symbols.size()==2,"active call and fleet symbols")
 check(annotations.route_lines.size()==1,"selected original road route")
 check(annotations.pick(annotations.projected(point)+Vector2(0,-24)).get("id")==2,"tap drawn call icon")
 check(annotations.pick(annotations.projected(point)).get("kind")=="unit","tap car independently of call")
 camera.position = Vector3(0,10000,14000)
 camera.look_at(Vector3.ZERO)
 camera.far = 24000
 annotations.rebuild()
 check(annotations.symbols[0].small,"small vehicle receives arrow")
 annotations.view = {"units":[],"incidents":[]}
 annotations.rebuild()
 check(annotations.symbols.is_empty() and annotations.hits.is_empty() and annotations.route_lines.is_empty(),"new empty campaign clears stale overlays")
 var actors = preload("res://scripts/live_actors.gd").new()
 root.add_child(actors)
 var incident := {"id":4,"type":0,"state":"working","participants":[point]}
 actors.refresh({"units":[],"incidents":[incident]},-1,Vector3.ZERO,100)
 check(actors.people[0].visible,"incident participant drawn")
 incident.type = 5
 actors.refresh({"units":[],"incidents":[incident]},-1,Vector3.ZERO,100)
 check(actors.cars[0].visible and not actors.people[0].visible,"pursuit driver uses car")
 actors.refresh({"units":[],"incidents":[]},-1,Vector3.ZERO,100)
 check(not actors.cars[0].visible,"pooled scene actor hidden after completion")
 print("Native annotations/scene actors ","FAILED" if failed else "PASSED")
 quit(1 if failed else 0)
