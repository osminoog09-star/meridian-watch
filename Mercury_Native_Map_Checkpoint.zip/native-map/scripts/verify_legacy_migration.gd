extends SceneTree
const Controller = preload("res://scripts/native_ui_controller.gd")
const Core = preload("res://scripts/simulation_core.gd")
func _initialize() -> void:
 var fixtures = JSON.parse_string(FileAccess.get_file_as_string("res://simulation/parity-fixtures.json"))
 var ui = Controller.new()
 var core = Core.new()
 if not ui.initialize({}) or not core.initialize():
  quit(1)
  return
 var passed := 0
 for fixture in fixtures:
  if not fixture.has("version"):
   continue
  var original: String = fixture.requests[0].save
  ui._legacy_storage_ready(JSON.stringify({"meridian-watch-v1":original}),"")
  if not ui.migration_error.is_empty() or not ui.snapshot.status.hadSave:
   quit(2)
   return
  core.invoke({"op":"load","save":original})
  var imported = JSON.parse_string(ui.runtime.eval("MercuryUI.call('{\"op\":\"state\"}')"))
  if imported!=core.state():
   quit(3)
   return
  passed += 1
 ui._legacy_storage_ready('{"meridian-watch-v1":"broken"}',"")
 if ui.migration_error.is_empty() or ui.save()==OK:
  quit(4)
  return
 print(JSON.stringify({"legacy_migrations":passed,"full_state_matches":true,"corrupt_input_blocks_save":true,"webview_origin_device_test":"pending"}))
 quit(0)
