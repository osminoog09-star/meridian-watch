extends Node3D
const MAX_CARS := 64
const MAX_PEOPLE := 128
const Geometry = preload("res://scripts/city_geometry.gd")
var quality := "models"
var models: Dictionary
var shared: Dictionary = {}
var cars: Array[MeshInstance3D] = []
var people: Array[MeshInstance3D] = []
var materials: Dictionary = {}
func set_quality(value: String) -> void:
 quality = value
 for actor in cars+people:
  actor.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_ON if quality=="models" else GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
func model(kind: String) -> Mesh:
 if quality=="simple":
  var key := "simple-"+kind
  if not shared.has(key):
   var box := BoxMesh.new()
   box.size = Vector3(0.5,1.7,0.5) if kind in ["civilian","officer"] else Vector3(4.2,1.5,1.8)
   shared[key] = box
  return shared[key]
 if shared.has(kind):
  return shared[kind]
 if kind in ["ambulance","rescue"]:
  shared[kind] = preload("res://scripts/service_models.gd").build(model("suv"),kind)
  return shared[kind]
 var data: Dictionary = models[kind]
 var builder := SurfaceTool.new()
 builder.begin(Mesh.PRIMITIVE_TRIANGLES)
 var geometry = Geometry.new()
 var palette := {"paint":"#d0d9de","trim":"#414b53","plate":"#f2f3e9","glass":"#274855","seal":"#273039","metal":"#89949a","stripe":"#295696","tire":"#252a2d","headlight":"#fff1bd","taillight":"#b73734","rubber":"#273039","beaconA":"#397fe6","beaconB":"#4385f1","skin":"#d2aa8d","uniform":"#28435c","cloth":"#8d786e","pants":"#3a4654","shoe":"#252a2d","hair":"#44372f"}
 for face in data.faces:
  var vertices: Array[Vector3] = []
  for index in face.v:
   var p = data.vertices[index]
   vertices.append(Vector3(p[0],p[2],p[1]))
  if vertices.size()<3:
   continue
  var normal := -(vertices[1]-vertices[0]).cross(vertices[2]-vertices[0]).normalized()
  for index in range(1,vertices.size()-1):
   geometry.triangle(builder,vertices[0],vertices[index],vertices[index+1],Color(palette.get(face.material,"#777e87")),normal)
 builder.index()
 shared[kind] = builder.commit()
 return shared[kind]
func _ready() -> void:
 models = JSON.parse_string(FileAccess.get_file_as_string("res://assets/actor-models.json"))
 for kind in ["police","civilian","ambulance","rescue"]:
  var material := StandardMaterial3D.new()
  material.vertex_color_use_as_albedo = true
  material.roughness = 0.7
  material.albedo_color = Color.WHITE
  materials[kind] = material
 for index in range(MAX_CARS):
  var actor := MeshInstance3D.new()
  actor.mesh = model("sedan")
  actor.visible = false
  add_child(actor)
  cars.append(actor)
 for index in range(MAX_PEOPLE):
  var actor := MeshInstance3D.new()
  actor.mesh = model("civilian")
  actor.visible = false
  actor.material_override = materials.civilian
  add_child(actor)
  people.append(actor)
func world(p: Dictionary) -> Vector3:
 var point := Vector3((float(p.get("x",1.55))-1.55)*1670,0.12,(float(p.get("y",2.52))-2.52)*1670)
 point.y += preload("res://scripts/road_elevation.gd").height_at(point)
 return point
func refresh(view: Dictionary,selected: int,focus: Vector3,distance: float) -> void:
 var car_count := 0
 var person_count := 0
 var radius := maxf(120,distance*1.6)
 var poses: Array = []
 for unit in view.get("units",[]):
  if int(unit.id)!=selected:
   poses.append({"pose":unit,"kind":"police","model":"sedan"})
  if typeof(unit.get("foot"))==TYPE_DICTIONARY:
   for person in unit.foot.get("actors",[]):
    if person_count>=MAX_PEOPLE:
     break
    var position: Vector3 = world(person)
    if position.distance_to(focus)>radius:
     continue
    var actor := people[person_count]
    actor.mesh = model("officer")
    actor.position = position
    actor.rotation.y = -float(person.get("heading",0))
    actor.visible = true
    person_count += 1
 for service in view.get("services",[]):
  poses.append({"pose":service,"kind":service.get("kind","ambulance"),"model":service.get("kind","ambulance")})
 for resident in view.get("residents",[]):
  if resident.get("status") in ["home","work"]:
   continue
  if resident.get("status") in ["toHome","toWork","toVisit","fromVisit"]:
   poses.append({"pose":resident,"kind":"civilian","model":"sedan"})
  elif person_count<MAX_PEOPLE:
   var position: Vector3 = world(resident)
   if position.distance_to(focus)>radius:
    continue
   var actor := people[person_count]
   actor.mesh = model("civilian")
   actor.position = position
   actor.rotation.y = -float(resident.get("heading",0))
   actor.visible = true
   person_count += 1
 for item in poses:
  if car_count>=MAX_CARS:
   break
  var position: Vector3 = world(item.pose)
  if position.distance_to(focus)>radius:
   continue
  var car := cars[car_count]
  car.mesh = model(item.model)
  car.material_override = materials.get(item.kind,materials.police)
  car.position = position
  car.rotation.y = -float(item.pose.get("heading",item.pose.get("renderHeading",0)))
  if typeof(item.pose.get("target"))==TYPE_DICTIONARY:
   var direction: Vector3 = world(item.pose.target)-position
   if direction.length()>0.01:
    car.rotation.y = -atan2(direction.z,direction.x)
  car.visible = true
  car_count += 1
 for index in range(car_count,MAX_CARS):
  cars[index].visible = false
 for index in range(person_count,MAX_PEOPLE):
  people[index].visible = false
