extends SceneTree
const Save = preload("res://scripts/campaign_save.gd")
const Core = preload("res://scripts/simulation_core.gd")
var differences: Array = []
func compare(a: Variant,b: Variant,path: String) -> void:
 if differences.size()>20:
  return
 if typeof(a)==TYPE_DICTIONARY and typeof(b)==TYPE_DICTIONARY:
  if a.size()!=b.size():
   differences.append(path+" key count")
  for key in a:
   if not b.has(key):
    differences.append(path+" missing "+key)
   else:
    compare(a[key],b[key],path+"."+key)
 elif typeof(a)==TYPE_ARRAY and typeof(b)==TYPE_ARRAY:
  if a.size()!=b.size():
   differences.append(path+" array size")
  else:
   for index in range(a.size()):
    compare(a[index],b[index],path+"["+str(index)+"]")
 elif (typeof(a)==TYPE_FLOAT or typeof(a)==TYPE_INT) and (typeof(b)==TYPE_FLOAT or typeof(b)==TYPE_INT):
  if absf(float(a)-float(b))>0.00000001:
   differences.append(path+" numeric difference "+str(a)+" != "+str(b))
 elif a!=b:
  differences.append(path+" value difference")
# Claude 16.10 (Release O): the chief scenario is earned in a career; start from an earned one.
const CHIEF_EARNED := {"mercury-chief-unlocked":"{\"police\": {\"first\": \"Анна\", \"last\": \"Тамм\", \"gender\": \"f\", \"age\": 41, \"skin\": 1, \"hair\": \"bun\", \"hairColor\": 1, \"build\": \"average\", \"beard\": false, \"glasses\": false}, \"rescue\": {\"first\": \"Анна\", \"last\": \"Тамм\", \"gender\": \"f\", \"age\": 41, \"skin\": 1, \"hair\": \"bun\", \"hairColor\": 1, \"build\": \"average\", \"beard\": false, \"glasses\": false}, \"ems\": {\"first\": \"Анна\", \"last\": \"Тамм\", \"gender\": \"f\", \"age\": 41, \"skin\": 1, \"hair\": \"bun\", \"hairColor\": 1, \"build\": \"average\", \"beard\": false, \"glasses\": false}, \"dispatch\": {\"first\": \"Анна\", \"last\": \"Тамм\", \"gender\": \"f\", \"age\": 41, \"skin\": 1, \"hair\": \"bun\", \"hairColor\": 1, \"build\": \"average\", \"beard\": false, \"glasses\": false}}"}
func _initialize() -> void:
 var traces = JSON.parse_string(FileAccess.get_file_as_string("res://ui/full-cycle-traces.json"))
 traces.append_array(JSON.parse_string(FileAccess.get_file_as_string("res://ui/manual-call-trace.json")))
 var total := 0
 for trace in traces:
  var controller = preload("res://scripts/native_ui_controller.gd").new()
  if not controller.initialize(CHIEF_EARNED):
   quit(1)
   return
  for request in trace.requests.slice(1):
   if controller.invoke(request)==null:
    push_error("Call failed: "+JSON.stringify(request))
    quit(2)
    return
   total += 1
  differences.clear()
  compare(controller.invoke({"op":"state"}),trace.expected,trace.mode)
  if not differences.is_empty():
   print(JSON.stringify(differences))
   quit(3)
   return
  print("Full native UI cycle passed: ",trace.mode)
 print("Native UI requests replayed: ",total)
 quit(0)
