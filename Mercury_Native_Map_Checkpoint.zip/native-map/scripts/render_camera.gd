extends SceneTree
# Claude 16.10 (Release N) audit tool: the camera views of the native map.
# Usage: xvfb-run Godot --path . --rendering-driver opengl3 --resolution 794x926 --script scripts/render_camera.gd -- --native-ui --out DIR
var out := ""
func wait(n: int) -> void:
 for i in range(n):
  await process_frame
func _initialize() -> void:
 var args := OS.get_cmdline_user_args()
 out = args[args.find("--out")+1]
 call_deferred("run")
func run() -> void:
 var scene = load("res://main.tscn").instantiate()
 root.add_child(scene)
 await wait(8)
 var cmd := OS.get_cmdline_user_args()
 if cmd.has("--storage"):
  # a prepared save (e.g. 19:30 for the night views): the game continues it
  scene.campaign.initialize(JSON.parse_string(FileAccess.get_file_as_string(cmd[cmd.find("--storage")+1])))
  scene.campaign.store.path = "user://render-camera.json"
  scene.campaign.action({"op":"event","domId":"continueBtn","event":"click"})
  scene.campaign.action({"op":"event","domId":"closeModal","event":"click"})
 else:
  scene.campaign.initialize({})
  scene.campaign.store.path = "user://render-camera.json"
  scene.campaign.action({"op":"event","domId":"startCareer","event":"click"})
  scene.campaign.action({"op":"event","domId":"closeModal","event":"click"})
 await wait(30)
 var args := OS.get_cmdline_user_args()
 if args.has("--clean-world"):
  scene.native_ui.hide()
 if args.has("--world"):
  # Claude 17.10: views at world points «x:z:zoomsteps;…» (zoom steps from the city view, + closer, − further)
  var n := 0
  for spec in str(args[args.find("--world")+1]).split(";"):
   var v := spec.split(":")
   var cmds: Array = [{"op":"city","value":null},{"op":"locate","value":{"x":float(v[0])/1670.0+1.55,"y":float(v[1])/1670.0+2.52}}]
   for k in range(absi(int(v[2]))):
    cmds.append({"op":"zoom","value":1 if int(v[2])>0 else -1})
   scene.campaign.snapshot["map"] = cmds
   scene.apply_native_camera_commands()
   await wait(120)
   await RenderingServer.frame_post_draw
   root.get_texture().get_image().save_png(out+"/world-"+str(n)+".png")
   print("shot world ",n)
   n += 1
  scene.queue_free()
  await wait(4)
  quit(0)
  return
 if args.has("--places"):
  # Claude 17.10: the bases on the map (hospital, fire station, prefecture team) seen from above at quarter distance.
  for place in scene.campaign.view().get("places",[]):
   scene.campaign.snapshot["map"] = [{"op":"quarter","value":null},{"op":"locate","value":{"x":place.x,"y":place.y}}]
   scene.apply_native_camera_commands()
   await wait(90)
   await RenderingServer.frame_post_draw
   root.get_texture().get_image().save_png(out+"/place-"+str(place.kind)+".png")
   print("shot ",place.kind)
  scene.queue_free()
  await wait(4)
  quit(0)
  return
 for view in [["angled",[["follow",null]]],["turned",[["rotate",1],["rotate",1]]],["street",[["tilt",null]]],["top",[["tilt",null]]],["chase",[["chase",null]]],["close",[["follow",null],["zoom",1],["zoom",1],["zoom",1],["zoom",1]]]]:
  for c in view[1]:
   scene.campaign.snapshot["map"] = [{"op":c[0],"value":c[1]}]
   scene.apply_native_camera_commands()
  await wait(60)
  await RenderingServer.frame_post_draw
  root.get_texture().get_image().save_png(out+"/"+view[0]+".png")
  print("shot ",view[0])
 scene.queue_free()
 await wait(4)
 quit(0)
