extends SceneTree
# Claude 16.10 (Release N) audit tool: the camera views of the native map.
# Usage: xvfb-run Godot --path . --rendering-driver opengl3 --resolution 794x926 --script scripts/render_camera.gd -- --native-ui --out DIR
var out := ""
func wait(n: int) -> void:
 for i in range(n):
  await process_frame
func _initialize() -> void:
 var args := OS.get_cmdline_user_args()
 out = args[args.find("--out")+1]
 call_deferred("run")
func run() -> void:
 var scene = load("res://main.tscn").instantiate()
 root.add_child(scene)
 await wait(8)
 scene.campaign.initialize({})
 scene.campaign.store.path = "user://render-camera.json"
 scene.campaign.action({"op":"event","domId":"startCareer","event":"click"})
 scene.campaign.action({"op":"event","domId":"closeModal","event":"click"})
 await wait(30)
 for view in [["angled",[["follow",null]]],["turned",[["rotate",1],["rotate",1]]],["street",[["tilt",null]]],["top",[["tilt",null]]],["chase",[["chase",null]]]]:
  for c in view[1]:
   scene.campaign.snapshot["map"] = [{"op":c[0],"value":c[1]}]
   scene.apply_native_camera_commands()
  await wait(60)
  await RenderingServer.frame_post_draw
  root.get_texture().get_image().save_png(out+"/"+view[0]+".png")
  print("shot ",view[0])
 quit(0)
