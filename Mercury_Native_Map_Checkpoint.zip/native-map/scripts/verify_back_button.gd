extends SceneTree
# Claude 16.10: Android «Back» never quits the game: it closes a window, returns to the map, or opens the shift menu.
var failed := false
func _initialize() -> void:
 call_deferred("verify")
func check(ok: bool,message: String) -> void:
 if not ok:
  failed = true
  push_error(message)
func frames(n: int) -> void:
 for i in range(n):
  await process_frame
func back() -> void:
 root.propagate_notification(Node.NOTIFICATION_WM_GO_BACK_REQUEST)
 await frames(6)
func verify() -> void:
 check(ProjectSettings.get_setting("application/config/quit_on_go_back",true)==false,"quit_on_go_back must be off")
 root.size = Vector2i(369,905)
 var scene = load("res://main.tscn").instantiate()
 root.add_child(scene)
 await frames(8)
 var ui = scene.native_ui
 var c = scene.campaign
 c.initialize({})
 c.store.path = "user://back-button-verification.json"
 c.action({"op":"event","domId":"startCareer","event":"click"})
 c.action({"op":"event","domId":"closeModal","event":"click"})
 await frames(10)
 c.action({"op":"event","domId":"settingsBtn","event":"click"})
 ui.signature = ""
 ui.refresh()
 await frames(4)
 check(ui.modal_open,"settings open")
 await back()
 check(not ui.modal_open,"Back closes the window")
 var nav: Dictionary = ui.find_class(c.snapshot.tree,"mobile-nav")
 c.action({"op":"event","id":nav.children[1].id,"event":"click"})
 await frames(4)
 check(str(c.snapshot.status.tab)=="units","crews tab open")
 await back()
 check(str(c.snapshot.status.tab)=="map","Back returns to the map")
 await back()
 check(ui.modal_open and ui.heading_of(c.snapshot.tree[0])=="Меню смены","Back on the map opens the shift menu")
 await back()
 check(not ui.modal_open,"Back closes the menu again")
 print("Back button ","FAILED" if failed else "PASSED")
 quit(1 if failed else 0)
