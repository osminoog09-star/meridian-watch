extends RefCounted
const Core = preload("res://scripts/simulation_core.gd")
const Save = preload("res://scripts/campaign_save.gd")
var core = Core.new()
var store = Save.new()
var autosave_elapsed := 0.0
var initialized := false
func initialize() -> bool:
 initialized = core.initialize()
 if not initialized:
  return false
 var saved: String = store.read_save()
 if saved.is_empty() or core.invoke({"op":"load","save":saved})==null:
  core.invoke({"op":"create","mode":"career","options":{"schedule":"ppa"}})
 return true
func advance(delta: float,speed: int) -> Dictionary:
 if not initialized:
  return {}
 var result = core.invoke({"op":"frame","seconds":delta,"speed":speed})
 autosave_elapsed += delta
 if autosave_elapsed>=30:
  save()
  autosave_elapsed = 0.0
 return result if typeof(result)==TYPE_DICTIONARY else {}
func view() -> Dictionary:
 return core.invoke({"op":"view"})
func command(name: String,args: Array = []) -> Variant:
 return core.invoke({"op":"command","name":name,"args":args})
func save() -> Error:
 return store.write_save(core.serialize())
