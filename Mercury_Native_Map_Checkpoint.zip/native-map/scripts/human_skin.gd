extends RefCounted
# Original rigid-limb transforms, in Godot's x-forward/y-up/z-right coordinates.
const Geometry = preload("res://scripts/city_geometry.gd")
const GROUPS = ["body","leftLeg","rightLeg","leftArm","rightArm","leftForearm","rightForearm"]
var cache: Dictionary = {}
func around(height: float,angle: float) -> Transform3D:
 var pivot := Vector3(0,height,0)
 var basis := Basis(Vector3(0,0,1),-angle)
 return Transform3D(basis,pivot-basis*pivot)
func pose_transform(group: String,pose: String,phase: float) -> Transform3D:
 var result := Transform3D.IDENTITY
 var leg: bool = group in ["leftLeg","rightLeg"]
 var arm: bool = group in ["leftArm","rightArm","leftForearm","rightForearm"]
 var sign_value := 1.0 if group.begins_with("left") else -1.0
 if pose=="radio" and group=="leftForearm":
  result = around(1.06,-2.5)*result
 if leg or arm:
  var joint: float = phase*sign_value*(0.5 if leg else -0.4)
  if arm:
   if pose=="radio" and sign_value==1:
    joint = -0.3
   elif pose=="talk":
    joint = -0.8 if sign_value==1 else -0.3
   elif pose=="search":
    joint = -1.15
   elif pose=="assist":
    joint = -1.55
  result = around(0.8 if leg else 1.30,joint)*result
 if pose in ["search","assist"]:
  result = around(0.8,0.27 if pose=="assist" else 0.12)*result
 return result
func parts(data: Dictionary,kind: String,palette: Dictionary) -> Dictionary:
 var key := kind+JSON.stringify(palette)
 if cache.has(key):
  return cache[key]
 var result: Dictionary = {}
 var geometry = Geometry.new()
 for group in GROUPS+["whole"]:
  var builder := SurfaceTool.new()
  builder.begin(Mesh.PRIMITIVE_TRIANGLES)
  for face in data.faces:
   if group!="whole" and face.get("group","body")!=group:
    continue
   var vertices: Array[Vector3] = []
   for index in face.v:
    var p: Array = data.vertices[index]
    vertices.append(Vector3(p[0],p[2],p[1]))
   var normal := -(vertices[1]-vertices[0]).cross(vertices[2]-vertices[0]).normalized()
   for index in range(1,vertices.size()-1):
    geometry.triangle(builder,vertices[0],vertices[index],vertices[index+1],Color(palette.get(face.material,"#d5d8d1")),normal)
  builder.index()
  result[group] = builder.commit()
 if cache.size()>=24:
  cache.clear()
 cache[key] = result
 return result
func apply(actor: MeshInstance3D,data: Dictionary,kind: String,style: Dictionary,pose: String,phase: float,detailed: bool,shadows: bool) -> void:
 var meshes := parts(data,kind,style.get("palette",{}))
 actor.mesh = null if detailed else meshes.whole
 for group in GROUPS:
  var name: String = "Human_"+group
  var part := actor.get_node_or_null(name) as MeshInstance3D
  if part==null and detailed:
   part = MeshInstance3D.new()
   part.name = name
   actor.add_child(part)
  if part==null:
   continue
  part.visible = detailed
  if detailed:
   part.mesh = meshes[group]
   part.material_override = actor.material_override
   part.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_ON if shadows else GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
   part.transform = pose_transform(group,pose,phase)
func hide_parts(actor: MeshInstance3D) -> void:
 for group in GROUPS:
  var part := actor.get_node_or_null("Human_"+group) as MeshInstance3D
  if part!=null:
   part.visible = false
