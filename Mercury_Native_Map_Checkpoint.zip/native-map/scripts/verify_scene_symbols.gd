extends SceneTree
# Claude 15.10: in the real scene (native UI) the map symbols must be visible — the pilot HUD loop used to hide
# them; a new chief campaign (no crew, selectedUnit=null) must not raise script errors in the actor refresh.
# Claude 16.10 (Release O): the chief scenario is earned in a career; start from an earned one.
const CHIEF_EARNED := {"mercury-chief-unlocked":"{\"police\": {\"first\": \"Анна\", \"last\": \"Тамм\", \"gender\": \"f\", \"age\": 41, \"skin\": 1, \"hair\": \"bun\", \"hairColor\": 1, \"build\": \"average\", \"beard\": false, \"glasses\": false}, \"rescue\": {\"first\": \"Анна\", \"last\": \"Тамм\", \"gender\": \"f\", \"age\": 41, \"skin\": 1, \"hair\": \"bun\", \"hairColor\": 1, \"build\": \"average\", \"beard\": false, \"glasses\": false}, \"ems\": {\"first\": \"Анна\", \"last\": \"Тамм\", \"gender\": \"f\", \"age\": 41, \"skin\": 1, \"hair\": \"bun\", \"hairColor\": 1, \"build\": \"average\", \"beard\": false, \"glasses\": false}, \"dispatch\": {\"first\": \"Анна\", \"last\": \"Тамм\", \"gender\": \"f\", \"age\": 41, \"skin\": 1, \"hair\": \"bun\", \"hairColor\": 1, \"build\": \"average\", \"beard\": false, \"glasses\": false}}"}
func _initialize() -> void:
 call_deferred("verify")
func verify() -> void:
 var failed := false
 for mode in ["startCareer","startChief"]:
  var scene = load("res://main.tscn").instantiate()
  root.add_child(scene)
  for i in range(6):
   await process_frame
  scene.campaign.initialize(CHIEF_EARNED)
  scene.campaign.store.path = "user://scene-symbols-test.json"
  scene.campaign.action({"op":"event","domId":mode,"event":"click"})
  scene.campaign.action({"op":"event","domId":"closeModal","event":"click"})
  for i in range(12):
   await process_frame
  var a = scene.annotations
  if a==null or not a.is_visible_in_tree():
   push_error(mode+": map symbols hidden in the native UI")
   failed = true
  if mode=="startCareer" and a!=null and a.symbols.is_empty():
   push_error("career: no patrol symbol on the map")
   failed = true
  if mode=="startChief" and scene.selected_unit_id()!=-1:
   push_error("chief without crews must have no selected unit")
   failed = true
  scene.queue_free()
  await process_frame
 print("Scene map symbols: visible in native UI, patrol symbol drawn; chief without crews refreshes without errors")
 quit(1 if failed else 0)
