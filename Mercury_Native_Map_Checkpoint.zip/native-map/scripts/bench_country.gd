extends SceneTree
# Claude 17.10 (Release G5) bench: time to build the countryside and what it holds.
func _initialize() -> void:
 var c = preload("res://scripts/countryside.gd").new()
 var t0 := Time.get_ticks_usec()
 c._ready()
 var counts := {}
 for key in c.cells:
  for kind in c.cells[key]:
   counts[kind] = int(counts.get(kind,0))+c.cells[key][kind].size()
 print("countryside ms ",(Time.get_ticks_usec()-t0)/1000," ",counts," road samples ",c.samples.size())
 c.free()
 quit(0)
