extends Node3D
# Bounded camera-local weather; visual clock never consumes simulation RNG.
const CAPACITY := 192
var particles := MultiMeshInstance3D.new()
var instances := MultiMesh.new()
var material := StandardMaterial3D.new()
var kind := "clear"
var storm := false
var wind := 0.0
var clock := 0.0
var extent := 180.0
var active_count := 0
var enabled := true
func _ready() -> void:
 instances.transform_format = MultiMesh.TRANSFORM_3D
 instances.instance_count = CAPACITY
 instances.visible_instance_count = 0
 var mesh := BoxMesh.new()
 mesh.size = Vector3.ONE
 instances.mesh = mesh
 material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
 material.albedo_color = Color("b6cfe0")
 material.no_depth_test = false
 particles.multimesh = instances
 particles.material_override = material
 particles.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
 add_child(particles)
func configure(weather: Dictionary,centre: Vector3,camera_distance: float,effects_enabled: bool = true) -> void:
 kind = str(weather.get("kind","clear"))
 var event: Variant = weather.get("event")
 storm = typeof(event)==TYPE_DICTIONARY and str(event.get("id","")).contains("storm")
 enabled = effects_enabled
 extent = clampf(camera_distance*0.55,90,650)
 position = Vector3(centre.x,0,centre.z)
 wind = 18.0 if storm else (8.0 if kind=="wind" else 2.0)
 active_count = CAPACITY if kind=="rain" or storm else (128 if kind=="snow" else (48 if kind=="wind" else 0))
 if not enabled:
  active_count = 0
 instances.visible_instance_count = active_count
 material.albedo_color = Color("e5edf2") if kind=="snow" else (Color("849c82") if kind=="wind" and not storm else Color("a1bfd4"))
func animate(delta: float) -> void:
 if active_count==0:
  return
 clock += clampf(delta,0,0.1)
 for i in range(active_count):
  var seed_x := fmod(float(i)*0.61803398875,1.0)
  var seed_z := fmod(float(i)*0.41421356237,1.0)
  var phase := fmod(float(i)*0.754877666+clock*(0.11 if kind=="snow" else 0.8),1.0)
  var x := (seed_x*2-1)*extent+sin(clock*0.7+float(i))*wind
  var z := (seed_z*2-1)*extent
  var y := 4+(1-phase)*90
  var size := Vector3(0.18,5.5,0.18)
  var basis := Basis(Vector3.FORWARD,-0.22 if storm else -0.06)
  if kind=="snow":
   size = Vector3.ONE*0.65
   x += sin(clock+float(i))*4
  elif kind=="wind" and not storm:
   size = Vector3(1.2,0.16,0.35)
   y = 1+phase*5
   x = fposmod(x+clock*wind,extent*2)-extent
   basis = Basis(Vector3.UP,clock+float(i))
  instances.set_instance_transform(i,Transform3D(basis.scaled(size),Vector3(x,y,z)))
func diagnostics() -> Dictionary:
 return {"kind":kind,"storm":storm,"instances":active_count,"capacity":CAPACITY,"enabled":enabled}
