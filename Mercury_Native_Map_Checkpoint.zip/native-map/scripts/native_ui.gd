extends Control
const RichButton = preload("res://scripts/native_rich_button.gd")
var expanded_sections: Dictionary = {}
var theme_key := ""
var modal_open := false
var controller: RefCounted
var model_factory: Node3D
var frame_report: Dictionary = {}
var signature := ""
var native_fps: Label
var root := VBoxContainer.new()
var scroll := preload("res://scripts/native_scroll.gd").new()
var modal_close: Control
var file_dialog: FileDialog
var pending_file: Dictionary = {}
# Claude 16.10: fingers held on interface controls. The HUD is rebuilt whenever the snapshot changes (the clock alone
# changes every game second); a rebuild between finger-down and finger-up freed the button and lost the tap.
var held_controls: Dictionary = {}
# Claude 17.10 (Release U2): the call card shows the actions first; the full details open on demand.
var call_details_open := false
# Claude 17.10 (Release V): the camera views fold behind «⋯».
var camera_menu_open := false
# Claude 17.10 (Release U3): owner — «карточка Оперативный центр мигает, дрожит». The whole screen was rebuilt every game
# second (a clock, a fatigue %, a km/h changed). Now a change of texts only updates the widgets in place; the screen is
# rebuilt only when its structure changes (another tab, a new call, a button appears).
var bindings: Dictionary = {}
var structure_key := ""
var held_released_ms := -1000
func _ready() -> void:
 set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
 mouse_filter = Control.MOUSE_FILTER_IGNORE
 scroll.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
 scroll.offset_left = 8
 scroll.offset_right = -8
 scroll.offset_top = 8
 scroll.offset_bottom = -8
 root.size_flags_horizontal = Control.SIZE_EXPAND_FILL
 scroll.add_child(root)
 add_child(scroll)
 resized.connect(func(): signature=""; refresh())
func _draw() -> void:
 if controller!=null and not modal_open:
  var flash := find_node(controller.snapshot.get("tree",[]),"a11yFlash")
  if str(flash.get("classes","")).split(" ").has("on"):
   draw_rect(Rect2(Vector2(3,3),size-Vector2(6,6)),Color("efa66b") if str(flash.get("classes","")).contains("urgent") else Color("77dacb"),false,6)
 if modal_open:
  draw_rect(Rect2(Vector2.ZERO,size),Color(0.025,0.06,0.085,0.8))
func event(node: Dictionary,kind: String,value: Variant = null,checked: Variant = null) -> void:
 var request := {"op":"event","id":node.get("id"),"domId":node.get("domId"),"target":node.get("target"),"event":kind}
 if value!=null:
  request.value = value
 if checked!=null:
  request.checked = checked
 controller.action(request)
 signature = ""
 refresh()
func text_of(node: Dictionary) -> String:
 if node.get("tag")=="#text":
  return str(node.get("text",""))
 var output := str(node.get("text",""))
 if output.is_empty():
  for child in node.get("children",[]):
   output += text_of(child)+" "
 return output.strip_edges()
func label(text: String,large: bool = false) -> Label:
 var item := Label.new()
 item.mouse_filter = Control.MOUSE_FILTER_IGNORE
 item.text = text
 item.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
 item.size_flags_horizontal = Control.SIZE_EXPAND_FILL
 var classes: String = controller.snapshot.get("bodyClasses","")
 var scale: float = 1.3 if classes.contains("a11y-text-huge") else (1.15 if classes.contains("a11y-text-large") else 1.0)
 item.add_theme_font_size_override("font_size",int((24 if large else 14)*scale))
 return item
func panel_style(color: String, border: String = "2a3943", padding: int = 12) -> StyleBoxFlat:
 var style := StyleBoxFlat.new()
 style.bg_color = Color(color)
 style.border_color = Color(border)
 style.set_border_width_all(1)
 style.set_corner_radius_all(8)
 style.content_margin_left = padding
 style.content_margin_right = padding
 style.content_margin_top = padding
 style.content_margin_bottom = padding
 return style
func apply_readability() -> void:
 var classes: String = controller.snapshot.get("bodyClasses","")
 if theme_key==classes and theme!=null:
  return
 theme_key = classes
 var scale: float = 1.3 if classes.contains("a11y-text-huge") else (1.15 if classes.contains("a11y-text-large") else 1.0)
 var next_theme := Theme.new()
 next_theme.default_font_size = int(14*scale)
 for type in ["Button","OptionButton"]:
  next_theme.set_stylebox("normal",type,panel_style("1c2c36"))
  next_theme.set_stylebox("hover",type,panel_style("2c424c"))
  next_theme.set_stylebox("pressed",type,panel_style("20383b","77dacb"))
  next_theme.set_stylebox("focus",type,panel_style("20383b","77dacb"))
  next_theme.set_stylebox("disabled",type,panel_style("142028"))
  next_theme.set_color("font_color",type,Color("e5edf0"))
  next_theme.set_color("font_disabled_color",type,Color("879ca9"))
 next_theme.set_color("font_color","Label",Color("ffffff" if classes.contains("a11y-contrast") else "e5edf0"))
 next_theme.set_stylebox("panel","PanelContainer",panel_style("16222b"))
 next_theme.set_stylebox("background","ProgressBar",panel_style("2a3b44","2a3b44",0))
 next_theme.set_stylebox("fill","ProgressBar",panel_style("77dacb","77dacb",0))
 theme = next_theme
 scroll.add_theme_stylebox_override("panel",panel_style("07111b" if classes.contains("a11y-contrast") else "162730","425861",16))
func styled_label(node: Dictionary) -> Label:
 var tag: String = node.get("tag","")
 var item := label(text_of(node),tag in ["h1","h2"])
 var classes: String = node.get("classes","")
 if tag=="small" or classes.contains("muted"):
  item.add_theme_color_override("font_color",Color("879ca9"))
 if tag in ["h3","h4"] or classes.contains("eyebrow") or classes.contains("status"):
  item.add_theme_color_override("font_color",Color("77dacb"))
 return item
func content_box(node: Dictionary) -> Container:
 var classes: PackedStringArray = str(node.get("classes","")).split(" ")
 var box: Container = VBoxContainer.new()
 for name in ["modal-actions","mode-switch","model-controls","awards","service-toggle","desk-row"]:
  if classes.has(name):
   box.free()
   box = HFlowContainer.new()
   break
 # Claude 15.10: «[✓] Включить звук» — a checkbox and its text on one row, as in the web label.
 if node.get("tag")=="label" and node.get("children",[]).any(func(c): return c.get("tag")=="input" and c.get("type") in ["checkbox","radio"]):
  box.free()
  box = HBoxContainer.new()
 # Claude 16.10: four services on a narrow phone — a 2×2 grid instead of three in a row and «112» alone on the next.
 if classes.has("service-toggle") and size.x<480:
  box.free()
  var services := GridContainer.new()
  services.columns = 2
  box = services
 for name in ["start-options","report-grid","focus-list"]:
  if classes.has(name) and size.x>=600:
   box.free()
   var grid := GridContainer.new()
   grid.columns = 2
   box = grid
   break
 box.size_flags_horizontal = Control.SIZE_EXPAND_FILL
 box.add_theme_constant_override("separation",9)
 box.add_theme_constant_override("h_separation",12)
 box.add_theme_constant_override("v_separation",9)
 for child in node.get("children",[]):
  var item = widget(child)
  if item!=null:
   box.add_child(item)
 return box
func widget(node: Dictionary) -> Control:
 var made: Control = _widget(node)
 var path: String = str(node.get("p",""))
 if made!=null and not path.is_empty() and (made is Label or made is ProgressBar or made is Button):
  # the text as built: a caller that later shortens a label («На карте ↗», «◎ Я») keeps its own text
  bindings[path] = [made,"",made.text if (made is Label or made is Button) else ""]
 return made
# Paths of nodes (child indexes) — the same element keeps its path while the screen keeps its shape.
func annotate(nodes: Array,prefix: String) -> void:
 for k in range(nodes.size()):
  var node: Dictionary = nodes[k]
  node["p"] = prefix+"/"+str(k)
  annotate(node.get("children",[]),node["p"])
# The shape of a screen: everything but texts, inline styles (bar widths) and element ids of plain buttons/text.
func shape_of(nodes: Array) -> Array:
 var out: Array = []
 for node in nodes:
  var tag: String = node.get("tag","")
  var classes: Array = Array(str(node.get("classes","")).split(" ",false)).filter(func(c): return not (c in ["active","selected","paused","on","urgent","warn"]))
  var item := {"t":tag,"c":" ".join(classes),"d":node.get("domId",""),"x":node.get("disabled",false),"k":node.get("checked",false),"o":node.get("open",false),"ch":shape_of(node.get("children",[]))}
  if tag in ["input","select","textarea","details"]:
   item["v"] = node.get("value","")
   item["i"] = node.get("id","")
  out.append(item)
 return out
func update_in_place(tree: Array) -> void:
 var nodes: Dictionary = {}
 index_nodes(tree,nodes)
 for path in bindings.keys():
  var pair: Array = bindings[path]
  var control = pair[0]
  if not is_instance_valid(control) or not nodes.has(path):
   continue
  var node: Dictionary = nodes[path]
  if control is ProgressBar:
   for child in node.get("children",[]):
    for part in str(child.get("style","")).split(";"):
     if part.strip_edges().begins_with("width:"):
      control.value = clampf(part.get_slice(":",1).replace("%","").to_float(),0,100)
  elif control is Button:
   control.set_meta("node",node)
   control.disabled = node.get("disabled",false)
   if control is RichButton or control.text!=pair[2]:
    continue
   var text: String = text_of(node)
   if control.text!=text:
    control.text = text
    pair[2] = text
  elif control is Label:
   if control.text!=pair[2]:
    continue
   var text: String = str(node.get("text","")) if node.get("tag")=="#text" else text_of(node)
   if control.text!=text:
    control.text = text
    pair[2] = text
 # the header and the transport are built by hand
 var header := get_node_or_null("ShiftHeader")
 if header!=null:
  for id in ["clock","trust","budget","resolved"]:
   var value := header.find_child(id,true,false) as Label
   if value!=null:
    value.text = text_of(find_node(tree,id))
 var footer := get_node_or_null("ShiftTransport")
 if footer!=null:
  var radio := footer.find_child("RadioText",true,false) as Button
  if radio!=null:
   radio.text = "📻 "+text_of(find_node(tree,"radioText"))
 # Release V2: speed and pause change in place (a full rebuild made the panels blink)
 if header!=null:
  var speed := header.find_child("SpeedCycle",true,false) as Button
  var speeds := collect_speed_nodes(tree)
  if speed!=null and not speeds.is_empty():
   var current := 0
   for k in range(speeds.size()):
    if str(speeds[k].get("classes","")).split(" ").has("active"):
     current = k
   speed.text = text_of(speeds[current])+" ▸"
   speed.set_meta("next",speeds[(current+1)%speeds.size()])
func index_nodes(nodes: Array,out: Dictionary) -> void:
 for node in nodes:
  out[str(node.get("p",""))] = node
  index_nodes(node.get("children",[]),out)
func _widget(node: Dictionary) -> Control:
 var tag: String = node.get("tag","")
 if tag=="#text":
  return label(str(node.text))
 if tag in ["button","a"]:
  var rich := false
  for child in node.get("children",[]):
   if child.get("tag") in ["div","strong","small","p","h3"]:
    rich = true
  var button: Button = RichButton.new() if rich else Button.new()
  if rich:
   button.set_content(content_box(node))
  else:
   button.text = text_of(node)
  var classes: PackedStringArray = str(node.get("classes","")).split(" ")
  if classes.has("active") or classes.has("selected") or classes.has("primary"):
   button.add_theme_stylebox_override("normal",panel_style("20383b","77dacb"))
  button.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
  button.custom_minimum_size = Vector2(52,52)
  button.size_flags_horizontal = Control.SIZE_EXPAND_FILL
  if not rich:
   button.ready.connect(_keep_words.bind(button))
  button.disabled = node.get("disabled",false)
  button.set_meta("node",node)
  button.pressed.connect(func(): get_tree().call_group("sound_world","ui_click"); event(button.get_meta("node",node),"click"))
  return button
 if tag=="input" and node.get("type") in ["checkbox","radio"]:
  var toggle := CheckButton.new()
  toggle.disabled = node.get("disabled",false)
  toggle.button_pressed = node.get("checked",false)
  toggle.custom_minimum_size = Vector2(52,52)
  toggle.size_flags_horizontal = Control.SIZE_SHRINK_BEGIN
  toggle.toggled.connect(func(on): event(node,"change",null,on))
  return toggle
 if tag=="input" and node.get("type")=="range":
  var slider := HSlider.new()
  slider.editable = not node.get("disabled",false)
  slider.custom_minimum_size = Vector2(120,52)
  slider.min_value = float(node.get("min",0))
  slider.max_value = float(node.get("max",100))
  slider.step = maxf(0.01,float(node.get("step",1)))
  slider.value = float(node.get("value",0))
  slider.value_changed.connect(func(value): event(node,"input",value))
  return slider
 if tag=="select":
  var options := OptionButton.new()
  options.disabled = node.get("disabled",false)
  options.custom_minimum_size = Vector2(120,52)
  # Claude 15.10: a long selected option («Реальное время: 1 секунда = …») must not widen the whole menu past the screen.
  options.clip_text = true
  options.fit_to_longest_item = false
  options.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS
  options.size_flags_horizontal = Control.SIZE_EXPAND_FILL
  for child in node.get("children",[]):
   if child.get("tag")=="option":
    options.add_item(text_of(child))
    options.set_item_metadata(options.item_count-1,child.get("value",""))
    options.set_item_disabled(options.item_count-1,child.get("disabled",false))
    if str(child.get("value"))==str(node.get("value")):
     options.select(options.item_count-1)
  options.item_selected.connect(func(index): event(node,"change",options.get_item_metadata(index)))
  return options
 if tag=="input" and node.get("type")=="file":
  var button := Button.new()
  button.text = "Открыть файл сохранения"
  button.custom_minimum_size = Vector2(52,52)
  button.pressed.connect(func(): choose_file(node,false))
  return button
 if tag=="textarea":
  var input := TextEdit.new()
  input.text = str(node.get("value",""))
  input.editable = not node.get("disabled",false) and not node.get("readOnly",false)
  input.wrap_mode = TextEdit.LINE_WRAPPING_BOUNDARY
  input.custom_minimum_size = Vector2(120,160)
  input.text_changed.connect(func(): event(node,"input",input.text))
  return input
 if tag=="input":
  var input := LineEdit.new()
  input.text = str(node.get("value",""))
  input.editable = not node.get("disabled",false) and not node.get("readOnly",false)
  input.placeholder_text = str(node.get("placeholder",""))
  input.custom_minimum_size = Vector2(120,52)
  input.text_changed.connect(func(value): event(node,"input",value))
  input.text_submitted.connect(func(value): event(node,"change",value))
  return input
 if tag=="canvas" and model_factory!=null:
  var container := SubViewportContainer.new()
  container.custom_minimum_size = Vector2(200,180)
  container.stretch = true
  var viewport := SubViewport.new()
  viewport.size = Vector2i(320,200)
  viewport.transparent_bg = true
  # Claude 16.10: an own 3D world — the preview car was placed into the city at its origin and the camera filmed the city.
  viewport.own_world_3d = true
  viewport.render_target_update_mode = SubViewport.UPDATE_ONCE
  var mesh := MeshInstance3D.new()
  var preview: Dictionary = node.get("preview") if typeof(node.get("preview"))==TYPE_DICTIONARY else {}
  var kind: String = preview.get("kind","officer" if str(node.get("domId","")).begins_with("officer-art-") else "sedan")
  var options: Dictionary = preview.get("options",{})
  # Claude 16.10: garage previews of fire engines and ambulances use their own models and paint (were a grey sedan).
  var LiveActors = preload("res://scripts/live_actors.gd")
  if LiveActors.SERVICE_MODELS.has(kind):
   kind = LiveActors.vehicle_model_of(kind)
  mesh.mesh = model_factory.model(kind if model_factory.models.has(kind) else "sedan")
  mesh.material_override = model_factory.materials.police
  viewport.add_child(mesh)
  mesh.rotation.y = -float(options.get("angle",0))
  if kind in ["sedan","suv","engine","ladder","tanker","ambulance-van","resus"] and options.has("palette"):
   model_factory.skins.apply(mesh,model_factory.models[kind],kind,{"police":options.get("police",true),"kit":options.get("kit","base"),"palette":options.palette},{},false,false,true)
  elif kind in ["officer","civilian"] and options.has("palette"):
   model_factory.humans.apply(mesh,model_factory.models[kind],kind,{"palette":options.palette},str(options.get("pose","idle")),float(options.get("phase",0)),true,true)
  # Claude 16.10: frame the model by its size (a car filled a tenth of the preview; a fire engine is twice as long).
  var camera := Camera3D.new()
  camera.fov = 30
  var bounds: AABB = mesh.get_aabb() if mesh.mesh!=null else AABB(Vector3(-2,0,-1),Vector3(4,1.6,2))
  var target: Vector3 = bounds.get_center()
  var reach: float = maxf(0.6,bounds.size.length()*0.5)/sin(deg_to_rad(camera.fov)*0.5)*0.95
  camera.position = target+Vector3(5,3,6).normalized()*reach
  viewport.add_child(camera)
  camera.transform = Transform3D(Basis(),camera.position).looking_at(target)
  var light := DirectionalLight3D.new()
  light.rotation_degrees = Vector3(-45,-30,0)
  viewport.add_child(light)
  container.add_child(viewport)
  return container
 if tag=="svg":
  var image := Image.new()
  if image.load_svg_from_string(node.get("markup",""))==OK:
   var texture := TextureRect.new()
   texture.texture = ImageTexture.create_from_image(image)
   texture.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
   texture.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
   texture.custom_minimum_size = Vector2(250,170)
   return texture
  return label("График не загрузился")
 if tag=="details":
  var box := VBoxContainer.new()
  var children: Array = node.get("children",[])
  var summary := Button.new()
  summary.text = text_of(children[0]) if not children.is_empty() else "Подробнее"
  summary.toggle_mode = true
  summary.custom_minimum_size.y = 52
  summary.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
  var key := str(node.get("id",""))
  summary.button_pressed = expanded_sections.get(key,node.get("open",false))
  box.add_child(summary)
  var body := VBoxContainer.new()
  for child in children.slice(1):
   body.add_child(widget(child))
  body.visible = summary.button_pressed
  box.add_child(body)
  summary.toggled.connect(func(on): body.visible=on; expanded_sections[key]=on)
  return box
 if tag=="dl":
  var grid := GridContainer.new()
  grid.columns = 2
  grid.size_flags_horizontal = Control.SIZE_EXPAND_FILL
  grid.add_theme_constant_override("h_separation",16)
  grid.add_theme_constant_override("v_separation",8)
  for child in node.get("children",[]):
   grid.add_child(widget(child))
  return grid
 if tag=="table":
  var rows := table_rows(node)
  var box := VBoxContainer.new()
  var headers: Array = []
  for row in rows:
   var cells: Array = row.get("children",[])
   if cells.is_empty():
    continue
   if cells[0].get("tag")=="th":
    headers = cells.map(func(cell): return text_of(cell))
    continue
   var panel := PanelContainer.new()
   var values := VBoxContainer.new()
   for i in range(cells.size()):
    values.add_child(label((str(headers[i])+": " if i<headers.size() else "")+text_of(cells[i])))
   panel.add_child(values)
   box.add_child(panel)
  return box
 if tag=="hr":
  return HSeparator.new()
 var classes: PackedStringArray = str(node.get("classes","")).split(" ")
 if classes.has("meter") or classes.has("xpbar") or classes.has("bond"):
  var bar := ProgressBar.new()
  bar.show_percentage = false
  bar.custom_minimum_size = Vector2(60,6)
  for child in node.get("children",[]):
   var style: String = child.get("style","")
   for part in style.split(";"):
    if part.strip_edges().begins_with("width:"):
     bar.value = clampf(part.get_slice(":",1).replace("%","").to_float(),0,100)
  return bar
 if tag in ["h1","h2","h3","h4","p","small","span","strong","b","li"]:
  if not has_control(node):
   return styled_label(node)
 # Claude 15.10: the report tiles (Решено / Пропущено / Опыт) as in style.css .report-grid.
 if classes.has("report-grid"):
  var tiles := GridContainer.new()
  tiles.columns = maxi(1,mini(3,node.get("children",[]).size()))
  tiles.size_flags_horizontal = Control.SIZE_EXPAND_FILL
  tiles.add_theme_constant_override("h_separation",12)
  tiles.add_theme_constant_override("v_separation",12)
  for child in node.get("children",[]):
   var tile := PanelContainer.new()
   tile.size_flags_horizontal = Control.SIZE_EXPAND_FILL
   tile.add_theme_stylebox_override("panel",panel_style("223741","223741",8))
   var lines := VBoxContainer.new()
   for part in child.get("children",[]):
    var item: Label = label(text_of(part))
    if part.get("tag")=="strong":
     item.add_theme_font_size_override("font_size",26)
     item.add_theme_color_override("font_color",Color("77dacb"))
    else:
     item.add_theme_font_size_override("font_size",11)
     item.add_theme_color_override("font_color",Color("8fa3ad"))
    lines.add_child(item)
   tile.add_child(lines)
   tiles.add_child(tile)
  return tiles
 var box := content_box(node)
 # Claude 15.10: every block that the web draws as a bordered/filled card (style.css) is a panel here too.
 for name in ["brief-row","scene","training-card","staff-card","case-card","notice","empty","person-card","partner-card","goals","news","award","case-item","finance-box","month-report","training-step","device-report","staff-condition","talk-stage","scene-card","debrief"]:
  if classes.has(name):
   var panel := PanelContainer.new()
   panel.add_child(box)
   return panel
 return box
func table_rows(node: Dictionary) -> Array:
 if node.get("tag")=="tr":
  return [node]
 var rows: Array = []
 for child in node.get("children",[]):
  rows.append_array(table_rows(child))
 return rows
func has_control(node: Dictionary) -> bool:
 for child in node.get("children",[]):
  if child.get("tag") in ["input","select","button","textarea","svg"] or has_control(child):
   return true
 return false
func close_file_dialog() -> void:
 if is_instance_valid(file_dialog):
  file_dialog.queue_free()
 file_dialog = null
func choose_file(node: Dictionary,saving: bool) -> void:
 if file_dialog!=null:
  file_dialog.queue_free()
 pending_file = node
 file_dialog = FileDialog.new()
 file_dialog.access = FileDialog.ACCESS_FILESYSTEM
 file_dialog.file_mode = FileDialog.FILE_MODE_SAVE_FILE if saving else FileDialog.FILE_MODE_OPEN_FILE
 file_dialog.use_native_dialog = true
 file_dialog.filters = PackedStringArray(["*.json ; Сохранение Mercury"])
 file_dialog.file_selected.connect(func(path):
  if saving:
   var file := FileAccess.open(path,FileAccess.WRITE)
   if file!=null:
    file.store_string(str(controller.snapshot.get("download",{}).get("parts",[]).reduce(func(a,b): return a+str(b),"")))
    controller.action({"op":"consume-download"})
  else:
   var text := FileAccess.get_file_as_string(path)
   if text.length()<=1048576:
    controller.action({"op":"file","domId":pending_file.domId,"text":text})
  signature = ""
  close_file_dialog())
 file_dialog.canceled.connect(close_file_dialog)
 add_child(file_dialog)
 file_dialog.popup_centered_ratio(0.8)
func _input(event: InputEvent) -> void:
 var index := -1
 var pressed := false
 var position := Vector2.ZERO
 if event is InputEventScreenTouch:
  index = event.index
  pressed = event.pressed
  position = event.position
 elif event is InputEventMouseButton and event.device!=InputEvent.DEVICE_ID_EMULATION and event.button_index==MOUSE_BUTTON_LEFT:
  index = 1000
  pressed = event.pressed
  position = event.position
 else:
  return
 if pressed and on_controls(position):
  held_controls[index] = true
 elif not pressed and held_controls.erase(index):
  held_released_ms = Time.get_ticks_msec()
  if held_controls.is_empty():
   refresh.call_deferred()
# Claude 16.10: Android «Back» (a swipe from the edge on Fold6) used to quit the game. Now it closes the open window,
# returns from «Экипажи»/«Вызовы» to the map, and on the map opens the shift menu — it never leaves the game.
func _notification(what: int) -> void:
 if what==NOTIFICATION_WM_GO_BACK_REQUEST:
  go_back.call_deferred()
func go_back() -> void:
 if controller==null:
  return
 var tree: Array = controller.snapshot.get("tree",[])
 if modal_open:
  event({"domId":"closeModal"},"click")
  return
 var tab: String = str(controller.snapshot.get("status",{}).get("tab","map"))
 var nav := find_class(tree,"mobile-nav")
 if tab!="map" and not nav.get("children",[]).is_empty():
  event(nav.children[0],"click")
  return
 event({"domId":"mobileMenu"},"click")
func on_controls(point: Vector2) -> bool:
 if modal_open:
  return true
 for child in get_children():
  if child is Control and child.is_visible_in_tree() and child.mouse_filter!=Control.MOUSE_FILTER_IGNORE and child.get_global_rect().has_point(point):
   return true
 return false
func refresh() -> void:
 if is_instance_valid(native_fps):
  native_fps.text = "%.0f FPS" % frame_report.get("fps",0)
  native_fps.tooltip_text = "P95 %.1f мс" % frame_report.get("p95_ms",0)
 if controller==null or not is_inside_tree():
  return
 if scroll.interaction_active():
  return
 if not held_controls.is_empty() or Time.get_ticks_msec()-held_released_ms<40:
  return
 var focus := get_viewport().gui_get_focus_owner()
 if focus is LineEdit or focus is TextEdit:
  return
 apply_readability()
 if controller.migration_pending or not controller.migration_error.is_empty():
  if signature=="migration"+controller.migration_error:
   return
  signature = "migration"+controller.migration_error
  for child in root.get_children():
   root.remove_child(child)
   child.queue_free()
  clear_chrome()
  scroll.show()
  scroll.offset_top = 8
  scroll.offset_bottom = -8
  root.add_child(label("Переносим сохранение из предыдущей версии…" if controller.migration_pending else controller.migration_error,true))
  if not controller.migration_error.is_empty():
   root.add_child(label("Данные предыдущей версии не удалены. Можно повторить перенос или открыть новую карьеру."))
   var retry := Button.new()
   retry.text = "Повторить перенос"
   retry.custom_minimum_size = Vector2(52,52)
   retry.pressed.connect(func(): controller.retry_migration(); signature=""; refresh())
   root.add_child(retry)
   var button := Button.new()
   button.text = "Начать без переноса, сохранив копию старых данных"
   button.custom_minimum_size = Vector2(52,52)
   button.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
   button.pressed.connect(func(): controller.continue_without_migration(); signature=""; refresh())
   root.add_child(button)
  return
 apply_readability()
 var tree: Array = controller.snapshot.get("tree",[])
 var next := JSON.stringify(tree)
 if next==signature:
  return
 annotate(tree,"")
 var shape := JSON.stringify(shape_of(tree))+"|"+str(controller.snapshot.get("status",{}).get("tab","map"))+"|"+str(size)
 if shape==structure_key and not bindings.is_empty():
  signature = next
  update_in_place(tree)
  return
 signature = next
 structure_key = shape
 bindings = {}
 var next_page := str(controller.snapshot.get("status",{}).get("tab","map"))
 if tree.size()>0 and tree[0].get("tag")=="dialog":
  next_page = "modal:"+heading_of(tree[0])
 var top := scroll.begin_page(next_page)
 for child in root.get_children():
  root.remove_child(child)
  child.queue_free()
 var modal: bool = tree.size()>0 and tree[0].get("tag")=="dialog"
 modal_open = modal
 queue_redraw()
 if modal:
  mouse_filter = Control.MOUSE_FILTER_STOP
  clear_chrome()
  scroll.show()
  scroll.offset_left = maxf(12,(size.x-760)/2)
  scroll.offset_right = -scroll.offset_left
  scroll.offset_top = 76
  scroll.offset_bottom = -16
  var close := find_node(tree,"closeModal")
  if not close.is_empty():
   var row := HBoxContainer.new()
   row.alignment = BoxContainer.ALIGNMENT_END
   var close_button = widget(close)
   close_button.size_flags_horizontal = Control.SIZE_SHRINK_END
   row.add_child(close_button)
   row.position = Vector2(scroll.offset_left,16)
   row.size = Vector2(size.x-2*scroll.offset_left,52)
   modal_close = row
   add_child(row)
  var content := find_node(tree,"modalContent")
  if not content.is_empty():
   root.add_child(widget(content))
   if heading_of(tree[0])=="Меню смены":
    var updates := Button.new()
    updates.text = "Обновления приложения"
    updates.custom_minimum_size.y = 52
    updates.pressed.connect(func(): controller.check_updates())
    root.add_child(updates)
  else:
   for node in tree:
    root.add_child(widget(node))
 else:
  mouse_filter = Control.MOUSE_FILTER_IGNORE
  scroll.offset_left = 8
  scroll.offset_right = -8
  for child in get_children():
   if child!=scroll and child!=file_dialog:
    remove_child(child)
    child.queue_free()
  # Claude 17.10 (Release V «Новый интерфейс»): a thin top bar, one context card with the next action, four tabs, two map buttons.
  var V = preload("res://scripts/native_v.gd")
  var side := wide_left()
  var shift_header: Control = V.header(self,tree)
  add_child(shift_header)
  shift_header.resized.connect(sync_hud.call_deferred)
  var bottom_panel := PanelContainer.new()
  bottom_panel.name = "ShiftTransport"
  bottom_panel.position = Vector2(side+8,maxf(200,size.y-200))
  bottom_panel.size = Vector2(minf(maxf(280,size.x-side-16),640),0)
  bottom_panel.add_theme_stylebox_override("panel",panel_style("111d25ee","2a3943",8))
  var bottom := VBoxContainer.new()
  bottom.add_theme_constant_override("separation",6)
  var tab: String = controller.snapshot.get("status",{}).get("tab","map")
  if tab not in ["units","calls"]:
   bottom.add_child(V.context(self,tree))
  bottom.add_child(V.nav(self,tree))
  bottom_panel.add_child(bottom)
  fix_wrap(bottom,bottom_panel.size.x-20)
  add_child(bottom_panel)
  bottom_panel.resized.connect(sync_hud.call_deferred)
  sync_hud.call_deferred()
  scroll.visible = tab in ["units","calls"] or side>0
  scroll.offset_top = 72
  scroll.offset_bottom = -132
  if side>0:
   scroll.offset_right = -(size.x-side)
  if tab=="units":
   root.add_child(V.patrol_sheet(self,tree) if not find_node(tree,"identity").is_empty() else widget(find_class(tree,"left-panel")))
  elif tab=="calls":
   root.add_child(widget(find_node(tree,"calls")))
   var detail := find_node(tree,"callDetail")
   if not detail.is_empty():
    root.add_child(call_card(detail))
  if tab not in ["units","calls"]:
   add_child(V.map_tools(self,tree))
 if not modal:
  var device_test := find_class(tree,"device-test-bar")
  if not device_test.is_empty():
   var bar := PanelContainer.new()
   bar.name = "DeviceTestBar"
   bar.position = Vector2(wide_left()+12,140)
   bar.size.x = maxf(240,size.x-wide_left()-110)
   bar.add_theme_stylebox_override("panel",panel_style("15222b"))
   bar.add_child(widget(device_test))
   add_child(bar)
  var decision := find_node(tree,"decisionBtn")
  if not decision.is_empty():
   var jump = widget(decision)
   jump.name = "DecisionJump"
   jump.position = Vector2(wide_left()+12,maxf(140,size.y-260))
   jump.size.x = maxf(240,size.x-wide_left()-112)
   add_child(jump)
  # Claude 17.10 (Release U): on the calls tab the main action («Направить экипаж») stays under the thumb above the tabs.
  var dispatch := find_node(tree,"dispatchBtn")
  if false and not dispatch.is_empty() and not dispatch.get("disabled",false) and str(controller.snapshot.get("status",{}).get("tab","map"))=="calls" and get_node_or_null("DecisionJump")==null:
   var send = widget(dispatch)
   send.name = "DispatchJump"
   send.position = Vector2(wide_left()+12,maxf(140,size.y-200))
   send.size.x = maxf(240,size.x-wide_left()-24)
   add_child(send)
  var tip := find_node(tree,"tipCard")
  if not tip.is_empty():
   var panel := PanelContainer.new()
   panel.name = "TipPanel"
   panel.position = Vector2(wide_left()+12,140)
   panel.size.x = maxf(240,minf(size.x-wide_left()-24,520))
   # Claude 17.10 (Release U): a compact strip — text and two small buttons in one row, not half the screen.
   panel.add_theme_stylebox_override("panel",panel_style("1b2d38ee","77dacb",8))
   var box := VBoxContainer.new()
   box.add_theme_constant_override("separation",4)
   var tip_text: Label = label(text_of(tip).replace("Понятно","").replace("Больше не показывать","").strip_edges())
   tip_text.max_lines_visible = 3
   tip_text.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS
   tip_text.add_theme_font_size_override("font_size",13)
   box.add_child(tip_text)
   var tip_row := HBoxContainer.new()
   tip_row.alignment = BoxContainer.ALIGNMENT_END
   for pair in [["tipOff","Не показывать"],["tipOk","Понятно"]]:
    var node := find_node([tip],pair[0])
    if node.is_empty():
     continue
    var b := Button.new()
    b.text = pair[1]
    b.custom_minimum_size = Vector2(0,44)
    b.add_theme_font_size_override("font_size",13)
    b.pressed.connect(func(): event(node,"click"))
    tip_row.add_child(b)
   box.add_child(tip_row)
   panel.add_child(box)
   fix_wrap(box,panel.size.x-20)
   add_child(panel)
  var toast := find_node(tree,"toast")
  if not toast.is_empty() and not text_of(toast).is_empty():
   var message := label(text_of(toast))
   message.position = Vector2(wide_left()+12,maxf(150,size.y-180))
   message.size.x = maxf(240,size.x-wide_left()-24)
   add_child(message)
 scroll.restore_after_layout(top)
 if controller.snapshot.get("download")!=null and file_dialog==null:
  choose_file({},true)
# Claude 16.10: wrap only between words («Начальни/к» was split); the button is at least as wide as its longest word.
func _keep_words(button: Button) -> void:
 if button.autowrap_mode==TextServer.AUTOWRAP_OFF:
  return
 var font := button.get_theme_font("font")
 var font_size := button.get_theme_font_size("font_size")
 var widest := 0.0
 for word in button.text.split(" ",false):
  widest = maxf(widest,font.get_string_size(word,HORIZONTAL_ALIGNMENT_LEFT,-1,font_size).x)
 var box := button.get_theme_stylebox("normal")
 var margins := box.get_margin(SIDE_LEFT)+box.get_margin(SIDE_RIGHT) if box!=null else 16.0
 button.custom_minimum_size.x = maxf(button.custom_minimum_size.x,ceilf(widest+margins+2))
# Claude 15.10: narrow phone buttons keep their text — small side padding instead of the card padding.
func _tight(button: Button) -> void:
 for state in ["normal","hover","pressed","focus","disabled","hover_pressed"]:
  var box := button.get_theme_stylebox(state)
  if box!=null:
   var copy: StyleBox = box.duplicate()
   copy.content_margin_left = 2
   copy.content_margin_right = 2
   button.add_theme_stylebox_override(state,copy)
# Width of the left column on a wide screen; 0 on a phone (the web switches at 760 px too).
func call_card(detail: Dictionary) -> Control:
 var box := VBoxContainer.new()
 box.add_theme_constant_override("separation",6)
 var title := find_tag(detail,"h3")
 if title.is_empty():
  return widget(detail)
 var head: Label = label(text_of(title),true)
 head.add_theme_font_size_override("font_size",18)
 box.add_child(head)
 var place := find_class([detail],"incident-location")
 if not place.is_empty():
  var where: Label = label(text_of(place))
  where.add_theme_color_override("font_color",Color("9fb4c0"))
  box.add_child(where)
 var scene := find_class([detail],"scene-card")
 if not scene.is_empty():
  var strong := find_tag(scene,"strong")
  if not strong.is_empty():
   var phase: Label = label("Сейчас: "+text_of(strong))
   phase.add_theme_color_override("font_color",Color("77dacb"))
   box.add_child(phase)
 # every action a player can take on this call, big and first
 var actions: Array = []
 collect_actions(detail,actions)
 for node in actions:
  var b = widget(node)
  if b is Button:
   b.custom_minimum_size.y = 56
   b.add_theme_font_size_override("font_size",15)
   box.add_child(b)
 var row := HBoxContainer.new()
 var locate := find_node([detail],"locateCallBtn")
 if not locate.is_empty():
  var l = widget(locate)
  l.text = "На карте ↗"
  l.size_flags_horizontal = Control.SIZE_EXPAND_FILL
  row.add_child(l)
 var more := Button.new()
 more.text = "Скрыть подробности ▴" if call_details_open else "Подробности ▾"
 more.size_flags_horizontal = Control.SIZE_EXPAND_FILL
 more.custom_minimum_size.y = 48
 more.pressed.connect(func(): call_details_open = not call_details_open; signature = ""; refresh())
 row.add_child(more)
 box.add_child(row)
 if call_details_open:
  box.add_child(widget(detail))
 return box
func collect_actions(node: Dictionary,out: Array) -> void:
 if node.get("tag")=="button":
  var id := str(node.get("domId",""))
  var t := text_of(node)
  if not node.get("disabled",false) and id!="locateCallBtn" and not id.begins_with("callPerson-") and not id.begins_with("callResident-") and not t.contains("↗"):
   out.append(node)
  return
 for child in node.get("children",[]):
  collect_actions(child,out)
func find_tag(node: Dictionary,tag: String) -> Dictionary:
 if node.get("tag")==tag:
  return node
 for child in node.get("children",[]):
  var f := find_tag(child,tag)
  if not f.is_empty():
   return f
 return {}
func wide_left() -> float:
 # Claude 17.10 (Release V2): on a wide screen too the map is the screen; «Патруль» / «Вызовы» open as a side panel.
 if size.x<760 or size.y<560 or controller==null or str(controller.snapshot.get("status",{}).get("tab","map")) not in ["units","calls"]:
  return 0.0
 return clampf(size.x*0.32,260,380)
func sync_hud() -> void:
 var header := get_node_or_null("ShiftHeader") as Control
 var footer := get_node_or_null("ShiftTransport") as Control
 if header==null or footer==null:
  return
 var expanded: bool = str(controller.snapshot.get("bodyClasses","")).contains("native-fullscreen")
 header.visible = not expanded
 footer.visible = not expanded
 # Claude 17.10 (Release V): wrapped labels measure before the panel has its width — shrink the card to its content.
 if footer.size.y>footer.get_combined_minimum_size().y+1:
  footer.size = Vector2(footer.size.x,0)
 footer.position.y = size.y-footer.size.y-8
 var top := 8.0 if expanded else header.position.y+header.size.y+8
 scroll.offset_top = top
 scroll.offset_bottom = -footer.size.y-16
 # Claude 17.10 (Release U2): on a phone «Экипажи» and «Вызовы» are a sheet over the lower part of the map — the map stays visible.
 if wide_left()==0 and not expanded and str(controller.snapshot.get("status",{}).get("tab","map")) in ["units","calls"]:
  scroll.offset_top = maxf(top,size.y*0.40)
 if wide_left()>0:
  scroll.offset_bottom = -8
  scroll.visible = not expanded
 var jump := get_node_or_null("DecisionJump") as Control
 if jump!=null:
  jump.position.y = footer.position.y-jump.size.y-8
 var send := get_node_or_null("DispatchJump") as Control
 if send!=null:
  send.position.y = footer.position.y-send.size.y-8
  scroll.offset_bottom = -footer.size.y-send.size.y-24
 # Claude 16.10: the tip card and device test bar start below the header (it is taller on a narrow phone).
 for floating in ["TipPanel","DeviceTestBar"]:
  var card := get_node_or_null(floating) as Control
  if card!=null:
   card.position.y = top
   # Wrapped text measured its height before the card had its width (a 2863 px tall tip over the map); shrink to fit.
   card.size = Vector2(card.size.x,0)
 var controls := get_node_or_null("MapControls") as Control
 if controls!=null:
  var limit: float = (size.y if expanded else footer.position.y)-8
  var wanted: float = minf(limit-top,(controls.get_child(0) as Control).get_combined_minimum_size().y if controls.get_child_count()>0 else 52.0)
  controls.size.y = maxf(52,wanted)
  controls.position.y = maxf(top,limit-controls.size.y)
# Claude 17.10 (Release V): a wrapped label measures its height at its minimum width (2500 px tall cards); give the
# labels of a floating card the card's width before the first layout.
func fix_wrap(node: Node,width: float) -> void:
 for child in node.get_children():
  if child is Label and child.autowrap_mode!=TextServer.AUTOWRAP_OFF and child.get_parent() is VBoxContainer:
   child.custom_minimum_size.x = maxf(child.custom_minimum_size.x,width)
  fix_wrap(child,width)
func heading_of(node: Dictionary) -> String:
 if node.get("tag") in ["h1","h2"]:
  return text_of(node)
 for child in node.get("children",[]):
  var value := heading_of(child)
  if not value.is_empty():
   return value
 return ""
func find_node(nodes: Array,id: String) -> Dictionary:
 for node in nodes:
  if node.get("domId")==id:
   return node
  var found := find_node(node.get("children",[]),id)
  if not found.is_empty():
   return found
 return {}
func find_class(nodes: Array,name: String) -> Dictionary:
 for node in nodes:
  if str(node.get("classes","")).split(" ").has(name):
   return node
  var found := find_class(node.get("children",[]),name)
  if not found.is_empty():
   return found
 return {}
func collect_speed_nodes(nodes: Array) -> Array:
 var output: Array = []
 for node in nodes:
  if node.get("tag")=="button" and str(node.get("text","")).ends_with("×"):
   output.append(node)
  output.append_array(collect_speed_nodes(node.get("children",[])))
 return output

func clear_chrome() -> void:
 native_fps = null
 for child in get_children():
  if child!=scroll and child!=file_dialog:
   remove_child(child)
   child.queue_free()
