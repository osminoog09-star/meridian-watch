extends Control
const RichButton = preload("res://scripts/native_rich_button.gd")
var expanded_sections: Dictionary = {}
var theme_key := ""
var modal_open := false
var controller: RefCounted
var model_factory: Node3D
var frame_report: Dictionary = {}
var signature := ""
var native_fps: Label
var root := VBoxContainer.new()
var scroll := preload("res://scripts/native_scroll.gd").new()
var modal_close: Control
var file_dialog: FileDialog
var pending_file: Dictionary = {}
func _ready() -> void:
 set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
 mouse_filter = Control.MOUSE_FILTER_IGNORE
 scroll.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
 scroll.offset_left = 8
 scroll.offset_right = -8
 scroll.offset_top = 8
 scroll.offset_bottom = -8
 root.size_flags_horizontal = Control.SIZE_EXPAND_FILL
 scroll.add_child(root)
 add_child(scroll)
 resized.connect(func(): signature=""; refresh())
func _draw() -> void:
 if controller!=null and not modal_open:
  var flash := find_node(controller.snapshot.get("tree",[]),"a11yFlash")
  if str(flash.get("classes","")).split(" ").has("on"):
   draw_rect(Rect2(Vector2(3,3),size-Vector2(6,6)),Color("efa66b") if str(flash.get("classes","")).contains("urgent") else Color("77dacb"),false,6)
 if modal_open:
  draw_rect(Rect2(Vector2.ZERO,size),Color(0.025,0.06,0.085,0.8))
func event(node: Dictionary,kind: String,value: Variant = null,checked: Variant = null) -> void:
 var request := {"op":"event","id":node.get("id"),"domId":node.get("domId"),"event":kind}
 if value!=null:
  request.value = value
 if checked!=null:
  request.checked = checked
 controller.action(request)
 signature = ""
 refresh()
func text_of(node: Dictionary) -> String:
 if node.get("tag")=="#text":
  return str(node.get("text",""))
 var output := str(node.get("text",""))
 if output.is_empty():
  for child in node.get("children",[]):
   output += text_of(child)+" "
 return output.strip_edges()
func label(text: String,large: bool = false) -> Label:
 var item := Label.new()
 item.mouse_filter = Control.MOUSE_FILTER_IGNORE
 item.text = text
 item.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
 item.size_flags_horizontal = Control.SIZE_EXPAND_FILL
 var classes: String = controller.snapshot.get("bodyClasses","")
 var scale: float = 1.3 if classes.contains("a11y-text-huge") else (1.15 if classes.contains("a11y-text-large") else 1.0)
 item.add_theme_font_size_override("font_size",int((24 if large else 14)*scale))
 return item
func panel_style(color: String, border: String = "2a3943", padding: int = 12) -> StyleBoxFlat:
 var style := StyleBoxFlat.new()
 style.bg_color = Color(color)
 style.border_color = Color(border)
 style.set_border_width_all(1)
 style.set_corner_radius_all(8)
 style.content_margin_left = padding
 style.content_margin_right = padding
 style.content_margin_top = padding
 style.content_margin_bottom = padding
 return style
func apply_readability() -> void:
 var classes: String = controller.snapshot.get("bodyClasses","")
 if theme_key==classes and theme!=null:
  return
 theme_key = classes
 var scale: float = 1.3 if classes.contains("a11y-text-huge") else (1.15 if classes.contains("a11y-text-large") else 1.0)
 var next_theme := Theme.new()
 next_theme.default_font_size = int(14*scale)
 for type in ["Button","OptionButton"]:
  next_theme.set_stylebox("normal",type,panel_style("1c2c36"))
  next_theme.set_stylebox("hover",type,panel_style("2c424c"))
  next_theme.set_stylebox("pressed",type,panel_style("20383b","77dacb"))
  next_theme.set_stylebox("focus",type,panel_style("20383b","77dacb"))
  next_theme.set_stylebox("disabled",type,panel_style("142028"))
  next_theme.set_color("font_color",type,Color("e5edf0"))
  next_theme.set_color("font_disabled_color",type,Color("879ca9"))
 next_theme.set_color("font_color","Label",Color("ffffff" if classes.contains("a11y-contrast") else "e5edf0"))
 next_theme.set_stylebox("panel","PanelContainer",panel_style("16222b"))
 next_theme.set_stylebox("background","ProgressBar",panel_style("2a3b44","2a3b44",0))
 next_theme.set_stylebox("fill","ProgressBar",panel_style("77dacb","77dacb",0))
 theme = next_theme
 scroll.add_theme_stylebox_override("panel",panel_style("07111b" if classes.contains("a11y-contrast") else "162730","425861",16))
func styled_label(node: Dictionary) -> Label:
 var tag: String = node.get("tag","")
 var item := label(text_of(node),tag in ["h1","h2"])
 var classes: String = node.get("classes","")
 if tag=="small" or classes.contains("muted"):
  item.add_theme_color_override("font_color",Color("879ca9"))
 if tag in ["h3","h4"] or classes.contains("eyebrow") or classes.contains("status"):
  item.add_theme_color_override("font_color",Color("77dacb"))
 return item
func content_box(node: Dictionary) -> Container:
 var classes: PackedStringArray = str(node.get("classes","")).split(" ")
 var box: Container = VBoxContainer.new()
 for name in ["modal-actions","mode-switch","model-controls","awards"]:
  if classes.has(name):
   box.free()
   box = HFlowContainer.new()
   break
 for name in ["start-options","report-grid","focus-list"]:
  if classes.has(name) and size.x>=600:
   box.free()
   var grid := GridContainer.new()
   grid.columns = 2
   box = grid
   break
 box.size_flags_horizontal = Control.SIZE_EXPAND_FILL
 box.add_theme_constant_override("separation",9)
 box.add_theme_constant_override("h_separation",12)
 box.add_theme_constant_override("v_separation",9)
 for child in node.get("children",[]):
  var item = widget(child)
  if item!=null:
   box.add_child(item)
 return box
func widget(node: Dictionary) -> Control:
 var tag: String = node.get("tag","")
 if tag=="#text":
  return label(str(node.text))
 if tag in ["button","a"]:
  var rich := false
  for child in node.get("children",[]):
   if child.get("tag") in ["div","strong","small","p","h3"]:
    rich = true
  var button: Button = RichButton.new() if rich else Button.new()
  if rich:
   button.set_content(content_box(node))
  else:
   button.text = text_of(node)
  var classes: PackedStringArray = str(node.get("classes","")).split(" ")
  if classes.has("active") or classes.has("selected") or classes.has("primary"):
   button.add_theme_stylebox_override("normal",panel_style("20383b","77dacb"))
  button.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
  button.custom_minimum_size = Vector2(52,52)
  button.size_flags_horizontal = Control.SIZE_EXPAND_FILL
  button.disabled = node.get("disabled",false)
  button.pressed.connect(func(): event(node,"click"))
  return button
 if tag=="input" and node.get("type") in ["checkbox","radio"]:
  var toggle := CheckButton.new()
  toggle.disabled = node.get("disabled",false)
  toggle.button_pressed = node.get("checked",false)
  toggle.custom_minimum_size = Vector2(52,52)
  toggle.toggled.connect(func(on): event(node,"change",null,on))
  return toggle
 if tag=="input" and node.get("type")=="range":
  var slider := HSlider.new()
  slider.editable = not node.get("disabled",false)
  slider.custom_minimum_size = Vector2(120,52)
  slider.min_value = float(node.get("min",0))
  slider.max_value = float(node.get("max",100))
  slider.step = maxf(0.01,float(node.get("step",1)))
  slider.value = float(node.get("value",0))
  slider.value_changed.connect(func(value): event(node,"input",value))
  return slider
 if tag=="select":
  var options := OptionButton.new()
  options.disabled = node.get("disabled",false)
  options.custom_minimum_size = Vector2(120,52)
  for child in node.get("children",[]):
   if child.get("tag")=="option":
    options.add_item(text_of(child))
    options.set_item_metadata(options.item_count-1,child.get("value",""))
    options.set_item_disabled(options.item_count-1,child.get("disabled",false))
    if str(child.get("value"))==str(node.get("value")):
     options.select(options.item_count-1)
  options.item_selected.connect(func(index): event(node,"change",options.get_item_metadata(index)))
  return options
 if tag=="input" and node.get("type")=="file":
  var button := Button.new()
  button.text = "Открыть файл сохранения"
  button.custom_minimum_size = Vector2(52,52)
  button.pressed.connect(func(): choose_file(node,false))
  return button
 if tag=="textarea":
  var input := TextEdit.new()
  input.text = str(node.get("value",""))
  input.editable = not node.get("disabled",false) and not node.get("readOnly",false)
  input.wrap_mode = TextEdit.LINE_WRAPPING_BOUNDARY
  input.custom_minimum_size = Vector2(120,160)
  input.text_changed.connect(func(): event(node,"input",input.text))
  return input
 if tag=="input":
  var input := LineEdit.new()
  input.text = str(node.get("value",""))
  input.editable = not node.get("disabled",false) and not node.get("readOnly",false)
  input.placeholder_text = str(node.get("placeholder",""))
  input.custom_minimum_size = Vector2(120,52)
  input.text_changed.connect(func(value): event(node,"input",value))
  input.text_submitted.connect(func(value): event(node,"change",value))
  return input
 if tag=="canvas" and model_factory!=null:
  var container := SubViewportContainer.new()
  container.custom_minimum_size = Vector2(200,180)
  container.stretch = true
  var viewport := SubViewport.new()
  viewport.size = Vector2i(320,200)
  viewport.transparent_bg = true
  viewport.render_target_update_mode = SubViewport.UPDATE_ONCE
  var mesh := MeshInstance3D.new()
  var preview: Dictionary = node.get("preview") if typeof(node.get("preview"))==TYPE_DICTIONARY else {}
  var kind: String = preview.get("kind","officer" if str(node.get("domId","")).begins_with("officer-art-") else "sedan")
  var options: Dictionary = preview.get("options",{})
  mesh.mesh = model_factory.model(kind if model_factory.models.has(kind) else "sedan")
  mesh.material_override = model_factory.materials.police
  viewport.add_child(mesh)
  mesh.rotation.y = -float(options.get("angle",0))
  if kind in ["sedan","suv"] and options.has("palette"):
   model_factory.skins.apply(mesh,model_factory.models[kind],kind,{"police":options.get("police",true),"kit":options.get("kit","base"),"palette":options.palette},{},false,false,true)
  elif kind in ["officer","civilian"] and options.has("palette"):
   model_factory.humans.apply(mesh,model_factory.models[kind],kind,{"palette":options.palette},str(options.get("pose","idle")),float(options.get("phase",0)),true,true)
  var camera := Camera3D.new()
  camera.position = Vector3(5,3,6)
  viewport.add_child(camera)
  camera.transform = Transform3D(Basis(),camera.position).looking_at(Vector3(0,0.7,0))
  var light := DirectionalLight3D.new()
  light.rotation_degrees = Vector3(-45,-30,0)
  viewport.add_child(light)
  container.add_child(viewport)
  return container
 if tag=="svg":
  var image := Image.new()
  if image.load_svg_from_string(node.get("markup",""))==OK:
   var texture := TextureRect.new()
   texture.texture = ImageTexture.create_from_image(image)
   texture.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
   texture.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
   texture.custom_minimum_size = Vector2(250,170)
   return texture
  return label("График не загрузился")
 if tag=="details":
  var box := VBoxContainer.new()
  var children: Array = node.get("children",[])
  var summary := Button.new()
  summary.text = text_of(children[0]) if not children.is_empty() else "Подробнее"
  summary.toggle_mode = true
  summary.custom_minimum_size.y = 52
  summary.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
  var key := str(node.get("id",""))
  summary.button_pressed = expanded_sections.get(key,node.get("open",false))
  box.add_child(summary)
  var body := VBoxContainer.new()
  for child in children.slice(1):
   body.add_child(widget(child))
  body.visible = summary.button_pressed
  box.add_child(body)
  summary.toggled.connect(func(on): body.visible=on; expanded_sections[key]=on)
  return box
 if tag=="dl":
  var grid := GridContainer.new()
  grid.columns = 2
  grid.size_flags_horizontal = Control.SIZE_EXPAND_FILL
  grid.add_theme_constant_override("h_separation",16)
  grid.add_theme_constant_override("v_separation",8)
  for child in node.get("children",[]):
   grid.add_child(widget(child))
  return grid
 if tag=="table":
  var rows := table_rows(node)
  var box := VBoxContainer.new()
  var headers: Array = []
  for row in rows:
   var cells: Array = row.get("children",[])
   if cells.is_empty():
    continue
   if cells[0].get("tag")=="th":
    headers = cells.map(func(cell): return text_of(cell))
    continue
   var panel := PanelContainer.new()
   var values := VBoxContainer.new()
   for i in range(cells.size()):
    values.add_child(label((str(headers[i])+": " if i<headers.size() else "")+text_of(cells[i])))
   panel.add_child(values)
   box.add_child(panel)
  return box
 if tag=="hr":
  return HSeparator.new()
 var classes: PackedStringArray = str(node.get("classes","")).split(" ")
 if classes.has("meter") or classes.has("xpbar"):
  var bar := ProgressBar.new()
  bar.show_percentage = false
  bar.custom_minimum_size = Vector2(60,6)
  for child in node.get("children",[]):
   var style: String = child.get("style","")
   for part in style.split(";"):
    if part.strip_edges().begins_with("width:"):
     bar.value = clampf(part.get_slice(":",1).replace("%","").to_float(),0,100)
  return bar
 if tag in ["h1","h2","h3","h4","p","small","span","strong","b","li"]:
  if not has_control(node):
   return styled_label(node)
 var box := content_box(node)
 for name in ["brief-row","scene","training-card","staff-card","case-card","notice","empty","person-card"]:
  if classes.has(name):
   var panel := PanelContainer.new()
   panel.add_child(box)
   return panel
 return box
func table_rows(node: Dictionary) -> Array:
 if node.get("tag")=="tr":
  return [node]
 var rows: Array = []
 for child in node.get("children",[]):
  rows.append_array(table_rows(child))
 return rows
func has_control(node: Dictionary) -> bool:
 for child in node.get("children",[]):
  if child.get("tag") in ["input","select","button","textarea","svg"] or has_control(child):
   return true
 return false
func close_file_dialog() -> void:
 if is_instance_valid(file_dialog):
  file_dialog.queue_free()
 file_dialog = null
func choose_file(node: Dictionary,saving: bool) -> void:
 if file_dialog!=null:
  file_dialog.queue_free()
 pending_file = node
 file_dialog = FileDialog.new()
 file_dialog.access = FileDialog.ACCESS_FILESYSTEM
 file_dialog.file_mode = FileDialog.FILE_MODE_SAVE_FILE if saving else FileDialog.FILE_MODE_OPEN_FILE
 file_dialog.use_native_dialog = true
 file_dialog.filters = PackedStringArray(["*.json ; Сохранение Mercury"])
 file_dialog.file_selected.connect(func(path):
  if saving:
   var file := FileAccess.open(path,FileAccess.WRITE)
   if file!=null:
    file.store_string(str(controller.snapshot.get("download",{}).get("parts",[]).reduce(func(a,b): return a+str(b),"")))
    controller.action({"op":"consume-download"})
  else:
   var text := FileAccess.get_file_as_string(path)
   if text.length()<=1048576:
    controller.action({"op":"file","domId":pending_file.domId,"text":text})
  signature = ""
  close_file_dialog())
 file_dialog.canceled.connect(close_file_dialog)
 add_child(file_dialog)
 file_dialog.popup_centered_ratio(0.8)
func refresh() -> void:
 if is_instance_valid(native_fps):
  native_fps.text = "%.0f FPS" % frame_report.get("fps",0)
  native_fps.tooltip_text = "P95 %.1f мс" % frame_report.get("p95_ms",0)
 if controller==null or not is_inside_tree():
  return
 if scroll.interaction_active():
  return
 var focus := get_viewport().gui_get_focus_owner()
 if focus is LineEdit or focus is TextEdit:
  return
 apply_readability()
 if controller.migration_pending or not controller.migration_error.is_empty():
  if signature=="migration"+controller.migration_error:
   return
  signature = "migration"+controller.migration_error
  for child in root.get_children():
   root.remove_child(child)
   child.queue_free()
  clear_chrome()
  scroll.show()
  scroll.offset_top = 8
  scroll.offset_bottom = -8
  root.add_child(label("Переносим сохранение из предыдущей версии…" if controller.migration_pending else controller.migration_error,true))
  if not controller.migration_error.is_empty():
   root.add_child(label("Данные предыдущей версии не удалены. Можно повторить перенос или открыть новую карьеру."))
   var retry := Button.new()
   retry.text = "Повторить перенос"
   retry.custom_minimum_size = Vector2(52,52)
   retry.pressed.connect(func(): controller.retry_migration(); signature=""; refresh())
   root.add_child(retry)
   var button := Button.new()
   button.text = "Начать без переноса, сохранив копию старых данных"
   button.custom_minimum_size = Vector2(52,52)
   button.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
   button.pressed.connect(func(): controller.continue_without_migration(); signature=""; refresh())
   root.add_child(button)
  return
 apply_readability()
 var tree: Array = controller.snapshot.get("tree",[])
 var next := JSON.stringify(tree)
 if next==signature:
  return
 signature = next
 var next_page := str(controller.snapshot.get("status",{}).get("tab","map"))
 if tree.size()>0 and tree[0].get("tag")=="dialog":
  next_page = "modal:"+heading_of(tree[0])
 var top := scroll.begin_page(next_page)
 for child in root.get_children():
  root.remove_child(child)
  child.queue_free()
 var modal: bool = tree.size()>0 and tree[0].get("tag")=="dialog"
 modal_open = modal
 queue_redraw()
 if modal:
  mouse_filter = Control.MOUSE_FILTER_STOP
  clear_chrome()
  scroll.show()
  scroll.offset_left = maxf(12,(size.x-760)/2)
  scroll.offset_right = -scroll.offset_left
  scroll.offset_top = 76
  scroll.offset_bottom = -16
  var close := find_node(tree,"closeModal")
  if not close.is_empty():
   var row := HBoxContainer.new()
   row.alignment = BoxContainer.ALIGNMENT_END
   var close_button = widget(close)
   close_button.size_flags_horizontal = Control.SIZE_SHRINK_END
   row.add_child(close_button)
   row.position = Vector2(scroll.offset_left,16)
   row.size = Vector2(size.x-2*scroll.offset_left,52)
   modal_close = row
   add_child(row)
  var content := find_node(tree,"modalContent")
  if not content.is_empty():
   root.add_child(widget(content))
   if heading_of(tree[0])=="Меню смены":
    var updates := Button.new()
    updates.text = "Обновления приложения"
    updates.custom_minimum_size.y = 52
    updates.pressed.connect(func(): controller.check_updates())
    root.add_child(updates)
  else:
   for node in tree:
    root.add_child(widget(node))
 else:
  mouse_filter = Control.MOUSE_FILTER_IGNORE
  scroll.offset_left = 8
  scroll.offset_right = -8
  for child in get_children():
   if child!=scroll and child!=file_dialog:
    remove_child(child)
    child.queue_free()
  add_child(preload("res://scripts/native_hud.gd").header(self,tree))
  var bottom_panel := PanelContainer.new()
  bottom_panel.name = "ShiftTransport"
  bottom_panel.position = Vector2(8,maxf(200,size.y-180))
  bottom_panel.size = Vector2(maxf(280,size.x-16),172)
  bottom_panel.add_theme_stylebox_override("panel",panel_style("15222b","2a3943",4))
  var bottom := VBoxContainer.new()
  bottom.add_child(preload("res://scripts/native_hud.gd").radio(self,tree))
  var speed_row := HBoxContainer.new()
  speed_row.add_theme_constant_override("separation",2)
  var pause := find_node(tree,"pauseBtn")
  if not pause.is_empty():
   speed_row.add_child(widget(pause))
  for node in collect_speed_nodes(tree):
   speed_row.add_child(widget(node))
  var speed_scroll := ScrollContainer.new()
  speed_scroll.custom_minimum_size.y = 52
  speed_scroll.vertical_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
  speed_scroll.add_child(speed_row)
  bottom.add_child(speed_scroll)
  var nav_node := find_class(tree,"mobile-nav")
  var nav_row := HBoxContainer.new()
  for node in nav_node.get("children",[]):
   var button = widget(node)
   if button is Button:
    button.add_theme_font_size_override("font_size",12)
    nav_row.add_child(button)
  bottom.add_child(nav_row)
  bottom_panel.add_child(bottom)
  add_child(bottom_panel)
  bottom_panel.resized.connect(sync_hud.call_deferred)
  sync_hud.call_deferred()
  var tab: String = controller.snapshot.get("status",{}).get("tab","map")
  scroll.visible = tab in ["units","calls"]
  scroll.offset_top = 140
  scroll.offset_bottom = -188
  if tab=="units":
   root.add_child(widget(find_class(tree,"left-panel")))
  elif tab=="calls":
   root.add_child(widget(find_node(tree,"calls")))
   root.add_child(widget(find_node(tree,"callDetail")))
  else:
   var map_buttons := VBoxContainer.new()
   map_buttons.custom_minimum_size.x = 72
   var controls := find_class(tree,"map-controls")
   for node in controls.get("children",[]):
    var item = widget(node)
    if item is Button:
     item.add_theme_font_size_override("font_size",13)
     map_buttons.add_child(item)
   var map_scroll := ScrollContainer.new()
   map_scroll.name = "MapControls"
   map_scroll.position = Vector2(maxf(8,size.x-88),140)
   map_scroll.size = Vector2(80,maxf(52,size.y-328))
   map_scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
   map_scroll.add_child(map_buttons)
   add_child(map_scroll)
 if not modal:
  var device_test := find_class(tree,"device-test-bar")
  if not device_test.is_empty():
   var bar := PanelContainer.new()
   bar.position = Vector2(12,140)
   bar.size.x = maxf(240,size.x-110)
   bar.add_theme_stylebox_override("panel",panel_style("15222b"))
   bar.add_child(widget(device_test))
   add_child(bar)
  var decision := find_node(tree,"decisionBtn")
  if not decision.is_empty():
   var jump = widget(decision)
   jump.name = "DecisionJump"
   jump.position = Vector2(12,maxf(140,size.y-260))
   jump.size.x = maxf(240,size.x-112)
   add_child(jump)
  var tip := find_node(tree,"tipCard")
  if not tip.is_empty():
   var panel := PanelContainer.new()
   panel.position = Vector2(12,140)
   panel.size.x = maxf(240,minf(size.x-24,520))
   panel.add_child(widget(tip))
   add_child(panel)
  var toast := find_node(tree,"toast")
  if not toast.is_empty() and not text_of(toast).is_empty():
   var message := label(text_of(toast))
   message.position = Vector2(12,maxf(150,size.y-180))
   message.size.x = maxf(240,size.x-24)
   add_child(message)
 scroll.restore_after_layout(top)
 if controller.snapshot.get("download")!=null and file_dialog==null:
  choose_file({},true)
func sync_hud() -> void:
 var header := get_node_or_null("ShiftHeader") as Control
 var footer := get_node_or_null("ShiftTransport") as Control
 if header==null or footer==null:
  return
 var expanded: bool = str(controller.snapshot.get("bodyClasses","")).contains("native-fullscreen")
 header.visible = not expanded
 footer.visible = not expanded
 footer.position.y = size.y-footer.size.y-8
 var top := 8.0 if expanded else header.position.y+header.size.y+8
 scroll.offset_top = top
 scroll.offset_bottom = -footer.size.y-16
 var jump := get_node_or_null("DecisionJump") as Control
 if jump!=null:
  jump.position.y = footer.position.y-jump.size.y-8
 var controls := get_node_or_null("MapControls") as Control
 if controls!=null:
  controls.position.y = top
  controls.size.y = maxf(52,(size.y if expanded else footer.position.y)-top-8)
func heading_of(node: Dictionary) -> String:
 if node.get("tag") in ["h1","h2"]:
  return text_of(node)
 for child in node.get("children",[]):
  var value := heading_of(child)
  if not value.is_empty():
   return value
 return ""
func find_node(nodes: Array,id: String) -> Dictionary:
 for node in nodes:
  if node.get("domId")==id:
   return node
  var found := find_node(node.get("children",[]),id)
  if not found.is_empty():
   return found
 return {}
func find_class(nodes: Array,name: String) -> Dictionary:
 for node in nodes:
  if str(node.get("classes","")).split(" ").has(name):
   return node
  var found := find_class(node.get("children",[]),name)
  if not found.is_empty():
   return found
 return {}
func collect_speed_nodes(nodes: Array) -> Array:
 var output: Array = []
 for node in nodes:
  if node.get("tag")=="button" and str(node.get("text","")).ends_with("×"):
   output.append(node)
  output.append_array(collect_speed_nodes(node.get("children",[])))
 return output

func clear_chrome() -> void:
 native_fps = null
 for child in get_children():
  if child!=scroll and child!=file_dialog:
   remove_child(child)
   child.queue_free()
