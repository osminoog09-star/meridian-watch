extends RefCounted
# Claude 22.10.2026 (City 2.0, «Машины»). Owner: «даже машины говно». A small kit of town cars with real shapes: a side
# profile per body (hood, windscreen, roof, boot) extruded across the width, a glass greenhouse under a painted roof,
# bumpers, lights and eight-sided wheels. Bodies: hatchback, sedan, wagon, delivery van, pickup and the town bus.
# One mesh per (body, paint), cached by the callers; cheap enough for the phone (≈200–400 triangles a car).
# The model's forward is +x, width along z, ground at y=0 (as actor-models.json). parked=true turns it to forward −z
# (the MultiMesh basis of the parked cars) and keeps white paint for the per-instance tint.
const Geometry = preload("res://scripts/city_geometry.gd")
const BODIES := ["hatch","sedan","wagon","van","pickup"]
const DARK := Color("23272a")
const TRIM := Color("3a4045")
const GLASS := Color("2d4652")
const LIGHT := Color("fff1c4")
const TAIL := Color("b5302c")
var geo = Geometry.new()
var turn := false
func p3(x: float,y: float,z: float) -> Vector3:
	return Vector3(z,y,-x) if turn else Vector3(x,y,z)
# a side profile (x,y) extruded from z0 to z1
func extrude(st: SurfaceTool,profile: Array,z0: float,z1: float,color: Color,side_color: Color = Color(0,0,0,0)) -> void:
	var poly := PackedVector2Array()
	for p in profile:
		poly.append(p)
	var area := 0.0
	for i in range(poly.size()):
		area += poly[i].cross(poly[(i+1)%poly.size()])
	if area<0.0:
		poly.reverse()
	var tris := Geometry2D.triangulate_polygon(poly)
	var sc: Color = side_color if side_color.a>0.0 else color
	for zz in [z0,z1]:
		var n := p3(0,0,signf(zz-(z0+z1)/2.0))-p3(0,0,0)
		for i in range(0,tris.size(),3):
			var a: Vector2 = poly[tris[i]]
			var b: Vector2 = poly[tris[i+1]]
			var c: Vector2 = poly[tris[i+2]]
			geo.triangle(st,p3(a.x,a.y,zz),p3(b.x,b.y,zz),p3(c.x,c.y,zz),sc,n)
	for i in range(poly.size()):
		var a: Vector2 = poly[i]
		var b: Vector2 = poly[(i+1)%poly.size()]
		var e := b-a
		var n2 := Vector2(e.y,-e.x).normalized()
		var n := p3(n2.x,n2.y,0)-p3(0,0,0)
		geo.quad(st,p3(a.x,a.y,z0),p3(b.x,b.y,z0),p3(b.x,b.y,z1),p3(a.x,a.y,z1),color,n)
func box(st: SurfaceTool,x0: float,x1: float,y0: float,y1: float,z0: float,z1: float,color: Color) -> void:
	extrude(st,[Vector2(x0,y0),Vector2(x1,y0),Vector2(x1,y1),Vector2(x0,y1)],z0,z1,color)
func wheel(st: SurfaceTool,x: float,z: float,r: float,w: float) -> void:
	var ring: Array = []
	for k in range(8):
		var a := TAU*(k+0.5)/8.0
		ring.append(Vector2(x+cos(a)*r,r+sin(a)*r))
	var zs := [z-w/2.0,z+w/2.0]
	extrude(st,ring,zs[0],zs[1],DARK)
	# the hub on the outer face
	var hub: Array = []
	for k in range(6):
		var a := TAU*k/6.0
		hub.append(Vector2(x+cos(a)*r*0.5,r+sin(a)*r*0.5))
	var outer: float = zs[1]+0.01 if z>0 else zs[0]-0.03
	extrude(st,hub,outer,outer+0.02,Color("9aa2a7"))
# Body proportions: length, width, sill, belt, roof height, hood/screen/roof/rear-window points, wheel radius
func spec(body: String) -> Dictionary:
	match body:
		"hatch":
			return {"l":3.95,"w":1.74,"belt":0.88,"h":1.48,"cab":[1.0,0.25,-1.35,-1.85],"r":0.31,"nose":0.62,"tail":0.95}
		"wagon":
			return {"l":4.7,"w":1.82,"belt":0.9,"h":1.5,"cab":[1.05,0.3,-2.0,-2.25],"r":0.33,"nose":0.62,"tail":0.92}
		"van":
			return {"l":4.95,"w":1.96,"belt":1.05,"h":2.15,"cab":[1.85,1.35,-2.4,-2.45],"r":0.35,"nose":0.8,"tail":1.0}
		"pickup":
			return {"l":5.0,"w":1.88,"belt":1.0,"h":1.82,"cab":[1.15,0.5,-0.55,-0.7],"r":0.37,"nose":0.85,"tail":1.0}
		_:
			return {"l":4.55,"w":1.8,"belt":0.86,"h":1.44,"cab":[0.95,0.2,-0.95,-1.45],"r":0.32,"nose":0.6,"tail":0.84}
func build(body: String,paint: Color,parked: bool = false) -> ArrayMesh:
	turn = parked
	var st := SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)
	geo.floor_height = 0.0
	if body=="bus":
		bus(st,paint)
	else:
		car(st,body,paint)
	st.index()
	geo.surface = 0.0
	return st.commit()
func car(st: SurfaceTool,body: String,paint: Color) -> void:
	var s := spec(body)
	var l: float = s.l
	var w: float = s.w
	var hl := l/2.0
	var hw := w/2.0
	var sill := 0.3
	var belt: float = s.belt
	var cab: Array = s.cab
	geo.surface = 6.0
	# the lower body: a sloped nose, a slightly higher tail, rounded corners in profile
	var lower := [Vector2(-hl+0.05,sill),Vector2(hl-0.05,sill),Vector2(hl,s.nose-0.12),Vector2(hl-0.12,s.nose),Vector2(cab[0],belt),Vector2(cab[3],belt+0.02),Vector2(-hl+0.1,s.tail),Vector2(-hl,s.tail-0.15)]
	if body=="pickup":
		# the bed: the body behind the cab stays at belt height, open on top (dark floor)
		lower = [Vector2(-hl+0.05,sill),Vector2(hl-0.05,sill),Vector2(hl,s.nose-0.12),Vector2(hl-0.12,s.nose),Vector2(cab[0],belt),Vector2(cab[3],belt),Vector2(-hl,belt),Vector2(-hl,sill+0.2)]
	extrude(st,lower,-hw,hw,paint)
	# the greenhouse: glass, under a painted roof
	geo.surface = 7.0
	var top: float = s.h
	var inset := 0.1
	extrude(st,[Vector2(cab[0],belt),Vector2(cab[1],top-0.05),Vector2(cab[2],top-0.05),Vector2(cab[3],belt)],-hw+inset,hw-inset,GLASS)
	geo.surface = 6.0
	extrude(st,[Vector2(cab[1]-0.04,top-0.06),Vector2(cab[2]+0.02,top-0.06),Vector2(cab[2]+0.06,top),Vector2(cab[1]-0.1,top)],-hw+inset-0.02,hw-inset+0.02,paint)
	# pillars between the side windows
	var mid: float = (cab[1]+cab[2])/2.0
	for z in [-hw+inset-0.015,hw-inset+0.005]:
		box(st,mid-0.05,mid+0.05,belt,top-0.06,z,z+0.01,paint)
	if body=="van":
		# a delivery van: blind side panels behind the doors
		box(st,cab[2]+0.05,cab[1]-0.75,belt+0.02,top-0.08,-hw+inset-0.02,hw-inset+0.02,paint)
	if body=="pickup":
		box(st,cab[3]-0.02,-hl+0.06,belt-0.06,belt-0.04,-hw+0.08,hw-0.08,TRIM)
	# bumpers, grille, lights, plates
	box(st,hl-0.06,hl+0.04,sill-0.02,sill+0.2,-hw+0.04,hw-0.04,TRIM)
	box(st,-hl-0.04,-hl+0.06,sill-0.02,sill+0.2,-hw+0.04,hw-0.04,TRIM)
	box(st,hl-0.02,hl+0.02,s.nose-0.24,s.nose-0.1,-hw*0.45,hw*0.45,TRIM)
	for side in [-1.0,1.0]:
		box(st,hl-0.06,hl+0.02,s.nose-0.2,s.nose-0.06,side*hw*0.62-0.18,side*hw*0.62+0.18,LIGHT)
		box(st,-hl-0.02,-hl+0.07,s.tail-0.3,s.tail-0.14,side*hw*0.7-0.16,side*hw*0.7+0.16,TAIL)
		# mirrors
		box(st,cab[0]-0.15,cab[0]-0.02,belt+0.05,belt+0.17,side*(hw+0.02)-0.06,side*(hw+0.02)+0.06,TRIM)
	box(st,hl+0.02,hl+0.05,sill+0.05,sill+0.17,-0.24,0.24,Color("eceee6"))
	# wheels in arches
	var wb := l*0.31
	for x in [wb,-wb]:
		for z in [-hw+0.12,hw-0.12]:
			wheel(st,x,z,s.r,0.24)
func bus(st: SurfaceTool,paint: Color) -> void:
	var l := 11.2
	var hl := l/2.0
	var hw := 1.26
	geo.surface = 6.0
	# a rounded box: sloped front, the roof a little lower at the ends
	extrude(st,[Vector2(-hl,0.42),Vector2(hl,0.42),Vector2(hl+0.05,1.1),Vector2(hl-0.05,2.85),Vector2(hl-0.35,3.05),Vector2(-hl+0.3,3.05),Vector2(-hl,2.85)],-hw,hw,paint)
	geo.surface = 7.0
	# a continuous window band, the windscreen and the rear window
	for z in [-hw-0.01,hw-0.01]:
		box(st,-hl+0.4,hl-0.6,1.35,2.55,z,z+0.02,GLASS)
	box(st,hl-0.02,hl+0.06,1.2,2.75,-hw+0.12,hw-0.12,GLASS)
	box(st,-hl-0.04,-hl+0.02,1.7,2.6,-hw+0.25,hw-0.25,GLASS)
	geo.surface = 6.0
	# a colour stripe under the windows, doors on the kerb side, the destination board
	for z in [-hw-0.015,hw-0.005]:
		box(st,-hl+0.1,hl-0.1,0.95,1.2,z,z+0.02,Color("1f7f86"))
	for x in [hl-1.3,-0.4]:
		box(st,x-0.6,x+0.6,0.45,2.6,hw,hw+0.025,Color("344c52"))
	box(st,hl+0.05,hl+0.08,2.62,2.88,-0.7,0.7,Color("f2b13a"))
	box(st,hl-0.02,hl+0.08,0.38,0.62,-hw+0.05,hw-0.05,TRIM)
	for side in [-1.0,1.0]:
		box(st,hl+0.02,hl+0.08,0.75,0.95,side*0.95-0.18,side*0.95+0.18,LIGHT)
		box(st,-hl-0.04,-hl+0.02,0.75,1.0,side*1.0-0.12,side*1.0+0.12,TAIL)
	box(st,-2.0,1.2,3.05,3.3,-0.7,0.7,TRIM)
	for x in [3.6,-3.4]:
		for z in [-hw+0.15,hw-0.15]:
			wheel(st,x,z,0.5,0.3)
