extends MultiMeshInstance3D
const CAPACITY := 128
var clock := 0.0
var active := false
func _ready() -> void:
 multimesh = MultiMesh.new()
 multimesh.transform_format = MultiMesh.TRANSFORM_3D
 multimesh.use_colors = true
 var spark := BoxMesh.new()
 spark.size = Vector3.ONE*0.9
 multimesh.mesh = spark
 multimesh.instance_count = CAPACITY
 multimesh.visible_instance_count = 0
 var material := StandardMaterial3D.new()
 material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
 material.vertex_color_use_as_albedo = true
 material_override = material
 cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
func configure(enabled: bool,calm: bool) -> void:
 active = enabled and not calm
 multimesh.visible_instance_count = CAPACITY if active else 0
func animate(delta: float) -> void:
 if not active:
  return
 clock += minf(delta,0.1)
 for index in range(CAPACITY):
  var burst := index/32
  var part := index%32
  var phase := fposmod(clock+float(burst)*0.93,4.5)
  var angle := float(part)*TAU/32
  var level := 0.5+0.5*sin(float(part)*2.399)
  var radius := minf(phase,2.5)*24*level
  var centre := Vector3(float(burst%2)*180-90,95+float(burst)*13,float(burst/2)*180-90)
  var point := centre+Vector3(cos(angle)*radius,sin(angle)*radius-phase*phase*4,sin(float(part)*1.7)*radius*0.45)
  var scale := clampf(3.5-phase,0,1)
  multimesh.set_instance_transform(index,Transform3D(Basis().scaled(Vector3.ONE*scale),point))
  multimesh.set_instance_color(index,Color.from_hsv(fposmod(float(burst)*0.27+floor(clock/4.5)*0.13,1),0.6,1))
