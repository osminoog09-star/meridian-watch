extends SceneTree
# Claude 16.10 (Release O) audit tool: the start screen with the hero and the character creator.
# Usage: xvfb-run Godot --path . --rendering-driver opengl3 --resolution 369x905 --script scripts/render_hero.gd -- --native-ui --out DIR
var out := ""
func wait(n: int) -> void:
 for i in range(n):
  await process_frame
func shot(name: String) -> void:
 await RenderingServer.frame_post_draw
 root.get_texture().get_image().save_png(out+"/"+name+".png")
func _initialize() -> void:
 var args := OS.get_cmdline_user_args()
 out = args[args.find("--out")+1]
 call_deferred("run")
func run() -> void:
 var scene = load("res://main.tscn").instantiate()
 root.add_child(scene)
 await wait(8)
 scene.campaign.initialize({})
 scene.campaign.store.path = "user://render-hero.json"
 scene.native_ui.signature = ""
 scene.native_ui.refresh()
 await wait(20)
 await shot("start")
 scene.campaign.action({"op":"event","domId":"editHero","event":"click"})
 scene.native_ui.signature = ""
 scene.native_ui.refresh()
 await wait(20)
 await shot("creator")
 quit(0)
