extends SceneTree
# Claude 16.10: a finger that lands on a button or card inside a long window must still scroll it (owner: «трудно
# пролистать вниз» on the phone); a short tap on a button must still press it.
var failed := false
func _initialize() -> void:
 call_deferred("verify")
func check(value: bool,message: String) -> void:
 if not value:
  failed = true
  push_error(message)
func frames(n: int) -> void:
 for i in range(n):
  await process_frame
func button_in(node: Node,scroll: Control) -> Control:
 for child in node.get_children():
  if child is Button and child.is_visible_in_tree():
   var r: Rect2 = child.get_global_rect()
   if scroll.get_global_rect().encloses(r) and r.size.y>30:
    return child
  var found = button_in(child,scroll)
  if found!=null:
   return found
 return null
func drag(from: Vector2,to: Vector2,steps: int) -> void:
 var touch := InputEventScreenTouch.new()
 touch.index = 0
 touch.position = from
 touch.pressed = true
 Input.parse_input_event(touch)
 await frames(2)
 for k in range(1,steps+1):
  var motion := InputEventScreenDrag.new()
  motion.index = 0
  motion.position = from.lerp(to,float(k)/steps)
  motion.relative = (to-from)/steps
  motion.velocity = (to-from)/steps*60
  Input.parse_input_event(motion)
  await frames(1)
 touch = touch.duplicate()
 touch.position = to
 touch.pressed = false
 Input.parse_input_event(touch)
 await frames(20)
func verify() -> void:
 root.size = Vector2i(369,905)
 var scene = load("res://main.tscn").instantiate()
 root.add_child(scene)
 await frames(8)
 var ui = scene.native_ui
 var campaign = scene.campaign
 campaign.initialize({})
 campaign.store.path = "user://touch-scroll-verification.json"
 campaign.action({"op":"event","domId":"startCareer","event":"click"})
 campaign.action({"op":"event","domId":"closeModal","event":"click"})
 campaign.action({"op":"event","domId":"settingsBtn","event":"click"})
 ui.signature = ""
 ui.refresh()
 await frames(10)
 var scroll = ui.scroll
 check(scroll.get_v_scroll_bar().max_value>scroll.size.y+200,"settings must overflow")
 var button = button_in(ui.root,scroll)
 check(button!=null,"a button inside the window")
 if button!=null:
  var start: Vector2 = button.get_global_rect().get_center()
  var before: int = scroll.scroll_vertical
  var clicks := [0]
  button.pressed.connect(func(): clicks[0] += 1)
  await drag(start,start-Vector2(0,320),12)
  check(clicks[0]==0,"the button under the finger was pressed after scrolling")
  print("drag from a button: ",before," -> ",scroll.scroll_vertical)
  check(scroll.scroll_vertical>before+150,"a drag starting on a button does not scroll the window")
 # A drag over plain text scrolls too.
 var before2: int = scroll.scroll_vertical
 var text_point: Vector2 = scroll.get_global_rect().position+Vector2(20,scroll.size.y*0.75)
 await drag(text_point,text_point-Vector2(0,200),10)
 print("drag from text: ",before2," -> ",scroll.scroll_vertical)
 # A short tap on a button still presses it.
 await frames(30)
 var tap_button = button_in(ui.root,scroll)
 var taps := [0]
 if tap_button!=null:
  tap_button.pressed.connect(func(): taps[0] += 1)
  var at: Vector2 = tap_button.get_global_rect().get_center()
  await drag(at,at+Vector2(0,3),2)
 print("tap presses: ",taps[0])
 check(taps[0]==1,"a short tap does not press the button")
 print("Touch scroll ","FAILED" if failed else "PASSED")
 quit(1 if failed else 0)
