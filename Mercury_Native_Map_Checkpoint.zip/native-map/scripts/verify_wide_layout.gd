extends SceneTree
# Claude 16.10: on a wide screen (Fold6 inner, 794×926) the native UI uses the web's two columns — the crews/calls
# column stays visible on the map tab, the transport bar sits right of it and the camera centres the free map area;
# on a narrow phone (369×905) the phone layout with tabs is unchanged.
func _initialize() -> void:
 call_deferred("verify")
func verify() -> void:
 var failed := false
 for spec in [[Vector2i(794,926),true],[Vector2i(369,905),false]]:
  root.size = spec[0]
  var scene = load("res://main.tscn").instantiate()
  root.add_child(scene)
  for i in range(6):
   await process_frame
  scene.campaign.initialize({})
  scene.campaign.store.path = "user://wide-layout-test.json"
  scene.campaign.action({"op":"event","domId":"startCareer","event":"click"})
  scene.campaign.action({"op":"event","domId":"closeModal","event":"click"})
  for i in range(12):
   await process_frame
  var ui = scene.native_ui
  var side: float = ui.wide_left()
  var transport := ui.get_node_or_null("ShiftTransport") as Control
  var tab: String = scene.campaign.snapshot.get("status",{}).get("tab","map")
  if spec[1]:
   # Claude 17.10 (Release V2): on a wide screen the map is the whole screen; «Патруль» opens as a side panel.
   if side!=0 or ui.scroll.visible:
    push_error("wide map: the map is the screen (side=%s scroll=%s)" % [side,ui.scroll.visible])
    failed = true
   scene.campaign.action({"op":"event","target":{"tag":"button","scope":"","data":{"data-tab-button":"units"}},"event":"click"})
   ui.signature = ""
   ui.refresh()
   for i in range(8):
    await process_frame
   side = ui.wide_left()
   transport = ui.get_node_or_null("ShiftTransport") as Control
   if side<=0 or not ui.scroll.visible or transport==null or transport.position.x<side:
    push_error("wide patrol: a side panel expected (side=%s scroll=%s)" % [side,ui.scroll.visible])
    failed = true
  else:
   if side!=0 or (tab=="map" and ui.scroll.visible) or absf(scene.camera.h_offset)>0.001:
    push_error("narrow: phone layout expected (side=%s scroll=%s tab=%s)" % [side,ui.scroll.visible,tab])
    failed = true
  scene.queue_free()
  await process_frame
 print("Wide layout: map screen and a side panel at 794×926, phone tabs at 369×905 ","FAILED" if failed else "PASSED")
 quit(1 if failed else 0)
