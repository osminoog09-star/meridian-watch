extends RefCounted
# Godot front faces are clockwise; explicit normals keep facades flat.
var triangles := 0
var roofs := 0
var failed_roofs: Array = []
var roof_area := 0.0
var expected_area := 0.0
func triangle(st: SurfaceTool,a: Vector3,b: Vector3,c: Vector3,color: Color,normal: Vector3) -> void:
 if (b-a).cross(c-a).dot(normal) > 0:
  var swap := b
  b = c
  c = swap
 st.set_color(color)
 st.set_normal(normal)
 for p in [a,b,c]:
  st.add_vertex(p)
 triangles += 1
func quad(st: SurfaceTool,a: Vector3,b: Vector3,c: Vector3,d: Vector3,color: Color,normal: Vector3) -> void:
 triangle(st,a,b,c,color,normal)
 triangle(st,a,c,d,color,normal)
func polygon_area(ring: PackedVector2Array) -> float:
 var area := 0.0
 for i in range(ring.size()):
  area += ring[i].cross(ring[(i+1)%ring.size()])
 return absf(area)/2.0
func building(st: SurfaceTool, b: Dictionary,lod: int = 0) -> void:
 var ring := PackedVector2Array()
 for p in b.ring:
  ring.append(Vector2(p[0],p[1]))
 if Geometry2D.is_polygon_clockwise(ring):
  ring.reverse()
 var height := float(b.height)
 var wall := Color(b.style.wall)
 for i in range(ring.size()):
  var a := ring[i]
  var d := ring[(i+1)%ring.size()]
  var edge := d-a
  var length := edge.length()
  if length < 0.05:
   continue
  var normal := Vector3(edge.y,0,-edge.x).normalized()
  var base_a := Vector3(a.x,0,a.y)
  var base_d := Vector3(d.x,0,d.y)
  quad(st,base_a,base_d,base_d+Vector3.UP*height,base_a+Vector3.UP*height,wall,normal)
  quad(st,base_a+normal*0.008,base_d+normal*0.008,base_d+normal*0.008+Vector3.UP*0.4,base_a+normal*0.008+Vector3.UP*0.4,Color(b.style.plinth),normal)
  var tangent := (base_d-base_a).normalized()
  var count := mini(12,int(length/3.0))
  for floor_index in range(int(b.floors) if lod==0 else 0):
   var y := 1.0 + floor_index*3.0
   if y+1.1 > height:
    continue
   for window in range(count):
    var centre := base_a+tangent*((window+0.5)*length/count)+normal*0.025+Vector3.UP*y
    var half := tangent*0.5
    quad(st,centre-half,centre+half,centre+half+Vector3.UP*1.1,centre-half+Vector3.UP*1.1,Color(b.style.glass),normal)
 var indices := Geometry2D.triangulate_polygon(ring)
 expected_area += polygon_area(ring)
 if indices.is_empty():
  failed_roofs.append(b.id)
  return
 var projected_area := 0.0
 for i in range(0,indices.size(),3):
  var a := ring[indices[i]]
  var c := ring[indices[i+1]]
  var d := ring[indices[i+2]]
  projected_area += absf((c-a).cross(d-a))/2
 roof_area += projected_area
 roofs += 1
 if b.pitched and ring.size()==4:
  # Ridge follows the long axis of the rectangular source footprint.
  var edge0 := ring[0].distance_to(ring[1])
  var edge1 := ring[1].distance_to(ring[2])
  var offset := 0 if edge0 < edge1 else 1
  var a := ring[offset]
  var c := ring[(offset+1)%4]
  var d := ring[(offset+2)%4]
  var e := ring[(offset+3)%4]
  var aa := Vector3(a.x,height,a.y)
  var cc := Vector3(c.x,height,c.y)
  var dd := Vector3(d.x,height,d.y)
  var ee := Vector3(e.x,height,e.y)
  var r1 := (aa+cc)/2+Vector3.UP*float(b.roofPitch)
  var r2 := (dd+ee)/2+Vector3.UP*float(b.roofPitch)
  var n1 := (r1-aa).cross(ee-aa).normalized()
  if n1.y < 0:
   n1 = -n1
  var n2 := (dd-cc).cross(r1-cc).normalized()
  if n2.y < 0:
   n2 = -n2
  quad(st,aa,r1,r2,ee,Color(b.style.roof[0]),n1)
  quad(st,cc,dd,r2,r1,Color(b.style.roof[1]),n2)
  triangle(st,aa,cc,r1,wall,Vector3(c.y-a.y,0,a.x-c.x).normalized())
  triangle(st,dd,ee,r2,wall,Vector3(e.y-d.y,0,d.x-e.x).normalized())
 else:
  for i in range(0,indices.size(),3):
   var a := ring[indices[i]]
   var c := ring[indices[i+1]]
   var d := ring[indices[i+2]]
   triangle(st,Vector3(a.x,height,a.y),Vector3(c.x,height,c.y),Vector3(d.x,height,d.y),Color(b.style.roof[0]),Vector3.UP)
func road(st: SurfaceTool,r: Dictionary) -> void:
 for profile in preload("res://scripts/road_elevation.gd").road_profile(r):
  road_piece(st,r,profile)
func road_piece(st: SurfaceTool,r: Dictionary,profile: Dictionary) -> void:
 var a := Vector3(profile.a[0],float(profile.ha)+0.02,profile.a[1])
 var b := Vector3(profile.b[0],float(profile.hb)+0.02,profile.b[1])
 var direction := Vector3(b.x-a.x,0,b.z-a.z).normalized()
 var side := direction.cross(Vector3.UP)
 var normal := side.cross(b-a).normalized()
 var width := float(r.width)/2.0
 var edge_width := float(r.edgeWidth)/2.0
 if r.drive or r.bridge:
  var edge := side*edge_width
  quad(st,a-edge,b-edge,b+edge,a+edge,Color(r.edge),normal)
 if r.drive and not r.bridge:
  # Raised curb and sidewalk bands. Tags no/separate never duplicate an existing footway.
  var sidewalk: Dictionary = r.get("sidewalk",{})
  for side_sign in [-1.0,1.0]:
   var inner: Vector3 = side*(width*side_sign)
   var outer: Vector3 = side*(edge_width*side_sign)
   var lift := Vector3.UP*0.12
   quad(st,a+inner,b+inner,b+outer+lift,a+outer+lift,Color(r.edge),normal)
   var enabled: bool = bool(sidewalk.get("left" if side_sign<0 else "right",false))
   if enabled:
    var beyond: Vector3 = side*((edge_width+float(sidewalk.width))*side_sign)
    quad(st,a+outer+lift,b+outer+lift,b+beyond+lift,a+beyond+lift,Color("aaa897"),normal)
 var span := side*width
 a.y += 0.08
 b.y += 0.08
 quad(st,a-span,b-span,b+span,a+span,Color(r.color),normal)
func chunk(data: Dictionary,mat: Material,lod: int = 0) -> MeshInstance3D:
 var st := SurfaceTool.new()
 st.begin(Mesh.PRIMITIVE_TRIANGLES)
 for r in data.roads:
  road(st,r)
 for b in data.buildings:
  building(st,b,lod)
 st.index()
 var instance := MeshInstance3D.new()
 instance.name = "Tile_"+str(data.key).replace(",","_")
 instance.mesh = st.commit()
 instance.material_override = mat
 return instance
