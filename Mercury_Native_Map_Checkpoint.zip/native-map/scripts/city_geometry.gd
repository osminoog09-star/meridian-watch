extends RefCounted
# Godot front faces are clockwise; explicit normals keep facades flat.
var triangles := 0
var roofs := 0
var failed_roofs: Array = []
var roof_area := 0.0
var expected_area := 0.0
# Claude 17.10 (Release G1): UV.x carries the floor height of a wall (the shader draws the windows), 0 elsewhere.
var floor_height := 0.0
# Claude 17.10 (Release G3): UV.y tells the shader the surface — 1 asphalt, 2 sidewalk and curb, 3 road paint.
var surface := 0.0
func triangle(st: SurfaceTool,a: Vector3,b: Vector3,c: Vector3,color: Color,normal: Vector3) -> void:
 if (b-a).cross(c-a).dot(normal) > 0:
  var swap := b
  b = c
  c = swap
 st.set_color(color)
 st.set_normal(normal)
 st.set_uv(Vector2(floor_height if absf(normal.y)<0.3 else 0.0,surface))
 for p in [a,b,c]:
  st.add_vertex(p)
 triangles += 1
func quad(st: SurfaceTool,a: Vector3,b: Vector3,c: Vector3,d: Vector3,color: Color,normal: Vector3) -> void:
 triangle(st,a,b,c,color,normal)
 triangle(st,a,c,d,color,normal)
func polygon_area(ring: PackedVector2Array) -> float:
 var area := 0.0
 for i in range(ring.size()):
  area += ring[i].cross(ring[(i+1)%ring.size()])
 return absf(area)/2.0
func building(st: SurfaceTool, b: Dictionary,lod: int = 0) -> void:
 var ring := PackedVector2Array()
 for p in b.ring:
  ring.append(Vector2(p[0],p[1]))
 if Geometry2D.is_polygon_clockwise(ring):
  ring.reverse()
 surface = 0.0
 var height := float(b.height)
 # Claude 17.10 (Release G1): a wider, Baltic palette — plaster in cream, ochre, pale green, blue and grey, some brick
 # and painted wood; roofs of dark tin, red-brown tiles, grey bitumen.
 var h := absi(hash(str(b.id)))
 var family := str(b.style.get("family",""))
 var walls := ["e6dcc4","e2cf9b","d9c38a","cfd8c4","c4d3dc","d7d7d0","efece4","d9b9a0","c99a7c","b9c4a8","a4664f","8e5a44"]
 var wall := Color(walls[h%walls.size()])
 if family=="house" or float(b.height)<8.0:
  var wood := ["b8a27f","8c6d4f","c9b48e","a7b7a3","b9483d","d9d2c0","7f8f9a"]
  wall = Color(wood[h%wood.size()])
 var roofs_pitched := ["7b4a3a","8e5440","a0604a","4b5257","9a5a45","59675e","b06a4c","5d4a42"]
 var roof_color := Color(roofs_pitched[(h/13)%roofs_pitched.size()]) if b.pitched else Color(["4a4f52","55595b","5f5a55","43494d","6a5a4f"][(h/13)%5])
 floor_height = clampf(height/maxf(1.0,float(b.floors)),2.8,4.2)
 for i in range(ring.size()):
  var a := ring[i]
  var d := ring[(i+1)%ring.size()]
  var edge := d-a
  var length := edge.length()
  if length < 0.05:
   continue
  var normal := Vector3(edge.y,0,-edge.x).normalized()
  var base_a := Vector3(a.x,0,a.y)
  var base_d := Vector3(d.x,0,d.y)
  quad(st,base_a,base_d,base_d+Vector3.UP*height,base_a+Vector3.UP*height,wall,normal)
  quad(st,base_a+normal*0.008,base_d+normal*0.008,base_d+normal*0.008+Vector3.UP*0.4,base_a+normal*0.008+Vector3.UP*0.4,wall.darkened(0.35),normal)
  # a cornice: a thin darker band at the top of the wall
  quad(st,base_a+normal*0.03+Vector3.UP*(height-0.35),base_d+normal*0.03+Vector3.UP*(height-0.35),base_d+normal*0.03+Vector3.UP*height,base_a+normal*0.03+Vector3.UP*height,wall.darkened(0.18),normal)
 var indices := Geometry2D.triangulate_polygon(ring)
 expected_area += polygon_area(ring)
 if indices.is_empty():
  failed_roofs.append(b.id)
  return
 var projected_area := 0.0
 for i in range(0,indices.size(),3):
  var a := ring[indices[i]]
  var c := ring[indices[i+1]]
  var d := ring[indices[i+2]]
  projected_area += absf((c-a).cross(d-a))/2
 roof_area += projected_area
 roofs += 1
 # Claude 17.10 (Release G2): most houses of a Baltic town have pitched roofs — gables on rectangles, hip roofs on
 # other compact footprints; big flat roofs get a parapet and some rooftop plant. Old data pitched only rectangles
 # and only 0.6 m high, so the town looked like boxes.
 var area := polygon_area(ring)
 var pitched: bool = bool(b.pitched) or (float(b.floors)<=3.0 and area<500.0)
 if not b.pitched and pitched:
  roof_color = Color(roofs_pitched[(h/13)%roofs_pitched.size()])
 var centroid := Vector2.ZERO
 for p in ring:
  centroid += p
 centroid /= maxf(1.0,ring.size())
 var star := ring.size()<=16
 if star:
  var sign := 0.0
  for i in range(ring.size()):
   var cr := (ring[(i+1)%ring.size()]-ring[i]).cross(centroid-ring[i])
   if absf(cr)<0.01:
    continue
   if sign==0.0:
    sign = signf(cr)
   elif signf(cr)!=sign:
    star = false
    break
 if pitched and ring.size()==4:
  # Ridge follows the long axis of the rectangular source footprint.
  var edge0 := ring[0].distance_to(ring[1])
  var edge1 := ring[1].distance_to(ring[2])
  var offset := 0 if edge0 < edge1 else 1
  var pitch := clampf(minf(edge0,edge1)*0.38,1.6,5.0)
  var a := ring[offset]
  var c := ring[(offset+1)%4]
  var d := ring[(offset+2)%4]
  var e := ring[(offset+3)%4]
  var aa := Vector3(a.x,height,a.y)
  var cc := Vector3(c.x,height,c.y)
  var dd := Vector3(d.x,height,d.y)
  var ee := Vector3(e.x,height,e.y)
  var r1 := (aa+cc)/2+Vector3.UP*pitch
  var r2 := (dd+ee)/2+Vector3.UP*pitch
  var n1 := (r1-aa).cross(ee-aa).normalized()
  if n1.y < 0:
   n1 = -n1
  var n2 := (dd-cc).cross(r1-cc).normalized()
  if n2.y < 0:
   n2 = -n2
  quad(st,aa,r1,r2,ee,roof_color,n1)
  quad(st,cc,dd,r2,r1,roof_color.lightened(0.08),n2)
  triangle(st,aa,cc,r1,wall,Vector3(c.y-a.y,0,a.x-c.x).normalized())
  triangle(st,dd,ee,r2,wall,Vector3(e.y-d.y,0,d.x-e.x).normalized())
 elif pitched and star:
  var apex := Vector3(centroid.x,height+clampf(sqrt(area)*0.3,1.5,5.0),centroid.y)
  for i in range(ring.size()):
   var a := ring[i]
   var c := ring[(i+1)%ring.size()]
   var aa := Vector3(a.x,height,a.y)
   var cc := Vector3(c.x,height,c.y)
   var n := (cc-aa).cross(apex-aa).normalized()
   if n.y<0:
    n = -n
   triangle(st,aa,cc,apex,roof_color.lightened(0.06*float(i%2)),n)
 else:
  var top := height-0.45
  for i in range(0,indices.size(),3):
   var a := ring[indices[i]]
   var c := ring[indices[i+1]]
   var d := ring[indices[i+2]]
   triangle(st,Vector3(a.x,top,a.y),Vector3(c.x,top,c.y),Vector3(d.x,top,d.y),roof_color,Vector3.UP)
  # inner side of the parapet
  for i in range(ring.size()):
   var a := ring[i]
   var c := ring[(i+1)%ring.size()]
   var n := Vector3(-(c.y-a.y),0,c.x-a.x).normalized()
   quad(st,Vector3(a.x,top,a.y),Vector3(c.x,top,c.y),Vector3(c.x,height,c.y),Vector3(a.x,height,a.y),wall.darkened(0.25),n)
  if area>180.0:
   # rooftop plant: a stair hut and a vent box
   var s := clampf(sqrt(area)*0.12,1.5,4.0)
   var base := Vector3(centroid.x,top,centroid.y)
   box(st,base,Vector3(s,2.2,s*0.8),wall.darkened(0.2))
   box(st,base+Vector3(s*1.6,0,s*0.4),Vector3(s*0.5,1.0,s*0.5),Color("8a8f92"))
func box(st: SurfaceTool,base: Vector3,size: Vector3,color: Color) -> void:
 var x := size.x/2
 var z := size.z/2
 var y := size.y
 var p := [base+Vector3(-x,0,-z),base+Vector3(x,0,-z),base+Vector3(x,0,z),base+Vector3(-x,0,z)]
 var fh := floor_height
 floor_height = 0.0
 for i in range(4):
  var a: Vector3 = p[i]
  var c: Vector3 = p[(i+1)%4]
  var n := (c-a).cross(Vector3.UP).normalized()
  quad(st,a,c,c+Vector3.UP*y,a+Vector3.UP*y,color,n)
 quad(st,p[0]+Vector3.UP*y,p[1]+Vector3.UP*y,p[2]+Vector3.UP*y,p[3]+Vector3.UP*y,color.darkened(0.1),Vector3.UP)
 floor_height = fh
func road(st: SurfaceTool,r: Dictionary) -> void:
 floor_height = 0.0
 var profiles: Array = preload("res://scripts/road_elevation.gd").road_profile(r)
 for profile in profiles:
  road_piece(st,r,profile)
 # Claude 17.10 (Release G2): round joints at both ends — streets used to break into separate strips at every node.
 if r.drive and not r.bridge and not profiles.is_empty():
  for end in [[profiles[0].a,float(profiles[0].ha)],[profiles[-1].b,float(profiles[-1].hb)]]:
   var c := Vector3(end[0][0],end[1],end[0][1])
   surface = 2.0
   disc(st,c+Vector3.UP*0.07,float(r.edgeWidth)/2.0,Color(r.edge))
   surface = 1.0
   disc(st,c+Vector3.UP*0.105,float(r.width)/2.0,Color(r.color))
   surface = 0.0
func disc(st: SurfaceTool,c: Vector3,radius: float,color: Color) -> void:
 var n := 10
 for i in range(n):
  var a := TAU*i/n
  var b := TAU*(i+1)/n
  triangle(st,c,c+Vector3(cos(a),0,sin(a))*radius,c+Vector3(cos(b),0,sin(b))*radius,color,Vector3.UP)
var junctions := {}
func node_key(p: Array) -> String:
 return str(snappedf(float(p[0]),0.5))+","+str(snappedf(float(p[1]),0.5))
func road_piece(st: SurfaceTool,r: Dictionary,profile: Dictionary) -> void:
 var a := Vector3(profile.a[0],float(profile.ha)+0.02,profile.a[1])
 var b := Vector3(profile.b[0],float(profile.hb)+0.02,profile.b[1])
 var direction := Vector3(b.x-a.x,0,b.z-a.z).normalized()
 var side := direction.cross(Vector3.UP)
 var normal := side.cross(b-a).normalized()
 var width := float(r.width)/2.0
 var edge_width := float(r.edgeWidth)/2.0
 if r.drive or r.bridge:
  var edge := side*edge_width
  surface = 2.0
  quad(st,a-edge,b-edge,b+edge,a+edge,Color(r.edge),normal)
 if r.drive and not r.bridge:
  # Raised curb and sidewalk bands. Tags no/separate never duplicate an existing footway.
  var sidewalk: Dictionary = r.get("sidewalk",{})
  for side_sign in [-1.0,1.0]:
   var inner: Vector3 = side*(width*side_sign)
   var outer: Vector3 = side*(edge_width*side_sign)
   var lift := Vector3.UP*0.12
   quad(st,a+inner,b+inner,b+outer+lift,a+outer+lift,Color(r.edge),normal)
   var enabled: bool = bool(sidewalk.get("left" if side_sign<0 else "right",false))
   if enabled:
    var beyond: Vector3 = side*((edge_width+float(sidewalk.width))*side_sign)
    quad(st,a+outer+lift,b+outer+lift,b+beyond+lift,a+beyond+lift,Color("aaa897"),normal)
 var span := side*width
 a.y += 0.08
 b.y += 0.08
 surface = 1.0 if r.drive else 2.0
 quad(st,a-span,b-span,b+span,a+span,Color(r.color),normal)
 surface = 3.0
 # solid edge lines on wider streets; zebra crossings next to junctions
 if r.drive and not r.bridge and float(r.width)>=6.0:
  for s in [-1.0,1.0]:
   var o: Vector3 = side*(width-0.35)*s+Vector3.UP*0.02
   quad(st,a+o-side*0.06,b+o-side*0.06,b+o+side*0.06,a+o+side*0.06,Color("cfccbf"),normal)
 if r.drive and not r.bridge and float(r.width)>=5.0:
  var seg_len := Vector3(b.x-a.x,0,b.z-a.z).length()
  for spec in [[profile.a,a,1.0],[profile.b,b,-1.0]]:
   if int(junctions.get(node_key(spec[0]),0))<3 or seg_len<14.0:
    continue
   var start: Vector3 = spec[1]+direction*float(spec[2])*(float(r.edgeWidth)/2.0+2.0)+Vector3.UP*0.02
   var stripe := -width+0.4
   while stripe<width-0.4:
    var c0: Vector3 = start+side*stripe
    quad(st,c0,c0+direction*float(spec[2])*3.0,c0+direction*float(spec[2])*3.0+side*0.5,c0+side*0.5,Color("e8e6dc"),normal)
    stripe += 1.0
 # Claude 17.10 (Release G1): a dashed centre line on two-way streets and trees along the sidewalks.
 if r.drive and not r.bridge and float(r.width)>=5.0:
  var length := Vector3(b.x-a.x,0,b.z-a.z).length()
  var dash := 3.0
  var step := 9.0
  var k := 1.5
  while k+dash<length:
   var p1 := a.lerp(b,k/length)+Vector3.UP*0.02
   var p2 := a.lerp(b,(k+dash)/length)+Vector3.UP*0.02
   quad(st,p1-side*0.08,p2-side*0.08,p2+side*0.08,p1+side*0.08,Color("d9d6c8"),normal)
   k += step
  # street trees stand inside building footprints where the sidewalk is only illustrative — off until real tree data
  if false and not r.bridge and bool(r.get("sidewalk",{}).get("right",false)) and length>14.0:
   var spacing := 14.0
   var j := 6.0
   while j<length-4.0:
    var at := a.lerp(b,j/length)+side*(edge_width+float(r.sidewalk.width)+0.9)
    street_trees.append(Vector3(at.x,-0.2,at.z))
    j += spacing
var street_trees: Array = []
static var tree_mesh: ArrayMesh
static var tree_material: StandardMaterial3D
func make_tree_mesh() -> void:
 var st := SurfaceTool.new()
 st.begin(Mesh.PRIMITIVE_TRIANGLES)
 for i in range(6):
  var a := TAU*i/6
  var b := TAU*(i+1)/6
  var n := Vector3(cos((a+b)/2),0,sin((a+b)/2))
  st.set_color(Color("6b4f3a")); st.set_normal(n)
  for p in [Vector3(cos(a)*0.2,0,sin(a)*0.2),Vector3(cos(b)*0.2,2.4,sin(b)*0.2),Vector3(cos(b)*0.2,0,sin(b)*0.2),Vector3(cos(a)*0.2,0,sin(a)*0.2),Vector3(cos(a)*0.2,2.4,sin(a)*0.2),Vector3(cos(b)*0.2,2.4,sin(b)*0.2)]:
   st.add_vertex(p)
 for i in range(8):
  var a := TAU*i/8
  var b := TAU*(i+1)/8
  var p1 := Vector3(cos(a)*2.2,4.0,sin(a)*2.2)
  var p2 := Vector3(cos(b)*2.2,4.0,sin(b)*2.2)
  for spec in [[Vector3(0,7.0,0),1.0],[Vector3(0,2.2,0),-1.0]]:
   var tip: Vector3 = spec[0]
   var n := (p2-p1).cross(tip-p1).normalized()*float(spec[1])
   if n.y*float(spec[1])<0:
    n = -n
   st.set_color(Color("5b8a45").lightened(0.06*(i%2))); st.set_normal(n)
   for p in ([p1,tip,p2] if spec[1]>0 else [p1,p2,tip]):
    st.add_vertex(p)
 tree_mesh = st.commit()
 tree_material = StandardMaterial3D.new()
 tree_material.vertex_color_use_as_albedo = true
 tree_material.roughness = 0.95
func chunk(data: Dictionary,mat: Material,lod: int = 0) -> MeshInstance3D:
 street_trees = []
 parked = []
 lamps = []
 var st := SurfaceTool.new()
 st.begin(Mesh.PRIMITIVE_TRIANGLES)
 junctions = {}
 for r in data.roads:
  if r.drive:
   for e in [r.a,r.b]:
    var k := node_key(e)
    junctions[k] = int(junctions.get(k,0))+1
 for r in data.roads:
  road(st,r)
 for b in data.buildings:
  building(st,b,lod)
 # Claude 17.10 (Release G4 «Улица»): lamp posts with light on the asphalt at night, cars parked in the courtyards.
 if lod==0:
  index_buildings(data.buildings)
  for r in data.roads:
   street_furniture(st,r)
  floor_height = 0.0
  surface = 0.0
 st.index()
 var instance := MeshInstance3D.new()
 instance.name = "Tile_"+str(data.key).replace(",","_")
 instance.mesh = st.commit()
 instance.material_override = mat
 if not parked.is_empty() or not lamps.is_empty():
  if car_mesh==null:
   make_furniture_meshes()
  if not parked.is_empty():
   instance.add_child(furniture_node("ParkedCars",car_mesh,parked,mat))
  if not lamps.is_empty():
   instance.add_child(furniture_node("StreetLamps",lamp_mesh,lamps,mat))
 if lod==0 and not street_trees.is_empty():
  if tree_mesh==null:
   make_tree_mesh()
  var mm := MultiMesh.new()
  mm.transform_format = MultiMesh.TRANSFORM_3D
  mm.mesh = tree_mesh
  mm.instance_count = street_trees.size()
  for i in range(street_trees.size()):
   var s := 0.8+0.4*fmod(float(i)*0.618,1.0)
   mm.set_instance_transform(i,Transform3D(Basis(Vector3.UP,float(i)).scaled(Vector3.ONE*s),street_trees[i]))
  var trees := MultiMeshInstance3D.new()
  trees.name = "StreetTrees"
  trees.multimesh = mm
  trees.material_override = tree_material
  trees.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
  instance.add_child(trees)
 return instance

# ---- Claude 17.10 (Release G4 «Улица»): street lamps and parked cars, merged into the tile mesh ----
const CELL := 16.0
var footprint_grid: Dictionary = {}
func index_buildings(buildings: Array) -> void:
 footprint_grid = {}
 for b in buildings:
  var ring := PackedVector2Array()
  for p in b.ring:
   ring.append(Vector2(p[0],p[1]))
  if ring.size()<3:
   continue
  var lo := ring[0]
  var hi := ring[0]
  for p in ring:
   lo = Vector2(minf(lo.x,p.x),minf(lo.y,p.y))
   hi = Vector2(maxf(hi.x,p.x),maxf(hi.y,p.y))
  for gx in range(int(floor(lo.x/CELL)),int(floor(hi.x/CELL))+1):
   for gy in range(int(floor(lo.y/CELL)),int(floor(hi.y/CELL))+1):
    var key := Vector2i(gx,gy)
    if not footprint_grid.has(key):
     footprint_grid[key] = []
    footprint_grid[key].append(ring)
func built(p: Vector2,margin: float = 0.0) -> bool:
 for offset in ([Vector2.ZERO] if margin<=0.0 else [Vector2.ZERO,Vector2(margin,0),Vector2(-margin,0),Vector2(0,margin),Vector2(0,-margin)]):
  var q: Vector2 = p+offset
  var key := Vector2i(int(floor(q.x/CELL)),int(floor(q.y/CELL)))
  for ring in footprint_grid.get(key,[]):
   if Geometry2D.is_point_in_polygon(q,ring):
    return true
 return false
func rand01(seed_a: float,seed_b: float) -> float:
 return fposmod(sin(seed_a*12.9898+seed_b*78.233)*43758.5453,1.0)
# An oriented box: centre of the bottom face, forward direction on the ground, size (length, height, width).
func obox(st: SurfaceTool,base: Vector3,forward: Vector3,size: Vector3,color: Color,top: Color = Color(0,0,0,0)) -> void:
 var f := forward*size.x/2.0
 var r := forward.cross(Vector3.UP).normalized()*size.z/2.0
 var up := Vector3.UP*size.y
 var p := [base-f-r,base+f-r,base+f+r,base-f+r]
 for i in range(4):
  var a: Vector3 = p[i]
  var c: Vector3 = p[(i+1)%4]
  var n := (c-a).cross(Vector3.UP).normalized()
  quad(st,a,c,c+up,a+up,color,n)
 quad(st,p[0]+up,p[1]+up,p[2]+up,p[3]+up,top if top.a>0 else color.lightened(0.06),Vector3.UP)
const CAR_COLORS := ["e8e8e4","2b2f33","8d9399","5f6a72","1f3550","7a1e22","b7b9b4","3c4a3a","c9c3b4","4a4f57","9a2f2a","24548a"]
var parked: Array = []
var lamps: Array = []
static var car_mesh: ArrayMesh
static var lamp_mesh: ArrayMesh
func parked_car(_st: SurfaceTool,at: Vector3,forward: Vector3,tint: float) -> void:
 var paint := Color(CAR_COLORS[int(tint*CAR_COLORS.size())%CAR_COLORS.size()])
 parked.append([Transform3D(Basis(forward.cross(Vector3.UP).normalized(),Vector3.UP,-forward),at),paint])
# One car and one lamp post, shared by all tiles (MultiMesh): white paint is tinted per car by the instance colour.
func make_furniture_meshes() -> void:
 var keep_s := surface
 var keep_f := floor_height
 floor_height = 0.0
 var st := SurfaceTool.new()
 st.begin(Mesh.PRIMITIVE_TRIANGLES)
 var fwd := Vector3(0,0,-1)
 surface = 6.0
 obox(st,Vector3.ZERO,fwd,Vector3(3.9,0.34,1.6),Color("1b1c1e"))
 obox(st,Vector3.UP*0.26,fwd,Vector3(4.3,0.66,1.76),Color.WHITE)
 surface = 7.0
 obox(st,Vector3.UP*0.92+Vector3(0,0,0.25),fwd,Vector3(2.2,0.5,1.56),Color("2a3238"),Color.WHITE)
 car_mesh = st.commit()
 st = SurfaceTool.new()
 st.begin(Mesh.PRIMITIVE_TRIANGLES)
 surface = 6.0
 obox(st,Vector3.ZERO,fwd,Vector3(0.22,6.6,0.22),Color("3d4245"))
 obox(st,Vector3(0.65,6.45,0),Vector3(1,0,0),Vector3(1.3,0.09,0.09),Color("3d4245"))
 surface = 4.0
 obox(st,Vector3(1.3,6.33,0),fwd,Vector3(0.5,0.14,0.26),Color("d8d2c0"))
 lamp_mesh = st.commit()
 surface = keep_s
 floor_height = keep_f
func furniture_node(name: String,mesh: Mesh,items: Array,mat: Material) -> MultiMeshInstance3D:
 var mm := MultiMesh.new()
 mm.transform_format = MultiMesh.TRANSFORM_3D
 mm.use_colors = true
 mm.mesh = mesh
 mm.instance_count = items.size()
 for i in range(items.size()):
  mm.set_instance_transform(i,items[i][0])
  mm.set_instance_color(i,items[i][1])
 var node := MultiMeshInstance3D.new()
 node.name = name
 node.multimesh = mm
 node.material_override = mat
 node.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
 return node
func street_lamp(st: SurfaceTool,foot: Vector3,toward: Vector3,inset: float,width: float,along: Vector3) -> void:
 # the post's local +x points over the road
 lamps.append([Transform3D(Basis(toward,Vector3.UP,toward.cross(Vector3.UP).normalized()),foot),Color.WHITE])
 # the pool of light on the asphalt: bright under the lamp, fading along the street and across it
 surface = 5.0
 var near := Vector3(foot.x,0.115,foot.z)+toward*inset
 var far := near+toward*width
 for s in [-1.0,1.0]:
  var reach: Vector3 = along*9.0*s
  pool(st,[near,far,far+reach,near+reach],[1.0,0.45,0.0,0.0])
 surface = 0.0
func pool(st: SurfaceTool,corners: Array,strength: Array) -> void:
 for tri in [[0,1,2],[0,2,3]]:
  var order: Array = tri
  var p0: Vector3 = corners[order[0]]
  var p1: Vector3 = corners[order[1]]
  var p2: Vector3 = corners[order[2]]
  if (p1-p0).cross(p2-p0).dot(Vector3.UP)>0:
   order = [order[0],order[2],order[1]]
  for k in order:
   var v: float = strength[k]
   st.set_color(Color(v,v,v))
   st.set_normal(Vector3.UP)
   st.set_uv(Vector2(0.0,5.0))
   st.add_vertex(corners[k])
  triangles += 1
func street_furniture(st: SurfaceTool,r: Dictionary) -> void:
 if not r.drive or r.bridge:
  return
 var a := Vector3(r.a[0],0,r.a[1])
 var b := Vector3(r.b[0],0,r.b[1])
 var length := Vector3(b.x-a.x,0,b.z-a.z).length()
 if length<6.0:
  return
 var along := (b-a).normalized()
 var side := along.cross(Vector3.UP).normalized()
 var width := float(r.width)
 var edge := float(r.edgeWidth)/2.0
 var seed := a.x*0.37+a.z*0.61
 floor_height = 0.0
 # lamps: every ~30 m on streets, alternating sides; not on narrow driveways
 if width>=5.0:
  var spacing := 30.0 if width<8.0 else 26.0
  var k := fposmod(seed,spacing)*0.5+4.0
  var n := 0
  while k<length-2.0:
   var s := 1.0 if (n+int(seed))%2==0 else -1.0
   if width>=8.0:
    s = 1.0 if n%2==0 else -1.0
   var foot := a+along*k+side*s*(edge+0.35)
   if not built(Vector2(foot.x,foot.z),0.6):
    street_lamp(st,foot,-side*s,0.35+edge-width/2.0,width,along)
   k += spacing
   n += 1
 # parked cars: along courtyard driveways and quiet residential streets, on the side away from the traffic
 if width<=5.0 and length>=12.0:
  var chance := 0.55 if width<4.5 else 0.3
  var j := 5.0
  var slot := 0
  while j<length-5.0:
   if rand01(seed,float(slot))<chance:
    var s2 := 1.0 if rand01(seed+3.0,float(slot))<0.5 else -1.0
    var at := a+along*j+side*s2*(edge+1.15)
    var ok := true
    for probe in [Vector2(0,0),Vector2(2.2,0.95),Vector2(-2.2,0.95),Vector2(2.2,-0.95),Vector2(-2.2,-0.95)]:
     var q: Vector3 = at+along*probe.x+side*probe.y
     if built(Vector2(q.x,q.z)):
      ok = false
      break
    if ok:
     parked_car(st,at+Vector3.UP*0.12,along*(1.0 if rand01(seed,float(slot)+9.0)<0.5 else -1.0),rand01(seed+7.0,float(slot)))
   j += 6.2
   slot += 1
