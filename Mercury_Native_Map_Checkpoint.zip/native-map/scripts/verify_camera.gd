extends SceneTree
# Claude 16.10 (Release N «Камера»): the map camera turns (buttons and a two-finger twist), tilts from above to street
# level (buttons and two fingers up/down), never goes under 6 m, and rides behind the selected crew.
var failed := false
func check(ok: bool,message: String) -> void:
 if not ok:
  failed = true
  push_error(message)
func _initialize() -> void:
 call_deferred("verify")
func frames(n: int) -> void:
 for i in range(n):
  await process_frame
func command(scene,op: String,value = null) -> void:
 scene.campaign.snapshot["map"] = [{"op":op,"value":value}]
 scene.apply_native_camera_commands()
func verify() -> void:
 root.size = Vector2i(794,926)
 var scene = load("res://main.tscn").instantiate()
 root.add_child(scene)
 await frames(8)
 scene.campaign.initialize({})
 scene.campaign.store.path = "user://camera-verification.json"
 scene.campaign.action({"op":"event","domId":"startCareer","event":"click"})
 scene.campaign.action({"op":"event","domId":"closeModal","event":"click"})
 await frames(10)
 var tree := JSON.stringify(scene.campaign.snapshot.get("tree",[]))
 check(tree.contains("Наклон") and tree.contains("За машиной") and tree.contains("⟳"),"camera buttons in the native UI")
 scene.set_process(false)
 scene.following = false
 # buttons: turn by 45°, tilt through three steps
 var yaw0: float = scene.yaw
 command(scene,"rotate",1)
 check(absf(angle_difference(yaw0,scene.yaw)-PI/4.0)<0.001,"rotate turns by 45°")
 command(scene,"north")
 check(absf(scene.yaw)<0.001,"north up")
 var pitches := []
 for k in range(3):
  command(scene,"tilt")
  pitches.append(scene.pitch)
 check(pitches[0]<0.4 and pitches[1]>1.3 and absf(pitches[2]-scene.PITCH_DEFAULT)<0.001,"tilt: street → from above → angled, got %s" % str(pitches))
 # never under the street
 scene.pitch = scene.PITCH_MIN
 scene.distance = 35
 scene.update_camera()
 check(scene.camera.position.y>=scene.MIN_CAMERA_HEIGHT-0.01,"camera stays above 6 m, got %.2f" % scene.camera.position.y)
 # a two-finger twist turns the map, the pinch length stays — so the zoom does not change
 scene.pitch = scene.PITCH_DEFAULT
 scene.distance = 300
 var a := Vector2(300,500)
 var b := Vector2(500,500)
 for pair in [[0,a],[1,b]]:
  var touch := InputEventScreenTouch.new()
  touch.index = pair[0]
  touch.position = pair[1]
  touch.pressed = true
  Input.parse_input_event(touch)
 await frames(2)
 var yaw1: float = scene.yaw
 var turned: Vector2 = a+(b-a).rotated(deg_to_rad(30.0))
 var drag := InputEventScreenDrag.new()
 drag.index = 1
 drag.position = turned
 drag.relative = turned-b
 Input.parse_input_event(drag)
 await frames(2)
 check(absf(rad_to_deg(angle_difference(yaw1,scene.yaw))-30.0)<1.0,"twist 30° turns the camera 30°, got %.1f" % rad_to_deg(angle_difference(yaw1,scene.yaw)))
 check(absf(scene.distance-300.0)<1.0,"twist keeps the zoom")
 # two fingers moving down together tilt the camera
 var pitch1: float = scene.pitch
 for pair in [[0,a],[1,turned]]:
  var lift := InputEventScreenDrag.new()
  lift.index = pair[0]
  lift.position = pair[1]+Vector2(0,60)
  lift.relative = Vector2(0,60)
  Input.parse_input_event(lift)
  await frames(2)
 check(scene.pitch>pitch1,"two fingers down tilt towards a top view")
 for index in [0,1]:
  var up := InputEventScreenTouch.new()
  up.index = index
  up.pressed = false
  up.position = a
  Input.parse_input_event(up)
 # behind the car
 scene.set_process(true)
 command(scene,"chase")
 await frames(90)
 check(scene.following and scene.chase,"chase follows the crew")
 var heading: float = -scene.patrol.rotation.y
 var ahead := Vector2(cos(heading),sin(heading))
 var back := Vector2(scene.camera.position.x-scene.focus.x,scene.camera.position.z-scene.focus.z).normalized()
 check(ahead.dot(back)<-0.7,"the camera rides behind the car (dot %.2f)" % ahead.dot(back))
 check(scene.camera.position.y>=scene.MIN_CAMERA_HEIGHT-0.01,"chase camera above the street")
 print("Camera: turn, tilt, twist, street limit and chase view ","FAILED" if failed else "PASSED")
 quit(1 if failed else 0)
