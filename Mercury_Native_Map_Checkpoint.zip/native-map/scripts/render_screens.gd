extends SceneTree
# Claude audit tool: render the main screens of the native game for visual comparison with the web version.
# Usage: xvfb-run Godot --path . --rendering-driver opengl3 --resolution 369x905 --script scripts/render_screens.gd -- --native-ui --out DIR [--chief] [--call] [--service Спасатели|Скорая|112]
var scene
var out := ""
func find(nodes: Array,pred: Callable) -> Dictionary:
 for item in nodes:
  if pred.call(item):
   return item
  var f := find(item.get("children",[]),pred)
  if not f.is_empty():
   return f
 return {}
func text_of(n: Dictionary) -> String:
 var t := str(n.get("text",""))
 for c in n.get("children",[]):
  t += " "+text_of(c)
 return t
func wait(n: int) -> void:
 for i in range(n):
  await process_frame
func shot(name: String) -> void:
 await RenderingServer.frame_post_draw
 root.get_texture().get_image().save_png(out+"/"+name+".png")
 print("shot ",name)
func dom(id: String) -> bool:
 if find(scene.campaign.snapshot.tree,func(x): return x.get("domId")==id).is_empty():
  print("no dom ",id)
  return false
 scene.campaign.action({"op":"event","domId":id,"event":"click"})
 return true
func press(prefix: String) -> bool:
 var n := find(scene.campaign.snapshot.tree,func(x): return x.get("tag")=="button" and text_of(x).strip_edges().begins_with(prefix))
 if n.is_empty():
  print("no button ",prefix)
  return false
 scene.campaign.action({"op":"event","id":n.id,"event":"click"})
 return true
func screen(name: String,open: String) -> void:
 if dom(open):
  await wait(15)
  await shot(name)
  dom("closeModal")
  await wait(5)
func _initialize() -> void:
 call_deferred("run")
func run() -> void:
 var args := OS.get_cmdline_user_args()
 out = args[args.find("--out")+1]
 var chief := args.has("--chief")
 scene = load("res://main.tscn").instantiate()
 root.add_child(scene)
 await wait(30)
 scene.campaign.initialize({})
 scene.campaign.store.path = "user://render-screens.json"
 await wait(10)
 if args.has("--service"):
  press(args[args.find("--service")+1])
  await wait(5)
 await shot("01-welcome")
 dom("startChief" if chief else "startCareer")
 await wait(20)
 await shot("02-start-modal")
 dom("closeModal")
 await wait(10)
 press("Понятно")
 await wait(30)
 await shot("03-map")
 press("Патруль")
 await wait(40)
 await shot("03b-map-patrol")
 press("Город")
 await wait(40)
 await shot("03c-map-city")
 press("▣")
 await wait(15)
 await shot("04-crews")
 press("Вызовы")
 await wait(15)
 await shot("05-calls")
 press("⌖")
 await wait(10)
 await screen("06-history","serviceBtn")
 await screen("07-report","reportBtn")
 await screen("08-settings","settingsBtn")
 await screen("09-journal","journalBtn")
 await screen("10-help","helpBtn")
 if chief:
  await screen("11-department","departmentBtn")
 if args.has("--call"):
  # Fast-forward at 60× until the first call, then the map icon and the call card.
  press("60×")
  var started := Time.get_ticks_msec()
  while scene.campaign.snapshot.get("view",{}).get("incidents",[]).filter(func(i): return not (i.get("state") in ["resolved","missed"])).is_empty() and Time.get_ticks_msec()-started<180000:
   await process_frame
  press("1×")
  await wait(20)
  await shot("12-call-map")
  press("Вызовы")
  await wait(10)
  var item := find(scene.campaign.snapshot.tree,func(x): return x.get("tag")=="button" and str(x.get("classes","")).contains("call"))
  if not item.is_empty():
   scene.campaign.action({"op":"event","id":item.id,"event":"click"})
  await wait(15)
  await shot("13-call-card")
  press("Понятно")
  press("⌖")
  await wait(5)
  press("Патруль")
  press("+")
  press("+")
  await wait(60)
  await shot("14-unit-close")
 quit(0)
