extends Node3D
const Geometry = preload("res://scripts/city_geometry.gd")
var route: Array = []
var segment := 1
var travelled := 0.0
var finished := false
var time_scale := 1.0
func _ready() -> void:
 route = JSON.parse_string(FileAccess.get_file_as_string("res://assets/patrol.json"))
 position = Vector3(route[0].p[0],0.04,route[0].p[1])
 var model = JSON.parse_string(FileAccess.get_file_as_string("res://assets/sedan.json"))
 var st := SurfaceTool.new()
 st.begin(Mesh.PRIMITIVE_TRIANGLES)
 var geometry = Geometry.new()
 var colors := {"paint":"#cbdce3","trim":"#414b53","plate":"#f2f3e9","glass":"#274855","seal":"#273039","metal":"#89949a","stripe":"#295696","tire":"#252a2d","headlight":"#fff1bd","taillight":"#b73734","rubber":"#273039","beaconA":"#397fe6","beaconB":"#4385f1","aidCase":"#b44842"}
 for face in model.faces:
  var vertices: Array[Vector3] = []
  for index in face.v:
   var p = model.vertices[index]
   vertices.append(Vector3(p[0],p[2],p[1]))
  var normal := -(vertices[1]-vertices[0]).cross(vertices[2]-vertices[0]).normalized()
  for i in range(1,vertices.size()-1):
   geometry.triangle(st,vertices[0],vertices[i],vertices[i+1],Color(colors.get(face.material,"#aaaaaa")),normal)
 st.index()
 var mesh := MeshInstance3D.new()
 mesh.mesh = st.commit()
 var mat := StandardMaterial3D.new()
 mat.vertex_color_use_as_albedo = true
 mat.roughness = 0.65
 mesh.material_override = mat
 add_child(mesh)
func advance(world_seconds: float) -> void:
 var remaining := maxf(0,world_seconds)
 while remaining>0 and segment<route.size():
  var goal := Vector3(route[segment].p[0],0.04,route[segment].p[1])
  var delta := goal-position
  var length := delta.length()
  if length<0.0001:
   position = goal
   segment += 1
   continue
  var metres_per_second := float(route[segment].kmh)/3.6
  var moved := minf(length,remaining*metres_per_second)
  position += delta/length*moved
  travelled += moved
  remaining -= moved/metres_per_second
  rotation.y = -atan2(delta.z,delta.x)
  if moved>=length-0.0001:
   position = goal
   segment += 1
 finished = segment>=route.size()
func _process(delta: float) -> void:
 advance(delta*time_scale)

func reset_route() -> void:
 segment = 1
 travelled = 0.0
 finished = false
 position = Vector3(route[0].p[0],0.04,route[0].p[1])
