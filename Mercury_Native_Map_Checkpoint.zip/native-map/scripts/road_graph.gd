extends RefCounted
var nodes: Dictionary = {}
var heap: Array = []
func load_graph(path: String) -> void:
 var data = JSON.parse_string(FileAccess.get_file_as_string(path))
 for n in data.nodes:
  nodes[str(n.id)] = n
func push(value: Array) -> void:
 var k := heap.size()
 heap.append(value)
 while k>0:
  var parent := (k-1)/2 as int
  if heap[parent][0] <= value[0]:
   break
  heap[k] = heap[parent]
  k = parent
 heap[k] = value
func pop() -> Array:
 var first: Array = heap[0]
 var last: Array = heap.pop_back()
 if not heap.is_empty():
  var k := 0
  while k*2+1<heap.size():
   var child := k*2+1
   if child+1<heap.size() and heap[child+1][0]<heap[child][0]:
    child += 1
   if heap[child][0]>=last[0]:
    break
   heap[k] = heap[child]
   k = child
  heap[k] = last
 return first
func route(start: String,goal: String) -> Dictionary:
 if not nodes.has(start) or not nodes.has(goal):
  return {}
 heap.clear()
 var costs := {start:0.0}
 var previous := {}
 push([0.0,start])
 while not heap.is_empty():
  var item := pop()
  var id := str(item[1])
  var cost := float(item[0])
  if cost != costs.get(id,INF):
   continue
  if id==goal:
   break
  for edge in nodes[id].edges:
   var target := str(edge.id)
   var alt := cost+float(edge.w)
   if alt<float(costs.get(target,INF)):
    costs[target] = alt
    previous[target] = {"id":id,"speed":edge.speed}
    push([alt,target])
 if not costs.has(goal):
  return {}
 var ids: Array = [goal]
 while ids[0]!=start:
  ids.push_front(previous[ids[0]].id)
 return {"ids":ids,"weight":costs[goal],"previous":previous}
