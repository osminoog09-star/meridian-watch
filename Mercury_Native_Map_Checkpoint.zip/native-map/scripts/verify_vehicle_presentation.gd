extends SceneTree
var failed := false
func check(ok: bool,message: String) -> void:
 if not ok:
  failed = true
  push_error(message)
func _initialize() -> void:
 var models: Dictionary = JSON.parse_string(FileAccess.get_file_as_string("res://assets/actor-models.json"))
 var fixtures: Array = JSON.parse_string(FileAccess.get_file_as_string("res://ui/vehicle-fixtures.json"))
 var skins = preload("res://scripts/vehicle_skin.gd").new()
 for fixture in fixtures:
  var actor := MeshInstance3D.new()
  root.add_child(actor)
  var data: Dictionary = models[fixture.kind]
  skins.apply(actor,data,fixture.kind,fixture.style,{},false,false,true)
  var meshes: Dictionary = skins.parts(data,fixture.kind,fixture.style,fixture.style.palette)
  for part in ["body","leftDoor","rightDoor"]:
   var arrays: Array = meshes[part].surface_get_arrays(0)
   check(arrays[Mesh.ARRAY_INDEX].size()==int(fixture.counts[part]),"exact original face selection "+fixture.kind+" "+part)
  for sample in fixture.samples:
   skins.apply(actor,data,fixture.kind,fixture.style,{sample.side:sample.amount},false,false,true)
   var door: MeshInstance3D = actor.get_node(sample.side+"Door")
   var p := Vector3(sample.point[0],sample.point[1],sample.point[2])-door.position
   var expected := Vector3(sample.expected[0],sample.expected[1],sample.expected[2])
   check((door.transform*p).distance_to(expected)<0.00001,"source door hinge transform")
  skins.hide_doors(actor)
  check(not actor.get_node("leftDoor").visible and not actor.get_node("rightDoor").visible,"pool reset to civilian/simple")
  actor.free()
 print("Native vehicle geometry, kits and doors ","FAILED" if failed else "PASSED")
 quit(1 if failed else 0)
