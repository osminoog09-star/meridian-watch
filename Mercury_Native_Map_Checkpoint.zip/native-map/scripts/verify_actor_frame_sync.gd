extends SceneTree
var failed := false
func _initialize() -> void:
 call_deferred("verify")
func verify() -> void:
 var scene = load("res://main.tscn").instantiate()
 root.add_child(scene)
 for i in range(6):
  await process_frame
 scene.set_process(false)
 scene.campaign.initialize({})
 scene.campaign.store.path = "user://actor-frame-sync-test.json"
 for id in ["startCareer","closeModal","followUnit"]:
  scene.campaign.action({"op":"event","domId":id,"event":"click"})
 scene.campaign.action({"op":"event","domId":"settingsBtn","event":"click"})
 scene.campaign.action({"op":"event","domId":"settingsWorldRate","event":"change","value":"45"})
 scene.campaign.action({"op":"event","domId":"applyAudio","event":"click"})
 for warmup in range(1500):
  scene.campaign.advance(1.0/30.0)
  if scene.campaign.view().units[0].status == "patrol":
   break
 scene._process(1.0/30.0)
 var moved := 0
 var between_snapshots := 0
 var previous: Vector3 = scene.patrol.position
 for frame in range(18):
  scene._process(1.0/30.0)
  var unit: Dictionary = scene.campaign.view().units[0]
  var expected: Vector3 = scene.live_actors.world(unit)
  if scene.patrol.position.distance_to(expected)>0.00001 or scene.focus.distance_to(expected)>0.00001:
   failed = true
   push_error("Frame pose/follow camera lags authoritative route")
  if previous.distance_to(expected)>0.00001:
   moved += 1
   if scene.simulation_snapshot_elapsed>0.00001:
    between_snapshots += 1
  previous = expected
 # Original fixed-step simulation moves at 10 Hz; verify updates also land
 # between the old presentation timer boundaries, without inventing poses.
 if moved<4 or between_snapshots<1:
  failed = true
  push_error("Fixture did not exercise moving vehicle")
 print("Native actor/camera per-frame route sync ","FAILED" if failed else "PASSED", "; moved frames ",moved,"; between snapshot boundaries ",between_snapshots)
 quit(1 if failed else 0)
