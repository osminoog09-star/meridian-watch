extends RefCounted
const Geometry = preload("res://scripts/city_geometry.gd")
var cache: Dictionary = {}

func parts(data: Dictionary,kind: String,style: Dictionary,palette: Dictionary) -> Dictionary:
 var key := kind+JSON.stringify(style.get("police",false))+str(style.get("kit","base"))+JSON.stringify(palette)
 if cache.has(key):
  return cache[key]
 var result: Dictionary = {}
 var geometry = Geometry.new()
 for section in ["body","leftDoor","rightDoor"]:
  var builder := SurfaceTool.new()
  builder.begin(Mesh.PRIMITIVE_TRIANGLES)
  var count := 0
  for face in data.faces:
   var group: String = face.get("group","body")
   if (group=="police" and not style.get("police",false)) or (group in ["aid","search"] and (not style.get("police",false) or style.get("kit","base")!=group)):
    continue
   if (section=="body" and group in ["leftDoor","rightDoor"]) or (section!="body" and group!=section):
    continue
   var vertices: Array[Vector3] = []
   var hinge := Vector3.ZERO
   if section!="body":
    var p: Array = data.doorHinges["left" if section=="leftDoor" else "right"]
    hinge = Vector3(p[0],0,p[1])
   for index in face.v:
    var p: Array = data.vertices[index]
    vertices.append(Vector3(p[0],p[2],p[1])-hinge)
   if vertices.size()<3:
    continue
   var normal := -(vertices[1]-vertices[0]).cross(vertices[2]-vertices[0]).normalized()
   for index in range(1,vertices.size()-1):
    geometry.triangle(builder,vertices[0],vertices[index],vertices[index+1],Color(palette.get(face.material,"#d5d8d1")),normal)
    count += 1
  if count:
   builder.index()
   result[section] = builder.commit()
 if cache.size()>=96:
  cache.clear()
 cache[key] = result
 return result

func apply(actor: MeshInstance3D,data: Dictionary,kind: String,style: Dictionary,doors: Dictionary,emergency: bool,flash: bool,shadows: bool) -> void:
 var palette: Dictionary = style.get("flashPalette" if flash else "activePalette",style.get("palette",{})) if emergency else style.get("palette",{})
 var meshes := parts(data,kind,style,palette)
 actor.mesh = meshes.body
 for side in ["left","right"]:
  var name: String = side+"Door"
  var door := actor.get_node_or_null(name) as MeshInstance3D
  if door==null:
   door = MeshInstance3D.new()
   door.name = name
   actor.add_child(door)
  door.mesh = meshes.get(name)
  door.material_override = actor.material_override
  door.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_ON if shadows else GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
  var hinge: Array = data.doorHinges[side]
  door.position = Vector3(hinge[0],0,hinge[1])
  door.rotation.y = (-1 if side=="left" else 1)*clampf(float(doors.get(side,0)),0,1)*deg_to_rad(65)
  door.visible = true

func hide_doors(actor: MeshInstance3D) -> void:
 for name in ["leftDoor","rightDoor"]:
  var door := actor.get_node_or_null(name) as MeshInstance3D
  if door!=null:
   door.visible = false
