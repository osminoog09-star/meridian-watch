extends SceneTree
# Claude 17.10 (Release R2 «Звук»): the native game plays the sound bank — every file of audio/ loads, the city beds
# play, the radio speaks voiced fragments, the own engine and sirens follow the game, and nothing sounds when sound
# is switched off.
var failed := false
func check(ok: bool,message: String) -> void:
 if not ok:
  failed = true
  push_error(message)
func _initialize() -> void:
 call_deferred("verify")
func verify() -> void:
 var dir := DirAccess.open("res://audio")
 var count := 0
 for sub in ["city","weather","siren","vehicle","steps","ui","radio","voice"]:
  for f in DirAccess.get_files_at("res://audio/"+sub):
   if f.ends_with(".ogg"):
    count += 1
    check(load("res://audio/"+sub+"/"+f) is AudioStreamOggVorbis,"loads "+sub+"/"+f)
 check(count>=50,"the bank has the sounds: "+str(count))
 var scene = load("res://main.tscn").instantiate()
 root.add_child(scene)
 for i in range(6):
  await process_frame
 var campaign = scene.campaign
 campaign.initialize({"meridian-watch-audio-v1":"{}"})
 campaign.store.path = "user://sound-world-test.json"
 for id in ["startCareer","closeModal"]:
  campaign.action({"op":"event","domId":id,"event":"click"})
 var sound: Node = null
 for child in scene.get_children():
  if child.has_method("ui_click"):
   sound = child
 check(sound!=null,"the sound node is in the map")
 if sound==null:
  quit(1)
  return
 var radio := 0
 var bed := false
 var voiced := 0
 for k in range(300):
  if k==100:
   sound.on_event({"kind":"radio","voice":"duty","clips":[[0.0,0.5],[0.6,0.4]],"own":true})
   sound.on_event({"kind":"newcall","urgent":true})
  campaign.advance(1.0)
  await process_frame
  for p in sound.beds.values():
   if p.playing:
    bed = true
  if sound.radio_player.playing and sound.radio_player.stream in sound.voices.values():
   voiced += 1
  radio = max(radio,sound.radio_queue.size())
 check(bool(sound.prefs.get("enabled",false)),"sound is on by default")
 check(bed,"a city bed plays")
 check(voiced>0,"the radio speaks")
 sound.prefs["enabled"] = false
 sound.data["active"] = false
 for k in range(120):
  sound.mix(0.05)
 var loud := 0
 for p in sound.beds.values():
  if p.playing:
   loud += 1
 check(loud==0,"switched off: silence")
 print("radio queue max ",radio," time ",campaign.snapshot.get("status",{}).get("clock",""));print("Sound world: ",count," files, beds ",bed,", voiced frames ",voiced," ","FAILED" if failed else "PASSED")
 quit(1 if failed else 0)
