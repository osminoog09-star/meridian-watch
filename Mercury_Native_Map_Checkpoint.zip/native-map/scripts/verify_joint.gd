extends SceneTree
# Claude 16.10 (Release K): joint calls run in the native core — for police, rescue and ambulance careers the city
# partners come, every part is done and the common debrief is graded; the native call card shows the joint block.
const Core = preload("res://scripts/simulation_core.gd")
const Controller = preload("res://scripts/native_ui_controller.gd")
const VARIANTS := {"police":"crash","rescue":"rescue-crash","ems":"ems-trauma"}
var failed := false
func check(ok: bool,message: String) -> void:
 if not ok:
  failed = true
  push_error(message)
func _initialize() -> void:
 var core = Core.new()
 if not core.initialize():
  quit(1)
  return
 var save_for_ui := ""
 for service in ["police","rescue","ems"]:
  var options := {"schedule":"ppa"}
  if service!="police":
   options["service"] = service
  core.invoke({"op":"create","mode":"career","seed":7182,"options":options})
   # A real map point: the place of the first ordinary call.
  var point = null
  for k in range(4000):
   core.invoke({"op":"tick","dt":0.5})
   var incidents: Array = core.state().get("incidents",[])
   if not incidents.is_empty():
    point = {"x":incidents[0].x,"y":incidents[0].y}
    break
  check(point!=null,service+": no ordinary call to take a point from")
  if point==null:
   continue
  var joint_id := -1
  for k in range(20):
   var incident = core.invoke({"op":"command","name":"spawnIncident","args":[null,{"variant":VARIANTS[service],"point":point}]})
   if typeof(incident)==TYPE_DICTIONARY and incident.has("joint"):
    joint_id = int(incident.id)
    break
  check(joint_id>0,service+": no joint call in 20 spawns")
  if joint_id<0:
   continue
  if service=="rescue":
   for k in range(6):
    core.invoke({"op":"tick","dt":0.5})
   save_for_ui = core.serialize()
  var done := false
  for k in range(8000):
   core.invoke({"op":"tick","dt":0.5})
   if k%100==0 or k>7990:
    var call := {}
    for i in core.state().get("incidents",[]):
     if int(i.id)==joint_id:
      call = i
    if call.is_empty() or call.get("state") in ["resolved","missed"]:
     done = not call.is_empty() and call.get("state")=="resolved" and call.joint.report!=null and call.joint.report.grade in ["A","B","C"]
     if call.is_empty():
      done = true
     break
  check(done,service+": the joint call did not close with a graded debrief")
 # K2: the 112 desk — ask, notify the other services, route the lead service; the notified ones leave at once.
 core.invoke({"op":"create","mode":"career","seed":7182,"options":{"schedule":"ppa","service":"dispatch"}})
 var desk_point = null
 for k in range(4000):
  core.invoke({"op":"tick","dt":0.5})
  var incidents: Array = core.state().get("incidents",[])
  if not incidents.is_empty():
   desk_point = {"x":incidents[0].x,"y":incidents[0].y}
   break
 var desk_id := -1
 for k in range(30):
  var incident = core.invoke({"op":"command","name":"spawnIncident","args":[null,{"variant":"rescue-crash","point":desk_point}]})
  if typeof(incident)==TYPE_DICTIONARY and incident.has("joint"):
   desk_id = int(incident.id)
   break
 check(desk_id>0,"112: no joint call")
 if desk_id>0:
  var took = core.invoke({"op":"command","name":"takeCall","args":[desk_id]})
  check(typeof(took)==TYPE_DICTIONARY and took.get("ok",false),"112: take the joint call")
  var answer = core.invoke({"op":"command","name":"askCaller","args":[desk_id,"trapped"]})
  check(str(answer.get("message","")).contains("зажало"),"112: the caller tells about the trapped driver")
  core.invoke({"op":"command","name":"notifyService","args":[desk_id,"police"]})
  core.invoke({"op":"command","name":"notifyService","args":[desk_id,"ems"]})
  core.invoke({"op":"command","name":"pickRoute","args":[desk_id,"rescue","A"]})
  var sent = core.invoke({"op":"command","name":"sendCall","args":[desk_id]})
  check(typeof(sent)==TYPE_DICTIONARY and sent.get("ok",false),"112: route the call")
  var kinds := []
  for a in core.state().get("services",[]):
   if int(a.incident)==desk_id:
    kinds.append(str(a.kind))
  kinds.sort()
  check(kinds==["ambulance","police"],"112: the notified services leave at once, got %s" % str(kinds))
 # The native call card shows the joint block.
 var ui = Controller.new()
 if save_for_ui.is_empty() or not ui.initialize({}):
  check(false,"no rescue save for the UI")
 else:
  ui._legacy_storage_ready(JSON.stringify({"meridian-watch-v1":save_for_ui}),"")
  ui.action({"op":"event","domId":"resumeBtn","event":"click"})
  ui.action({"op":"event","domId":"continueBtn","event":"click"})
  var text := JSON.stringify(ui.snapshot.get("tree",[]))
  var call_button := ""
  check(text.contains("совместно"),"the call list marks the joint call")
  var ids := []
  var stack: Array = ui.snapshot.get("tree",[]).duplicate()
  while not stack.is_empty():
   var node = stack.pop_back()
   if node.get("tag")=="button" and JSON.stringify(node).contains("совместно"):
    ui.action({"op":"event","id":node.get("id"),"event":"click"})
    break
   stack.append_array(node.get("children",[]))
  check(JSON.stringify(ui.snapshot.get("tree",[])).contains("Совместное происшествие"),"the call card shows the joint block")
 print("Joint calls: police, rescue and ambulance careers close with a graded debrief in the native core; 112 notifies the other services; the native call card shows the joint block")
 quit(1 if failed else 0)
