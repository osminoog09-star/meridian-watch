extends RefCounted
static var bridges: Array = []
static var loaded := false
static func height_at(position: Vector3) -> float:
 if not loaded:
  bridges = JSON.parse_string(FileAccess.get_file_as_string("res://assets/bridges.json"))
  loaded = true
 var point := Vector2(position.x,position.z)
 for bridge in bridges:
  var a := Vector2(bridge.a[0],bridge.a[1])
  var b := Vector2(bridge.b[0],bridge.b[1])
  var nearest := Geometry2D.get_closest_point_to_segment(point,a,b)
  if nearest.distance_squared_to(point)<=pow(float(bridge.edgeWidth)*0.5+0.5,2):
   return 2.5
 return 0.0
