extends RefCounted
# Generated profiles follow connected source road segments, never straight-line shortcuts.
static var profiles: Dictionary = {}
static var grid: Dictionary = {}
static var loaded := false
static func road_key(road: Dictionary) -> String:
 var values: Array[String] = [str(road.id)]
 for p in [road.a,road.b]:
  for v in p:
   values.append(str(floori(float(v)*1000.0+0.5)))
 return ":".join(values)
static func ensure_loaded() -> void:
 if loaded:
  return
 var data: Dictionary = JSON.parse_string(FileAccess.get_file_as_string("res://assets/bridge-profiles.json"))
 profiles = data.profiles
 for segment in data.segments:
  var pad: float = float(segment.edgeWidth)*0.5+0.5
  var lo := Vector2(minf(segment.a[0],segment.b[0])-pad,minf(segment.a[1],segment.b[1])-pad)
  var hi := Vector2(maxf(segment.a[0],segment.b[0])+pad,maxf(segment.a[1],segment.b[1])+pad)
  for x in range(floori(lo.x/64.0),floori(hi.x/64.0)+1):
   for y in range(floori(lo.y/64.0),floori(hi.y/64.0)+1):
    var cell := Vector2i(x,y)
    if not grid.has(cell):
     grid[cell] = []
    grid[cell].append(segment)
 loaded = true
static func road_profile(road: Dictionary) -> Array:
 ensure_loaded()
 return profiles.get(road_key(road),[{"a":road.a,"b":road.b,"ha":0.0,"hb":0.0}])
static func height_at(position: Vector3,heading: float = INF) -> float:
 ensure_loaded()
 var point := Vector2(position.x,position.z)
 var closest := INF
 var height := 0.0
 for segment in grid.get(Vector2i(floori(point.x/64.0),floori(point.y/64.0)),[]):
  var a := Vector2(segment.a[0],segment.a[1])
  var b := Vector2(segment.b[0],segment.b[1])
  var vector := b-a
  var t := clampf((point-a).dot(vector)/maxf(vector.length_squared(),0.000001),0,1)
  var separation := (point-(a+vector*t)).length_squared()
  var score := separation
  if is_finite(heading) and vector.length_squared()>0.000001:
   score += (1.0-absf(vector.normalized().dot(Vector2(cos(heading),sin(heading)))))*0.000001
  if separation<=pow(float(segment.edgeWidth)*0.5+0.5,2) and score<closest:
   closest = score
   height = lerpf(segment.ha,segment.hb,t)
 return height
