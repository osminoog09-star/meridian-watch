extends SceneTree
const Geometry = preload("res://scripts/city_geometry.gd")
func _initialize() -> void:
 var data = JSON.parse_string(FileAccess.get_file_as_string("res://assets/city.json"))
 var geometry = Geometry.new()
 var material := StandardMaterial3D.new()
 var began := Time.get_ticks_msec()
 var vertices := 0
 for tile in data.chunks:
  var mesh: MeshInstance3D = geometry.chunk(tile,material,1)
  vertices += mesh.mesh.surface_get_array_len(0)
  mesh.free()
 var result := {"buildings":data.buildingCount,"roads":data.roads,"chunks":data.chunks.size(),"segments":data.segments,"roof_failures":geometry.failed_roofs,"roof_area_error":absf(geometry.roof_area-geometry.expected_area),"roofs":geometry.roofs,"triangles":geometry.triangles,"vertices":vertices,"headless_bake_ms":Time.get_ticks_msec()-began}
 print(JSON.stringify(result))
 FileAccess.open("res://full-city-verification.json",FileAccess.WRITE).store_string(JSON.stringify(result,"  "))
 quit(0 if geometry.failed_roofs.is_empty() and geometry.roofs==int(data.buildingCount) else 1)
