extends ScrollContainer
# Keep native touch/inertia handling; never rebuild children under a moving finger.
var touches: Dictionary = {}
var last_motion := -1000
var restoring := false
var generation := 0
var page := ""
var positions: Dictionary = {}
func _ready() -> void:
 horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
 scroll_deadzone = 10
 follow_focus = false
 get_v_scroll_bar().value_changed.connect(func(_value):
  if not restoring:
   last_motion = Time.get_ticks_msec())
func _input(event: InputEvent) -> void:
 if event is InputEventScreenTouch:
  if event.pressed and is_visible_in_tree() and get_global_rect().has_point(event.position):
   touches[event.index] = true
  elif not event.pressed:
   touches.erase(event.index)
func interaction_active() -> bool:
 return not touches.is_empty() or (not restoring and Time.get_ticks_msec()-last_motion<180)
func begin_page(next_page: String) -> int:
 if not page.is_empty():
  positions[page] = scroll_vertical
 page = next_page
 generation += 1
 restoring = true
 return int(positions.get(page,0))
func restore_after_layout(value: int) -> void:
 var token := generation
 # Wrapping rich cards needs two layout passes before scroll maximum is valid.
 await get_tree().process_frame
 await get_tree().process_frame
 if token!=generation:
  return
 scroll_vertical = value
 restoring = false
 last_motion = -1000
