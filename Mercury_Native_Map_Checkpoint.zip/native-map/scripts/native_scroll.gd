extends ScrollContainer
# Keep native touch/inertia handling; never rebuild children under a moving finger.
var touches: Dictionary = {}
var last_motion := -1000
var restoring := false
var generation := 0
var page := ""
var positions: Dictionary = {}
# Claude 16.10 (owner: «трудно что-то пролистать вниз»): Godot's own touch drag never starts when the finger lands on
# a Button/card (they stop the event) — and nearly everything here is a button or card. Own finger scrolling:
# past DRAG_START px it scrolls whatever is under the finger, the button under it is not pressed, a fling coasts on.
const DRAG_START := 12.0
const FRICTION := 4.0
var finger := -1
var finger_from := Vector2.ZERO
var scroll_from := 0.0
var dragging := false
var swallow_release := false
var fling := 0.0
var last_drag_ms := 0
func _ready() -> void:
 horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
 # The built-in drag (emulated mouse) would scroll a second time; ours handles touch.
 scroll_deadzone = 100000
 follow_focus = false
 get_v_scroll_bar().value_changed.connect(func(_value):
  if not restoring:
   last_motion = Time.get_ticks_msec())
func cancel_interaction() -> void:
 touches.clear()
 last_motion = -1000
 finger = -1
 dragging = false
 fling = 0.0
func _notification(what: int) -> void:
 # Android can lose focus without sending the finger-up event.
 if what==NOTIFICATION_APPLICATION_FOCUS_OUT or what==NOTIFICATION_WM_WINDOW_FOCUS_OUT or what==NOTIFICATION_PAUSED:
  cancel_interaction()
 elif what==NOTIFICATION_VISIBILITY_CHANGED and not is_visible_in_tree():
  cancel_interaction()
func _input(event: InputEvent) -> void:
 if event is InputEventScreenTouch:
  if event.pressed and is_visible_in_tree() and get_global_rect().has_point(event.position):
   touches[event.index] = true
   if finger<0:
    finger = event.index
    finger_from = event.position
    scroll_from = scroll_vertical
    dragging = false
    fling = 0.0
  elif not event.pressed:
   touches.erase(event.index)
   if event.index==finger:
    finger = -1
    if dragging:
     dragging = false
     swallow_release = true
     if Time.get_ticks_msec()-last_drag_ms>120:
      fling = 0.0
 elif event is InputEventScreenDrag and event.index==finger:
  var moved: float = event.position.y-finger_from.y
  if not dragging and absf(moved)>DRAG_START:
   dragging = true
   finger_from = event.position
   scroll_from = scroll_vertical
   moved = 0.0
  if dragging:
   scroll_vertical = int(round(scroll_from-moved))
   fling = clampf(-float(event.velocity.y),-4000,4000)
   last_drag_ms = Time.get_ticks_msec()
   last_motion = Time.get_ticks_msec()
   get_viewport().set_input_as_handled()
 elif event is InputEventMouseButton and event.button_index==MOUSE_BUTTON_LEFT and not event.pressed and swallow_release:
  # The finger lifted after scrolling: release the button under it outside its rect, so it is not clicked.
  swallow_release = false
  get_viewport().set_input_as_handled()
  var away := InputEventMouseButton.new()
  away.button_index = MOUSE_BUTTON_LEFT
  away.pressed = false
  away.position = Vector2(-10000,-10000)
  away.global_position = away.position
  Input.parse_input_event(away)
func _process(delta: float) -> void:
 if finger<0 and absf(fling)>20:
  scroll_vertical = int(round(scroll_vertical+fling*delta))
  fling *= maxf(0.0,1.0-FRICTION*delta)
  last_motion = Time.get_ticks_msec()
 elif finger<0:
  fling = 0.0
func interaction_active() -> bool:
 return not touches.is_empty() or (not restoring and Time.get_ticks_msec()-last_motion<180)
func begin_page(next_page: String) -> int:
 if not page.is_empty():
  positions[page] = scroll_vertical
 page = next_page
 generation += 1
 restoring = true
 return int(positions.get(page,0))
func restore_after_layout(value: int) -> void:
 var token := generation
 # Wrapping rich cards needs two layout passes before scroll maximum is valid.
 await get_tree().process_frame
 await get_tree().process_frame
 if token!=generation:
  return
 scroll_vertical = value
 restoring = false
 last_motion = -1000
