extends SceneTree
# Claude 22.10 (City 2.0 «Машины»): every car body and the bus build as one surface with sane dimensions, both as a
# moving car (forward +x) and as a parked car (forward −z).
func _initialize() -> void:
 var kit = preload("res://scripts/car_kit.gd").new()
 var ok := true
 for body in kit.BODIES+["bus"]:
  var m: ArrayMesh = kit.build(body,Color("7a1e22"))
  var p: ArrayMesh = kit.build(body,Color.WHITE,true)
  var a := m.get_aabb()
  var b := p.get_aabb()
  var long := 10.0 if body=="bus" else 3.5
  ok = ok and m.get_surface_count()==1 and a.size.x>long and a.size.z>1.6 and a.size.y>1.3 and a.size.y<3.6
  ok = ok and b.size.z>long and b.size.x>1.6 and absf(a.size.x-b.size.z)<0.01
  if not ok:
   push_error("car kit body "+body+" "+str(a)+" "+str(b))
   break
 print("Car kit: hatch, sedan, wagon, van, pickup, bus ","PASS" if ok else "FAILED")
 quit(0 if ok else 1)
