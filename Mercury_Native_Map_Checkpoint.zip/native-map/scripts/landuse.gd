extends MeshInstance3D
var failed_polygons := 0
func _ready() -> void:
 var areas = JSON.parse_string(FileAccess.get_file_as_string("res://assets/landuse.json"))
 var tool := SurfaceTool.new()
 tool.begin(Mesh.PRIMITIVE_TRIANGLES)
 var palette := {"water":"#497c99","beach":"#bfba8c","park":"#658957","grass":"#7d9461","forest":"#416a49","wood":"#416a49","scrub":"#6f8252","garden":"#768f62","pitch":"#6f995c","cemetery":"#658060","residential":"#929387","industrial":"#8a8b82"}
 # Broad land below detail; water stays above overlapping land polygons.
 var layers := {"residential":-1.5,"industrial":-1.4,"forest":-1.3,"wood":-1.3,"grass":-1.2,"scrub":-1.1,"park":-1.0,"garden":-0.9,"cemetery":-0.8,"pitch":-0.7,"beach":-0.6,"water":-0.4}
 for area in areas:
  var polygon := PackedVector2Array()
  for p in area.p:
   polygon.append(Vector2(p[0],p[1]))
  var triangles := Geometry2D.triangulate_polygon(polygon)
  if triangles.is_empty():
   failed_polygons += 1
   continue
  var color := Color(palette.get(area.kind,"#788763"))
  for index in range(0,triangles.size(),3):
   tool.set_normal(Vector3.UP)
   tool.set_color(color)
   for offset in [0,2,1]:
    var p := polygon[triangles[index+offset]]
    tool.add_vertex(Vector3(p.x,float(layers.get(area.kind,-1.6)),p.y))
 tool.index()
 mesh = tool.commit()
 var material := StandardMaterial3D.new()
 material.vertex_color_use_as_albedo = true
 material.roughness = 0.9
 material.cull_mode = BaseMaterial3D.CULL_DISABLED
 material_override = material
 # Claude 17.10 (Release G1 «Графика»): trees in parks, forests, woods, gardens and on larger lawns — low-poly
 # deciduous and spruce trees, one MultiMesh per 300 m cell so the camera only draws the cells it sees.
 plant_trees(areas)
func tree_mesh(spruce: bool) -> ArrayMesh:
 var st := SurfaceTool.new()
 st.begin(Mesh.PRIMITIVE_TRIANGLES)
 var trunk := Color("6b4f3a")
 var leaf := Color("3f6a3a") if spruce else Color("5b8a45")
 var sides := 6
 for i in range(sides):
  var a := TAU*i/sides
  var b := TAU*(i+1)/sides
  var p1 := Vector3(cos(a)*0.25,0,sin(a)*0.25)
  var p2 := Vector3(cos(b)*0.25,0,sin(b)*0.25)
  var n := Vector3(cos((a+b)/2),0,sin((a+b)/2))
  st.set_color(trunk); st.set_normal(n)
  for p in [p1,p2+Vector3.UP*2.2,p2,p1,p1+Vector3.UP*2.2,p2+Vector3.UP*2.2]:
   st.add_vertex(p)
 var layers := [[1.6,2.2,4.2],[0.0,0.0,0.0]] if not spruce else [[1.2,1.8,4.0],[3.0,1.3,5.6],[4.6,0.8,7.2]]
 for layer in layers:
  if layer[1]<=0.0:
   continue
  var base_y: float = layer[0]
  var radius: float = layer[1]*(1.6 if not spruce else 1.0)
  var top_y: float = layer[2]+(1.6 if not spruce else 0.0)
  for i in range(8):
   var a := TAU*i/8
   var b := TAU*(i+1)/8
   var p1 := Vector3(cos(a)*radius,base_y,sin(a)*radius)
   var p2 := Vector3(cos(b)*radius,base_y,sin(b)*radius)
   var top := Vector3(0,top_y,0)
   var n := (p2-p1).cross(top-p1).normalized()
   if n.y<0:
    n = -n
   st.set_color(leaf.lightened(0.08*(i%2))); st.set_normal(n)
   for p in [p1,top,p2]:
    st.add_vertex(p)
   # a round-ish crown for leaf trees: a second, lower cone upside down
   if not spruce:
    var bottom := Vector3(0,base_y-1.2,0)
    st.set_normal(-n)
    for p in [p1,p2,bottom]:
     st.add_vertex(p)
 return st.commit()
func plant_trees(areas: Array) -> void:
 var density := {"park":1.0/260.0,"forest":1.0/90.0,"wood":1.0/90.0,"garden":1.0/320.0,"cemetery":1.0/200.0,"grass":1.0/1400.0,"scrub":1.0/700.0}
 var cells := {}
 var rng := RandomNumberGenerator.new()
 rng.seed = 1707
 var total := 0
 for area in areas:
  if not density.has(area.kind):
   continue
  var polygon := PackedVector2Array()
  for p in area.p:
   polygon.append(Vector2(p[0],p[1]))
  var box := Rect2(polygon[0],Vector2.ZERO)
  for p in polygon:
   box = box.expand(p)
  var count := mini(int(box.get_area()*density[area.kind]),400)
  for k in range(count):
   var p := Vector2(rng.randf_range(box.position.x,box.end.x),rng.randf_range(box.position.y,box.end.y))
   if not Geometry2D.is_point_in_polygon(p,polygon):
    continue
   var key := Vector2i(int(floor(p.x/300.0)),int(floor(p.y/300.0)))
   if not cells.has(key):
    cells[key] = []
   cells[key].append([p,rng.randf_range(0.75,1.3),rng.randf()*TAU,area.kind in ["forest","wood"] and rng.randf()<0.6])
   total += 1
   if total>=7000:
    break
  if total>=7000:
   break
 var meshes := [tree_mesh(false),tree_mesh(true)]
 var material := StandardMaterial3D.new()
 material.vertex_color_use_as_albedo = true
 material.roughness = 0.95
 for key in cells:
  for kind in [0,1]:
   var items: Array = cells[key].filter(func(x): return int(x[3])==kind)
   if items.is_empty():
    continue
   var mm := MultiMesh.new()
   mm.transform_format = MultiMesh.TRANSFORM_3D
   mm.mesh = meshes[kind]
   mm.instance_count = items.size()
   for i in range(items.size()):
    var it: Array = items[i]
    var basis := Basis(Vector3.UP,it[2]).scaled(Vector3.ONE*it[1])
    mm.set_instance_transform(i,Transform3D(basis,Vector3(it[0].x,-1.0,it[0].y)))
   var node := MultiMeshInstance3D.new()
   node.multimesh = mm
   node.material_override = material
   node.visibility_range_end = 900.0
   node.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
   add_child(node)
