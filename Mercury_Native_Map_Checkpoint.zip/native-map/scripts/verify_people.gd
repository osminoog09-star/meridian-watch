extends SceneTree
# Claude 17.10 (Release O2 «Жители-личности»): in the native core the people of calls are people of the city and
# are remembered; the native UI opens «Люди города» and a dossier.
const Core = preload("res://scripts/simulation_core.gd")
const Controller = preload("res://scripts/native_ui_controller.gd")
var failed := false
func check(ok: bool,message: String) -> void:
 if not ok:
  failed = true
  push_error(message)
func find(nodes: Array,pred: Callable) -> Dictionary:
 for item in nodes:
  if pred.call(item):
   return item
  var f := find(item.get("children",[]),pred)
  if not f.is_empty():
   return f
 return {}
func _initialize() -> void:
 var core = Core.new()
 if not core.initialize():
  quit(1)
  return
 core.invoke({"op":"create","mode":"career","seed":7182,"options":{"schedule":"ppa"}})
 var named := false
 for k in range(4000):
  core.invoke({"op":"tick","dt":0.5})
  if k%200==0:
   for i in core.state().get("incidents",[]):
    for a in i.get("scene",{}).get("participants",[]):
     if a.has("citizen") and str(a.get("name","")).contains(" "):
      named = true
 var state: Dictionary = core.state()
 check(named,"participants are people of the city with a first and last name")
 check(state.get("people",{}).size()>3,"people met on the shift are remembered")
 var ui = Controller.new()
 if not ui.initialize({"meridian-watch-v1":core.serialize()}):
  check(false,"the UI did not start")
 else:
  ui.action({"op":"event","domId":"continueBtn","event":"click"})
  ui.action({"op":"event","domId":"mobileMenu","event":"click"})
  ui.action({"op":"event","domId":"menuPeople","event":"click"})
  var tree: Array = ui.snapshot.get("tree",[])
  check(JSON.stringify(tree).contains("Кого вы встречали"),"the people list opens")
  var row := find(tree,func(x): return str(x.get("domId","")).begins_with("personRow-"))
  check(not row.is_empty(),"a person in the list")
  if not row.is_empty():
   ui.action({"op":"event","domId":row.domId,"event":"click"})
   check(JSON.stringify(ui.snapshot.get("tree",[])).contains("ДОСЬЕ"),"the dossier opens")
 print("People: named people of the city, remembered, list and dossier in the native UI ","FAILED" if failed else "PASSED")
 quit(1 if failed else 0)
