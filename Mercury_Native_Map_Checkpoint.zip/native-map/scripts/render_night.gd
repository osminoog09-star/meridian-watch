extends SceneTree
# Claude audit tool: fast-forward a shift to dusk and night and render the crew with headlights and beacons.
# Usage: xvfb-run Godot --path . --rendering-driver opengl3 --resolution 794x926 --script scripts/render_night.gd -- --native-ui --out DIR [--service Скорая]
var scene
var out := ""
func find(nodes: Array,pred: Callable) -> Dictionary:
 for item in nodes:
  if pred.call(item):
   return item
  var f := find(item.get("children",[]),pred)
  if not f.is_empty():
   return f
 return {}
func text_of(n: Dictionary) -> String:
 var t := str(n.get("text",""))
 for c in n.get("children",[]):
  t += " "+text_of(c)
 return t
func press(prefix: String) -> void:
 var n := find(scene.campaign.snapshot.tree,func(x): return x.get("tag")=="button" and text_of(x).strip_edges().begins_with(prefix))
 if not n.is_empty():
  scene.campaign.action({"op":"event","id":n.id,"event":"click"})
func dom(id: String) -> void:
 scene.campaign.action({"op":"event","domId":id,"event":"click"})
func wait(n: int) -> void:
 for i in range(n):
  await process_frame
func shot(name: String) -> void:
 await RenderingServer.frame_post_draw
 root.get_texture().get_image().save_png(out+"/"+name+".png")
 var minute := int(scene.campaign.view().get("absoluteMinute",0))%1440
 print("shot ",name," ",minute/60,":",minute%60," darkness ",scene.campaign.view().get("lighting",{}).get("darkness"))
func minute() -> int:
 return int(scene.campaign.view().get("absoluteMinute",0))%1440
func _initialize() -> void:
 call_deferred("run")
func run() -> void:
 var args := OS.get_cmdline_user_args()
 out = args[args.find("--out")+1]
 scene = load("res://main.tscn").instantiate()
 root.add_child(scene)
 await wait(30)
 scene.campaign.initialize({})
 scene.campaign.store.path = "user://render-night.json"
 await wait(10)
 if args.has("--service"):
  press(args[args.find("--service")+1])
 dom("startCareer")
 await wait(10)
 dom("closeModal")
 press("Понятно")
 press("60×")
 var started := Time.get_ticks_msec()
 for target in [[17*60+40,"dusk"],[19*60+30,"night"]]:
  var report := Time.get_ticks_msec()
  while minute()<target[0] and Time.get_ticks_msec()-started<1500000:
   await process_frame
   if Time.get_ticks_msec()-report>20000:
    report = Time.get_ticks_msec()
    print("time ",minute()/60,":",minute()%60," speed ",scene.campaign.snapshot.get("status",{}).get("speed")," modal ",scene.native_ui.modal_open)
    if scene.native_ui.modal_open:
     dom("closeModal")
     press("60×")
   if minute()<480:
    break
  press("1×")
  await wait(10)
  dom("followUnit")
  press("+")
  await wait(40)
  await shot("night-"+target[1]+"-close")
  press("−")
  press("−")
  await wait(40)
  await shot("night-"+target[1]+"-wide")
  press("60×")
 quit(0)
