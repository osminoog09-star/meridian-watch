extends SceneTree
var failed := false
func _initialize() -> void:
 call_deferred("verify")
func check(value: bool,message: String) -> void:
 if not value:
  failed = true
  push_error(message)
func verify() -> void:
 var scene = load("res://main.tscn").instantiate()
 root.add_child(scene)
 for i in range(8):
  await process_frame
 scene.campaign.initialize({})
 var ui = scene.native_ui
 scene.campaign.action({"op":"event","domId":"startCareer","event":"click"})
 scene.campaign.action({"op":"event","domId":"closeModal","event":"click"})
 for width in [360,740]:
  root.size = Vector2i(width,724)
  ui.signature = ""
  ui.refresh()
  for i in range(8):
   await process_frame
  var header = ui.get_node_or_null("ShiftHeader")
  var footer = ui.get_node_or_null("ShiftTransport")
  if header==null or footer==null:
   push_error("HUD absent; page="+ui.scroll.page)
   quit(1)
   return
  check(header.position.y+header.size.y<=170,"HUD exceeds compact header budget")
  check(header.size.x<=width-16,"Header exceeds narrow screen")
  print("GEOMETRY ",width," ",header.size," ",footer.size)
  check(footer.position.y+footer.size.y<=724,"Footer exceeds screen")
  # Claude 17.10 (Release V «Новый интерфейс»): the top bar shows time, weather, the player's rank, pause and speed;
  # trust, budget and the resolved count are for the chief and the report; FPS is in «FPS и диагностика».
  for id in ["clock","ShiftWeather","ShiftRank","SpeedCycle"]:
   var item = header.find_child(id,true,false)
   check(item!=null and not item.text.is_empty(),"Missing in the top bar: "+id)
  for id in ["budget","resolved","NativeFPS"]:
   check(header.find_child(id,true,false)==null,"Clutter back in the top bar: "+id)
  check(footer.find_child("RadioText",true,false)!=null,"Radio missing")
  check(footer.find_child("ContextCard",true,false)!=null,"The context card is missing")
  var tabs = footer.find_child("MainTabs",true,false)
  check(tabs!=null and tabs.get_child_count()==4,"Four tabs")
 print("HUD checks ","FAILED" if failed else "PASSED")
 quit(1 if failed else 0)
