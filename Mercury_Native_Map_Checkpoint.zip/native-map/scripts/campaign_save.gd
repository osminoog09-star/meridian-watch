extends RefCounted
var path := "user://mercury-campaign.json"
func read_one(file_path: String) -> String:
 if not FileAccess.file_exists(file_path):
  return ""
 var parser := JSON.new()
 if parser.parse(FileAccess.get_file_as_string(file_path))!=OK:
  return ""
 var envelope = parser.data
 if typeof(envelope)!=TYPE_DICTIONARY or envelope.get("schema")!=1 or typeof(envelope.get("payload"))!=TYPE_STRING:
  return ""
 var payload: String = envelope.payload
 if payload.sha256_text()!=envelope.get("sha256"):
  return ""
 return payload
func read_save() -> String:
 var result := read_one(path)
 return read_one(path+".backup") if result.is_empty() else result
func write_save(payload: String) -> Error:
 if typeof(JSON.parse_string(payload))!=TYPE_DICTIONARY:
  return ERR_INVALID_DATA
 var pending := path+".pending"
 var file := FileAccess.open(pending,FileAccess.WRITE)
 if file==null:
  return FileAccess.get_open_error()
 file.store_string(JSON.stringify({"schema":1,"payload":payload,"sha256":payload.sha256_text()}))
 file.flush()
 var error := file.get_error()
 file.close()
 if error!=OK:
  return error
 if FileAccess.file_exists(path) and not read_one(path).is_empty():
  error = DirAccess.copy_absolute(path,path+".backup")
  if error!=OK:
   return error
 return DirAccess.rename_absolute(pending,path)
