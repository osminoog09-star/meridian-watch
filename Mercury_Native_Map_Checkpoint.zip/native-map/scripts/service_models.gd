extends RefCounted
const Geometry = preload("res://scripts/city_geometry.gd")
static func box(st: SurfaceTool,centre: Vector3,size: Vector3,color: Color) -> void:
 var geometry = Geometry.new()
 for axis in range(3):
  for sign_value in [-1.0,1.0]:
   var normal := Vector3.ZERO
   normal[axis] = sign_value
   var u := Vector3.ZERO
   var v := Vector3.ZERO
   u[(axis+1)%3] = size[(axis+1)%3]*0.5
   v[(axis+2)%3] = size[(axis+2)%3]*0.5
   var c := centre+normal*size[axis]*0.5
   geometry.quad(st,c-u-v,c+u-v,c+u+v,c-u+v,color,normal)
static func build(base: Mesh,kind: String) -> Mesh:
 var st := SurfaceTool.new()
 st.begin(Mesh.PRIMITIVE_TRIANGLES)
 st.append_from(base,0,Transform3D.IDENTITY)
 var paint := Color("f5e7b8") if kind=="ambulance" else Color("b64336")
 box(st,Vector3(-0.75,1.55,0),Vector3(2.75,1.8,1.95),paint)
 for side in [-1.0,1.0]:
  box(st,Vector3(-0.75,1.2,side*0.984),Vector3(2.6,0.19,0.025),Color("b44842") if kind=="ambulance" else Color("e5ded1"))
  if kind=="ambulance":
   box(st,Vector3(-0.9,1.95,side*0.99),Vector3(0.65,0.19,0.025),Color("b44842"))
   box(st,Vector3(-0.9,1.95,side*0.995),Vector3(0.19,0.65,0.025),Color("b44842"))
  else:
   box(st,Vector3(-0.7,1.77,side*0.989),Vector3(1.8,0.65,0.025),Color("999f9f"))
 box(st,Vector3(0.5,2.15,0),Vector3(0.35,0.18,1.2),Color("3886d7"))
 st.index()
 return st.commit()
