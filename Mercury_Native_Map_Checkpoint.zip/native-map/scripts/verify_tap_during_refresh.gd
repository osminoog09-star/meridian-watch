extends SceneTree
# Claude 16.10: a tap on a bottom-bar / speed / map button must work while the game runs — the HUD is rebuilt whenever
# the snapshot changes (the clock changes every game second), and a rebuild between finger-down and finger-up lost the tap.
var failed := false
func _initialize() -> void:
 call_deferred("verify")
func frames(n: int) -> void:
 for i in range(n):
  await process_frame
func find_button(node: Node,prefix: String) -> Button:
 for child in node.get_children():
  if child is Button and child.is_visible_in_tree() and child.text.replace("\n"," ").strip_edges().begins_with(prefix):
   return child
  var found = find_button(child,prefix)
  if found!=null:
   return found
 return null
func touch(at: Vector2,pressed: bool) -> void:
 var e := InputEventScreenTouch.new()
 e.index = 0
 e.position = at
 e.pressed = pressed
 Input.parse_input_event(e)
func verify() -> void:
 root.size = Vector2i(369,905)
 var scene = load("res://main.tscn").instantiate()
 root.add_child(scene)
 await frames(8)
 var ui = scene.native_ui
 var c = scene.campaign
 c.initialize({})
 c.store.path = "user://tap-refresh-verification.json"
 c.action({"op":"event","domId":"startCareer","event":"click"})
 c.action({"op":"event","domId":"closeModal","event":"click"})
 await frames(20)
 for label in ["▣","1× ▸","Вызовы"]:  # Release U: the speed is one button that steps to the next speed
  var button := find_button(ui,label)
  if button==null:
   failed = true
   push_error("no button "+label)
   continue
  var at: Vector2 = button.get_global_rect().get_center()
  var tab_before: String = str(c.snapshot.get("status",{}).get("tab"))
  var speed_before = c.snapshot.get("status",{}).get("speed")
  touch(at,true)
  # The game runs while the finger is down: several snapshot changes and HUD refreshes.
  for k in range(12):
   await frames(1)
  touch(at,false)
  await frames(6)
  var tab_after: String = str(c.snapshot.get("status",{}).get("tab"))
  var speed_after = c.snapshot.get("status",{}).get("speed")
  var worked: bool = (label=="1× ▸" and speed_after==2.0) or (label=="▣" and tab_after=="units") or (label=="Вызовы" and tab_after=="calls")
  print(label,": tab ",tab_before,"→",tab_after," speed ",speed_before,"→",speed_after," ",("OK" if worked else "LOST"))
  if not worked:
   failed = true
   push_error("tap on «%s» lost while the HUD refreshed" % label)
 print("Tap during refresh ","FAILED" if failed else "PASSED")
 quit(1 if failed else 0)
