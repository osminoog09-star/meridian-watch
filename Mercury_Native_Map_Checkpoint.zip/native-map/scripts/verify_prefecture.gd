extends SceneTree
# Claude 16.10 (Release M): the prefecture's rapid response team in the native core — an armed call brings
# the team (a dark police SUV on the map), the patrol keeps distance, the call closes; a career officer
# transferred to the team takes only its calls; the native call list names the armed call.
const Core = preload("res://scripts/simulation_core.gd")
const Controller = preload("res://scripts/native_ui_controller.gd")
var failed := false
func check(ok: bool,message: String) -> void:
 if not ok:
  failed = true
  push_error(message)
func find_call(core,id: int) -> Dictionary:
 for i in core.state().get("incidents",[]):
  if int(i.id)==id:
   return i
 return {}
func _initialize() -> void:
 var core = Core.new()
 if not core.initialize():
  quit(1)
  return
 core.invoke({"op":"create","mode":"career","seed":7182,"options":{"schedule":"ppa"}})
 var point = null
 for k in range(4000):
  core.invoke({"op":"tick","dt":0.5})
  var incidents: Array = core.state().get("incidents",[])
  if not incidents.is_empty():
   point = {"x":incidents[0].x,"y":incidents[0].y}
   break
 check(point!=null,"no ordinary call to take a point from")
 var armed_id := -1
 for k in range(40):
  var incident = core.invoke({"op":"command","name":"spawnIncident","args":[null,{"variant":"street-fight","point":point}]})
  if typeof(incident)==TYPE_DICTIONARY and incident.get("armed","")=="knife":
   armed_id = int(incident.id)
   break
 check(armed_id>0,"no armed call in 40 spawns")
 var save_for_ui := ""
 if armed_id>0:
  core.invoke({"op":"tick","dt":0.5})
  save_for_ui = core.serialize()
  var team := false
  for a in core.state().get("services",[]):
   if str(a.kind)=="gbr" and int(a.incident)==armed_id:
    team = true
  check(team,"the command centre sent the rapid response team")
  var closed := false
  for k in range(8000):
   core.invoke({"op":"tick","dt":0.5})
   if k%100==0:
    var call := find_call(core,armed_id)
    if call.is_empty() or call.get("state") in ["resolved","missed"]:
     closed = call.is_empty() or (call.get("state")=="resolved" and call.get("gbr")=="onscene")
     break
  check(closed,"the armed call closed with the team on scene")
 # A career officer in the rapid response team: only its calls.
 core.invoke({"op":"create","mode":"career","seed":4242,"options":{"schedule":"ppa"}})
 var raw: Dictionary = JSON.parse_string(core.serialize())
 raw.life.role = "rapid"
 raw.rank = 2
 core.invoke({"op":"load","save":JSON.stringify(raw)})
 var allowed := ["street-fight","fan-fight","domestic","restraining-order","suspect-found","vehicle-alert","dangerous-driving","alarm-burglary"]
 var taken := {}
 for k in range(3000):
  core.invoke({"op":"tick","dt":0.5})
  if k%10==0:
   var state: Dictionary = core.state()
   for u in state.get("units",[]):
    if int(u.id)==1 and u.get("incident")!=null:
     for i in state.get("incidents",[]):
      if int(i.id)==int(u.incident):
       taken[str(i.get("variant",""))] = true
   if state.get("ended",false):
    break
 check(not taken.is_empty(),"the team got calls")
 for v in taken.keys():
  check(v in allowed,"the team took a patrol call: "+v)
 # The native call list names the armed call.
 var ui = Controller.new()
 if save_for_ui.is_empty() or not ui.initialize({}):
  check(false,"no save for the UI")
 else:
  ui._legacy_storage_ready(JSON.stringify({"meridian-watch-v1":save_for_ui}),"")
  ui.action({"op":"event","domId":"resumeBtn","event":"click"})
  ui.action({"op":"event","domId":"continueBtn","event":"click"})
  check(JSON.stringify(ui.snapshot.get("tree",[])).contains("Нож: "),"the call list names the armed call")
 print("Prefecture: an armed call brings the rapid response team and closes with it; the team in a career takes only its calls; the native call list names the armed call")
 quit(1 if failed else 0)
