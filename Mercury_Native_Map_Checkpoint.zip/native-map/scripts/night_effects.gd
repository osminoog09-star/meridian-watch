extends Node3D
# Bounded native night details built only from already streamed source tiles.
const WINDOW_CAP := 192
const LAMP_CAP := 48
var windows := MultiMeshInstance3D.new()
var bulbs := MultiMeshInstance3D.new()
var poles := MultiMeshInstance3D.new()
var pools := MultiMeshInstance3D.new()
var last_focus := Vector3.INF
var last_tiles := -1
func batch(node: MultiMeshInstance3D,capacity: int,size: Vector3,color: Color,glowing: bool) -> void:
 var data := MultiMesh.new()
 data.transform_format = MultiMesh.TRANSFORM_3D
 var box := BoxMesh.new()
 box.size = size
 data.mesh = box
 data.instance_count = capacity
 data.visible_instance_count = 0
 node.multimesh = data
 var material := StandardMaterial3D.new()
 material.albedo_color = color
 if glowing:
  material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
 node.material_override = material
 node.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
 add_child(node)
func _ready() -> void:
 batch(windows,WINDOW_CAP,Vector3(1,1.1,0.035),Color("edcc83"),true)
 batch(bulbs,LAMP_CAP,Vector3(0.65,0.12,0.4),Color("ffedc3"),true)
 batch(poles,LAMP_CAP,Vector3(0.12,6,0.12),Color("58636a"),false)
 batch(pools,LAMP_CAP,Vector3(6,0.014,3),Color("a7a082"),false)
func configure(stream: Node3D,focus: Vector3,distance: float,night: bool,enabled: bool) -> void:
 visible = enabled and distance<650
 windows.visible = night
 bulbs.visible = night
 pools.visible = night
 if not visible or stream==null:
  return
 if last_focus.distance_to(focus)<60 and last_tiles==stream.cache.size():
  return
 last_focus = focus
 last_tiles = stream.cache.size()
 var w := 0
 var l := 0
 var candidates: Array = []
 for tile in stream.tiles:
  if stream.cache.has(tile.key):
   candidates.append(tile)
 candidates.sort_custom(func(a,b):
  var aa: PackedStringArray = str(a.key).split(",")
  var bb: PackedStringArray = str(b.key).split(",")
  return Vector3((int(aa[0])+0.5)*250,0,(int(aa[1])+0.5)*250).distance_squared_to(focus)<Vector3((int(bb[0])+0.5)*250,0,(int(bb[1])+0.5)*250).distance_squared_to(focus))
 for tile in candidates:
  for building in tile.buildings:
   var ring: Array = building.ring
   var poly := PackedVector2Array()
   for point in ring:
    poly.append(Vector2(point[0],point[1]))
   if Geometry2D.is_polygon_clockwise(poly):
    poly.reverse()
   for edge in range(poly.size()):
    var a := Vector3(poly[edge].x,0,poly[edge].y)
    var end: Vector2 = poly[(edge+1)%poly.size()]
    var b := Vector3(end.x,0,end.y)
    if a.distance_to(focus)>420 or w>=WINDOW_CAP:
     continue
    var tangent := (b-a).normalized()
    var normal := Vector3(tangent.z,0,-tangent.x)
    var count := mini(12,int(a.distance_to(b)/3))
    for floor_index in range(int(building.floors)):
     var height := 1.55+floor_index*3
     if height+0.55>float(building.height):
      continue
     for index in range(count):
      if w>=WINDOW_CAP or (index+floor_index+edge)%3!=0:
       continue
      var centre := a+(b-a)*((index+0.5)/count)+normal*0.06+Vector3.UP*height
      windows.multimesh.set_instance_transform(w,Transform3D(Basis(tangent,Vector3.UP,normal),centre))
      w += 1
  for road in tile.roads:
   if l>=LAMP_CAP or not road.drive or road.bridge:
    continue
   var a := Vector3(road.a[0],0,road.a[1])
   var b := Vector3(road.b[0],0,road.b[1])
   if a.distance_to(b)<22:
    continue
   var centre := (a+b)*0.5
   if centre.distance_to(focus)>420:
    continue
   var side := (b-a).normalized().cross(Vector3.UP)
   var point := centre+side*(float(road.edgeWidth)*0.5+0.6)
   poles.multimesh.set_instance_transform(l,Transform3D(Basis(),point+Vector3.UP*3))
   bulbs.multimesh.set_instance_transform(l,Transform3D(Basis(),point+Vector3.UP*6))
   pools.multimesh.set_instance_transform(l,Transform3D(Basis(Vector3.UP,atan2(side.x,side.z)),centre+Vector3.UP*0.125))
   l += 1
 windows.multimesh.visible_instance_count = w
 for node in [bulbs,poles,pools]:
  node.multimesh.visible_instance_count = l
