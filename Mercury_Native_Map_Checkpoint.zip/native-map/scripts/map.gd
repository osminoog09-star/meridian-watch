extends Node3D
const Stream = preload("res://scripts/city_stream.gd")
const Onlookers = preload("res://scripts/onlookers.gd")
var annotations: Control
var onlookers: Node3D
var live_actors: Node3D
var following := false
var city_stream: Node3D
const CampaignPanel = preload("res://scripts/campaign_panel.gd")
var campaign_panel: PanelContainer
const Campaign = preload("res://scripts/campaign_controller.gd")
var campaign = Campaign.new()
var native_ui_mode := false
var native_ui: Control
var campaign_ready := false
var campaign_view: Dictionary = {}
var simulation_snapshot_elapsed := 0.0
var sun_light: DirectionalLight3D
var weather_effects: Node3D
var walking_overlay: Node3D
var night_effects: Node3D
var fireworks: MultiMeshInstance3D
var graphics_quality := "models"
var native_render_report: Dictionary = {"native":true}
var sky_environment: WorldEnvironment
const Geometry = preload("res://scripts/city_geometry.gd")
const Patrol = preload("res://scripts/patrol.gd")
const Marker = preload("res://scripts/patrol_marker.gd")
const Metrics = preload("res://scripts/frame_metrics.gd")
const GAME_SPEEDS = [1,2,4,10,30,60]
var metrics = Metrics.new()
var clock_label: Label
var fps_label: Label
var elapsed := 0.0
var reporting := 0.0
var patrol: Node3D
const RoadGraph = preload("res://scripts/road_graph.gd")
var camera: Camera3D
var yaw := 0.0
var distance := 650.0
var tap_origin := Vector2.ZERO
var tap_candidate := false
var focus := Vector3.ZERO
var touches: Dictionary = {}
var geometry = Geometry.new()
var tile_count := 0
var stats: Dictionary = {}
func _ready() -> void:
 native_ui_mode = OS.has_feature("android") or "--native-ui" in OS.get_cmdline_user_args()
 if native_ui_mode:
  campaign = preload("res://scripts/native_ui_controller.gd").new()
 configure_mobile_scale()
 get_tree().root.size_changed.connect(configure_mobile_scale)
 var began := Time.get_ticks_msec()
 var data = JSON.parse_string(FileAccess.get_file_as_string("res://assets/map.json"))
 var ground := MeshInstance3D.new()
 var plane := PlaneMesh.new()
 plane.size = Vector2(24000,24000)
 ground.mesh = plane
 var ground_mat := StandardMaterial3D.new()
 ground_mat.albedo_color = Color("68785e")
 ground.material_override = ground_mat
 ground.position.y = -2.0
 add_child(ground)
 var landuse = preload("res://scripts/landuse.gd").new()
 add_child(landuse)
 var mat := StandardMaterial3D.new()
 mat.vertex_color_use_as_albedo = true
 mat.roughness = 0.9
 if "--verify-map" in OS.get_cmdline_user_args():
  for tile in data.chunks:
   add_child(geometry.chunk(tile,mat))
   tile_count += 1
 else:
  city_stream = Stream.new()
  add_child(city_stream)
 var environment := WorldEnvironment.new()
 environment.environment = Environment.new()
 environment.environment.background_mode = Environment.BG_COLOR
 environment.environment.background_color = Color("a2bcc9")
 environment.environment.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
 environment.environment.ambient_light_color = Color("cbd9df")
 environment.environment.ambient_light_energy = 0.55
 add_child(environment)
 sky_environment = environment
 night_effects = preload("res://scripts/night_effects.gd").new()
 add_child(night_effects)
 fireworks = preload("res://scripts/fireworks.gd").new()
 add_child(fireworks)
 walking_overlay = preload("res://scripts/walking_overlay.gd").new()
 add_child(walking_overlay)
 weather_effects = preload("res://scripts/weather_effects.gd").new()
 add_child(weather_effects)
 var sun := DirectionalLight3D.new()
 sun_light = sun
 sun.rotation_degrees = Vector3(-45,-30,0)
 sun.shadow_enabled = true
 add_child(sun)
 camera = Camera3D.new()
 camera.far = 24000
 camera.current = true
 add_child(camera)
 update_camera()
 live_actors = preload("res://scripts/live_actors.gd").new()
 add_child(live_actors)
 onlookers = Onlookers.new()
 add_child(onlookers)
 patrol = Patrol.new()
 add_child(patrol)
 if not "--verify-map" in OS.get_cmdline_user_args():
  campaign_ready = campaign.initialize()
  if campaign_ready:
   patrol.set_process(false)
   if not native_ui_mode:
    campaign_view = campaign.view()
    refresh_campaign_actors()
   if campaign_panel!=null:
    campaign_panel.refresh(campaign_view)
 var hud := CanvasLayer.new()
 var text := Label.new()
 text.text = "MERCURY · нативная карта\nКарта: движение пальцем · масштаб: два пальца\n© OpenStreetMap contributors · стенд, не готовая игра"
 text.position = Vector2(16,16)
 hud.add_child(text)
 var marker = Marker.new()
 marker.camera = camera
 marker.patrol = patrol
 if native_ui_mode:
  marker.visible = false
  annotations = preload("res://scripts/map_annotations.gd").new()
  annotations.camera = camera
  hud.add_child(annotations)
  for child in patrol.get_children():
   if child is MeshInstance3D:
    child.visible = false
 hud.add_child(marker)
 clock_label = Label.new()
 clock_label.position = Vector2(16,78)
 hud.add_child(clock_label)
 fps_label = Label.new()
 fps_label.position = Vector2(16,99)
 hud.add_child(fps_label)
 var speeds := HBoxContainer.new()
 speeds.add_theme_constant_override("separation",2)
 speeds.position = Vector2(16,182)
 for speed in GAME_SPEEDS:
  var speed_button := Button.new()
  speed_button.text = "×"+str(speed)
  speed_button.custom_minimum_size = Vector2(52,52)
  speed_button.pressed.connect(func(): patrol.time_scale = speed)
  speeds.add_child(speed_button)
 hud.add_child(speeds)
 var row := HBoxContainer.new()
 row.position = Vector2(16,126)
 for action in ["−","+","Центр","Патруль","Город"]:
  var button := Button.new()
  button.text = action
  button.custom_minimum_size = Vector2(52,52)
  button.pressed.connect(func():
   following = action=="Патруль"
   if action=="Центр":
    focus = Vector3.ZERO
    distance = 650
   elif action=="Город":
    distance = 14000
   elif action=="Патруль":
    focus = patrol.position
    distance = 90
   else:
    distance = clampf(distance*(1.2 if action=="−" else 0.8),35,16000)
   update_camera())
  row.add_child(button)
 hud.add_child(row)
 if campaign_ready and not native_ui_mode:
  campaign_panel = CampaignPanel.new()
  campaign_panel.controller = campaign
  hud.add_child(campaign_panel)
 if native_ui_mode and campaign_ready:
  for child in hud.get_children():
   # Claude 15.10: the map symbols (patrol numbers, call icons, the selected route) belong to the native UI too —
   # hiding them with the pilot HUD left the real app without any call or patrol marker.
   if child!=marker and child!=annotations:
    child.hide()
  native_ui = preload("res://scripts/native_ui.gd").new()
  native_ui.controller = campaign
  native_ui.model_factory = live_actors
  hud.add_child(native_ui)
  var audio_player = preload("res://scripts/native_audio.gd").new()
  audio_player.controller = campaign
  audio_player.map = self
  add_child(audio_player)
 add_child(hud)
 if native_ui!=null:
  native_ui.refresh()
 stats = {"tiles":tile_count,"mesh_instances":tile_count+1,"buildings":int(data.buildingCount),"roads":int(data.roads),"road_segments":int(data.segments),"triangles":geometry.triangles,"roofs":geometry.roofs,"failed_roofs":geometry.failed_roofs,"roof_area":geometry.roof_area,"expected_roof_area":geometry.expected_area,"construction_ms":Time.get_ticks_msec()-began}
 if "--verify-map" in OS.get_cmdline_user_args():
  verify()
func _process(delta: float) -> void:
 metrics.add(delta)
 if weather_effects!=null:
  weather_effects.animate(delta)
 if fireworks!=null:
  fireworks.animate(delta)
 if campaign_ready:
  if native_ui_mode:
   campaign.invoke({"op":"camera","scene":{"x":focus.x/1670.0+1.55,"y":focus.z/1670.0+2.52,"zoom":clampf(6500.0/distance,0.2,80),"following":following},"width":get_viewport().get_visible_rect().size.x,"height":get_viewport().get_visible_rect().size.y,"dpr":float(get_tree().root.size.x)/maxf(1,get_viewport().get_visible_rect().size.x),"stats":native_render_report})
  campaign.advance(delta,int(patrol.time_scale))
  if native_ui_mode:
   Engine.max_fps = int(campaign.snapshot.get("status",{}).get("frameRate",30))
   apply_native_camera_commands()
   patrol.time_scale = float(campaign.snapshot.get("status",{}).get("speed",1))
   native_ui.refresh()
  if native_ui_mode:
   campaign_view = campaign.view()
   refresh_campaign_actors()
  simulation_snapshot_elapsed += delta
  if simulation_snapshot_elapsed>=0.1:
   if not native_ui_mode:
    campaign_view = campaign.view()
    refresh_campaign_actors()
   if campaign_panel!=null:
    campaign_panel.refresh(campaign_view)
   simulation_snapshot_elapsed = 0.0
   var minute: float = fmod(float(campaign_view.absoluteMinute),1440)
   var daylight: bool = campaign_view.sun!=null and minute>=campaign_view.sun[0] and minute<campaign_view.sun[1]
   onlookers.quality = graphics_quality
   onlookers.refresh(campaign_view.get("onlookers",[]),focus,distance,not daylight)
   var darkness: float = clampf(float(campaign_view.get("lighting",{}).get("darkness",0.0 if daylight else 0.55))/0.55,0,1)
   var lighting: bool = not native_ui_mode or campaign.snapshot.get("status",{}).get("lightingEnabled",true)
   var calm: bool = native_ui_mode and str(campaign.snapshot.get("bodyClasses","")).contains("a11y-calm")
   weather_effects.configure(campaign_view.get("weather",{}),focus,distance,lighting and not calm)
   night_effects.configure(city_stream,focus,distance,not daylight,lighting and graphics_quality!="simple")
   fireworks.configure(campaign_view.get("fireworks",false) and lighting,calm)
   sky_environment.environment.ambient_light_energy = lerpf(0.55,0.22,darkness) if lighting else 0.55
   sun_light.light_energy = lerpf(1.0,0.12,darkness) if lighting else 1.0
   sky_environment.environment.background_color = Color("a2bcc9").lerp(Color("101723"),darkness if lighting else 0.0)
 elapsed += delta*patrol.time_scale
 reporting += delta
 clock_label.text = "Стенд · %02d:%02d · ×%d" % [int(elapsed/3600)%24,int(elapsed/60)%60,int(patrol.time_scale)]
 if campaign_ready:
  var minute := int(campaign_view.absoluteMinute)%1440
  clock_label.text = "Смена %d · %02d:%02d · ×%d" % [int(campaign_view.shift),int(minute/60),minute%60,int(patrol.time_scale)]
 if reporting>=0.5:
  var report: Dictionary = metrics.report()
  if native_ui_mode:
   report.merge(campaign.device_report(),true)
   report["native"] = true
   report["sampleTime"] = Time.get_ticks_msec()
   report["pixelWidth"] = get_tree().root.size.x*get_viewport().scaling_3d_scale
   report["pixelHeight"] = get_tree().root.size.y*get_viewport().scaling_3d_scale
   native_render_report = report
  if native_ui!=null:
   native_ui.frame_report = report
  fps_label.text = "%.1f FPS · P95 %.1f мс · память %.1f МБ" % [report.fps,report.p95_ms,report.static_memory_bytes/1048576.0]
  reporting = 0.0
func refresh_campaign_actors() -> void:
 patrol.visible = not campaign_view.units.is_empty()
 if not campaign_view.units.is_empty():
  var unit: Dictionary = campaign_view.units[0]
  if native_ui_mode:
   for candidate in campaign_view.units:
    if int(candidate.id)==selected_unit_id():
     unit = candidate
  patrol.position = live_actors.world(unit)
  if unit.has("heading"):
   patrol.rotation.y = -float(unit.heading)
  elif typeof(unit.get("target"))==TYPE_DICTIONARY:
   var target := Vector3((float(unit.target.x)-1.55)*1670,0.04,(float(unit.target.y)-2.52)*1670)
   var direction := target-patrol.position
   if direction.length()>0.01:
    patrol.rotation.y = -atan2(direction.z,direction.x)
 var selected: int = selected_unit_id() if native_ui_mode else 1
 live_actors.lights_enabled = not native_ui_mode or campaign.snapshot.get("status",{}).get("lightingEnabled",true)
 live_actors.flashes_enabled = not native_ui_mode or not str(campaign.snapshot.get("bodyClasses","")).contains("a11y-calm")
 live_actors.refresh(campaign_view,-1 if native_ui_mode else selected,focus,distance)
 if annotations!=null:
  annotations.view = campaign_view
  annotations.selected_unit = selected
  var call_id = campaign.snapshot.get("status",{}).get("selectedCall")
  annotations.selected_call = int(call_id) if call_id!=null else -1
 if following:
  focus = patrol.position
  update_camera()

# Claude 15.10: a new chief campaign has no crew yet — selectedUnit is null; int(null) stopped every actor refresh.
func selected_unit_id() -> int:
 var value = campaign.snapshot.get("status",{}).get("selectedUnit",1)
 return int(value) if value!=null else -1
func verify() -> void:
 var failed := false
 if not geometry.failed_roofs.is_empty() or absf(geometry.roof_area-geometry.expected_area)>0.01 or geometry.roofs!=stats.buildings:
  failed = true
 var graph = RoadGraph.new()
 graph.load_graph("res://assets/routes.json")
 var golden = JSON.parse_string(FileAccess.get_file_as_string("res://assets/route-golden.json"))
 var passed := 0
 for item in golden:
  var result: Dictionary = graph.route(str(item.start),str(item.goal))
  if result.is_empty() or absf(float(result.weight)-float(item.weight))>0.00000001:
   failed = true
   push_error("Native routing parity failed "+str(item)+" result "+str(result.get("weight",-1)))
  else:
   passed += 1
 stats["route_parity_passed"] = passed
 stats["route_nodes"] = graph.nodes.size()
 var route = patrol.route
 patrol.set_process(false)
 var start_position: Vector3 = patrol.position
 patrol.advance(0.1)
 var speed_error: float = absf(patrol.travelled-float(route[1].kmh)/3.6*0.1)
 if speed_error>0.0001:
  failed = true
 stats["patrol_distance_error_m"] = speed_error
 patrol.advance(10000)
 if not patrol.finished:
  failed = true
 stats["patrol_route_finished"] = patrol.finished
 var partition_errors: Array = []
 for speed in GAME_SPEEDS:
  patrol.reset_route()
  for frame in range(120):
   patrol.advance(speed/60.0)
  var fine_position: Vector3 = patrol.position
  var fine_travel: float = patrol.travelled
  patrol.reset_route()
  for frame in range(30):
   patrol.advance(speed/15.0)
  var error: float = fine_position.distance_to(patrol.position)
  partition_errors.append(error)
  if error>0.002 or absf(fine_travel-patrol.travelled)>0.002:
   failed = true
 stats["speed_partition_errors_m"] = partition_errors
 var test_metrics = Metrics.new()
 for frame in range(900):
  test_metrics.add(1.0/60.0)
 var metrics_result: Dictionary = test_metrics.report()
 if metrics_result.samples!=600 or absf(metrics_result.fps-60.0)>0.0001:
  failed = true
 stats["metrics_bounded_samples"] = metrics_result.samples
 patrol.position = start_position
 var file := FileAccess.open("res://verification.json",FileAccess.WRITE)
 file.store_string(JSON.stringify(stats,"  "))
 print(JSON.stringify(stats))
 get_tree().quit(1 if failed else 0)
func update_camera() -> void:
 # Keep depth precision across street and whole-city zoom on mobile GPUs.
 camera.near = maxf(0.5,distance*0.1)
 camera.far = maxf(2000.0,distance*3.0+2000.0)
 camera.position = focus+Vector3(sin(yaw)*distance,distance*0.75,cos(yaw)*distance)
 camera.look_at(focus)
 if city_stream!=null:
  city_stream.request_view(focus,distance)
func _unhandled_input(event: InputEvent) -> void:
 if event is InputEventScreenTouch:
  if event.pressed:
   touches[event.index] = event.position
   tap_origin = event.position
   tap_candidate = touches.size()==1
  else:
   if tap_candidate and touches.size()==1 and event.position.distance_to(tap_origin)<12:
    pick_map(event.position)
   tap_candidate = false
   touches.erase(event.index)
 if event is InputEventScreenDrag:
  if event.position.distance_to(tap_origin)>=12:
   tap_candidate = false
  if touches.size()==2 and touches.has(event.index):
   var ids := touches.keys()
   var other = ids[1] if ids[0]==event.index else ids[0]
   var old_length: float = touches[event.index].distance_to(touches[other])
   var new_length: float = event.position.distance_to(touches[other])
   if new_length>10 and old_length>10:
    distance = clampf(distance*old_length/new_length,35,16000)
  elif touches.size()<=1:
   pan_camera(event.relative)
  touches[event.index] = event.position
  update_camera()
 if event is InputEventMouseMotion and event.button_mask & MOUSE_BUTTON_MASK_LEFT:
  if event.button_mask & MOUSE_BUTTON_MASK_RIGHT:
   yaw -= event.relative.x*0.005
  else:
   pan_camera(event.relative)
  update_camera()
 if event is InputEventMouseButton and event.pressed:
  if event.button_index==MOUSE_BUTTON_WHEEL_UP:
   distance = maxf(35,distance*0.9)
  elif event.button_index==MOUSE_BUTTON_WHEEL_DOWN:
   distance = minf(16000,distance*1.1)
  update_camera()

func pan_camera(relative: Vector2) -> void:
 following = false
 var scale: float = distance/maxf(1,get_viewport().get_visible_rect().size.y)
 var right: Vector3 = camera.global_transform.basis.x
 var forward: Vector3 = camera.global_transform.basis.z
 forward.y = 0
 forward = forward.normalized()
 focus -= (right*relative.x+forward*relative.y)*scale*1.5
 focus.y = 0

func _notification(what: int) -> void:
 if campaign_ready and native_ui_mode and what==NOTIFICATION_APPLICATION_RESUMED:
  campaign.invoke({"op":"foreground"})
 if campaign_ready and (what==NOTIFICATION_APPLICATION_PAUSED or what==NOTIFICATION_WM_CLOSE_REQUEST):
  if native_ui_mode:
   campaign.background()
  else:
   campaign.save()

func apply_native_camera_commands() -> void:
 for command in campaign.snapshot.get("map",[]):
  match command.op:
   "zoom": distance = clampf(distance*(0.8 if float(command.value)>0 else 1.2),35,16000)
   "reset": following = false; distance = 14000
   "city": following = false; distance = 650
   "quarter": following = false; distance = 90
   "follow": following = true; distance = 90
   "locate":
    following = false
    if typeof(command.value)==TYPE_DICTIONARY:
     focus = Vector3((float(command.value.x)-1.55)*1670,0,(float(command.value.y)-2.52)*1670)
   "lighting": sun_light.visible = bool(command.value)
   "quality":
    graphics_quality = str(command.value)
    sun_light.shadow_enabled = graphics_quality=="models"
    live_actors.set_quality(graphics_quality)
    if city_stream!=null:
     city_stream.detail_enabled = graphics_quality=="models"
   "resolution": get_viewport().scaling_3d_scale = clampf(float(command.value)/2.0,0.5,1.0)
   "walking":
    walking_overlay.visible = bool(command.value)
    walking_overlay.show_route([])
   "walking-route": walking_overlay.show_route(command.value)
  update_camera()
 campaign.snapshot["map"] = []

func configure_mobile_scale() -> void:
 if not OS.has_feature("android"):
  return
 var dpi := 160.0
 if Engine.has_singleton("MercuryAndroid"):
  var report = JSON.parse_string(Engine.get_singleton("MercuryAndroid").deviceDiagnostics())
  if typeof(report)==TYPE_DICTIONARY:
   dpi = float(report.get("densityDpi",160))
 var window := get_tree().root
 var logical_size := Vector2i(Vector2(window.size)/maxf(1,dpi/160.0))
 if window.content_scale_size!=logical_size:
  window.content_scale_size = logical_size
  window.content_scale_mode = Window.CONTENT_SCALE_MODE_CANVAS_ITEMS

func pick_map(point: Vector2) -> void:
 if not native_ui_mode or not campaign_ready:
  return
 if walking_overlay.visible:
  var ray := camera.project_ray_normal(point)
  if absf(ray.y)>0.00001:
   var origin := camera.project_ray_origin(point)
   var location := origin+ray*(-origin.y/ray.y)
   campaign.action({"op":"walking-pick","point":{"x":location.x/1670.0+1.55,"y":location.z/1670.0+2.52}})
  return
 annotations.view = campaign.view()
 var hit: Dictionary = annotations.pick(point)
 if not hit.is_empty():
  campaign.action({"op":"pick","hit":hit})
  native_ui.signature = ""
  native_ui.refresh()
