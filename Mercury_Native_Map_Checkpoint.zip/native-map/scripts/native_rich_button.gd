extends Button
var content: Control
func set_content(value: Control) -> void:
 content = value
 add_child(content)
 ignore_pointer(content)
 content.minimum_size_changed.connect(reflow.call_deferred)
 resized.connect(reflow.call_deferred)
 reflow.call_deferred()
func ignore_pointer(node: Node) -> void:
 if node is Control:
  node.mouse_filter = Control.MOUSE_FILTER_IGNORE
  node.focus_mode = Control.FOCUS_NONE
 for child in node.get_children():
  ignore_pointer(child)
func reflow() -> void:
 if not is_instance_valid(content):
  return
 content.position = Vector2(12,12)
 content.size.x = maxf(1,size.x-24)
 custom_minimum_size.y = maxf(52,content.get_combined_minimum_size().y+24)
 content.size.y = content.get_combined_minimum_size().y
