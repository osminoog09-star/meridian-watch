extends Control
# Screen-space map symbols stay readable without intercepting gestures.
const Elevation = preload("res://scripts/road_elevation.gd")
var camera: Camera3D
var view: Dictionary = {}
var selected_unit := -1
var selected_call := -1
var hits: Array[Dictionary] = []
var symbols: Array[Dictionary] = []
var route_lines: Array[PackedVector2Array] = []
var height_cache: Dictionary = {}

func _ready() -> void:
 mouse_filter = Control.MOUSE_FILTER_IGNORE
 set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

func world(p: Dictionary) -> Vector3:
 var v := Vector3((float(p.get("x",1.55))-1.55)*1670,0.12,(float(p.get("y",2.52))-2.52)*1670)
 var key := Vector2(v.x,v.z)
 if not height_cache.has(key):
  if height_cache.size()>=8192:
   height_cache.clear()
  height_cache[key] = Elevation.height_at(v)
 v.y += float(height_cache[key])
 return v

func projected(p: Dictionary,height: float=1.5) -> Vector2:
 return camera.unproject_position(world(p)+Vector3.UP*height)

func on_screen(p: Dictionary) -> bool:
 return not camera.is_position_behind(world(p)) and get_viewport_rect().grow(20).has_point(projected(p))

func rebuild() -> void:
 hits.clear()
 symbols.clear()
 route_lines.clear()
 if not is_instance_valid(camera):
  return
 for unit in view.get("units",[]):
  if int(unit.id)==selected_unit:
   var previous: Dictionary = unit
   for waypoint in unit.get("route",[]):
    if not camera.is_position_behind(world(previous)) and not camera.is_position_behind(world(waypoint)):
     route_lines.append(PackedVector2Array([projected(previous,0.2),projected(waypoint,0.2)]))
    previous = waypoint
  if on_screen(unit):
   var centre := projected(unit)
   var rotation := -float(unit.get("heading",0))
   var front := camera.unproject_position(world(unit)+Vector3(cos(rotation),0,-sin(rotation))*4.6+Vector3.UP*1.5)
   symbols.append({"kind":"unit","id":unit.id,"point":centre,"direction":(front-centre).normalized(),"small":centre.distance_to(front)<14,"emergency":unit.get("emergency",false)})
   hits.append({"kind":"unit","id":unit.id,"point":centre})
  for crew in unit.get("crew",[]):
   if on_screen(crew):
    hits.append({"kind":"unit","id":unit.id,"point":projected(crew)})
 for resident in view.get("residents",[]):
  if on_screen(resident):
   hits.append({"kind":"resident","id":resident.id,"point":projected(resident)})
 for incident in view.get("incidents",[]):
  if incident.get("state") in ["resolved","missed"]:
   continue
  var anchor: Dictionary = incident.get("anchor",incident)
  if on_screen(anchor):
   var centre := projected(anchor)+Vector2(0,-24)
   symbols.append({"kind":"incident","id":incident.id,"point":centre})
   hits.append({"kind":"incident","id":incident.id,"point":centre})
  for participant in incident.get("participants",[]):
   if participant.get("residentId")!=null and on_screen(participant):
    hits.append({"kind":"resident","id":participant.residentId,"point":projected(participant)})

func pick(point: Vector2) -> Dictionary:
 rebuild()
 var best := 28.0
 var result: Dictionary = {}
 for hit in hits:
  var pixels: float = hit.point.distance_to(point)
  if pixels<=best:
   best = pixels
   result = {"kind":hit.kind,"id":hit.id}
 return result

func _process(_delta: float) -> void:
 rebuild()
 queue_redraw()

func _draw() -> void:
 for line in route_lines:
  draw_dashed_line(line[0],line[1],Color("83f2d0"),2.5,6,true)
 var font := ThemeDB.fallback_font
 for symbol in symbols:
  var centre: Vector2 = symbol.point
  if symbol.kind=="incident":
   draw_circle(centre,12,Color("efbc87") if int(symbol.id)==selected_call else Color("543e2c"))
   draw_arc(centre,12,0,TAU,24,Color("efbc87"),1.5,true)
   draw_string(font,centre+Vector2(-3.5,5),"!",HORIZONTAL_ALIGNMENT_LEFT,-1,16,Color("fff0d0"))
  else:
   if int(symbol.id)==selected_unit:
    draw_arc(centre,15,0,TAU,24,Color("8cf1d7"),2,true)
   if symbol.small:
    var direction: Vector2 = symbol.direction
    var side := Vector2(-direction.y,direction.x)
    draw_colored_polygon(PackedVector2Array([centre+direction*10,centre-direction*7+side*6,centre-direction*4,centre-direction*7-side*6]),Color("ffbd73") if symbol.emergency else Color("4a9dff"))
   var label := "%02d" % int(symbol.id)
   draw_style_box(label_box(),Rect2(centre+Vector2(-13,-34),Vector2(26,18)))
   draw_string(font,centre+Vector2(-10,-20),label,HORIZONTAL_ALIGNMENT_LEFT,-1,13,Color("b4f9e4"))

var backing: StyleBoxFlat
func label_box() -> StyleBoxFlat:
 if backing==null:
  backing = StyleBoxFlat.new()
  backing.bg_color = Color("17343ddd")
 return backing
