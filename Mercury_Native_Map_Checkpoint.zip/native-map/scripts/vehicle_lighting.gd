extends Node3D
# Limit mobile forward-light cost independently of total traffic/population.
const MAX_RIGS := 4
var rigs: Array[Node3D] = []
func _ready() -> void:
 for i in range(MAX_RIGS):
  var rig := Node3D.new()
  rig.visible = false
  add_child(rig)
  rigs.append(rig)
  for side in range(2):
   var lamp := SpotLight3D.new()
   lamp.name = "Head"+str(side)
   lamp.light_color = Color("fff0bc")
   lamp.shadow_enabled = false
   lamp.spot_attenuation = 1.5
   lamp.spot_angle_attenuation = 1.0
   # Source models face +X. Aim slightly down from the lamp to the road.
   lamp.rotation = Vector3(-atan2(0.65,28.0),-PI/2,0)
   rig.add_child(lamp)
   var beacon := OmniLight3D.new()
   beacon.name = "Beacon"+str(side)
   beacon.shadow_enabled = false
   beacon.omni_range = 7.0
   beacon.omni_attenuation = 2.0
   rig.add_child(beacon)
func refresh(sources: Array,lighting: Dictionary,focus: Vector3,distance: float,enabled: bool,quality: String,time: float = -1.0) -> void:
 for rig in rigs:
  rig.visible = false
 if not enabled or quality=="simple" or distance>400 or not is_inside_tree():
  return
 var candidates: Array = sources.filter(func(source): return source.transform.origin.distance_to(focus)<160)
 candidates.sort_custom(func(a,b): return a.transform.origin.distance_squared_to(focus)<b.transform.origin.distance_squared_to(focus))
 var darkness := clampf(float(lighting.get("darkness",0.0))/0.55,0,1)
 var flash: bool = fmod(Time.get_ticks_msec()/1000.0 if time<0 else time,1.0)<0.5
 var count := 0
 for source in candidates:
  if count>=(MAX_RIGS if quality=="models" else 2):
   break
  if darkness<=0.001 and not source.emergency:
   continue
  var rig := rigs[count]
  rig.transform = source.transform
  rig.visible = true
  var specs: Array = lighting.get("headlights",{}).get("suv" if source.model in ["suv","ambulance","rescue"] else "sedan",[])
  for side in range(2):
   var head := rig.get_node("Head"+str(side)) as SpotLight3D
   head.visible = darkness>0.001 and specs.size()==2
   head.light_energy = 2.4*darkness
   if specs.size()==2:
    var spec: Dictionary = specs[side]
    head.position = Vector3(spec.origin[0],spec.height,spec.origin[1])
    head.spot_range = spec.range
    head.spot_angle = spec.angle
   var beacon := rig.get_node("Beacon"+str(side)) as OmniLight3D
   beacon.position = Vector3(0.5,2.15 if source.kind in ["ambulance","rescue"] else 1.65,(-1 if side==0 else 1)*0.45)
   beacon.visible = source.emergency and (flash if side==0 else not flash)
   var palette: Dictionary = source.style.get("flashPalette" if side==0 else "activePalette",{})
   beacon.light_color = Color(palette.get("beaconA" if side==0 else "beaconB","8bddff"))
   beacon.light_energy = 2.0
  count += 1
