extends SceneTree
# Claude audit tool: render the main road bridges and their approaches from two sides.
# Usage: xvfb-run Godot --path . --rendering-driver opengl3 --resolution 794x926 --script scripts/render_bridges.gd -- --native-ui --out DIR
const BRIDGES := [["main-east",Vector3(3284,0,882)],["south",Vector3(-202,0,-339)],["west",Vector3(-2104,0,-1206)],["centre",Vector3(-1026,0,-232)]]
var scene
func _initialize() -> void:
 call_deferred("run")
func wait(n: int) -> void:
 for i in range(n):
  await process_frame
func run() -> void:
 var args := OS.get_cmdline_user_args()
 var out: String = args[args.find("--out")+1]
 scene = load("res://main.tscn").instantiate()
 root.add_child(scene)
 await wait(30)
 scene.campaign.initialize({})
 scene.campaign.store.path = "user://render-bridges.json"
 scene.campaign.action({"op":"event","domId":"startCareer","event":"click"})
 scene.campaign.action({"op":"event","domId":"closeModal","event":"click"})
 await wait(20)
 for bridge in BRIDGES:
  for side in [0.6,2.6]:
   scene.following = false
   scene.focus = bridge[1]
   scene.distance = 85.0
   scene.yaw = side
   scene.update_camera()
   await wait(90)
   if scene.native_ui!=null:
    scene.native_ui.visible = false
   scene.following = false
   scene.focus = bridge[1]
   scene.update_camera()
   await RenderingServer.frame_post_draw
   root.get_texture().get_image().save_png("%s/bridge-%s-%d.png" % [out,bridge[0],int(side*10)])
   print("shot ",bridge[0]," ",side)
 quit(0)
