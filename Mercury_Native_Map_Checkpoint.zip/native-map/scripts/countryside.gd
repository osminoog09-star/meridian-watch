extends Node3D
# Claude 17.10.2026 (Release G2 «Графика», G5 «Пригород»). Owner: «за городом пустота; посёлки — херня».
# The land around Meridian: the main roads leave the town where its streets end (to the capital in the north, along the
# coast to the west, inland to the east, south along the bay) and run to the horizon; villages stand on them — houses
# along the road and a side street, a church in the larger ones, a shop; farmsteads at the end of gravel driveways;
# woods that keep off the roads. Deterministic; roads are one mesh, buildings and trees one MultiMesh per kind and
# 1.5 km cell with a visibility range, cheap on the phone. Houses use the city shader: windows, lit at night.
const TOWN := Rect2(-2900,-4500,8500,8200)
const LAND_Y := -2.0
const Geometry = preload("res://scripts/city_geometry.gd")
const SEA = preload("res://scripts/landuse.gd").SEA
# Roads in world metres: the first point is where the town street ends (city data edge).
const ROADS := [
 {"width":10.0,"points":[Vector2(-190,-4340),Vector2(-260,-5600),Vector2(-420,-7600),Vector2(-250,-10000),Vector2(150,-12500)]},
 {"width":7.0,"points":[Vector2(-1560,-4499),Vector2(-2300,-5500),Vector2(-3300,-6900),Vector2(-5000,-8200),Vector2(-7200,-9800),Vector2(-9800,-11500)]},
 {"width":6.5,"points":[Vector2(-3016,-1086),Vector2(-3150,-1500),Vector2(-3900,-2050),Vector2(-5200,-2400),Vector2(-7200,-2700),Vector2(-10500,-3300)]},
 {"width":7.0,"points":[Vector2(6005,950),Vector2(6900,850),Vector2(8200,800),Vector2(10000,1300),Vector2(12500,900)]},
 {"width":10.0,"points":[Vector2(4875,4015),Vector2(5250,4800),Vector2(5800,6300),Vector2(6400,8200),Vector2(7300,10500),Vector2(8200,12500)]},
 {"width":5.5,"points":[Vector2(-420,-7600),Vector2(1200,-7700),Vector2(2700,-7000),Vector2(4300,-6300),Vector2(5600,-5000),Vector2(6800,-3200),Vector2(7600,-1000),Vector2(8200,800)]},
 {"width":4.5,"points":[Vector2(-3300,-6900),Vector2(-2400,-7700),Vector2(-1300,-7900),Vector2(-420,-7600)]},
 {"width":4.5,"points":[Vector2(8200,800),Vector2(8000,2800),Vector2(7200,4800),Vector2(5800,6300)]},
]
const VILLAGES := [
 {"at":Vector2(-420,-7600),"houses":50,"church":true},
 {"at":Vector2(-3300,-6900),"houses":28,"church":false},
 {"at":Vector2(-5200,-2400),"houses":40,"church":true},
 {"at":Vector2(8200,800),"houses":44,"church":true},
 {"at":Vector2(5800,6300),"houses":36,"church":false},
 {"at":Vector2(2700,-7000),"houses":24,"church":false},
 {"at":Vector2(6800,-3200),"houses":28,"church":false},
]
var city_material := ShaderMaterial.new()
var tree_material := StandardMaterial3D.new()
var geo = Geometry.new()
var rng := RandomNumberGenerator.new()
var cells := {}
var road_grid := {}
var samples: Array = []
func _ready() -> void:
 rng.seed = 4242
 city_material.shader = preload("res://shaders/city.gdshader")
 tree_material.vertex_color_use_as_albedo = true
 tree_material.roughness = 0.95
 geo.base_y = LAND_Y
 var roads: Array = ROADS.duplicate(true)
 # each village gets a side street off the main road
 for v in VILLAGES:
  var t := tangent_near(v.at)
  var perp := Vector2(-t.y,t.x)*(1.0 if rng.randf()<0.5 else -1.0)
  var bend := t*rng.randf_range(-40,40)
  roads.append({"width":4.5,"points":[v.at,v.at+perp*140.0,v.at+perp*300.0+bend]})
 var st := SurfaceTool.new()
 st.begin(Mesh.PRIMITIVE_TRIANGLES)
 for r in roads:
  var line := smooth(r.points)
  ribbon(st,line,float(r.width))
  for i in range(line.size()-1):
   var d: Vector2 = ((line[i+1] as Vector2)-(line[i] as Vector2)).normalized()
   samples.append([line[i],d,float(r.width)])
   mark_road(line[i],float(r.width))
 for v in VILLAGES:
  village(v)
 farmsteads(st)
 woods(st)
 st.index()
 var mesh := MeshInstance3D.new()
 mesh.name = "CountryRoads"
 mesh.mesh = st.commit()
 mesh.material_override = city_material
 mesh.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
 add_child(mesh)
 build_cells()
# ---- roads ----
func smooth(points: Array) -> Array:
 # Catmull-Rom through the points with a little wobble, a sample every ~18 m
 var out: Array = []
 var pts: Array = [points[0]]
 for i in range(points.size()-1):
  var a: Vector2 = points[i]
  var b: Vector2 = points[i+1]
  var n := (b-a).normalized()
  var side := Vector2(-n.y,n.x)
  if a.distance_to(b)>900.0:
   pts.append(a.lerp(b,0.5)+side*rng.randf_range(-90,90))
  pts.append(b)
 for i in range(pts.size()-1):
  var p0: Vector2 = pts[maxi(i-1,0)]
  var p1: Vector2 = pts[i]
  var p2: Vector2 = pts[i+1]
  var p3: Vector2 = pts[mini(i+2,pts.size()-1)]
  var steps := maxi(2,int(p1.distance_to(p2)/18.0))
  for k in range(steps):
   var t := float(k)/steps
   var t2 := t*t
   var t3 := t2*t
   out.append(0.5*((2.0*p1)+(-p0+p2)*t+(2.0*p0-5.0*p1+4.0*p2-p3)*t2+(-p0+3.0*p1-3.0*p2+p3)*t3))
 out.append(pts[-1])
 # stop where the road would run into the sea
 var sea := PackedVector2Array(SEA)
 for i in range(out.size()):
  if Geometry2D.is_point_in_polygon(out[i],sea):
   return out.slice(0,i)
 return out
func ribbon(st: SurfaceTool,line: Array,width: float) -> void:
 if line.size()<2:
  return
 var gravel := width<5.0
 var half := width/2.0
 var lefts: Array = []
 for i in range(line.size()):
  var d: Vector2 = ((line[mini(i+1,line.size()-1)] as Vector2)-(line[maxi(i-1,0)] as Vector2)).normalized()
  lefts.append(Vector2(-d.y,d.x))
 var run := 0.0
 for i in range(line.size()-1):
  var a: Vector2 = line[i]
  var b: Vector2 = line[i+1]
  var la: Vector2 = lefts[i]
  var lb: Vector2 = lefts[i+1]
  var seg := a.distance_to(b)
  # the verge, then the carriageway
  geo.surface = 0.0
  band(st,a,b,la,lb,-half-1.3,half+1.3,LAND_Y+0.04,Color("8d8778"))
  if gravel:
   band(st,a,b,la,lb,-half,half,LAND_Y+0.06,Color("a39b86"))
   continue
  geo.surface = 1.0
  band(st,a,b,la,lb,-half,half,LAND_Y+0.07,Color("3f4a4e"))
  geo.surface = 3.0
  if width>=6.5:
   band(st,a,b,la,lb,-half+0.3,-half+0.45,LAND_Y+0.09,Color("d9d6c8"))
   band(st,a,b,la,lb,half-0.45,half-0.3,LAND_Y+0.09,Color("d9d6c8"))
  if width>=6.0:
   # dashes: 3 m paint, 9 m gap, continuous over the whole road
   var k := fposmod(-run,12.0)
   while k<seg:
    var p1 := a.lerp(b,k/seg)
    var p2 := a.lerp(b,minf(1.0,(k+3.0)/seg))
    band(st,p1,p2,la,lb,-0.08,0.08,LAND_Y+0.09,Color("d9d6c8"))
    k += 12.0
  run += seg
 geo.surface = 0.0
func band(st: SurfaceTool,a: Vector2,b: Vector2,la: Vector2,lb: Vector2,from: float,to: float,y: float,color: Color) -> void:
 var p1 := Vector3(a.x+la.x*from,y,a.y+la.y*from)
 var p2 := Vector3(b.x+lb.x*from,y,b.y+lb.y*from)
 var p3 := Vector3(b.x+lb.x*to,y,b.y+lb.y*to)
 var p4 := Vector3(a.x+la.x*to,y,a.y+la.y*to)
 geo.quad(st,p1,p2,p3,p4,color,Vector3.UP)
func mark_road(p: Vector2,width: float) -> void:
 var key := Vector2i(int(floor(p.x/50.0)),int(floor(p.y/50.0)))
 if not road_grid.has(key):
  road_grid[key] = []
 road_grid[key].append([p,width])
func near_road(p: Vector2,clearance: float) -> bool:
 var key := Vector2i(int(floor(p.x/50.0)),int(floor(p.y/50.0)))
 for dx in range(-1,2):
  for dy in range(-1,2):
   for item in road_grid.get(key+Vector2i(dx,dy),[]):
    if p.distance_to(item[0])<clearance+float(item[1])/2.0:
     return true
 return false
func tangent_near(p: Vector2) -> Vector2:
 var best := 1e12
 var t := Vector2.RIGHT
 for r in ROADS:
  for i in range(r.points.size()-1):
   var a: Vector2 = r.points[i]
   var b: Vector2 = r.points[i+1]
   var q := Geometry2D.get_closest_point_to_segment(p,a,b)
   if q.distance_to(p)<best:
    best = q.distance_to(p)
    t = (b-a).normalized()
 return t
func blocked(p: Vector2) -> bool:
 return TOWN.grow(250).has_point(p) or Geometry2D.is_point_in_polygon(p,PackedVector2Array(SEA))
# ---- villages and farmsteads ----
const WALLS := ["e6dcc4","e2cf9b","cfd8c4","c4d3dc","efece4","d9b9a0","b9483d","8c6d4f","a7b7a3","d9d2c0"]
const ROOFS := ["7b4a3a","8e5440","4b5257","59675e","5d4a42","a0604a"]
func add(kind: String,p: Vector2,facing: Vector2,scale: float = 1.0,color: Color = Color.WHITE) -> void:
 var key := Vector2i(int(floor(p.x/1500.0)),int(floor(p.y/1500.0)))
 if not cells.has(key):
  cells[key] = {}
 if not cells[key].has(kind):
  cells[key][kind] = []
 var f := Vector3(facing.x,0,facing.y).normalized()
 var basis := Basis(f.cross(Vector3.UP).normalized(),Vector3.UP,-f).scaled(Vector3.ONE*scale)
 cells[key][kind].append([Transform3D(basis,Vector3(p.x,LAND_Y,p.y)),color])
func village(v: Dictionary) -> void:
 var centre: Vector2 = v.at
 var radius := 60.0+float(v.houses)*7.0
 var placed := 0
 for s in samples:
  if placed>=int(v.houses):
   break
  var p: Vector2 = s[0]
  if p.distance_to(centre)>radius or rng.randf()<0.12:
   continue
  var d: Vector2 = s[1]
  var side := Vector2(-d.y,d.x)*(1.0 if rng.randf()<0.5 else -1.0)
  var at := p+side*(float(s[2])/2.0+rng.randf_range(13.0,19.0))
  if blocked(at) or near_road(at,7.0):
   continue
  var kind := "house2" if rng.randf()<0.25 else "house"
  # the house's long side faces the road: its ridge runs along the road
  var scale := rng.randf_range(0.9,1.15)
  add(kind,at,d,scale,Color(WALLS[rng.randi()%WALLS.size()]))
  add("roof_"+kind,at,d,scale,Color(ROOFS[rng.randi()%ROOFS.size()]))
  for k in range(rng.randi_range(1,3)):
   var tp := at+side*rng.randf_range(10,22)+d*rng.randf_range(-12,12)
   if not near_road(tp,4.0):
    add("tree",tp,Vector2(1,0).rotated(rng.randf()*TAU),rng.randf_range(0.8,1.2))
  placed += 1
 var t := tangent_near(centre)
 var off := Vector2(-t.y,t.x)
 if bool(v.church):
  var spot := centre-off*36.0-t*40.0
  if not near_road(spot,12.0) and not blocked(spot):
   add("church",spot,off)
 var shop := centre+off*26.0-t*70.0
 if not near_road(shop,8.0) and not blocked(shop):
  add("shop",shop,-off)
func farmsteads(st: SurfaceTool) -> void:
 var travelled := 0.0
 var next := 400.0
 for s in samples:
  travelled += 18.0
  if travelled<next:
   continue
  travelled = 0.0
  next = rng.randf_range(260,650)
  var p: Vector2 = s[0]
  var d: Vector2 = s[1]
  var far_from_villages := true
  for v in VILLAGES:
   if p.distance_to(v.at)<520.0:
    far_from_villages = false
  if not far_from_villages:
   continue
  var side := Vector2(-d.y,d.x)*(1.0 if rng.randf()<0.5 else -1.0)
  var length := rng.randf_range(45,110)
  var yard := p+side*(float(s[2])/2.0+length)
  if blocked(yard) or blocked(p) or near_road(yard,25.0):
   continue
  # the gravel driveway
  geo.surface = 0.0
  var start := p+side*float(s[2])/2.0
  var along := Vector2(-side.y,side.x)
  band(st,start,yard,along,along,-1.6,1.6,LAND_Y+0.05,Color("a39b86"))
  add("house",yard+along*8.0,along,rng.randf_range(0.9,1.15),Color(WALLS[rng.randi()%WALLS.size()]))
  add("roof_house",yard+along*8.0,along,1.0,Color(ROOFS[rng.randi()%ROOFS.size()]))
  add("barn",yard-along*14.0+side*12.0,side,rng.randf_range(0.9,1.3))
  for k in range(rng.randi_range(4,9)):
   add("tree",yard+Vector2(rng.randf_range(-35,35),rng.randf_range(-35,35))+side*24.0,Vector2(1,0).rotated(rng.randf()*TAU),rng.randf_range(0.8,1.3))
func woods(st: SurfaceTool) -> void:
 # a wood: a dark forest floor (one irregular disc in the road mesh) and big spruces and birches on it
 var outer := TOWN.grow(8000)
 for w in range(150):
  var c := Vector2(rng.randf_range(outer.position.x,outer.end.x),rng.randf_range(outer.position.y,outer.end.y))
  if TOWN.grow(300).has_point(c) or Geometry2D.is_point_in_polygon(c,PackedVector2Array(SEA)) or near_road(c,80.0):
   continue
  var r := rng.randf_range(140,420)
  var ring: Array = []
  for k in range(14):
   ring.append(c+Vector2(1,0).rotated(TAU*k/14.0)*r*rng.randf_range(0.8,1.1))
  geo.surface = 0.0
  for k in range(14):
   var a: Vector2 = ring[k]
   var b: Vector2 = ring[(k+1)%14]
   geo.triangle(st,Vector3(c.x,LAND_Y+0.02,c.y),Vector3(a.x,LAND_Y+0.02,a.y),Vector3(b.x,LAND_Y+0.02,b.y),Color("2f4a2c"),Vector3.UP)
  for k in range(int(r*0.6)):
   var a := rng.randf()*TAU
   var dist := sqrt(rng.randf())*r*0.85
   var p := c+Vector2(cos(a),sin(a))*dist
   if near_road(p,8.0) or blocked(p):
    continue
   add("tree",p,Vector2(1,0).rotated(rng.randf()*TAU),rng.randf_range(1.2,1.9))
# ---- meshes ----
func build_cells() -> void:
 var meshes := {"house":house_mesh(10,4.6,7,1),"roof_house":roof_mesh(10,4.6,7,3.2),"house2":house_mesh(11,7.4,8,2),"roof_house2":roof_mesh(11,7.4,8,3.4),
  "barn":barn_mesh(),"tree":tree_mesh(),"church":church_mesh(),"shop":shop_mesh()}
 for key in cells:
  for kind in cells[key]:
   var list: Array = cells[key][kind]
   var mm := MultiMesh.new()
   mm.transform_format = MultiMesh.TRANSFORM_3D
   mm.use_colors = true
   mm.mesh = meshes[kind]
   mm.instance_count = list.size()
   for i in range(list.size()):
    mm.set_instance_transform(i,list[i][0])
    mm.set_instance_color(i,list[i][1])
   var node := MultiMeshInstance3D.new()
   node.multimesh = mm
   node.material_override = tree_material if kind=="tree" else city_material
   node.visibility_range_end = 4500.0 if kind=="tree" else 8000.0
   node.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
   add_child(node)
func begin() -> SurfaceTool:
 var st := SurfaceTool.new()
 st.begin(Mesh.PRIMITIVE_TRIANGLES)
 return st
# Local frame of the meshes: the ridge runs along local z (the facing direction), the long side is the length.
# Walls are white: the instance colour paints them; the roof is a separate mesh with its own instance colour.
func house_mesh(l: float,h: float,w: float,floors: int) -> ArrayMesh:
 var st := begin()
 geo.surface = 0.0
 geo.floor_height = h/floors
 geo.obox(st,Vector3.ZERO,Vector3(0,0,-1),Vector3(l,h,w),Color.WHITE)
 geo.floor_height = 0.0
 gable_ends(st,l,h,w,3.2 if floors==1 else 3.4,Color.WHITE)
 return st.commit()
func gable_ends(st: SurfaceTool,l: float,h: float,w: float,rise: float,color: Color) -> void:
 for s in [-1.0,1.0]:
  var z: float = l/2.0*s
  geo.triangle(st,Vector3(-w/2.0,h,z),Vector3(w/2.0,h,z),Vector3(0,h+rise,z),color.darkened(0.08),Vector3(0,0,s))
func pitched(st: SurfaceTool,l: float,h: float,w: float,rise: float,color: Color) -> void:
 var x := w/2.0+0.5
 var z := l/2.0+0.4
 for s in [-1.0,1.0]:
  var e1 := Vector3(x*s,h-0.25,-z)
  var e2 := Vector3(x*s,h-0.25,z)
  var r1 := Vector3(0,h+rise,-z)
  var r2 := Vector3(0,h+rise,z)
  var n := (e2-e1).cross(r1-e1).normalized()
  if n.y<0:
   n = -n
  geo.quad(st,e1,e2,r2,r1,color,n)
func roof_mesh(l: float,h: float,w: float,rise: float) -> ArrayMesh:
 var st := begin()
 geo.surface = 0.0
 geo.floor_height = 0.0
 pitched(st,l,h,w,rise,Color.WHITE)
 return st.commit()
func barn_mesh() -> ArrayMesh:
 var st := begin()
 geo.surface = 0.0
 geo.floor_height = 0.0
 geo.obox(st,Vector3.ZERO,Vector3(0,0,-1),Vector3(16,5,9),Color("8e4b3a"))
 gable_ends(st,16,5,9,3.6,Color("8e4b3a"))
 pitched(st,16,5,9,3.6,Color("5a5e60"))
 return st.commit()
func church_mesh() -> ArrayMesh:
 var st := begin()
 geo.surface = 0.0
 geo.floor_height = 4.5
 geo.obox(st,Vector3.ZERO,Vector3(0,0,-1),Vector3(20,9,10),Color("ece8de"))
 geo.floor_height = 0.0
 gable_ends(st,20,9,10,5.0,Color("ece8de"))
 pitched(st,20,9,10,5.0,Color("3f474b"))
 # the tower at one end with a spire
 geo.floor_height = 6.0
 geo.obox(st,Vector3(0,0,12.5),Vector3(0,0,-1),Vector3(5,22,5),Color("ece8de"))
 geo.floor_height = 0.0
 var top := Vector3(0,34,12.5)
 var c := [Vector3(-2.7,22,9.8),Vector3(2.7,22,9.8),Vector3(2.7,22,15.2),Vector3(-2.7,22,15.2)]
 for i in range(4):
  var a: Vector3 = c[i]
  var b: Vector3 = c[(i+1)%4]
  var n := (b-a).cross(top-a).normalized()
  if n.y<0:
   n = -n
  geo.triangle(st,a,b,top,Color("2f3a36"),n)
 return st.commit()
func shop_mesh() -> ArrayMesh:
 var st := begin()
 geo.surface = 0.0
 geo.floor_height = 4.2
 geo.obox(st,Vector3.ZERO,Vector3(0,0,-1),Vector3(16,4.2,11),Color("c9c4b7"),Color("55595b"))
 geo.floor_height = 0.0
 # a coloured sign band over the front
 geo.surface = 6.0
 geo.obox(st,Vector3(0,3.3,-5.6),Vector3(1,0,0),Vector3(12,0.8,0.3),Color("c8463c"))
 geo.surface = 0.0
 return st.commit()
func tree_mesh() -> ArrayMesh:
 var st := begin()
 for i in range(6):
  var a := TAU*i/6
  var b := TAU*(i+1)/6
  var n := Vector3(cos((a+b)/2),0,sin((a+b)/2))
  st.set_color(Color("5e4634")); st.set_normal(n)
  for v in [Vector3(cos(a)*0.25,0,sin(a)*0.25),Vector3(cos(b)*0.25,3,sin(b)*0.25),Vector3(cos(b)*0.25,0,sin(b)*0.25),Vector3(cos(a)*0.25,0,sin(a)*0.25),Vector3(cos(a)*0.25,3,sin(a)*0.25),Vector3(cos(b)*0.25,3,sin(b)*0.25)]:
   st.add_vertex(v)
 for layer in [[2.0,3.2,8.0],[5.0,2.2,11.0]]:
  for i in range(8):
   var a := TAU*i/8
   var b := TAU*(i+1)/8
   var p1 := Vector3(cos(a)*layer[1],layer[0],sin(a)*layer[1])
   var p2 := Vector3(cos(b)*layer[1],layer[0],sin(b)*layer[1])
   var top := Vector3(0,layer[2],0)
   var n := (p2-p1).cross(top-p1).normalized()
   if n.y<0:
    n = -n
   st.set_color(Color("3d6338").lightened(0.07*(i%2))); st.set_normal(n)
   for v in [p1,top,p2]:
    st.add_vertex(v)
 return st.commit()
