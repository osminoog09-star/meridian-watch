extends Node3D
# Claude 17.10.2026 (Release G2 «Графика»). Owner: «за городом пустота». Around the town: farmsteads (a house, a barn)
# along the field edges, woods and tree lines, so the land around Meridian looks lived in. Deterministic; one
# MultiMesh per 1.5 km cell with a visibility range, cheap on the phone.
const TOWN := Rect2(-2900,-4500,8500,8200)
func _ready() -> void:
 var rng := RandomNumberGenerator.new()
 rng.seed = 4242
 var house := house_mesh()
 var barn := barn_mesh()
 var tree := tree_mesh()
 var cells := {}
 var add := func(kind: String,p: Vector3,rot: float,scale: float):
  var key := Vector2i(int(floor(p.x/1500.0)),int(floor(p.z/1500.0)))
  if not cells.has(key):
   cells[key] = {"house":[],"barn":[],"tree":[]}
  cells[key][kind].append(Transform3D(Basis(Vector3.UP,rot).scaled(Vector3.ONE*scale),p))
 var outer := TOWN.grow(7000)
 # farmsteads
 for i in range(520):
  var p := Vector2(rng.randf_range(outer.position.x,outer.end.x),rng.randf_range(outer.position.y,outer.end.y))
  if TOWN.grow(250).has_point(p) or Geometry2D.is_point_in_polygon(p,PackedVector2Array(preload("res://scripts/landuse.gd").SEA)):
   continue
  var rot := rng.randf()*TAU
  add.call("house",Vector3(p.x,-2.0,p.y),rot,rng.randf_range(0.9,1.2))
  add.call("barn",Vector3(p.x+cos(rot)*18,-2.0,p.y+sin(rot)*18),rot,rng.randf_range(0.9,1.3))
  for t in range(rng.randi_range(3,8)):
   add.call("tree",Vector3(p.x+rng.randf_range(-30,30),-2.0,p.y+rng.randf_range(-30,30)),rng.randf()*TAU,rng.randf_range(0.8,1.3))
 # woods: clusters of trees
 for w in range(150):
  var c := Vector2(rng.randf_range(outer.position.x,outer.end.x),rng.randf_range(outer.position.y,outer.end.y))
  if TOWN.grow(150).has_point(c) or Geometry2D.is_point_in_polygon(c,PackedVector2Array(preload("res://scripts/landuse.gd").SEA)):
   continue
  var r := rng.randf_range(120,420)
  for t in range(int(r*0.35)):
   var a := rng.randf()*TAU
   var d := sqrt(rng.randf())*r
   add.call("tree",Vector3(c.x+cos(a)*d,-2.0,c.y+sin(a)*d),rng.randf()*TAU,rng.randf_range(0.9,1.5))
 var mat := StandardMaterial3D.new()
 mat.vertex_color_use_as_albedo = true
 mat.roughness = 0.95
 var meshes := {"house":house,"barn":barn,"tree":tree}
 for key in cells:
  for kind in cells[key]:
   var list: Array = cells[key][kind]
   if list.is_empty():
    continue
   var mm := MultiMesh.new()
   mm.transform_format = MultiMesh.TRANSFORM_3D
   mm.mesh = meshes[kind]
   mm.instance_count = list.size()
   for i in range(list.size()):
    mm.set_instance_transform(i,list[i])
   var node := MultiMeshInstance3D.new()
   node.multimesh = mm
   node.material_override = mat
   node.visibility_range_end = 6500.0
   node.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
   add_child(node)
func box(st: SurfaceTool,c: Vector3,s: Vector3,color: Color) -> void:
 var x := s.x/2
 var z := s.z/2
 var p := [c+Vector3(-x,0,-z),c+Vector3(x,0,-z),c+Vector3(x,0,z),c+Vector3(-x,0,z)]
 for i in range(4):
  var a: Vector3 = p[i]
  var b: Vector3 = p[(i+1)%4]
  var n := (b-a).cross(Vector3.UP).normalized()
  st.set_color(color); st.set_normal(n)
  for v in [a,b+Vector3.UP*s.y,b,a,a+Vector3.UP*s.y,b+Vector3.UP*s.y]:
   st.add_vertex(v)
func gable(st: SurfaceTool,c: Vector3,s: Vector3,h: float,color: Color) -> void:
 var x := s.x/2+0.4
 var z := s.z/2+0.4
 var y := c.y+s.y
 var r1 := Vector3(c.x-x,y+h,c.z)
 var r2 := Vector3(c.x+x,y+h,c.z)
 for side in [-1.0,1.0]:
  var e1 := Vector3(c.x-x,y,c.z+z*side)
  var e2 := Vector3(c.x+x,y,c.z+z*side)
  var n := (e2-e1).cross(r1-e1).normalized()
  if n.y<0:
   n = -n
  st.set_color(color); st.set_normal(n)
  for v in [e1,r1,e2,e2,r1,r2]:
   st.add_vertex(v)
 for side in [-1.0,1.0]:
  st.set_color(color.darkened(0.2)); st.set_normal(Vector3(side,0,0))
  for v in [Vector3(c.x+x*side,y,c.z-z),Vector3(c.x+x*side,y+h,c.z),Vector3(c.x+x*side,y,c.z+z)]:
   st.add_vertex(v)
func house_mesh() -> ArrayMesh:
 var st := SurfaceTool.new()
 st.begin(Mesh.PRIMITIVE_TRIANGLES)
 box(st,Vector3.ZERO,Vector3(10,4.5,7),Color("d9cdb0"))
 gable(st,Vector3.ZERO,Vector3(10,4.5,7),3.2,Color("7b4a3a"))
 return st.commit()
func barn_mesh() -> ArrayMesh:
 var st := SurfaceTool.new()
 st.begin(Mesh.PRIMITIVE_TRIANGLES)
 box(st,Vector3.ZERO,Vector3(16,5,9),Color("8e4b3a"))
 gable(st,Vector3.ZERO,Vector3(16,5,9),3.6,Color("5a5e60"))
 return st.commit()
func tree_mesh() -> ArrayMesh:
 var st := SurfaceTool.new()
 st.begin(Mesh.PRIMITIVE_TRIANGLES)
 box(st,Vector3.ZERO,Vector3(0.5,3,0.5),Color("5e4634"))
 for layer in [[2.0,3.2,8.0],[5.0,2.2,11.0]]:
  for i in range(8):
   var a := TAU*i/8
   var b := TAU*(i+1)/8
   var p1 := Vector3(cos(a)*layer[1],layer[0],sin(a)*layer[1])
   var p2 := Vector3(cos(b)*layer[1],layer[0],sin(b)*layer[1])
   var top := Vector3(0,layer[2],0)
   var n := (p2-p1).cross(top-p1).normalized()
   if n.y<0:
    n = -n
   st.set_color(Color("3d6338").lightened(0.07*(i%2))); st.set_normal(n)
   for v in [p1,top,p2]:
    st.add_vertex(v)
 return st.commit()
