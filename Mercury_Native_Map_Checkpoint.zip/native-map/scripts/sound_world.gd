extends Node
# Claude 17.10.2026 (Release R2 «Звук»). Owner 17.10: «звук надо доработать полноценно, а не то, что сейчас».
# Plays the sound bank in audio/ (tools/make_sounds.py): looping beds, the own engine with gears, up to three
# sirens with stereo and Doppler, the radio voice (TETRA talk-permit tone + voiced fragments), console tones,
# footsteps, doors, passing cars, horns and thunder. What sounds and how loud comes from the game every 0.1 s
# (ui/sound-scene.js through the «audio» call); this node only mixes. It replaces the 22 kHz generator.
const BEDS := {"traffic":"city/traffic","rain":"weather/rain","wind":"weather/wind","storm":"weather/storm","snow":"weather/snow","sea":"city/sea","river":"city/river","crowd":"city/crowd","birds":"city/birds","fire":"city/fire"}
const BED_LEVEL := {"traffic":0.55,"rain":0.8,"wind":0.5,"storm":0.8,"snow":0.6,"sea":0.7,"river":0.5,"crowd":0.55,"birds":0.4,"fire":0.8}
const ENGINES := ["petrol","diesel","truck"]
const SIRENS := {"police":{"wail":"siren/police_wail","yelp":"siren/police_yelp","hilo":"siren/police_wail"},"ambulance":{"wail":"siren/ambulance_wail","yelp":"siren/ambulance_yelp","hilo":"siren/ambulance_wail"},"rescue":{"wail":"siren/rescue_hilo","yelp":"siren/rescue_hilo","hilo":"siren/rescue_hilo"}}
const STEPS := {"asphalt":["concrete_1","concrete_2","concrete_3"],"grass":["grass_1","grass_2","grass_3"],"snow":["snow_1","snow_2","snow_3"],"ice":["snow_1","snow_2"],"wet":["wet_1","wet_2","wet_3"],"gravel":["gravel_1","gravel_2","gravel_3"]}
const BUSES := ["Beds","Vehicles","Siren0","Siren1","Siren2","Radio","Cues"]
var controller: RefCounted
var map: Node3D
var elapsed := 0.0
var poll := 1.0
var data: Dictionary = {}
var prefs: Dictionary = {"enabled":false,"master":0.55,"radio":0.6,"siren":0.35,"engine":0.3,"environment":0.45}
var streams := {}
var beds := {}
var engine_idle: AudioStreamPlayer
var engine_drive: AudioStreamPlayer
var tyres: AudioStreamPlayer
var engine_kind := ""
var sirens: Array = []
var radio_player: AudioStreamPlayer
var radio_queue: Array = []
var radio_until := 0.0
var voices := {}
var cue_players: Array = []
var gear_phase := 0.0
var last_test := false
var random := RandomNumberGenerator.new()

func _ready() -> void:
 add_to_group("sound_world")
 random.seed = 1707
 for name in BUSES:
  if AudioServer.get_bus_index(name)<0:
   var index := AudioServer.bus_count
   AudioServer.add_bus(index)
   AudioServer.set_bus_name(index,name)
   AudioServer.set_bus_send(index,"Master")
   if name.begins_with("Siren"):
    AudioServer.add_bus_effect(index,AudioEffectPanner.new())
    var low := AudioEffectLowPassFilter.new()
    low.cutoff_hz = 9000
    AudioServer.add_bus_effect(index,low)
   if name=="Siren0" or name=="Vehicles":
    var reverb := AudioEffectReverb.new()
    reverb.room_size = 0.55
    reverb.damping = 0.6
    reverb.wet = 0.12
    reverb.dry = 1.0
    AudioServer.add_bus_effect(index,reverb)
 for key in BEDS:
  beds[key] = player(BEDS[key],"Beds",true)
 tyres = player("vehicle/tyres","Vehicles",true)
 for k in range(3):
  var siren := player("","Siren"+str(k),true)
  siren.set_meta("key","")
  sirens.append(siren)
 radio_player = player("","Radio",false)
 for k in range(6):
  cue_players.append(player("","Cues",false))
 for voice in ["duty","crewA","crewB"]:
  voices[voice] = stream("voice/"+voice,false)

func stream(path: String,loop: bool) -> AudioStream:
 if path.is_empty():
  return null
 var key := path+("#loop" if loop else "")
 if streams.has(key):
  return streams[key]
 var resource = load("res://audio/"+path+".ogg")
 if resource is AudioStreamOggVorbis:
  resource = resource.duplicate()
  resource.loop = loop
 streams[key] = resource
 return resource

func player(path: String,bus: String,loop: bool) -> AudioStreamPlayer:
 var p := AudioStreamPlayer.new()
 p.bus = bus
 p.stream = stream(path,loop)
 p.volume_db = -80
 add_child(p)
 return p

func db(level: float) -> float:
 return linear_to_db(maxf(level,0.00001))

func fade(p: AudioStreamPlayer,level: float,delta: float,speed := 3.0) -> void:
 var target := db(level)
 if level<=0.0005:
  p.volume_db = move_toward(p.volume_db,-80,delta*60*speed/3.0)
  if p.playing and p.volume_db<=-79:
   p.stop()
  return
 if not p.playing and p.stream!=null:
  p.volume_db = -50
  p.play(random.randf()*maxf(0.0,p.stream.get_length()-1.0) if p.stream.get_length()>4 else 0.0)
 p.volume_db = move_toward(p.volume_db,target,delta*60*speed/3.0)

func _process(delta: float) -> void:
 elapsed += delta
 poll += delta
 if controller==null or not controller.initialized:
  return
 if poll>=0.1:
  poll = 0
  var scene := {"x":map.focus.x/1670.0+1.55,"y":map.focus.z/1670.0+2.52,"zoom":clampf(6500.0/map.distance,0.2,80)}
  var raw = controller.runtime.eval("MercuryUI.call("+JSON.stringify(JSON.stringify({"op":"audio","time":elapsed,"scene":scene}))+")")
  var result = JSON.parse_string(str(raw))
  if typeof(result)==TYPE_DICTIONARY:
   data = result
   if typeof(result.get("prefs"))==TYPE_DICTIONARY:
    prefs = result.prefs
   var sound = result.get("sound")
   if typeof(sound)==TYPE_DICTIONARY:
    for event in sound.get("events",[]):
     on_event(event)
 mix(delta)
 run_radio()

func mix(delta: float) -> void:
 var on: bool = bool(data.get("active",false)) and bool(prefs.get("enabled",false))
 AudioServer.set_bus_volume_db(0,db(float(prefs.get("master",0.55))*1.6 if on else 0.0))
 var sound = data.get("sound",{})
 if typeof(sound)!=TYPE_DICTIONARY:
  sound = {}
 var duck := 0.45 if sound.get("ducked",false) else 1.0
 var env_level := float(prefs.get("environment",0.45))*duck
 var levels: Dictionary = sound.get("beds",{})
 for key in beds:
  fade(beds[key],(float(levels.get(key,0.0))*BED_LEVEL[key]*env_level if on else 0.0),delta)
 engine(sound.get("car",{}),delta,on,duck)
 siren_mix(sound.get("sirens",[]),delta,on)

func engine(car: Dictionary,delta: float,on: bool,duck: float) -> void:
 var kind := str(car.get("kind","petrol"))
 if kind!=engine_kind:
  engine_kind = kind
  for p in [engine_idle,engine_drive]:
   if p!=null:
    p.queue_free()
  engine_idle = player("vehicle/"+kind+"_idle","Vehicles",true)
  engine_drive = player("vehicle/"+kind+"_drive","Vehicles",true)
 var gain := float(car.get("gain",0.0))*float(prefs.get("engine",0.3))*duck*1.8 if on and car.get("on",false) else 0.0
 var kmh := float(car.get("kmh",0.0))
 # A gearbox: the pitch climbs inside a gear and drops at each shift.
 var gears := [0.0,18.0,35.0,55.0,80.0,120.0] if kind=="petrol" else [0.0,15.0,30.0,48.0,70.0,110.0]
 var inside := 0.0
 for g in range(gears.size()-1):
  if kmh<gears[g+1] or g==gears.size()-2:
   inside = clampf((kmh-gears[g])/(gears[g+1]-gears[g]),0,1)
   break
 var drive := clampf(kmh/10.0,0,1)
 gear_phase = lerpf(gear_phase,inside,clampf(delta*4,0,1))
 engine_idle.pitch_scale = 1.0+0.15*drive
 engine_drive.pitch_scale = 0.7+0.55*gear_phase
 fade(engine_idle,gain*(1.0-0.7*drive),delta,6)
 fade(engine_drive,gain*drive*0.9,delta,6)
 var want := "vehicle/tyres_wet" if car.get("wet",false) else "vehicle/tyres"
 if tyres.get_meta("path","")!=want:
  tyres.stream = stream(want,true)
  tyres.set_meta("path",want)
  tyres.stop()
 fade(tyres,gain*clampf(kmh/70.0,0,1)*0.8,delta,6)

func siren_mix(list: Array,delta: float,on: bool) -> void:
 var level := float(prefs.get("siren",0.35))*1.4
 var used := []
 for item in list:
  var key := str(item.get("key",""))+"|"+str(item.get("mode",""))
  var slot := -1
  for k in range(3):
   if sirens[k].get_meta("key","")==key:
    slot = k
  if slot<0:
   for k in range(3):
    if not used.has(k) and not list.any(func(x): return str(x.get("key",""))+"|"+str(x.get("mode",""))==sirens[k].get_meta("key","")):
     slot = k
     break
  if slot<0:
   continue
  used.append(slot)
  var p: AudioStreamPlayer = sirens[slot]
  if p.get_meta("key","")!=key:
   p.set_meta("key",key)
   p.stream = stream(SIRENS.get(str(item.get("kind","police")),SIRENS.police).get(str(item.get("mode","wail")),"siren/police_wail"),true)
   p.stop()
   p.volume_db = -60
  var bus := AudioServer.get_bus_index("Siren"+str(slot))
  (AudioServer.get_bus_effect(bus,0) as AudioEffectPanner).pan = clampf(float(item.get("pan",0.0)),-1,1)
  (AudioServer.get_bus_effect(bus,1) as AudioEffectLowPassFilter).cutoff_hz = lerpf(9000,1400,float(item.get("muffle",0.0)))
  p.pitch_scale = clampf(float(item.get("pitch",1.0)),0.85,1.15)
  fade(p,float(item.get("gain",0.0))*level if on else 0.0,delta,8)
 for k in range(3):
  if not used.has(k):
   fade(sirens[k],0.0,delta,8)
   if not sirens[k].playing:
    sirens[k].set_meta("key","")

func play_cue(path: String,level: float,pan := 0.0,pitch := 1.0) -> void:
 if not bool(data.get("active",false)) or not bool(prefs.get("enabled",false)) or level<=0.0:
  return
 var best: AudioStreamPlayer = cue_players[0]
 for p in cue_players:
  if not p.playing:
   best = p
   break
 best.stream = stream(path,false)
 best.volume_db = db(level)
 best.pitch_scale = pitch
 best.play()

func on_event(e: Dictionary) -> void:
 var env_level := float(prefs.get("environment",0.45))
 match str(e.get("kind","")):
  "radio":
   if radio_queue.size()>=2:
    radio_queue.pop_front()
   radio_queue.append(e)
  "newcall":
   play_cue("ui/urgent_call" if e.get("urgent",false) else "ui/new_call",float(prefs.get("radio",0.6))*0.7)
  "resolved":
   play_cue("ui/resolved",float(prefs.get("radio",0.6))*0.6)
  "missed":
   play_cue("ui/missed",float(prefs.get("radio",0.6))*0.6)
  "step":
   var list: Array = STEPS.get(str(e.get("surface","asphalt")),STEPS.asphalt)
   play_cue("steps/"+list[random.randi()%list.size()],env_level*float(e.get("level",0.5))*1.2,0.0,random.randf_range(0.92,1.08))
  "door":
   play_cue("vehicle/door_close",float(prefs.get("engine",0.3))*1.6*float(e.get("level",0.6)))
  "pass":
   play_cue("vehicle/pass_"+str(int(e.get("variant",1))),env_level*float(e.get("level",0.4))*1.1,float(e.get("pan",0.0)),random.randf_range(0.9,1.1))
  "horn":
   play_cue("vehicle/horn",env_level*float(e.get("level",0.3)),float(e.get("pan",0.0)),random.randf_range(0.93,1.07))
  "thunder":
   play_cue("weather/thunder_"+str(int(e.get("variant",1))),env_level*float(e.get("level",0.6))*1.4)

# The radio: permit tone, then each clip of the sprite, then the end tone. Only one line at a time.
func run_radio() -> void:
 if radio_player.playing and elapsed<radio_until:
  return
 if radio_player.playing:
  radio_player.stop()
 if radio_queue.is_empty():
  return
 var line: Dictionary = radio_queue[0]
 var level := float(prefs.get("radio",0.6))*(1.4 if line.get("own",false) else 0.9)
 if not bool(prefs.get("enabled",false)) or not bool(data.get("active",false)):
  radio_queue.clear()
  return
 var step := int(line.get("step",0))
 var clips: Array = line.get("clips",[])
 line["step"] = step+1
 if step==0:
  radio_player.stream = stream("radio/permit",false)
  radio_player.volume_db = db(level*0.5)
  radio_player.play()
  radio_until = elapsed+0.16
 elif step<=clips.size():
  var clip: Array = clips[step-1]
  radio_player.stream = voices.get(str(line.get("voice","duty")))
  if radio_player.stream==null:
   return
  radio_player.volume_db = db(level)
  radio_player.play(float(clip[0]))
  radio_until = elapsed+float(clip[1])+0.04
 elif step==clips.size()+1:
  radio_player.stream = stream("radio/end",false)
  radio_player.volume_db = db(level*0.4)
  radio_player.play()
  radio_until = elapsed+0.12
 else:
  radio_queue.pop_front()

func ui_click() -> void:
 play_cue("ui/click",float(prefs.get("environment",0.45))*0.7)

func _notification(what: int) -> void:
 if what==NOTIFICATION_APPLICATION_PAUSED:
  AudioServer.set_bus_mute(0,true)
 elif what==NOTIFICATION_APPLICATION_RESUMED:
  AudioServer.set_bus_mute(0,false)
