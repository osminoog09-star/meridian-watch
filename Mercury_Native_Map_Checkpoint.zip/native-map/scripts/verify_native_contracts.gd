extends SceneTree
var failed := false
func check(ok: bool,message: String) -> void:
 if not ok:
  failed = true
  push_error(message)
func _initialize() -> void:
 call_deferred("verify")
func verify() -> void:
 var controller = preload("res://scripts/native_ui_controller.gd").new()
 check(controller.initialize({}),"initialize")
 controller.store.path = "user://native-contract-test.json"
 controller.action({"op":"event","domId":"startCareer","event":"click"})
 controller.action({"op":"event","domId":"closeModal","event":"click"})
 controller.snapshot["map"] = []
 controller.action({"op":"event","domId":"quarterBtn","event":"click"})
 check(controller.snapshot.get("map",[]).any(func(c): return c.op=="quarter"),"autosave discarded camera command")
 controller.action({"op":"event","domId":"settingsBtn","event":"click"})
 controller.action({"op":"event","domId":"a11yText","event":"change","value":"huge"})
 controller.action({"op":"event","domId":"a11yContrast","event":"change","checked":true})
 controller.action({"op":"event","domId":"applyAudio","event":"click"})
 check(controller.snapshot.bodyClasses.contains("a11y-text-huge"),"large text bridge")
 check(controller.snapshot.bodyClasses.contains("a11y-contrast"),"contrast bridge")
 var ui = preload("res://scripts/native_ui.gd").new()
 ui.controller = controller
 root.add_child(ui)
 for node in [{"tag":"input","type":"checkbox","disabled":true},{"tag":"input","type":"range","disabled":true},{"tag":"select","disabled":true,"children":[{"tag":"option","text":"Unavailable","value":"x","disabled":true}]},{"tag":"textarea","readOnly":true,"value":"first\nsecond"}]:
  var control = ui.widget(node)
  if control is BaseButton:
   check(control.disabled,"disabled button")
  if control is HSlider or control is TextEdit:
   check(not control.editable,"readonly/disabled input")
  if control is OptionButton:
   check(control.is_item_disabled(0),"disabled option")
  if control is TextEdit:
   check(control.text.contains("\n"),"multiline report")
  control.free()
 print("Native contract checks ","FAILED" if failed else "PASSED")
 quit(1 if failed else 0)
