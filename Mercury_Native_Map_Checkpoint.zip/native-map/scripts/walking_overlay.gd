extends Node3D
var paths := MeshInstance3D.new()
var route := MeshInstance3D.new()
func _ready() -> void:
 var data = JSON.parse_string(FileAccess.get_file_as_string("res://assets/walking.json"))
 var mesh := ImmediateMesh.new()
 mesh.surface_begin(Mesh.PRIMITIVE_LINES)
 for segment in data.segments:
  mesh.surface_add_vertex(world(data.nodes[segment.a]))
  mesh.surface_add_vertex(world(data.nodes[segment.b]))
 mesh.surface_end()
 paths.mesh = mesh
 paths.material_override = ink(Color("60cfed"))
 route.material_override = ink(Color("fff0a1"))
 paths.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
 route.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
 add_child(paths)
 add_child(route)
 visible = false
func world(point: Array) -> Vector3:
 return Vector3((float(point[0])-1.55)*1670,0.16,(float(point[1])-2.52)*1670)
func ink(color: Color) -> StandardMaterial3D:
 var material := StandardMaterial3D.new()
 material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
 material.albedo_color = color
 material.no_depth_test = true
 return material
func show_route(points: Array) -> void:
 var mesh := ImmediateMesh.new()
 if points.size()>1:
  mesh.surface_begin(Mesh.PRIMITIVE_LINE_STRIP)
  for point in points:
   mesh.surface_add_vertex(world([point.x,point.y]))
  mesh.surface_end()
 route.mesh = mesh
