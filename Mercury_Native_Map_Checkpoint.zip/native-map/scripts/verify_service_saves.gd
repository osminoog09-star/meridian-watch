extends SceneTree
# Claude 16.10: saves of the services made by the current APK game (rescue with a fire, ambulance with a patient, the 112 desk,
# ambulance and rescue chiefs, police) migrate into the native game unchanged and keep running in the native core.
const Controller = preload("res://scripts/native_ui_controller.gd")
const Core = preload("res://scripts/simulation_core.gd")
func _initialize() -> void:
 var saves = JSON.parse_string(FileAccess.get_file_as_string("res://simulation/service-save-fixtures.json"))
 var ui = Controller.new()
 var core = Core.new()
 if not ui.initialize({}) or not core.initialize():
  quit(1)
  return
 var passed := 0
 for fixture in saves:
  ui._legacy_storage_ready(JSON.stringify({"meridian-watch-v1":fixture.save}),"")
  if not ui.migration_error.is_empty() or not ui.snapshot.status.hadSave:
   push_error("%s %s: migration refused: %s" % [fixture.mode,fixture.service,ui.migration_error])
   quit(2)
   return
  core.invoke({"op":"load","save":fixture.save})
  var imported = JSON.parse_string(ui.runtime.eval("MercuryUI.call('{\"op\":\"state\"}')"))
  var expected = core.state()
  if imported!=expected:
   push_error("%s %s: imported state differs" % [fixture.mode,fixture.service])
   quit(3)
   return
  if str(imported.get("agency","police"))!=str(fixture.service):
   push_error("%s %s: service lost (%s)" % [fixture.mode,fixture.service,str(imported.get("agency"))])
   quit(4)
   return
  for k in range(240):
   core.invoke({"op":"tick","dt":0.5})
  var after = core.state()
  if typeof(after)!=TYPE_DICTIONARY or float(after.time)<=float(expected.time):
   push_error("%s %s: the migrated shift does not run" % [fixture.mode,fixture.service])
   quit(5)
   return
  passed += 1
 print(JSON.stringify({"service_save_migrations":passed,"services":"rescue fire, ambulance patient, 112 desk, ambulance and rescue chiefs, police, head of the 112 centre"}))
 quit(0)
