extends Node3D
# Claude 17.10.2026 (Release R4 «Город 2.0», first part). Owner: «город не нравится, непонятный». The places that matter
# are marked on the map so a player always knows where they are: the police station, the fire station, the hospital,
# the prefecture with its rapid response team and the player's own home. Each is a tall coloured mast with a sign
# (billboard text, readable from far away, smaller near the camera), and the block around it gets a coloured pad.
const STYLE := {"hq":["2f6fd0","Полицейский участок"],"fire":["d0452f","Пожарная часть"],"hospital":["e8e8e8","Больница"],"gbr":["1d2a44","Префектура · ГБР"],"home":["e0a83a","Ваш дом"]}
var built := {}
# Tests quit the tree without a frame to free queued nodes; free the signs and masts with this node.
func _exit_tree() -> void:
 for child in get_children():
  child.free()
 built.clear()
func world(p: Dictionary) -> Vector3:
 return Vector3((float(p.get("x",1.55))-1.55)*1670,0.0,(float(p.get("y",2.52))-2.52)*1670)
func refresh(places: Array) -> void:
 # headless checks quit without freeing the dummy renderer's instances of these nodes (an exit-time error); no signs there
 if DisplayServer.get_name()=="headless":
  return
 var seen := {}
 for place in places:
  var key := str(place.get("kind",""))+"@"+str(snappedf(float(place.get("x",0)),0.0001))+","+str(snappedf(float(place.get("y",0)),0.0001))
  seen[key] = true
  if built.has(key):
   continue
  built[key] = make(place)
  add_child(built[key])
 for key in built.keys():
  if not seen.has(key):
   built[key].queue_free()
   built.erase(key)
func make(place: Dictionary) -> Node3D:
 var kind := str(place.get("kind","hq"))
 var style: Array = STYLE.get(kind,STYLE.hq)
 var node := Node3D.new()
 node.name = "Landmark_"+kind
 node.position = world(place)+Vector3(14,0,10)
 var mast := MeshInstance3D.new()
 var cylinder := CylinderMesh.new()
 cylinder.top_radius = 0.6
 cylinder.bottom_radius = 0.9
 cylinder.height = 46.0
 cylinder.radial_segments = 8
 mast.mesh = cylinder
 mast.position.y = 23.0
 var mat := StandardMaterial3D.new()
 mat.albedo_color = Color(style[0])
 mat.emission_enabled = true
 mat.emission = Color(style[0])
 mat.emission_energy_multiplier = 0.35
 mast.material_override = mat
 mast.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
 # the mast is for the city view; close up it would stand in the street — only the sign stays
 mast.visibility_range_begin = 320.0
 node.add_child(mast)
 var pad := MeshInstance3D.new()
 var disc := CylinderMesh.new()
 disc.top_radius = 14.0
 disc.bottom_radius = 14.0
 disc.height = 0.12
 pad.mesh = disc
 pad.position.y = 0.18
 var pad_mat := StandardMaterial3D.new()
 pad_mat.albedo_color = Color(style[0],0.35)
 pad_mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
 pad_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
 pad.material_override = pad_mat
 # (the pad covered the street at the station; left out)
 var sign := Label3D.new()
 sign.text = str(place.get("label",style[1]))
 sign.billboard = BaseMaterial3D.BILLBOARD_ENABLED
 sign.fixed_size = true
 sign.pixel_size = 0.0011
 sign.font_size = 30
 sign.outline_size = 10
 sign.modulate = Color("ffffff")
 sign.outline_modulate = Color(style[0]).darkened(0.45)
 sign.no_depth_test = true
 sign.render_priority = 2
 sign.position.y = 50.0
 sign.visibility_range_begin = 0.0
 node.add_child(sign)
 return node
