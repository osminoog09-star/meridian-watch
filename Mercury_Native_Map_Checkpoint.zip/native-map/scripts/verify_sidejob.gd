extends SceneTree
# Claude 17.10 (Release P1 «Вторая работа»): in the native core a career officer notifies the head about a taxi side
# job, gets the answer two shifts later, and the native personal file shows the second job.
const Core = preload("res://scripts/simulation_core.gd")
const Controller = preload("res://scripts/native_ui_controller.gd")
var failed := false
func check(ok: bool,message: String) -> void:
 if not ok:
  failed = true
  push_error(message)
func _initialize() -> void:
 var core = Core.new()
 if not core.initialize():
  quit(1)
  return
 core.invoke({"op":"create","mode":"career","seed":7182,"options":{"schedule":"ppa"}})
 var raw: Dictionary = JSON.parse_string(core.serialize())
 raw.life.money = 100
 core.invoke({"op":"load","save":JSON.stringify(raw)})
 var r = core.invoke({"op":"command","name":"takeSideJob","args":["taxi",true]})
 check(typeof(r)==TYPE_DICTIONARY and r.get("ok",false),"the notice is filed")
 for k in range(2):
  var s: Dictionary = JSON.parse_string(core.serialize())
  s.ended = true
  core.invoke({"op":"load","save":JSON.stringify(s)})
  core.invoke({"op":"nextShift"})
 var state: Dictionary = core.state()
 check(str(state.life.get("sideJob",{}).get("status",""))=="approved","the head approved the taxi")
 var ui = Controller.new()
 if not ui.initialize({"meridian-watch-v1":core.serialize()}):
  check(false,"the UI did not start")
 else:
  ui.action({"op":"event","domId":"continueBtn","event":"click"})
  ui.action({"op":"event","domId":"serviceBtn","event":"click"})
  var text := JSON.stringify(ui.snapshot.get("tree",[]))
  check(text.contains("Вторая работа") and text.contains("согласована"),"the personal file shows the second job")
 print("Side job: notice, answer, personal file ","FAILED" if failed else "PASSED")
 quit(1 if failed else 0)
