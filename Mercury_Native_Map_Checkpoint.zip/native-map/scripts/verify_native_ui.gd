extends SceneTree
const Controller = preload("res://scripts/native_ui_controller.gd")
func _initialize() -> void:
 var ui = Controller.new()
 ui.store.path = "user://mercury-ui-verification.json"
 if not ui.initialize({}):
  quit(1)
  return
 # Use a clean context regardless of personal saved data.
 ui.action({"op":"event","domId":"startCareer","event":"click"})
 if not ui.snapshot.status.started or not JSON.parse_string(ui.runtime.eval("MercuryUI.call('{\"op\":\"state\"}')")).life.has("week"):
  quit(2)
  return
 ui.action({"op":"event","domId":"closeModal","event":"click"})
 for id in ["serviceBtn","reportBtn","settingsBtn","journalBtn","helpBtn"]:
  if ui.invoke({"op":"event","domId":id,"event":"click"})==null or ui.snapshot.tree[0].tag!="dialog":
   quit(3)
   return
  ui.action({"op":"event","domId":"closeModal","event":"click"})
 for frame in range(300):
  ui.advance(1.0/60)
 ui.background()
 if not ui.snapshot.status.paused or not ui.snapshot.storage.has("meridian-watch-v1"):
  quit(4)
  return
 print("Native UI: career first week,5 screens,300frames/background save passed")
 quit(0)
