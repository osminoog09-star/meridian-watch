extends SceneTree
# Claude 16.10: one finger moving on the map pans it once — the emulated mouse copy of the same touch must not pan it
# a second time (the map moved twice as fast as the finger and drifted while pinching).
var failed := false
func _initialize() -> void:
 call_deferred("verify")
func frames(n: int) -> void:
 for i in range(n):
  await process_frame
func verify() -> void:
 root.size = Vector2i(794,926)
 var scene = load("res://main.tscn").instantiate()
 root.add_child(scene)
 await frames(8)
 scene.campaign.initialize({})
 scene.campaign.store.path = "user://map-touch-verification.json"
 scene.campaign.action({"op":"event","domId":"startCareer","event":"click"})
 scene.campaign.action({"op":"event","domId":"closeModal","event":"click"})
 await frames(10)
 scene.set_process(false)
 scene.following = false
 var start := Vector2(560,420)
 var touch := InputEventScreenTouch.new()
 touch.index = 0
 touch.position = start
 touch.pressed = true
 Input.parse_input_event(touch)
 await frames(2)
 var before: Vector3 = scene.focus
 var motion := InputEventScreenDrag.new()
 motion.index = 0
 motion.position = start+Vector2(0,100)
 motion.relative = Vector2(0,100)
 Input.parse_input_event(motion)
 await frames(2)
 var moved: float = scene.focus.distance_to(before)
 var single: Vector3 = before
 scene.focus = before
 scene.pan_camera(Vector2(0,100))
 var expected: float = scene.focus.distance_to(single)
 touch = touch.duplicate()
 touch.position = motion.position
 touch.pressed = false
 Input.parse_input_event(touch)
 await frames(2)
 print("finger 100 px: map moved ",moved," m, one pan is ",expected," m")
 if absf(moved-expected)>expected*0.05:
  failed = true
  push_error("the map moved %.2fx the finger" % (moved/maxf(0.001,expected)))
 print("Map touch ","FAILED" if failed else "PASSED")
 quit(1 if failed else 0)
