// Claude 17.10 (Release R2 «Звук»): the radio voice. A radio line is cut into fragments (phrases between punctuation,
// numbers apart); each fragment is a recorded clip of one of three voices — the duty officer, crew A and crew B. The
// same cutting builds the clip bank (tools/make_sounds.py) and picks clips in the game, so every line the game says
// is voiced from the bank; a fragment without a clip is skipped.
export const VOICES=Object.freeze(['duty','crewA','crewB']);
const DUTY=/^(Дежурный|Командный центр|Префектура|112)/;
export function radioVoice(from){const f=String(from??'');if(DUTY.test(f))return 'duty';const m=f.match(/(\d+)\s*$/);return m&&Number(m[1])%2===0?'crewB':'crewA';}
export const fragmentKey=t=>t.toLowerCase().replace(/ё/g,'е').replace(/[^a-zа-я0-9 -]/g,' ').replace(/\s+/g,' ').trim().replace(/^-+|-+$/g,'').trim();
export function radioFragments(text){const out=[];for(const chunk of String(text??'').replace(/№\s*/g,'номер ').split(/[,.:;!?—()«»]+\s*/)){for(const piece of chunk.split(/(\d+)/)){if(/^\d+$/.test(piece)){out.push({key:'n'+piece,text:piece});continue;}const key=fragmentKey(piece);if(key)out.push({key,text:piece.trim().replace(/^-+|-+$/g,'').trim()});}}return out;}
export const clipName=(voice,key)=>{let h=2166136261;for(const c of voice+'|'+key){h^=c.codePointAt(0);h=Math.imul(h,16777619);}return voice+'-'+(h>>>0).toString(36);};
