import {modelPalette} from './source/models.js';
export function humanStyle(officer=false,color='#95adc2',service=null) {
 return {palette:modelPalette({officer,color,service})};
}
