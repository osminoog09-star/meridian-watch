import {modelPalette} from './source/models.js';
export function humanStyle(officer=false,color='#95adc2') {
 return {palette:modelPalette({officer,color})};
}
