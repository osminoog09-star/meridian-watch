import {modelPalette} from './source/models.js';
// Claude 16.10 (Release O): the player's own officer wears the hero's skin and hair.
export function humanStyle(officer=false,color='#95adc2',service=null,look=null) {
 return {palette:{...modelPalette({officer,color,service}),...(look?{skin:look.skin,hair:look.hair}:{})}};
}
