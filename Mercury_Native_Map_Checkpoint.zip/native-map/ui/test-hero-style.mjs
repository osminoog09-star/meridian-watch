// Claude 16.10 (Release O): the player's own officer wears the hero's skin and hair; other officers keep the uniform default.
import assert from 'node:assert/strict';
import {humanStyle} from './human-style.js';
import {heroLook,makeHero,HERO} from './source/hero.js';
const hero=makeHero({first:'Яна',last:'Ребане',gender:'f',age:24,skin:3,hair:'long',hairColor:3}).hero;
const mine=humanStyle(true,undefined,'police',heroLook(hero)),other=humanStyle(true,undefined,'police');
assert.equal(mine.palette.skin,HERO.skins[3]);assert.equal(mine.palette.hair,HERO.hairColors[3]);
assert.equal(mine.palette.uniform,other.palette.uniform,'the same uniform');assert.notEqual(other.palette.skin,HERO.skins[3]);
assert.equal(humanStyle(true,undefined,'police',heroLook({...hero,hair:'shaved'})).palette.hair,HERO.skins[3],'shaved head shows skin');
const src=(await import('node:fs')).readFileSync(new URL('./map-view.js',import.meta.url),'utf8');assert.match(src,/u\.id===1&&index===0\?heroLook\(state\.hero\)/);
console.log('Hero style: the player officer wears the hero look');
