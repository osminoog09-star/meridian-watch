// Claude 17.10 (Release R2 «Звук»): the sample-based sound decides beds, the own engine, sirens and events from the
// game state; every radio line of a shift is voiced from the clip bank.
import assert from 'node:assert/strict';
import {createGame,tick,assign,spawnIncident} from './source/sim.js';
import {audioParameters} from './audio-parameters.js';
import {radioClips} from './sound-scene.js';
import bank from '../audio/voice/bank.json' with {type:'json'};
const prefs={enabled:true,master:.6,radio:.6,siren:.4,engine:.3,environment:.5};
const s=createGame('career',7182,{schedule:'ppa'});s.units.forEach(u=>{u.status='patrol';delete u.routineLeft;});
const counts={},voiced={lines:0,clips:0,missing:0};let sirens=0,engine=0,t=0;
const frame=weather=>({state:s,selected:1,active:true,scene:{x:s.units[0].x,y:s.units[0].y,zoom:9},environment:{weather,date:{minute:13*60,month:6}}});
for(let k=0;k<3000;k++){tick(s,.5);t+=.25;if(k===50){const i=spawnIncident(s,null);assign(s,1,i.id,true);}
 const a=audioParameters(frame(k<1500?'rain':'clear'),prefs,t,{x:s.units[0].x,y:s.units[0].y,zoom:9});assert.ok(a.sound,'sound scene');
 for(const e of a.sound.events){counts[e.kind]=(counts[e.kind]??0)+1;if(e.kind==='radio'){voiced.lines++;voiced.clips+=e.clips.length;if(!e.clips.length)voiced.missing++;assert.ok(['duty','crewA','crewB'].includes(e.voice));}}
 if(a.sound.sirens.length){sirens++;for(const x of a.sound.sirens){assert.ok(['police','ambulance','rescue'].includes(x.kind));assert.ok(['wail','yelp','hilo'].includes(x.mode));assert.ok(x.pitch>=.85&&x.pitch<=1.15);}}
 if(a.sound.car.gain>0)engine++;
 for(const v of Object.values(a.sound.beds))assert.ok(v>=0&&v<=1);
 if(k===100)assert.ok(a.sound.beds.rain>0,'rain is heard in rain');if(k===2000)assert.equal(a.sound.beds.rain,0,'no rain when clear');}
assert.ok(voiced.lines>5,'radio lines: '+voiced.lines);assert.ok(voiced.missing===0,'every radio line has a voice: '+JSON.stringify(voiced));
assert.ok(sirens>0,'the own car drives to the call with a siren');assert.ok(engine>0,'the own engine');assert.ok(counts.newcall>0,'the console announces calls');
const r=radioClips('Дежурный','Меридиан-01, для вас вызов: кража в магазине, Центр. Приём.');assert.ok(r.voice==='duty'&&r.clips.length>=5,JSON.stringify(r));
assert.ok(radioClips('Меридиан-02','Выезжаем на №134').clips.length>=3,'a three-digit call number: hundreds and the rest');
for(const v of ['duty','crewA','crewB'])assert.ok(Object.keys(bank[v]).length>200,v);
console.log('Sound scene:',JSON.stringify(counts),JSON.stringify(voiced),'siren frames',sirens,'PASSED');
