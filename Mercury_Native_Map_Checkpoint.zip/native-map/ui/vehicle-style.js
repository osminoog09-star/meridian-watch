import {modelPalette} from './source/models.js';
import {LIVERIES} from './source/garage.js';
export function vehicleStyle(vehicle={},police=true){
 const livery=LIVERIES[vehicle.paint]??LIVERIES.white;
 const options={paint:police?livery.paint:(vehicle.color??'#95adc2'),stripe:police?livery.stripe:null,lights:police?(vehicle.lights??'redblue'):null};
 return {police,kit:police?(vehicle.kit??'base'):'base',
  palette:modelPalette({...options,beaconActive:false}),
  activePalette:modelPalette({...options,beaconActive:true,flash:false}),
  flashPalette:modelPalette({...options,beaconActive:true,flash:true})};
}
