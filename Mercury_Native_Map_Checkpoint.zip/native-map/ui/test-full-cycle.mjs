// Claude 16.10 (Release O): a chief campaign is earned in a career — these scenarios start from an earned one.
import fs from 'node:fs';
import vm from 'node:vm';
import assert from 'node:assert/strict';
const bundle=fs.readFileSync(new URL('./ui-bundle.js',import.meta.url),'utf8');
const flatten=nodes=>nodes.flatMap(n=>[n,...flatten(n.children??[])]);
function engine(){const c=vm.createContext({console});vm.runInContext(bundle,c);return r=>JSON.parse(c.MercuryUI.call(JSON.stringify(r)));}
const results=[],traces=[];
for(const mode of ['career','chief']){
 const invoke=engine(),requests=[];
 const call=r=>{requests.push(r);return invoke(r)};
 let s=call({op:'initialize',storage:{'mercury-chief-unlocked':"{\"police\": {\"first\": \"Анна\", \"last\": \"Тамм\", \"gender\": \"f\", \"age\": 41, \"skin\": 1, \"hair\": \"bun\", \"hairColor\": 1, \"build\": \"average\", \"beard\": false, \"glasses\": false}, \"rescue\": {\"first\": \"Анна\", \"last\": \"Тамм\", \"gender\": \"f\", \"age\": 41, \"skin\": 1, \"hair\": \"bun\", \"hairColor\": 1, \"build\": \"average\", \"beard\": false, \"glasses\": false}, \"ems\": {\"first\": \"Анна\", \"last\": \"Тамм\", \"gender\": \"f\", \"age\": 41, \"skin\": 1, \"hair\": \"bun\", \"hairColor\": 1, \"build\": \"average\", \"beard\": false, \"glasses\": false}, \"dispatch\": {\"first\": \"Анна\", \"last\": \"Тамм\", \"gender\": \"f\", \"age\": 41, \"skin\": 1, \"hair\": \"bun\", \"hairColor\": 1, \"build\": \"average\", \"beard\": false, \"glasses\": false}}"}});
 const event=(domId,value,event='click',checked)=>s=call({op:'event',domId,event,...(value!==undefined?{value}:{}),...(checked!==undefined?{checked}:{})});
 event(mode==='career'?'startCareer':'startChief');
 if(mode==='chief')for(let i=0;i<4;i++)event('wizardNext');else{assert.ok(call({op:'state'}).life.week);event('closeModal');}
 assert.equal(s.status.started,true);assert.ok(s.view.units.length);
 for(const id of [mode==='career'?'serviceBtn':'departmentBtn','reportBtn','settingsBtn','journalBtn','helpBtn']){event(id);assert.equal(s.tree[0].tag,'dialog',id);assert.ok(flatten(s.tree).some(n=>n.tag==='h2'),id);event('closeModal');}
 event('settingsBtn');event('a11yText','huge','change');event('a11yContrast',undefined,'change',true);event('settingsWorldRate','45','change');event('applyAudio');
 await Promise.resolve();await Promise.resolve();s=call({op:'snapshot'});
 assert.match(s.bodyClasses,/a11y-text-huge/);assert.match(s.bodyClasses,/a11y-contrast/);assert.equal(s.status.worldRate,45);
 const speed=flatten(s.tree).find(n=>n.tag==='button'&&n.text==='60×');assert.ok(speed);s=call({op:'event',id:speed.id,event:'click'});
 let frames=0;for(;frames<3000&&!s.view.ended;frames++)s=call({op:'frame',seconds:1/30,full:true});
 assert.equal(s.view.ended,true,mode+' shift ends');let end=call({op:'state'});assert.ok(end.resolved+end.missed>0);
 event('reportBtn');event('exportBtn');const exported=s.download.parts.join('');assert.deepEqual(JSON.parse(exported),end);call({op:'consume-download'});
 event('nextShiftBtn');if(flatten(s.tree).some(n=>n.domId==='startShiftBtn'))event('startShiftBtn');if(flatten(s.tree).some(n=>n.domId==='toShiftBtn'))event('toShiftBtn');
 const next=call({op:'state'});assert.equal(next.shift,2);assert.equal(next.ended,false);
 s=call({op:'snapshot'});const resume=engine();let rs=resume({op:'initialize',storage:s.storage});assert.equal(rs.status.hadSave,true);resume({op:'event',domId:'continueBtn',event:'click'});assert.deepEqual(resume({op:'state'}),next);
 event('reportBtn');s=call({op:'file',domId:'importFile',text:exported,name:'save.json'});await Promise.resolve();await Promise.resolve();s=call({op:'snapshot'});assert.ok(flatten(s.tree).some(n=>n.domId==='applyImport'));event('applyImport');assert.deepEqual(call({op:'state'}),end);
 traces.push({mode,requests,expected:end});results.push({mode,frames,resolved:end.resolved,missed:end.missed,shift2:true,restartExact:true,importExact:true});console.log(results.at(-1));
}
fs.writeFileSync(new URL('./full-cycle-traces.json',import.meta.url),JSON.stringify(traces));fs.writeFileSync(new URL('./full-cycle-results.json',import.meta.url),JSON.stringify(results,null,2));
