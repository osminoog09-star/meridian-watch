import {vehicleLighting} from './vehicle-lighting.js';
import {humanStyle} from './human-style.js';
import {parseHTML} from './node_modules/linkedom/worker.js';
import html from './index.html';
import {audioParameters} from './audio-parameters.js';
import * as sim from './source/sim.js';
import {onlookersFor} from './source/onlookers.js';
import {dateOf} from './source/season.js';
import {fireworksTime} from './source/audio-design.js';
import {mapActors} from './map-view.js';
import {callSummary} from './call-summary.js';
import {PROFILES} from './source/agency.js';
import {shiftSummary} from './shift-summary.js';
let app,clock=0,raf=[],timers=new Map(),nextTimer=1,storage=new Map(),elements=new Map(),ids=new WeakMap(),serial=1,download=null;
let document,window;
const noop=()=>{};
function setup(request){
 storage=new Map(Object.entries(request.storage??{}));clock=0;raf=[];timers.clear();elements.clear();ids=new WeakMap();serial=1;
 ({document,window}=parseHTML(html));
 const proto=window.HTMLElement.prototype;
 proto.focus=noop;proto.scrollIntoView=noop;proto.getBoundingClientRect=()=>({x:0,y:0,left:0,top:0,width:412,height:900,right:412,bottom:900});
 proto.showModal=function(){this.open=true};proto.close=function(){this.open=false};
 Object.defineProperty(window.HTMLInputElement.prototype,'checked',{get(){return this.hasAttribute('checked')},set(v){if(v)this.setAttribute('checked','');else this.removeAttribute('checked')},configurable:true});
 Object.defineProperty(window.HTMLSelectElement.prototype,'value',{get(){return this.querySelector('option[selected]')?.value??this.querySelector('option')?.value??''},set(v){for(const option of this.querySelectorAll('option')){if(option.value===String(v))option.setAttribute('selected','');else option.removeAttribute('selected')}},configurable:true});
 const context=new Proxy({measureText:t=>({width:String(t).length*8}),getImageData:()=>({data:new Uint8ClampedArray(4)}),createLinearGradient:()=>({addColorStop:noop}),createRadialGradient:()=>({addColorStop:noop})},{get:(t,k)=>k in t?t[k]:noop,set:(t,k,v)=>(t[k]=v,true)});
 window.HTMLCanvasElement.prototype.getContext=function(){context.canvas=this;return context};
 globalThis.nativeModelPreview=(canvas,kind,options)=>{if(canvas)canvas.nativePreview={kind,options}};
 const global={document,window,navigator:{userAgent:'MercuryResponseNative Android',clipboard:{writeText:t=>{globalThis.nativeClipboard=String(t);return Promise.resolve()}},vibrate:p=>{globalThis.nativeSignals.push(p);return true}},innerWidth:request.width??412,innerHeight:request.height??900,devicePixelRatio:1,performance:{now:()=>clock},localStorage:{getItem:k=>storage.get(k)??null,setItem:(k,v)=>storage.set(String(k),String(v)),removeItem:k=>storage.delete(k)},requestAnimationFrame:f=>{raf.push(f);return raf.length},cancelAnimationFrame:noop,setTimeout:(f,ms=0)=>{const id=nextTimer++;timers.set(id,{f,due:clock+ms});return id},clearTimeout:id=>timers.delete(id),setInterval:(f,ms=0)=>{const id=nextTimer++;timers.set(id,{f,due:clock+ms,interval:Math.max(1,ms)});return id},clearInterval:id=>timers.delete(id),Blob:class{constructor(parts,options){this.parts=parts;this.type=options?.type}},URL:{createObjectURL(blob){download={parts:blob.parts,type:blob.type};return 'native-export'},revokeObjectURL:noop},ResizeObserver:class{observe(){} disconnect(){}}};
 for(const [key,value] of Object.entries(global))globalThis[key]=value;
 window.matchMedia=()=>({matches:true,addEventListener:noop,removeEventListener:noop});window.devicePixelRatio=1;
 document.hidden=false;globalThis.nativeMapCommands=[];globalThis.nativeAudioCommands=[];globalThis.nativeSignals=[];globalThis.nativeClipboard=null;globalThis.nativeRenderStats={native:true};globalThis.nativeFrameHistory=[];
 const anchorClick=window.HTMLAnchorElement.prototype.click;window.HTMLAnchorElement.prototype.click=function(){if(this.getAttribute('href')==='native-export'){download.name=this.download||'Mercury_Response_Save.json';return;}return anchorClick?.call(this)};
 app=require('./source/app.js');
 return snapshot();
}
function view(){const state=app.nativeCampaign();const minute=sim.cityAbsoluteMinute(state),weather=sim.shiftWeather(state);return {lighting:vehicleLighting(minute,sim.sunOf(state)),fireworks:fireworksTime({...dateOf(minute),minute:((minute%1440)+1440)%1440}),time:state.time,absoluteMinute:minute,shift:state.shift,ended:state.ended,mode:state.mode,budget:state.budget,trust:state.trust,rank:state.rank,sun:sim.sunOf(state),weather,...mapActors(state),agency:state.agency??'police',rankTitle:state.mode==='career'?((PROFILES[state.agency]?.ranks??sim.RANKS)[state.rank??0]??''):'',call:callSummary(state,null),selectedCall:app.nativeStatus().selectedCall!=null?callSummary(state,app.nativeStatus().selectedCall):null,report:state.ended?shiftSummary(state):null,onlookers:state.incidents.flatMap(i=>onlookersFor(i,{minute,weather:weather.kind,event:weather.event?.id}).map(p=>({...p,nativeStyle:humanStyle(false,p.role==='witness'?'#d9b25f':'#7f8c9b')})))};}
// Controls may survive several source DOM refreshes while a finger is down.
// Resolve data-bound actions in their live container, never click detached nodes.
function eventTarget(el){
 const data=Object.fromEntries(Array.from(el.attributes??[]).filter(a=>a.name.startsWith('data-')).map(a=>[a.name,a.value]));
 if(!Object.keys(data).length)return null;
 let parent=el.parentElement;while(parent&&!parent.id)parent=parent.parentElement;
 return {tag:el.tagName.toLowerCase(),scope:parent?.id??'',data};
}
function resolveEvent(request){
 if(request.domId)return document.getElementById(request.domId);
 const old=elements.get(request.id);
 if(old?.el.isConnected)return old.el;
 const target=request.target??old?.target;
 if(!target||!Object.keys(target.data??{}).length)return null;
 const scope=target.scope?document.getElementById(target.scope):document;
 if(!scope)return null;
 const matches=Array.from(scope.querySelectorAll('*')).filter(el=>el.tagName.toLowerCase()===target.tag&&Object.entries(target.data).every(([key,value])=>key.startsWith('data-')&&el.getAttribute(key)===value));
 return matches.length===1?matches[0]:null;
}
function node(el,depth=0){
 if(depth>30)return null;if(el.nodeType===3){const text=el.textContent.replace(/\s+/g,' ').trim();return text?{tag:'#text',text}:null;}if(el.nodeType!==1||['SCRIPT','STYLE'].includes(el.tagName)||el.tagName==='CANVAS'&&el.id==='map')return null;
 if(el.id==='toast'&&!el.classList.contains('visible'))return null;
 if(el.hidden||el.style?.display==='none'||el.classList.contains('hidden'))return null;
 let id=ids.get(el);if(!id){id='n'+serial++;ids.set(el,id)}elements.set(id,{el,time:clock,target:eventTarget(el)});
 const tag=el.tagName.toLowerCase(),base={tag,id,domId:el.id,target:eventTarget(el),classes:el.className?.toString()??'',style:el.getAttribute('style')??'',open:!!el.open||el.hasAttribute('open'),readOnly:!!el.readOnly||el.hasAttribute('readonly'),placeholder:el.getAttribute('placeholder')??'',disabled:!!el.disabled||el.hasAttribute('disabled'),value:el.value??'',checked:!!el.checked,type:el.type??'',text:['button','option'].includes(tag)?el.textContent.trim():'',min:el.min,max:el.max,step:el.step};
 if(tag==='canvas')base.preview=el.nativePreview??null;
 if(tag==='svg'){base.markup=el.outerHTML;return base;}
 base.children=Array.from(el.childNodes).map(c=>node(c,depth+1)).filter(Boolean);return base;
}
function nativeDiagnostics(){
 const area=document.getElementById('diagSummary');if(!area)return;
 const stats=globalThis.nativeRenderStats??{};
 area.textContent='Godot · интервалы кадров приложения, не время GPU\n'+JSON.stringify(stats,null,2);
 const button=document.getElementById('diagExport');if(button)button.onclick=()=>{download={parts:[JSON.stringify({engine:'Godot',metrics:stats,frames:globalThis.nativeFrameHistory},null,2)],type:'application/json',name:'Mercury_Native_Diagnostics.json'}};
 const clear=document.getElementById('diagClear');if(clear)clear.onclick=()=>{globalThis.nativeFrameHistory=[];nativeDiagnostics()};
}
export function snapshot(){nativeDiagnostics();const modal=document.getElementById('modal');const roots=modal.open?[modal]:['header','#weather','.stats','.transport','.map-controls','.left-panel','#calls','#callDetail','.mobile-nav','#tipCard','#toast','#radioText','#decisionBtn','#a11yFlash','.device-test-bar'].map(q=>document.querySelector(q)).filter(Boolean);if(elements.size>6000)for(const [id,item] of elements)if(item.time<clock-1000)elements.delete(id);return {status:app.nativeStatus(),view:view(),tree:roots.map(el=>node(el)).filter(Boolean),storage:Object.fromEntries(storage),map:globalThis.nativeMapCommands.splice(0),audio:globalThis.nativeAudioCommands.splice(0),signals:globalThis.nativeSignals.splice(0),audioPreferences:globalThis.nativeAudioPreferences,download,clipboard:globalThis.nativeClipboard,bodyClasses:[document.documentElement.className,document.body.className].filter(Boolean).join(' ')};}
export function call(raw){const request=JSON.parse(raw);switch(request.op){case 'initialize':return JSON.stringify(setup(request));case 'frame':{clock+=Math.max(0,request.seconds)*1000;for(const [id,t] of [...timers])if(t.due<=clock){if(t.interval)t.due=clock+t.interval;else timers.delete(id);t.f()}const callbacks=raf;raf=[];for(const f of callbacks)f(clock);return JSON.stringify(request.full?snapshot():{status:app.nativeStatus(),view:view(),map:globalThis.nativeMapCommands.splice(0)});}case 'event':{const el=resolveEvent(request);if(!el||el.disabled||el.hasAttribute('disabled'))return JSON.stringify(snapshot());if(request.value!==undefined)el.value=String(request.value);if(request.checked!==undefined)el.checked=request.checked;if(request.event==='click')el.click();else el.dispatchEvent(new window.Event(request.event??'change',{bubbles:true}));return JSON.stringify(snapshot());}case 'camera':globalThis.nativeCamera(request.scene);globalThis.nativeRenderStats=request.stats??globalThis.nativeRenderStats;if(request.width){globalThis.innerWidth=request.width;globalThis.innerHeight=request.height;globalThis.devicePixelRatio=request.dpr??1;}if(request.stats?.samples&&globalThis.nativeFrameHistory.at(-1)?.sampleTime!==request.stats.sampleTime){globalThis.nativeFrameHistory.push(request.stats);if(globalThis.nativeFrameHistory.length>240)globalThis.nativeFrameHistory.shift();}return '{}';case 'walking-pick':globalThis.nativeWalkingPick(request.point);return JSON.stringify(snapshot());case 'pick':globalThis.nativePick(request.hit);return JSON.stringify(snapshot());case 'background':case 'foreground':document.hidden=request.op==='background';document.dispatchEvent(new window.Event('visibilitychange'));return JSON.stringify(snapshot());case 'audio':return JSON.stringify(audioParameters(globalThis.nativeAudioFrame,globalThis.nativeAudioPreferences,request.time,request.scene));case 'state':return sim.serialize(app.nativeCampaign());case 'snapshot':return JSON.stringify(snapshot());case 'file':{const el=document.getElementById(request.domId);el.files=[{name:request.name??'save.json',size:request.text.length,text:()=>Promise.resolve(request.text)}];el.dispatchEvent(new window.Event('change'));return JSON.stringify(snapshot());}case 'consume-download':download=null;return JSON.stringify(snapshot());default:throw Error('Unknown native UI operation');}}
