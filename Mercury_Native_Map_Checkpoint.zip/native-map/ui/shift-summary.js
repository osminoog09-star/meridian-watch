// Claude 17.10.2026 (U4 «Итог смены на одном экране»). Owner: «инфы много, толку ноль». The end of a shift in a few
// lines: how it went, the money, the way to the next rank, the skills, the people, and what matters for the next shift.
// The long report (finances, districts, history, news) stays below under «Подробный отчёт».
import {promotionCheck,SKILLS,skillLevel,LEVEL_WORDS} from './source/promotion.js';
import {mandatoryOk,COURSES,shiftNet} from './source/life.js';
import {RANKS} from './source/sim.js';
import {nextShiftInfo,isScheduled} from './source/schedule.js';
import {shiftDebrief} from './source/debrief.js';
import {lifeEvent} from './source/career2.js';
import {PROFILES} from './source/agency.js';
import {rivalName,mentorName,standing} from './source/story.js';
const hhmm=m=>`${String(Math.floor(m/60)).padStart(2,'0')}:${String(m%60).padStart(2,'0')}`;
export function shiftSummary(s){
 if(!s?.ended)return null;
 const l=s.life,scheduled=isScheduled(s),lines=[];
 const out={shift:s.shift,resolved:s.resolved,missed:s.missed,xp:s.xp,money:null,pay:null,rank:null,skills:[],people:[],next:null,warnings:[],tip:null};
 try{out.tip=shiftDebrief(s).tip;}catch{out.tip=null;}
 if(s.mode==='career'&&l){
  out.pay=scheduled?shiftNet():null;out.money=Math.round(l.money);
  const titles=PROFILES[s.agency]?.ranks??RANKS;
  const pc=promotionCheck(s,{mandatory:mandatoryOk(l,s.shift),courses:Object.keys(l.courses??{}).filter(id=>!COURSES[id]?.mandatory).length,awards:(s.awards??[]).length});
  if(pc){const ok=pc.items.filter(x=>x.ok).length;out.rank={next:titles[pc.rank]??'',ok,total:pc.items.length,missing:pc.items.filter(x=>!x.ok).slice(0,2).map(x=>x.text)};}
  out.skills=Object.entries(l.skills??{}).sort((a,b)=>b[1]-a[1]).slice(0,3).map(([id,v])=>({label:SKILLS[id]??id,level:skillLevel(v),word:LEVEL_WORDS[skillLevel(v)]??''}));
  if(l.people)out.people=[{name:mentorName(l),role:'наставник',standing:standing(l.people.mentor)},{name:rivalName(s.seed,l.agency??s.agency),role:'однокурсник',standing:standing(l.people.rival)}];
  if(l.partner&&l.partner.name!==mentorName(l))out.people.push({name:l.partner.name,role:'напарник',standing:standing(l.partner.bond??50)});
  if((l.sleepDebt??0)>=60)out.warnings.push(`Недосып ${Math.round(l.sleepDebt)}: отдохните перед сменой`);
  if((l.stress??0)>=70)out.warnings.push(`Стресс ${Math.round(l.stress)}: нужен отдых, близкие или спорт`);
  if(l.event){const ev=lifeEvent(l.event.id);if(ev)out.warnings.push(`Ждёт решения: ${ev.title}`);}
  if(l.jobMove)out.warnings.push('Заявление о переходе на другую работу рассматривается');
 }
 if(scheduled){const n=nextShiftInfo(s.shift);out.next=`${n.label[0].toUpperCase()+n.label.slice(1)} смена — ${n.when} в ${hhmm(n.startMinute)}${n.daysOff?` · сначала ${n.daysOff} выходных`:` · отдых ${Math.round(n.restHours)} ч`}`;}
 return out;
}
