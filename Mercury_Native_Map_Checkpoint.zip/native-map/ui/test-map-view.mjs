import assert from 'node:assert/strict';
import {mapActors} from './map-view.js';
import {createGame} from './source/sim.js';
const state=createGame('career',7182,{schedule:'ppa'});
const unit=state.units[0];
unit.status='patrol';
unit.foot={phase:'board',actors:unit.people.map((_,i)=>({id:'f'+i,x:unit.x,y:unit.y,heading:0})),elapsed:100};
const driver={id:'driver',x:unit.x+0.1,y:unit.y,visible:true,route:[]};
state.incidents=[{id:900,type:5,state:'working',x:unit.x,y:unit.y,scene:{participants:[driver]}},
 {id:901,type:0,state:'resolved',x:unit.x,y:unit.y},
 {id:902,type:0,state:'waiting',x:unit.x,y:unit.y,scene:{participants:[{id:'hidden',visible:false}]}}];
const before=JSON.stringify(state);
const result=mapActors(state);
assert.equal(JSON.stringify(state),before,'presentation must not change saves/RNG');
assert.deepEqual(result.incidents.map(i=>i.id),[900,902]);
assert.equal(result.incidents[0].anchor.x,driver.x,'chase call follows driver');
assert.equal(result.incidents[1].participants.length,0,'hidden missing person stays hidden');
assert.ok(result.residents.every(r=>!['home','work','incident'].includes(r.status)));
unit.foot=null;unit.status='patrol';
assert.equal(mapActors(state).units[0].crew.length,0,'officers inside vehicle are not drawn');
unit.status='decision';unit.incident=902;
assert.equal(mapActors(state).units[0].crew.length,unit.people.length,'visible crew at contact restored');
console.log('Map source anchors, visibility, crew and read-only state PASSED');
