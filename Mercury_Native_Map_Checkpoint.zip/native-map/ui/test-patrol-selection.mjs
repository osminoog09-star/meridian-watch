import fs from 'node:fs';
import vm from 'node:vm';
import assert from 'node:assert/strict';
const flatten=nodes=>nodes.flatMap(n=>[n,...flatten(n.children??[])]);
for(const width of [360,740]){
 const context=vm.createContext({console});
 vm.runInContext(fs.readFileSync(new URL('./ui-bundle.js',import.meta.url),'utf8'),context);
 const call=request=>JSON.parse(context.MercuryUI.call(JSON.stringify(request)));
 call({op:'initialize',width,height:900});
 call({op:'event',domId:'startCareer',event:'click'});
 let snapshot=call({op:'event',domId:'closeModal',event:'click'});
 snapshot=call({op:'pick',hit:{kind:'unit',id:1}});
 // A finger retains the native widget while simulation refresh replaces its DOM node.
 const retained=flatten(snapshot.tree).find(n=>n.tag==='button'&&n.text.startsWith('Патруль 02'));
 assert.ok(retained);
 for(let i=0;i<90;i++)snapshot=call({op:'frame',seconds:1/30,full:true});
 const current=flatten(snapshot.tree).find(n=>n.tag==='button'&&n.text.startsWith('Патруль 02'));
 assert.notEqual(current.id,retained.id,'Must actually replace the source DOM button');
 snapshot=call({op:'event',id:retained.id,domId:retained.domId,target:retained.target,event:'click'});
 assert.equal(snapshot.status.selectedUnit,2,`Retained patrol button must select patrol 2 at width ${width}`);
 snapshot=call({op:'event',domId:'followUnit',event:'click'});
 assert.ok(snapshot.map.some(command=>command.op==='follow'&&command.value===2),'Camera must follow the selected patrol');
 // Exercise identity even after the transient ID cache has discarded the widget.
 call({op:'pick',hit:{kind:'unit',id:1}});
 snapshot=call({op:'event',id:'expired-native-id',target:retained.target,event:'click'});
 assert.equal(snapshot.status.selectedUnit,2,'Stable identity must survive cache eviction');
 snapshot=call({op:'event',id:'expired-native-id',target:{...retained.target,data:{'data-unit':'99999'}},event:'click'});
 assert.equal(snapshot.status.selectedUnit,2,'Removed patrol must not select a different crew');
 console.log(`Patrol selection after DOM replacement: ${width}px passed`);
}
