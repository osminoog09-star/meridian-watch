import assert from 'node:assert/strict';
import {mapActors} from './map-view.js';
import {createGame} from './source/sim.js';
// Claude 15.10 (J3): crews on foot wear their service's uniform in the native map; police unchanged.
const expected={police:'#3d6d8a',rescue:'#3b4349',ems:'#2f6f5b'};
for(const [service,uniform] of Object.entries(expected)){
 const state=createGame('career',7182,{schedule:'ppa',service:service==='police'?undefined:service});
 const unit=state.units[0];
 unit.foot={phase:'board',actors:unit.people.map((_,i)=>({id:'f'+i,x:unit.x,y:unit.y,heading:0})),elapsed:100};
 const crew=mapActors(state).units[0].crew;
 assert.ok(crew.length>0,service+': crew on foot is visible');
 for(const person of crew)assert.equal(person.nativeStyle.palette.uniform,uniform,service);
}
const desk=createGame('career',7182,{schedule:'ppa',service:'dispatch'});
const seen=new Set();for(const unit of desk.units){unit.foot={phase:'board',actors:unit.people.map((_,i)=>({id:'f'+unit.id+i,x:unit.x,y:unit.y,heading:0})),elapsed:100};}
for(const u of mapActors(desk).units)for(const p of u.crew)seen.add(p.nativeStyle.palette.uniform);
assert.deepEqual([...seen].sort(),Object.values(expected).sort(),'112: the city crews of three services, each in its own uniform');
console.log('Service uniforms: police, rescue, ambulance; 112 city crews by service');
