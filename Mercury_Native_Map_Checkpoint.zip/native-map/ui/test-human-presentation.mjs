import fs from 'node:fs';
import assert from 'node:assert/strict';
import {MODELS,posedVertex} from './source/models.js';
import {humanStyle} from './human-style.js';
import {mapActors} from './map-view.js';
import {createGame} from './source/sim.js';
import {residentProfile} from './source/population.js';
const fixtures=[];
for(const kind of ['officer','civilian']){
 const model=MODELS[kind],points=new Map(),counts={};
 for(const f of model.faces){counts[f.group]=(counts[f.group]??0)+(f.v.length-2)*3;for(const id of f.v)points.set(f.group+':'+id,{group:f.group,id});}
 const samples=[];
 for(const pose of ['idle','radio','talk','search','assist'])for(const phase of [-1,0,.6,1])for(const {group,id} of points.values()){
  const expected=posedVertex(model,{group},id,{pose,phase});const p=model.vertices[id];
  samples.push({group,pose,phase,point:[p[0],p[2],p[1]],expected:[expected[0],expected[2],expected[1]]});
 }
 fixtures.push({kind,style:humanStyle(kind==='officer','#c6a7e9'),counts,samples});
}
fs.writeFileSync(new URL('./human-fixtures.json',import.meta.url),JSON.stringify(fixtures));
const state=createGame('career',7182,{schedule:'ppa'}),unit=state.units[0],resident=state.population.residents[0];
unit.status='working';unit.incident=901;unit.foot=null;
state.incidents=[{id:901,type:1,state:'working',x:unit.x,y:unit.y,scene:{participants:[{id:'p',residentId:resident.id,x:unit.x,y:unit.y,visible:true,route:[]}]}}];
resident.status='walkVisit';resident.route=[{x:resident.x+.01,y:resident.y}];
const before=JSON.stringify(state),view=mapActors(state);
assert.equal(JSON.stringify(state),before);
assert.equal(view.units[0].crew[0].pose,'assist');
assert.equal(view.units[0].crew[0].nativeStyle.palette.uniform,humanStyle(true).palette.uniform);
assert.equal(view.residents[0].nativeStyle.palette.uniform,residentProfile(resident.id).color);
assert.equal(view.residents[0].walking,true);
assert.equal(view.residents[0].vehicleStyle.police,false);
assert.equal(view.residents[0].vehicleStyle.palette.paint,residentProfile(resident.id).color);
assert.equal(view.incidents[0].participants[0].nativeStyle.palette.uniform,residentProfile(resident.id).color);
resident.status='visiting';resident.route=[];assert.equal(mapActors(state).residents[0].walking,false);
console.log('Human source pose/colour/read-only contract PASSED; vertex samples',fixtures.reduce((n,f)=>n+f.samples.length,0));
