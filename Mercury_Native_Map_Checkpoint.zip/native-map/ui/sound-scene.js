// Claude 17.10.2026 (Release R2 «Звук»). Owner 17.10: «звук надо доработать полноценно, а не то, что сейчас».
// The old native sound was a 22 kHz generator (beeps and noise). Now the game plays a bank of recorded and
// pre-rendered sounds (audio/, tools/make_sounds.py) in Godot (scripts/sound_world.gd); this module decides WHAT
// sounds and how loud, from the same state the old generator used:
//  · beds — distant city, rain, wind / storm, snow, sea or river near water, crowd at a scene, birds by day, fire;
//  · the own car — engine (petrol / diesel / truck), speed, tyres (wet in rain);
//  · sirens — up to three nearest emergency vehicles: police wail / yelp, ambulance wail / yelp, rescue hi-lo,
//    with distance, stereo and Doppler;
//  · events — the radio (a TETRA talk-permit tone and the voiced fragments of the line, radio-voice.js), a new call
//    on the console (urgent for violence), the own call closed or missed, footsteps by surface, car doors,
//    passing cars, a horn, thunder.
import {radioFragments,radioVoice} from './radio-voice.js';
import bank from '../audio/voice/bank.json' with {type:'json'};
import {MAP_METRES} from './source/world-scale.js';
import {districtOf} from './source/sim.js';

const clamp=v=>Math.max(0,Math.min(1,Number.isFinite(v)?v:0));
const URGENT_TYPES=[2,5];
let last=new Map(),outcome=new Map(),nextPass=0,nextThunder=0,nextHorn=0,seq=0;
const hash=(a,b=0)=>{let h=Math.imul((a|0)+0x9e37,2654435761)^Math.imul((b|0)+0x85eb,2246822519);h^=h>>>15;return (h>>>0)/4294967296;};

// The clips of one radio line for one voice; a number the bank does not have is said as hundreds + the rest.
export function radioClips(from,text){const voice=radioVoice(from),b=bank[voice]??{},clips=[];
 const add=key=>{const c=b[key];if(c)clips.push(c);return !!c;};
 for(const f of [...radioFragments(from),...radioFragments(text)]){if(add(f.key))continue;const m=f.key.match(/^n(\d+)$/);if(!m)continue;const n=Number(m[1]);if(n>=100&&n<1000){add('n'+Math.floor(n/100)*100);if(n%100)add('n'+(n%100));}}
 return {voice,clips};}

export function engineKind(vehicle,agency){const t=vehicle?.type??'';if(['truck','fire','ladder','tanker'].includes(t)||agency==='rescue')return 'truck';if(['van','ambulance','suv','minibus'].includes(t)||agency==='ems')return 'diesel';return 'petrol';}

export function sirenKind(item){return item.kind==='ambulance'||item.agency==='ems'?'ambulance':item.kind==='rescue'||item.agency==='rescue'?'rescue':'police';}

// Doppler from the change of distance between two calls (metres per second towards the listener → higher pitch).
function doppler(key,metres,time){const p=last.get(key);last.set(key,{metres,time});if(!p||time<=p.time)return 1;const v=(p.metres-metres)/(time-p.time);return Math.max(.85,Math.min(1.15,343/(343-Math.max(-60,Math.min(60,v)))));}

export function soundScene(c){const {s,env,scene,place,weather,amb,mix,near,crowd,u,vehicle,engine,position,gainAt,spatial,time,stepEvent,doorEvent,radioNew,fresh}=c;
 const kind=env.weather??'clear',events=[];
 const district=districtOf(scene),water=clamp(mix.water*1.4),beach=district==='beach';
 const fire=Math.max(0,...s.incidents.filter(i=>['decision','working','waiting'].includes(i.state)&&/fire/.test(i.variant??'')).map(i=>1-Math.hypot(i.x-scene.x,i.y-scene.y)*MAP_METRES/140));
 const beds={
  traffic:clamp((.35+.65*(1-near))*amb.traffic*weather.traffic*.9+mix.traffic*.6),
  rain:clamp(weather.rain*(kind==='rain'?.9:0)),
  wind:clamp(.22*weather.wind*(1-(kind==='wind'?1:0))+(.1*(1-near))),
  storm:kind==='wind'?.75:0,
  snow:kind==='snow'?.55:0,
  sea:beach?clamp(water+.25*(1-near)):0,
  river:beach?0:water,
  crowd:clamp(Math.max(amb.crowd*.6,Math.min(1,crowd/6))*near),
  birds:clamp(amb.birds*(scene.zoom>=5?1:.4)*(weather.rain?0:1)*(kind==='snow'?.3:1)),
  fire:clamp(fire*near*1.2)};
 const moving=!!u?.route?.length,kmh=moving?Math.max(0,u?.currentSpeedKmh??0):0;
 const car={on:!!engine?.level||!!engine?.noise||(u&&!u.foot&&['idle','patrol','responding','returning','transporting','proactive'].includes(u.status)),kmh,kind:engineKind(vehicle,u?.agency??s.agency),gain:clamp(position.gain),pan:position.pan??0,wet:kind==='rain'||kind==='snow'};
 if(!car.on)car.gain=0;
 // Sirens: the selected own car when it drives with lights, the nearest other crews, ambulances and rescue engines.
 const sirenItems=[];
 for(const x of s.units)if(x.route?.length&&(x.status==='responding'||x.pursuing===true)){const target=x.route.at(-1),metres=target?Math.hypot(target.x-x.x,target.y-x.y)*MAP_METRES:Infinity;sirenItems.push({key:'u'+x.id,item:x,kind:sirenKind({agency:x.agency??s.agency}),mode:x.pursuing===true||metres<120?'yelp':'wail'});}
 for(const a of s.services??[])if(a.status==='responding'&&a.route?.length&&a.kind!=='lead'){const target=a.route.at(-1),metres=target?Math.hypot(target.x-a.x,target.y-a.y)*MAP_METRES:Infinity;sirenItems.push({key:'s'+a.kind+a.id,item:a,kind:sirenKind(a),mode:a.kind==='rescue'?'hilo':metres<120?'yelp':'wail'});}
 const sirens=sirenItems.map(x=>{const g=gainAt(x.item,scene),metres=Math.hypot(x.item.x-scene.x,x.item.y-scene.y)*MAP_METRES;return {key:x.key,kind:x.kind,mode:x.mode,gain:clamp(g),pan:spatial(x.item,scene).pan??0,pitch:doppler(x.key,metres,time),muffle:clamp(metres/900)};}).filter(x=>x.gain>.01).sort((a,b)=>b.gain-a.gain).slice(0,3);
 for(const k of [...last.keys()])if(!sirenItems.some(x=>x.key===k))last.delete(k);
 if(radioNew&&s.radio?.[0]){const r=s.radio[0],{voice,clips}=radioClips(r.from,r.text),own=r.from==='Меридиан-01'||r.text.includes('Меридиан-01');events.push({kind:'radio',voice,clips,own:!!own,id:++seq});}
 if(fresh?.length)events.push({kind:'newcall',urgent:fresh.some(i=>URGENT_TYPES.includes(i.type)||!!i.armed)});
 for(const i of s.incidents){if(!i.units?.includes(1))continue;const was=outcome.get(i.id);if(was===i.state)continue;outcome.set(i.id,i.state);if(was&&i.state==='resolved')events.push({kind:'resolved'});if(was&&i.state==='missed')events.push({kind:'missed'});}
 if(outcome.size>200)outcome=new Map([...outcome].slice(-100));
 if(stepEvent)events.push({kind:'step',surface:stepEvent.surface,level:clamp(stepEvent.level)});
 if(doorEvent)events.push({kind:'door',level:clamp(doorEvent.level)});
 const t=Math.floor(time);
 if(time>=nextPass&&beds.traffic>.15&&near>.3){nextPass=time+2+6*hash(t,1)/(.3+beds.traffic);events.push({kind:'pass',variant:hash(t,2)<.5?1:2,level:clamp(beds.traffic*near*(.5+.5*hash(t,3))),pan:hash(t,4)*1.6-.8,wet:car.wet});}
 if(time>=nextHorn&&beds.traffic>.4&&near>.6){nextHorn=time+40+80*hash(t,5);if(hash(t,6)<.5)events.push({kind:'horn',level:clamp(.25+.3*hash(t,7)),pan:hash(t,8)*1.4-.7});}
 if(time>=nextThunder&&kind==='rain'&&(env.date?.month??6)>=4&&(env.date?.month??6)<=9){nextThunder=time+45+90*hash(t,9);if(hash(t,10)<.35)events.push({kind:'thunder',variant:hash(t,11)<.5?1:2,level:clamp(.4+.5*hash(t,12))});}
 return {beds,car,sirens,events,ducked:!!env.ducked};}
export function resetSoundScene(){last=new Map();outcome=new Map();nextPass=0;nextThunder=0;nextHorn=0;}
