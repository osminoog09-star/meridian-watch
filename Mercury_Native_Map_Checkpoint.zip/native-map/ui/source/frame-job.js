// Cooperative Canvas work. A yield is one atomic feature, not a guaranteed GPU budget.
export function createFrameJob(iterator,{budgetMs=4,maxItems=64,clock=()=>globalThis.performance?.now?.()??Date.now()}={}){
 let done=false,items=0;
 return {step(synchronous=false,budget=budgetMs){const start=clock();let count=0;while(!done&&(synchronous||count<maxItems&&(count===0||clock()-start<budget))){const result=iterator.next();done=!!result.done;if(!done){count++;items++;}}return {done,items,count,ms:Math.max(0,clock()-start)};},done:()=>done};
}

// Stable bottom-up merge sort. Source is read-only; equal depths keep source order.
export function* sortSlices(values,compare,chunk=256){
 let source=values.slice(),target=new Array(source.length),work=0;
 for(let size=1;size<source.length;size*=2){
  for(let start=0;start<source.length;start+=size*2){const middle=Math.min(start+size,source.length),end=Math.min(start+size*2,source.length);let left=start,right=middle;
   for(let at=start;at<end;at++){target[at]=left<middle&&(right>=end||compare(source[left],source[right])<=0)?source[left++]:source[right++];if(++work%chunk===0)yield;}
  }[source,target]=[target,source];
 }return source;
}
