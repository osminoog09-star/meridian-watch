import {travelDistance} from './transport.js';

// Follow the actual simulation polyline so a smoothed car cannot cut a corner.
export function advanceVisualPath(visual,entity,trace,dt=1/60,timeScale=1){
 const v=visual??{x:entity.x,y:entity.y,path:[],revision:0};v.path??=[];
 if(trace&&trace.revision!==v.revision){for(const p of trace.points){const last=v.path.at(-1)??v;if(Math.hypot(last.x-p.x,last.y-p.y)>1e-12)v.path.push({x:p.x,y:p.y});}v.path=v.path.slice(-64);v.revision=trace.revision;}
 if(!v.path.length&&Math.hypot(v.x-entity.x,v.y-entity.y)>1e-12)v.path.push({x:entity.x,y:entity.y});
 const frame=Math.max(0,Math.min(.5,dt)),factor=Math.max(0,Math.min(4,Number.isFinite(timeScale)?timeScale:1)),speed=Number.isFinite(entity.currentSpeedKmh)?entity.currentSpeedKmh:0;
 let queued=0,from=v;for(const p of v.path){queued+=Math.hypot(p.x-from.x,p.y-from.y);from=p;}
 if(speed>0)v.lastSpeed=speed;
 // Follow physical metres, including the last stop trace; never race to a queued snapshot.
 let budget=travelDistance(speed||v.lastSpeed||0,frame*factor);
 while(budget>1e-12&&v.path.length){const p=v.path[0],dx=p.x-v.x,dy=p.y-v.y,d=Math.hypot(dx,dy);if(d<=budget){v.x=p.x;v.y=p.y;v.path.shift();budget-=d;}else{v.x+=dx*budget/d;v.y+=dy*budget/d;budget=0;}}
 if(!v.path.length)v.lastSpeed=0;
 return v;
}
