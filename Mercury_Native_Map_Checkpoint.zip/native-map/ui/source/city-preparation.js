import data from './city-data.js';
import {CITY_VIEW,groundVector} from './city-projection.js';
import {createFeatureIndexSlices} from './feature-index.js';
import {createWallIndexSlices} from './city-light-walls.js';
import {sortSlices} from './frame-job.js';
// Shared page-level preparation. Cancellation of a camera job cannot discard index progress.
export function createCityPreparation(source,{clock=()=>globalThis.performance?.now?.()??Date.now()}={}){
 let result=null,phase='prepare',prepareMs=0,indexMs=0,steps=0,peakMs=0;
 const prep=(f,withDepth=false)=>{let l=Infinity,t=Infinity,r=-Infinity,b=-Infinity,depth=-Infinity;for(const [x,y] of f.p){l=Math.min(l,x);t=Math.min(t,y);r=Math.max(r,x);b=Math.max(b,y);if(withDepth)depth=Math.max(depth,groundVector(x,y,CITY_VIEW).y);}return {...f,box:[l,t,r,b],viewDepth:withDepth?depth:undefined};};
 function* build(){let buildings=[];const roads=[],areas=[];for(const b of source.buildings){buildings.push(prep(b,true));yield;}for(const r of source.roads){roads.push(prep(r));yield;}for(const a of source.areas){areas.push(prep(a));yield;}buildings=yield* sortSlices(buildings,(a,b)=>a.box[3]-b.box[3]);phase='index';yield;
 const buildingIndex=yield* createFeatureIndexSlices(buildings,.16,true),roadIndex=yield* createFeatureIndexSlices(roads,.16,true),areaIndex=yield* createFeatureIndexSlices(areas,.16,true),wallIndex=yield* createWallIndexSlices(source.buildings);return {buildings,roads,areas,buildingIndex,roadIndex,areaIndex,wallIndex};}
 const job=build();
 return {value:()=>result,advance(batch=1){if(result)return true;const start=clock(),stage=phase;let part;try{for(let i=0;i<Math.max(1,Math.min(64,Math.floor(batch)||1));i++){part=job.next();steps++;if(part.done||phase!==stage)break;}}finally{const ms=Math.max(0,clock()-start);if(stage==='prepare')prepareMs+=ms;else indexMs+=ms;peakMs=Math.max(peakMs,ms);}if(part.done){result=part.value;phase='ready';}return !!result;},stats:()=>({prepareMs,indexMs,preparationSteps:steps,preparationPeakMs:peakMs,preparationPending:result?0:1})};
}
export const cityPreparation=createCityPreparation(data);
