import {QUARTER} from './quarter.js';
const streets=new Map(QUARTER.streetInfo.map(r=>[r.id,r]));
// Width without an explicit tag is illustrative. No traffic rules are inferred.
export function streetStyle(road,scale,zoom){
 const source=streets.get(String(road.id))??{},tagWidth=Number(source.width),lanes=Number(source.lanes),assumed={trunk:10,primary:9,secondary:8,tertiary:7,residential:5,living_street:4,service:3.5};
 const metres=tagWidth>=1&&tagWidth<=30?tagWidth:road.drive?(lanes>=1&&lanes<=6?lanes*3.2:assumed[road.kind]??5):1.8;
 const width=Math.max(road.drive?2:1,metres*scale/1670),surface=source.surface??'unknown';
 // Claude 11.10 (mobile readability): drivable ways always read as carriageways (dark, with a light
 // curb line, surface only tints them); footways are thin, muted and have no curb, so a car on the
 // map is never mistaken for driving along a footpath.
 const walk={paving_stones:'#a49e88',cobblestone:'#918e80',sett:'#989080',gravel:'#979580',compacted:'#a8a084',unpaved:'#a69979'},drive={asphalt:'#3f4a4e',paving_stones:'#5d5f58',cobblestone:'#57584f',sett:'#595a52',gravel:'#5f5d52',compacted:'#625f54',unpaved:'#615c50'};
 const color=road.drive?drive[surface]??'#455152':walk[surface]??'#a3a08a';
 return {width:road.drive?width:Math.max(.8,width*.8),color,edge:road.bridge?'#cbd0bf':road.drive?'#9aa79e':color,edgeWidth:road.drive||road.bridge?width+Math.max(.8,scale/1670*1.1):Math.max(.8,width*.8),paving:zoom>=12&&['paving_stones','cobblestone','sett'].includes(surface),knownWidth:tagWidth>=1&&tagWidth<=30,surface,source};
}
export const sceneModelScale=(zoom,kind='vehicle')=>Math.min(kind==='tree'?6:5,Math.max(kind==='person'?1.6:2,zoom*(kind==='tree'?.16:.10)));
// Decorative paving joints only on ways with an explicit paving surface.
// Segment-local phase is deterministic; no invented crossings or traffic rules.
export function pavingJoints(road,scale,zoom){const art=streetStyle(road,scale,zoom);if(!art.paving||zoom<24)return [];const result=[],half=art.width/scale*.42,step=.9/1670;for(let i=1;i<road.p.length;i++){const a=road.p[i-1],b=road.p[i],dx=b[0]-a[0],dy=b[1]-a[1],length=Math.hypot(dx,dy);if(length<step)continue;const stride=Math.max(step,length/80),nx=-dy/length*half,ny=dx/length*half;for(let d=stride;d<length;d+=stride){const t=d/length,x=a[0]+dx*t,y=a[1]+dy*t;result.push([[x-nx,y-ny],[x+nx,y+ny]]);}}return result;}
