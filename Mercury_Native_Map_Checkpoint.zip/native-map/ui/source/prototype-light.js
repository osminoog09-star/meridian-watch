// Artistic phases for the prototype, not astronomical sunrise times.
export const PHASES=Object.freeze({dawn:{label:'Утро',sun:[-.55,.45,.5],sky:[.36,.48,.62],horizon:[.85,.71,.54],night:0,star:0,disc:[-.26,.12,0]},day:{label:'День',sun:[-.35,.82,.44],sky:[.24,.43,.63],horizon:[.65,.76,.81],night:0,star:0,disc:[-.26,.31,0]},evening:{label:'Вечер',sun:[-.75,.25,.5],sky:[.20,.27,.46],horizon:[.88,.49,.30],night:.28,star:.1,disc:[-.28,.06,0]},night:{label:'Ночь',sun:[.4,.6,-.6],sky:[.015,.035,.075],horizon:[.075,.13,.20],night:1,star:1,disc:[.23,.28,1]}});
export const phaseOrder=Object.freeze(Object.keys(PHASES));

// Only colour/exposure interpolate; shadow direction stays at the selected phase.
export function blendPhase(from,to,progress){const t=Math.max(0,Math.min(1,Number.isFinite(progress)?progress:0)),w=t*t*(3-2*t),mix=(a,b)=>t===0?a:t===1?b:a+(b-a)*w;return {...to,sky:to.sky.map((v,k)=>mix(from.sky[k],v)),horizon:to.horizon.map((v,k)=>mix(from.horizon[k],v)),night:mix(from.night,to.night),star:mix(from.star,to.star)};}
export function windowIsLit(buildingSeed,edge,row,column){return ((buildingSeed>>>0)+edge*11+row*17+column*7)%5<3;}
