// «Разбор смены» (Claude, 11.10.2026). A short, rule-based debrief at the top of the shift report:
// what went well, what needs attention and one mentor tip. Pure function over the campaign state.
import {WEATHER,weatherFor,DISTRICT_IDS} from './calls.js';
import {districtName} from './fiction.js';
import {shiftWeather} from './sim.js';

const REPEAT=/^Повторно: /;
export function shiftDebrief(s){
 // s.history belongs to the current shift (nextShift starts a fresh one).
 const history=s.history??[],missed=history.filter(h=>!h.success),repeats=history.filter(h=>REPEAT.test(h.name));
 const w=shiftWeather(s),weather=`${WEATHER[w.kind].icon} ${WEATHER[w.kind].label}, ${w.temp>0?'+':''}${w.temp}°`;
 const districts=DISTRICT_IDS.map(id=>[id,s.districts?.[id]??s.trust]).sort((a,b)=>a[1]-b[1]);
 const [worstId,worst]=districts[0],[bestId,best]=districts.at(-1);
 const custody=s.custodyDone??0;
 const good=[`Решено вызовов: ${s.resolved}`];if(custody)good.push(`Доведено до участка: ${custody}`);
 // 0.7.0 step 4: investigations opened this shift (cases list belongs to the shift).
 const cases=s.cases??[],solved=cases.filter(c=>/^Раскрыто/.test(c.status)).length,open=cases.filter(c=>/^Розыск/.test(c.status)).length;if(solved)good.push(`Раскрыто по розыску: ${solved}`);const bolo=(s.bolo??[]).filter(b=>b.matched!==null).length;if(bolo)good.push(`Ориентировки с инструктажа: ${bolo} из ${s.bolo.length}`);if(best-worst>=5)good.push(`Спокойнее всего: ${districtName(bestId)} (${Math.round(best)}%)`);
 const attention=[];if(s.missed)attention.push(`Пропущено: ${s.missed}${missed.length?` — ${[...new Set(missed.map(h=>h.name))].slice(0,3).join(', ')}`:''}`);
 if(repeats.length)attention.push(`Повторные вызовы: ${repeats.length}`);if(open)attention.push(`Дел в розыске: ${open}`);if(worst<60)attention.push(`Проблемный район: ${districtName(worstId)} (${Math.round(worst)}%)`);else if(best-worst>=5)attention.push(`Ниже всего доверие: ${districtName(worstId)} (${Math.round(worst)}%)`);
 const tip=s.missed>s.resolved?'Пропусков больше, чем решённых вызовов. Отправляйте ближайший свободный экипаж и перенаправляйте машины с мелких вызовов на срочные.'
  :repeats.length>=2?'Мягкие решения возвращаются повторными звонками. На семейные конфликты и драки берите второй экипаж.'
  :worst<50?`В районе «${districtName(worstId)}» доверие ниже половины. Там чаще будут звонить повторно.`
  :s.resolved>=4&&!custody?'Задержания доводят дело до конца и поднимают доверие района, хотя экипаж на время занят доставкой.'
  :w.kind==='rain'||w.kind==='fog'?'В плохую погоду держите свободный экипаж у крупных дорог: ДТП случаются чаще.'
  :'Ровная смена. Следите за усталостью экипажей к концу смены.';
 return {weather,good,attention,tip};
}
