import {boardingPresentation} from './vehicle-doors.js';
// Presentation only: never changes crew, routes, decision or save schema.
export const CREW_POSES=Object.freeze({idle:'Ожидание',radio:'Рация',talk:'Разговор',search:'Осмотр',assist:'Помощь'});
export function crewPresentation(state,unit,index=0){
 if(unit.foot){const f=unit.foot,a=f.actors[index],boarding=boardingPresentation(unit,index),walking=['approach','return'].includes(f.phase);if(f.phase==='onScene')return {...crewPresentation(state,{...unit,foot:null},index),position:a,walking:false};return {visible:boarding?.visible??walking,pose:'idle',label:({exit:'Выходит из машины',board:'Садится в машину',return:'Возвращается к машине'})[f.phase]??'Идёт к участникам',position:a,walking,vehicleOffset:boarding?.offset??0};}
 const incident=state.incidents.find(i=>i.id===unit.incident);
 if(!['working','decision'].includes(unit.status)||!incident||unit.pursuing||incident.type===5)return {visible:false,pose:'idle',label:'В машине'};
 if(unit.status==='decision')return {visible:true,pose:'idle',label:'Ожидает решения'};
 const choice=incident.decision;
 if(choice==='backup')return {visible:true,pose:index===0?'radio':'idle',label:index===0?'Запрашивает поддержку':'Наблюдает'};
 if(index>0)return {visible:true,pose:incident.type===1?'assist':'idle',label:incident.type===1?'Помогает напарнику':'Прикрывает напарника'};
 if(incident.type===2||incident.type===3)return {visible:true,pose:'search',label:'Осматривает место'};
 if(incident.type===1)return {visible:true,pose:'assist',label:incident.variant==='fire-smoke'?'Держит оцепление у подъезда':incident.variant&&incident.variant!=='crash'?'Обеспечивает безопасность на месте':'Работает на месте ДТП'};
 return {visible:true,pose:'talk',label:'Разговаривает с участниками'};
}

export function crewRole(state,unit,index){return state.mode==='career'&&unit.id===1?{label:index===0?(state.rank>0?'Сотрудник':'Стажёр'):'Наставник',color:index===0?'#6597b6':'#9ba883'}:{label:index===0?'Сотрудник':'Напарник',color:'#6597b6'};}
