import {boardingPresentation} from './vehicle-doors.js';
// Presentation only: never changes crew, routes, decision or save schema.
export const CREW_POSES=Object.freeze({idle:'Ожидание',radio:'Рация',talk:'Разговор',search:'Осмотр',assist:'Помощь'});
export function crewPresentation(state,unit,index=0){
 if(unit.foot){const f=unit.foot,a=f.actors[index],boarding=boardingPresentation(unit,index),walking=['approach','return'].includes(f.phase);if(f.phase==='onScene')return {...crewPresentation(state,{...unit,foot:null},index),position:a,walking:false};return {visible:boarding?.visible??walking,pose:'idle',label:({exit:'Выходит из машины',board:'Садится в машину',return:'Возвращается к машине'})[f.phase]??'Идёт к участникам',position:a,walking,vehicleOffset:boarding?.offset??0};}
 const incident=state.incidents.find(i=>i.id===unit.incident);
 if(!['working','decision'].includes(unit.status)||!incident||unit.pursuing||incident.type===5)return {visible:false,pose:'idle',label:'В машине'};
 if(unit.status==='decision')return {visible:true,pose:'idle',label:'Ожидает решения'};
 const choice=incident.decision;
 if(incident.type>=10&&incident.type<=13)return {visible:true,pose:index===0?'assist':'search',label:index===0?({resus:'Реанимирует пациента',scoop:'Перекладывает на носилки',treat:'Лечит пациента'})[choice]??'Осматривает пациента':index===1?'Монитор, укладка, вена':'Готовит носилки'};/* Release I */
 if(incident.type>=6&&incident.type<=9)return {visible:true,pose:index===0?'radio':'assist',label:index===0?'Руководит работой':({attack:'Тушит в звене',defend:'Подаёт воду снаружи',extricate:'Работает гидравликой',secure:'Ограждает место',ice:'Спасает на воде',reach:'Подаёт спасательный конец'})[choice]??'Проверяет помещения'};/* Release H */
 if(choice==='backup')return {visible:true,pose:index===0?'radio':'idle',label:index===0?'Запрашивает поддержку':'Наблюдает'};
 if(index>0)return {visible:true,pose:incident.type===1?'assist':'idle',label:incident.type===1?'Помогает напарнику':'Прикрывает напарника'};
 if(incident.type===2||incident.type===3)return {visible:true,pose:'search',label:'Осматривает место'};
 if(incident.type===1)return {visible:true,pose:'assist',label:incident.variant==='fire-smoke'?'Держит оцепление у подъезда':incident.variant&&incident.variant!=='crash'?'Обеспечивает безопасность на месте':'Работает на месте ДТП'};
 return {visible:true,pose:'talk',label:'Разговаривает с участниками'};
}

export function crewRole(state,unit,index){const ag=unit.agency??state.agency,svc=ag==='ems'?['Медик','Водитель']:ag==='rescue'?['Спасатель','Звено']:null;if(svc&&index>=2)return {label:svc[1],color:'#9ba883'};return state.mode==='career'&&unit.id===1?{label:index===0?(state.rank>0?(svc?.[0]??'Сотрудник'):'Стажёр'):'Наставник',color:index===0?'#6597b6':'#9ba883'}:{label:index===0?'Сотрудник':'Напарник',color:'#6597b6'};}
