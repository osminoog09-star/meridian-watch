// Presentation-only feedback with hysteresis. Never changes world time, population or model detail.
export function createResolutionGovernor(){let cap=2,samples=[],holdUntil=0;return {
 reset(){samples=[];holdUntil=0;cap=2;return cap;},cap:()=>cap,
 sample(now,interval,renderMs,frameRate=30){if(![now,interval,renderMs].every(Number.isFinite)||interval<=0)return null;const period=1000/(frameRate===60?60:30);samples.push({slow:interval>period*1.4||renderMs>period*.75,stall:interval>period*2.5,good:interval<period*1.15&&renderMs<period*.25});if(samples.length<60)return null;const slow=samples.filter(s=>s.slow).length,good=samples.filter(s=>s.good).length,stalls=samples.filter(s=>s.stall).length;samples=[];if(now<holdUntil)return null;// Repeated stalls (visible hitches) also lower resolution even when most frames are on time.
 const next=slow>=18||stalls>=4?Math.max(1,cap-.5):good>=57&&!stalls?Math.min(2,cap+.5):cap;if(next===cap)return null;cap=next;holdUntil=now+12000;return cap;}
};}
