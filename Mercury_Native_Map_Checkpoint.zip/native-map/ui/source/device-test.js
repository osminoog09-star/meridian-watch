// Native adapter: one call corresponds to one Godot process/render frame.
import {createDeviceTest as sourceTest,formatDeviceReport as sourceReport} from './device-test-original.js';
export {DEVICE_STAGES} from './device-test-original.js';
export function createDeviceTest(options){const test=sourceTest(options),frame=test.frame;return {...test,frame:(now,drawn)=>frame(now,globalThis.nativeRenderStats?.native?true:drawn)};}
export function formatDeviceReport(results,info){const stats=globalThis.nativeRenderStats??{};return sourceReport(results,info)+'\nДвижок Godot · интервалы кадров приложения (не время GPU)'+(stats.processPssBytes?'\nПамять процесса: '+Math.round(stats.processPssBytes/1048576)+' МБ':'')+(Number.isFinite(stats.batteryTemperatureC)?'\nТемпература батареи: '+stats.batteryTemperatureC+' °C (не температура CPU)':'')+(Number.isFinite(stats.thermalStatus)?'\nThermal status Android: '+stats.thermalStatus:'');}
