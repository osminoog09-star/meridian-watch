import {hireOfficer,buyVehicle,createPatrol,shiftCost} from './sim.js';
export const PATROL_ZONES=Object.freeze({all:'Весь город',west:'Западная часть',east:'Восточная часть'});
export function patrolChoices(s){
 const assigned=new Set(s.units.flatMap(u=>u.officerIds)),usedCars=new Set(s.units.map(u=>u.vehicleId));
 return {people:[...s.officers.filter(o=>!assigned.has(o.id)).map(o=>({...o,key:'officer:'+o.id,fee:0,owned:true})),...s.candidates.map(c=>({...c,key:'candidate:'+c.id,owned:false}))],cars:s.vehicles.filter(v=>!usedCars.has(v.id)&&!v.service).map(v=>({...v,key:'vehicle:'+v.id}))};
}
function prepare(s,draft){
 if(s.mode!=='chief'||s.ended)return {ok:false,message:'Создание патруля доступно начальнику во время смены.'};
 if(!draft||!Object.hasOwn(PATROL_ZONES,draft.zone))return {ok:false,message:'Выберите действующую зону города.'};
 const choices=patrolChoices(s),keys=[draft.first,...(draft.second?[draft.second]:[])];
 const crew=keys.map(key=>choices.people.find(p=>p.key===key));
 if(keys.length>2||new Set(keys).size!==keys.length||crew.some(p=>!p))return {ok:false,message:'Выберите свободного сотрудника и другого напарника либо одиночный состав.'};
 if(!choices.cars.some(v=>v.key===draft.vehicle)&&!['new:sedan','new:suv'].includes(draft.vehicle))return {ok:false,message:'Выберите свободную машину или покупку новой.'};
 // Stage only department/finance edits. Existing moving units keep their object
 // identity and transport traces; geography/population are never copied here.
 const next={...s,officers:s.officers.map(o=>({...o})),vehicles:s.vehicles.map(v=>({...v})),candidates:s.candidates.map(c=>({...c})),units:[...s.units],logs:[...s.logs],finance:{...s.finance,entries:s.finance.entries.map(e=>({...e}))}};
 const ids=[];for(const p of crew){if(p.owned)ids.push(p.id);else{const id=next.nextOfficerId,r=hireOfficer(next,p.id);if(!r.ok)return r;ids.push(id);}}
 let vehicleId;if(draft.vehicle.startsWith('new:')){vehicleId=next.nextVehicleId;const r=buyVehicle(next,draft.vehicle.slice(4));if(!r.ok)return r;}else vehicleId=Number(draft.vehicle.slice(8));
 const created=createPatrol(next,ids[0],ids[1]??0,vehicleId,draft.zone);if(!created.ok)return created;
 const hireCost=crew.reduce((n,p)=>n+p.fee,0),purchaseCost=s.budget-next.budget-hireCost,totalShiftCost=shiftCost(next),vehicle=next.vehicles.find(v=>v.id===vehicleId);
 const quote={ok:true,message:'План готов',crew:crew.map(p=>p.name),vehicle:vehicle.name,zone:PATROL_ZONES[draft.zone],hireCost,purchaseCost,initialCost:s.budget-next.budget,shiftDelta:totalShiftCost-shiftCost(s),totalShiftCost,balanceAfter:next.budget,balanceAfterShift:Math.max(0,next.budget-totalShiftCost),subsidy:Math.max(0,totalShiftCost-next.budget)};
 // Recompute on confirmation: stale resources/costs cannot silently replace the
 // reviewed plan. This is a comparison token, not an authentication credential.
 quote.token=JSON.stringify([draft.first,draft.second??'',draft.vehicle,draft.zone,s.shift,s.nextOfficerId,s.nextVehicleId,s.nextUnitId,quote,crew.map(p=>[p.key,p.skill,p.salary,p.fatigue??0]),s.units.map(u=>[u.id,u.officerIds,u.vehicleId])]);
 return {quote,next,unitId:created.unitId};
}
export function quotePatrol(s,draft){const r=prepare(s,draft);return r.quote??r;}
export function confirmPatrol(s,draft,token){
 const r=prepare(s,draft);if(!r.quote)return r;
 if(!token||token!==r.quote.token)return {ok:false,message:'Условия изменились. Проверьте обновлённый итог перед созданием.'};
 const n=r.next;
 Object.assign(s,{budget:n.budget,officers:[...s.officers,...n.officers.slice(s.officers.length)],vehicles:[...s.vehicles,...n.vehicles.slice(s.vehicles.length)],candidates:n.candidates,units:[...s.units,n.units.at(-1)],finance:n.finance,logs:n.logs,nextOfficerId:n.nextOfficerId,nextVehicleId:n.nextVehicleId,nextUnitId:n.nextUnitId,setupPending:n.setupPending});
 return {ok:true,message:'Патруль сформирован. Автоматический режим включён.',unitId:r.unitId};
}
