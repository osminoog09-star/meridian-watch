import {buildingRise} from './world-scale.js';
import {cachedBuildingLayout} from './building-layout.js';
import {quarterBuildings} from './quarter.js';
// Deterministic illustrative materials, not surveyed facade/roof attributes.
import {shadeMaterial,shadowOffset,shadowHull} from './city-atmosphere.js';
import {windowIsLit} from './prototype-light.js';
import {architecture} from './architecture.js';
export const buildingStyle=architecture;
// Map feature objects are immutable; share layout between shadow and facade passes.
const layoutFor=b=>cachedBuildingLayout(b,quarterBuildings.get(String(b.id)));
export function* drawBuildingSlices(ctx,b,points,scale,zoom,night=false,light=null,{shadow=true,layout=null}={}){
 let pts=points.slice();if(pts.length>2&&Math.hypot(pts[0].x-pts.at(-1).x,pts[0].y-pts.at(-1).y)<.01)pts.pop();
 if(pts.length<3)return;
 layout??=layoutFor(b);const style=layout.style,rise=buildingRise(layout.height,scale,zoom);
 const poly=(p,fill,stroke=null,width=.7)=>{ctx.beginPath();p.forEach((v,k)=>k?ctx.lineTo(v.x,v.y):ctx.moveTo(v.x,v.y));ctx.closePath();if(fill){ctx.fillStyle=fill;ctx.fill();}if(stroke){ctx.strokeStyle=stroke;ctx.lineWidth=width;ctx.stroke();}};
 const lengthSafe=(x,y)=>Math.hypot(x,y);
 const line=(a,c,color,width=1)=>{ctx.beginPath();ctx.moveTo(a.x,a.y);ctx.lineTo(c.x,c.y);ctx.strokeStyle=color;ctx.lineWidth=width;ctx.stroke();};
 const top=pts.map(p=>({x:p.x,y:p.y-rise})),xs=pts.map(p=>p.x),ys=pts.map(p=>p.y),w=Math.max(...xs)-Math.min(...xs),h=Math.max(...ys)-Math.min(...ys);
 let area=0;for(let k=0;k<pts.length;k++){const a=pts[k],c=pts[(k+1)%pts.length];area+=a.x*c.y-c.x*a.y;}
 if(rise&&shadow)poly(shadowHull(pts,shadowOffset(rise,light)),'#24313c38');
 poly(pts,'#657469');
 if(rise)for(let k=0;k<pts.length;k++){
  const j=(k+1)%pts.length,a=pts[k],c=pts[j],dx=c.x-a.x,dy=c.y-a.y;
  poly([a,c,top[j],top[k]],light?shadeMaterial(style.wall,[dy*Math.sign(area)/(light.groundTilt??1),0,-dx*Math.sign(area)],light):(dy>0?'#8e9b90':style.wall),'#68776b',.5);
  if(zoom>=8&&rise>5){const baseRise=Math.min(3,rise*.12);poly([a,c,{x:c.x,y:c.y-baseRise},{x:a.x,y:a.y-baseRise}],shadeMaterial(style.plinth,[dy,0,-dx*Math.sign(area)],light));}
  if(zoom>=10&&rise>8){line(top[k],top[j],'#e2dac6',1.4);line(a,c,'#686f6255',2);if(lengthSafe(dx,dy)>18){line(a,top[k],'#eee4ce88',1.3);line(c,top[j],'#6a706655',1);}}
  // Only outward south-facing walls show window rows; roofs cover rear faces.
  const length=Math.hypot(dx,dy),front=-dx*Math.sign(area)>0;const panel=(x,y,ww,hh,color)=>{const tx=dx/(length||1)*ww/2,ty=dy/(length||1)*ww/2;poly([{x:x-tx,y:y-ty-hh/2},{x:x+tx,y:y+ty-hh/2},{x:x+tx,y:y+ty+hh/2},{x:x-tx,y:y-ty+hh/2}],color);};
  if(front&&zoom>=16&&length>25&&rise>9){const x=a.x+dx*.06,y=a.y+dy*.06;line({x,y:y-rise},{x,y:y-.5},shadeMaterial(style.drain,[0,0,1],light),1.1);line(top[k],top[j],shadeMaterial(style.trim,[0,1,0],light),1.3);}
  if(zoom>3.5&&front&&length>12&&rise>5){
   const columns=Math.max(1,Math.min(6,Math.floor((layout.edges[k]??length)/5))),floors=Math.min(layout.floors,Math.max(1,Math.floor(rise/5)));
   for(let row=0;row<floors;row++)for(let col=0;col<columns;col++){
    const t=(col+.5)/columns,x=a.x+dx*t,y=a.y+dy*t-rise+(row+.65)*rise/floors;
    const ww=Math.min(5,Math.max(2.8,length/columns*.38)),hh=Math.min(4,rise/floors*.48);
    panel(x,y,ww+1,hh+1,'#ded7c5');
    panel(x,y,ww,hh,night&&windowIsLit(style.detail,k,row,col)?'#f4cd7d':'#355567');
    if(zoom>=12){panel(x,y,.6,hh,'#bdb7a8');panel(x,y,ww,.5,'#bdb7a8');}
    panel(x,y+hh/2+.35,ww+2,.7,'#e5ddcb');if((row*columns+col+1)%4===0)yield;
   }
  }
  if(front&&k===layout.entranceEdge&&zoom>=12&&length>24&&rise>9){const x=(a.x+c.x)/2,y=(a.y+c.y)/2;
   panel(x,y-3,4,6,'#d8d0bb');panel(x,y-2.75,2.6,5.5,'#355567');panel(x,y-6,5,.8,'#b1a994');panel(x,y+.3,5,.6,'#aaa797');
   if(style.family==='shop'){panel(x,y-6,14,2,style.detail%2?'#718b70':'#a87861');}
   if(style.family==='town'&&zoom>=18){line({x:a.x,y:a.y},{x:a.x,y:a.y-rise},'#8c816977',.7);}
  }
  if(k%16===15)yield;
 }
 poly(top,shadeMaterial(style.roof[0],[0,1,0],light),zoom>2?'#59675b':null,.8);
 if(zoom>3&&w>12&&h>9){
  // A split pitched roof only on simple near-rectangular footprints.
  const length=(a,c)=>Math.hypot(a.x-c.x,a.y-c.y);
  const a=top[0],c=top[1],d=top[2];

  if(layout.pitched&&top.length===4){
   let t=top.slice();if(layout.rotateRoof)t.push(t.shift());
   const ridge=buildingRise(layout.roofPitch,scale,zoom);const mid=(a,c)=>({x:(a.x+c.x)/2,y:(a.y+c.y)/2-ridge});
   const l=mid(t[0],t[3]),r=mid(t[1],t[2]);
   poly([t[0],l,t[3]],style.wall);poly([t[1],t[2],r],style.wall);poly([t[0],t[1],r,l],shadeMaterial(style.roof[1],[0,.8,-.4],light));poly([l,r,t[2],t[3]],shadeMaterial(style.roof[0],[0,.8,.4],light));if(zoom>=8){const blend=(a,b,u)=>({x:a.x+(b.x-a.x)*u,y:a.y+(b.y-a.y)*u});const count=Math.min(10,Math.max(2,Math.floor(length(t[0],t[1])/10)));for(let k=1;k<count;k++){const u=k/count;line(blend(t[0],t[1],u),blend(l,r,u),'#3a40302b',.55);line(blend(l,r,u),blend(t[3],t[2],u),'#3a40302b',.55);yield;}}line(l,r,'#e1c5a1',1.1);
  }else{
   // Inset skylight: only if a centroid lies within the footprint.
   const centre={x:top.reduce((n,p)=>n+p.x,0)/top.length,y:top.reduce((n,p)=>n+p.y,0)/top.length};
   let inside=false;for(let i=0,j=top.length-1;i<top.length;j=i++){const a=top[i],b=top[j];if((a.y>centre.y)!==(b.y>centre.y)&&centre.x<(b.x-a.x)*(centre.y-a.y)/(b.y-a.y)+a.x)inside=!inside;}
   if(inside&&w>25&&h>20){ctx.fillStyle='#526969';ctx.fillRect(centre.x-3,centre.y-2,6,4);ctx.fillStyle='#bfc9bf';ctx.fillRect(centre.x-3,centre.y-2,6,.8);}
  }
  for(let k=0;k<top.length;k++){const a=top[k],c=top[(k+1)%top.length];if(c.x>a.x)line(a,c,'#e3dcc177',.6);if(k%16===15)yield;}
 }
}

// Ground shadows are a separate pass, below every house and every actor.
export function drawBuildingShadow(ctx,b,points,scale,zoom,light,layout=null){if(zoom<=1.3||points.length<3)return;const rise=buildingRise((layout??layoutFor(b)).height,scale,zoom),hull=shadowHull(points,shadowOffset(rise,light));if(hull.length<3)return;ctx.beginPath();hull.forEach((p,i)=>i?ctx.lineTo(p.x,p.y):ctx.moveTo(p.x,p.y));ctx.closePath();ctx.fillStyle=light?.night>.8?'#13223825':'#24313c38';ctx.fill();}

// Synchronous adapter for standalone presenters and existing callers.
export function drawBuilding(...args){const job=drawBuildingSlices(...args);while(!job.next().done){}}
