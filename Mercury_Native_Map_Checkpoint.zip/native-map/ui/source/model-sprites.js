import {projectModel,drawModel,drawProjectedModel} from './models.js';
// Tight transparent sprites: same model faces/materials, bounded LRU, never city-sized buffers.
export function createModelSprites({makeCanvas=()=>document.createElement('canvas'),maxEntries=128,maxBytes=4*1024*1024}={}){
 const entries=new Map(),ids=new WeakMap();let nextId=1,bytes=0,hits=0,misses=0;
 const drop=key=>{const old=entries.get(key);bytes-=old.bytes;entries.delete(key);old.canvas.width=0;old.canvas.height=0;};
 return {draw(ctx,model,options,dpr=1){
  if(!ids.has(model))ids.set(model,nextId++);
  const {x=0,y=0,...shape}=options;
  // One-degree heading steps retain fine close-view contours while straight travel reuses pixels.
  shape.angle=Math.round((shape.angle??0)*180/Math.PI)*Math.PI/180;
  const key=JSON.stringify([ids.get(model),dpr,shape]);let sprite=entries.get(key);
  if(sprite){hits++;entries.delete(key);entries.set(key,sprite);}else{
   misses++;const faces=projectModel(model,{...shape,x:0,y:0}),points=faces.flatMap(f=>f.points);if(!points.length)return false;
   const left=Math.floor(Math.min(...points.map(p=>p[0])))-2,top=Math.floor(Math.min(...points.map(p=>p[1])))-2,width=Math.ceil(Math.max(...points.map(p=>p[0])))-left+2,height=Math.ceil(Math.max(...points.map(p=>p[1])))-top+2;
   const pixelWidth=Math.ceil(width*dpr),pixelHeight=Math.ceil(height*dpr),cost=pixelWidth*pixelHeight*4;
   if(cost>maxBytes||pixelWidth>1024||pixelHeight>1024){drawModel(ctx,model,options);return false;}
   const canvas=makeCanvas();canvas.width=pixelWidth;canvas.height=pixelHeight;const paint=canvas.getContext('2d');paint.setTransform(dpr,0,0,dpr,0,0);drawProjectedModel(paint,faces,shape,-left,-top);sprite={canvas,left,top,width:pixelWidth/dpr,height:pixelHeight/dpr,bytes:cost};
   while(entries.size&&(entries.size>=maxEntries||bytes+cost>maxBytes))drop(entries.keys().next().value);
   entries.set(key,sprite);bytes+=cost;
  }
  ctx.drawImage(sprite.canvas,x+sprite.left,y+sprite.top,sprite.width,sprite.height);return true;
 },stats:()=>({spriteHits:hits,spriteMisses:misses,spriteEntries:entries.size,spriteBytes:bytes}),clear(){for(const key of entries.keys())drop(key);}};
}
