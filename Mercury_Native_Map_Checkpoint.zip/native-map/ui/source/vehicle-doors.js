import {MAP_METRES} from './world-scale.js';
// Presentation follows the existing saved 3.6-world-second exit/boarding stage.
// No new clock, routes, save fields or simulation mutations.
export const DOOR_STAGE=.08;
const clamp=n=>Math.max(0,Math.min(1,Number.isFinite(n)?n:0));
export function vehicleDoors(unit){
 const f=unit?.foot;if(!f||!['exit','board'].includes(f.phase))return {left:0,right:0};
 const t=clamp(1-f.timer/DOOR_STAGE),open=t<.2?t/.2:t<.75?1:(1-t)/.25;
 // Quantized poses keep animated sprites bounded and reusable.
 const amount=Math.round(clamp(open)*12)/12;
 return {left:amount,right:f.actors.length>1?amount:0};
}
export function boardingPresentation(unit,index){
 const f=unit.foot,a=f?.actors[index];if(!a)return null;
 const stage=['exit','board'].includes(f.phase),t=clamp(1-f.timer/DOOR_STAGE);
 const outside=stage?(f.phase==='exit'?clamp((t-.2)/.55):1-clamp((t-.2)/.55)):clamp(1-Math.hypot(a.x-unit.x,a.y-unit.y)*MAP_METRES/2);
 return {visible:stage?outside>.03:true,offset:outside?(index===0?-1:1)*1.4*outside:0,stage};
}
export function doorSoundEvent(previous,state,selected,scene){
 const u=state.units.find(u=>u.id===selected),f=u?.foot;
 const next={shift:state.shift,unit:selected,incident:f?.incident,phase:f?.phase,timer:f?.timer};
 const near=scene&&scene.zoom>=12&&u&&Math.hypot(scene.x-u.x,scene.y-u.y)*MAP_METRES<80;
 const same=previous&&previous.shift===next.shift&&previous.unit===selected&&previous.incident===next.incident&&previous.phase===next.phase;
 const event=near&&same&&['exit','board'].includes(f?.phase)&&previous.timer>.02&&f.timer<=.02?{level:.22}:null;
 return {next,event};
}
