import {pixelsPerMetre,CITY_HEIGHT} from './world-scale.js';
import data from './quarter-data.js';
import {MODELS,drawModel} from './models.js';
export const QUARTER=data;
export const QUARTER_CENTRE={x:1.55,y:2.52};
export const quarterBuildings=new Map(data.buildings.map(b=>[b.id,b]));
export function drawFurniture(ctx,o,q,zoom,night,projection={}){
 if(zoom<8)return;
 const scale=projection.scale?pixelsPerMetre(projection.scale):Math.max(1,zoom*.1),variant=Number(o.id.slice(-2))%3,palette={wood:'#ad8155',metal:'#596c70',bark:'#73563e',leaves:['#4f7649','#628451','#456b4b'][variant],headlight:night?'#ffe2a0':'#bdc7be'};

 // The recorded point is real; orientation and shapes are illustrative.
 if(o.kind==='lamp'&&night){ctx.beginPath();ctx.arc(q.x,q.y,Math.min(25,zoom),0,Math.PI*2);ctx.fillStyle='#ffd88b20';ctx.fill();}
 drawModel(ctx,o.kind==='tree'?[MODELS.treeBroad,MODELS.treeNarrow,MODELS.treeBroad][variant]:MODELS[o.kind],{x:q.x,y:q.y,scale,angle:projection.yaw??0,groundTilt:projection.tilt??1,heightTilt:CITY_HEIGHT,light:projection.light,palette:{...palette,stone:'#a1aba2',water:'#4e8797'}});
}
const segmentDistance=(q,a,b)=>{const dx=b[0]-a[0],dy=b[1]-a[1],t=Math.max(0,Math.min(1,((q.x-a[0])*dx+(q.y-a[1])*dy)/(dx*dx+dy*dy||1)));return Math.hypot(q.x-a[0]-t*dx,q.y-a[1]-t*dy);};
export function environmentMix(scene,residents=[]){
 if(!scene||![scene.x,scene.y,scene.zoom].every(Number.isFinite))return {wind:0,water:0,traffic:0};
 const near=Math.max(0,Math.min(1,(scene.zoom-1)/10));
 const waterDistance=Math.min(...data.waterEdges.map(([a,b])=>segmentDistance(scene,a,b)),...data.objects.filter(o=>o.kind==='fountain').map(o=>Math.hypot(scene.x-o.p[0],scene.y-o.p[1])*2));
 const water=Math.max(0,1-waterDistance/.07)*near;
 const traffic=Math.min(1,residents.reduce((v,r)=>v+(r.route?.length&&!['walkVisit','walkBack','visiting','incident'].includes(r.status)?Math.max(0,1-Math.hypot(r.x-scene.x,r.y-scene.y)/.12)*.35:0),0))*near;
 return {wind:.20+.15*(1-near),water,traffic};
}
