// Logical camera coordinates stay unchanged; cap only raster backing-store pixels.
export function rasterRatio(width,height,dpr=1,qualityCap=2,adaptiveCap=2,maxPixels=Infinity){
 const wanted=Math.min(Math.max(1,Number.isFinite(dpr)?dpr:1),qualityCap,adaptiveCap);
 if(!Number.isFinite(maxPixels)||maxPixels<=0||width<=0||height<=0)return wanted;
 return Math.min(wanted,Math.max(1,Math.sqrt(maxPixels/(width*height))));
}
