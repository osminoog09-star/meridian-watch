// Errors loading the module graph must not leave an endless preparation message.
import('./prototype3d.js?v=0.4.21').catch(()=>{document.getElementById('sceneStatus').textContent='Не удалось загрузить 3D-модуль. Обновите страницу или откройте статический вид ниже.';document.getElementById('sceneFallback').hidden=false;});
