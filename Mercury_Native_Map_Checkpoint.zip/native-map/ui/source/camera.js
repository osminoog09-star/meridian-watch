import {travelDistance} from './transport.js';
import {groundVector,groundInverse} from './city-projection.js';
import {WORLD_BOUNDS,VIEW_PADDING} from './city-coverage.js';
// Camera math is independent of the DOM so touch gestures can be replayed in tests.
export function createCamera(initial={x:1.5,y:2.6,zoom:5},projection={},bounds=WORLD_BOUNDS){
 let width=390,height=570,view={...initial},pointers=new Map(),gesture=null,tracking=null;
 const spanX=bounds.maxX-bounds.minX,spanY=bounds.maxY-bounds.minY;
 const scale=()=>Math.min(width/(spanX+VIEW_PADDING.x),height/(spanY+VIEW_PADDING.y))*view.zoom;
 const clamp=()=>{view.zoom=Math.max(.75,Math.min(96,view.zoom));view.x=Math.max(bounds.minX,Math.min(bounds.maxX,view.x));view.y=Math.max(bounds.minY,Math.min(bounds.maxY,view.y));};
 const world=p=>{const delta=groundInverse((p.x-width/2)/scale(),(p.y-height/2)/scale(),projection);return {x:view.x+delta.x,y:view.y+delta.y};};
 const screen=p=>{const delta=groundVector((p.x-view.x)*scale(),(p.y-view.y)*scale(),projection);return {x:width/2+delta.x,y:height/2+delta.y};};
 const anchorAt=(anchor,p)=>{const delta=groundInverse((p.x-width/2)/scale(),(p.y-height/2)/scale(),projection);view.x=anchor.x-delta.x;view.y=anchor.y-delta.y;};
 function baseline(){const pts=[...pointers.values()];if(!pts.length){gesture=null;return;}const mid=pts.length>1?{x:(pts[0].x+pts[1].x)/2,y:(pts[0].y+pts[1].y)/2}:pts[0];gesture={anchor:world(mid),zoom:view.zoom,distance:pts.length>1?Math.max(10,Math.hypot(pts[1].x-pts[0].x,pts[1].y-pts[0].y)):0};}
 let moved=false,origin=null;
 function down(id,p){tracking=null;pointers.set(id,p);if(pointers.size===1){moved=false;origin=p;}else moved=true;baseline();}
 function move(id,p){if(!pointers.has(id))return;pointers.set(id,p);if(origin&&Math.hypot(p.x-origin.x,p.y-origin.y)>5)moved=true;const pts=[...pointers.values()];const mid=pts.length>1?{x:(pts[0].x+pts[1].x)/2,y:(pts[0].y+pts[1].y)/2}:pts[0];if(pts.length>1&&gesture.distance)view.zoom=gesture.zoom*Math.hypot(pts[1].x-pts[0].x,pts[1].y-pts[0].y)/gesture.distance;clamp();anchorAt(gesture.anchor,mid);clamp();}
 function up(id,cancel=false){if(!pointers.has(id))return false;const tap=!moved&&!cancel&&pointers.size===1;pointers.delete(id);if(cancel)moved=true;baseline();return tap;}
 function zoomAt(factor,p={x:width/2,y:height/2}){const anchor=world(p);view.zoom*=factor;clamp();anchorAt(anchor,p);clamp();}
 function focus(p,zoom=5,id=null){view={x:p.x,y:p.y,zoom};tracking=id;clamp();}
 clamp();
 return {interacting:()=>pointers.size>0,screen,world,scale,down,move,up,zoomAt,focus,viewport(w,h){if(w>0&&h>0){width=w;height=h;baseline();}},getView:()=>({...view,tracking}),track(units,dt=1/60,timeScale=1){if(tracking===null)return;const u=units.find(u=>u.id===tracking);if(!u){tracking=null;return;}dt=Math.max(0,Math.min(.1,dt));const dx=u.x-view.x,dy=u.y-view.y,d=Math.hypot(dx,dy);if(d<1e-9)return;const factor=Math.max(0,Math.min(4,Number.isFinite(timeScale)?timeScale:1)),pixelsPerSecond=travelDistance(Number.isFinite(u.currentSpeedKmh)?u.currentSpeedKmh:0,factor)*scale(),response=Math.max(8,pixelsPerSecond/Math.max(30,width*.18));const amount=Math.min(1-Math.exp(-response*dt),Math.max(720,pixelsPerSecond*1.5)*dt/scale()/d);view.x+=dx*amount;view.y+=dy*amount;clamp();},cancel(){pointers.clear();gesture=null;moved=true;}};
}
