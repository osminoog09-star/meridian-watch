import {doorSoundEvent} from './vehicle-doors.js';
import {MAP_METRES} from './world-scale.js';
import {WORLD_SECONDS_PER_TICK_SECOND} from './transport.js';
import {urgentMovement} from './response-priority.js';
import {footstepEvent} from './footsteps.js';
import {transportTone,weatherSound,RAIN_LEVEL,fireworksTime,fireworkBurst,timeAmbience,birdCall,CROWD_LEVEL,engineWobble} from './audio-design.js';
import {noiseLoop,gust,lapping,engineSound,ENGINE_WAVE,SIREN_WAVE,sirenFrequency,spatial,radioPattern,footstepShape,serviceSirenFrequency,distanceCutoff,talkEnvelope,sceneRadioGap} from './sound-synth.js';
import {placeAt,surfaceAt,impulseResponse,SPACES} from './acoustics.js';
import {crowdNear} from './onlookers.js';
import {talkDone} from './dialogues.js';
import {environmentMix} from './quarter.js';
// Original procedural sound, no downloaded audio and no autoplay before a gesture.
// R26 rewrite (Claude, 12.10.2026) — owner: «звуки так себе… то есть, то пропадают».
// Why sound used to vanish, and what changed:
//  1. After the app went to the background (or the screen locked) the context was suspended and only
//     resumed on a few UI actions → now `update` retries `resume()` every 1.5 s while the game should
//     sound, and app.js resumes on return and on any touch.
//  2. Every modal (report, briefing, tips) muted everything → now the city ducks under dialogs.
//  3. The city bed came only from moving resident cars near the camera (usually zero) → now a constant
//     distant city layer follows the hour of the day; near traffic adds to it.
//  4. Engine and siren followed the selected crew only → the engine still does (it's «your» car),
//     but sirens come from the nearest responding crew, placed in stereo and faded by distance.
//  5. One white-noise loop fed every channel (hiss, one loop period) → pink and brown loops with a
//     crossfaded seam, separate filters per layer, wind gusts and water lapping.
export const AUDIO_KEY='meridian-watch-audio-v1';
const radioKey=s=>{const r=s.radio?.[0];return r?`${r.time}|${r.from}|${r.text}`:'';};
/* Release R2 (native): sound is on by default; the switch in settings still turns it off */
export const AUDIO_DEFAULTS=Object.freeze({enabled:true,master:.55,radio:.60,siren:.35,engine:.30,environment:.45});
export function audioPreferences(raw){let p={};try{p=typeof raw==='string'?JSON.parse(raw):raw??{};}catch{}return Object.fromEntries(Object.entries(AUDIO_DEFAULTS).map(([k,v])=>[k,k==='enabled'?(p?.enabled??true)===true:Number.isFinite(p?.[k])?Math.max(0,Math.min(1,p[k])):v]));}
// Channel levels (before the «Окружение» volume). Tuned so the bed is present but never loud.
const LEVELS=Object.freeze({city:.07,traffic:.06,wind:.085,water:.06});
// Mix (measured on an offline render, R26 audit): the old mix peaked at −30 dBFS and the radio was
// inaudible. Targets now: city bed about −32 dBFS RMS, engine nearby −24, a close siren −12 peak,
// radio and cues −10 peak; the limiter stays untouched (no clipping in any scenario).
const MIX=Object.freeze({ambience:6,engine:5,siren:.32,radio:6,cue:.28,rain:2.5,reverb:1.6,step:5,talk:.09,sceneRadio:2.2,service:.26,farSiren:.07});
// Release A (Claude, 12.10.2026): a siren is heard across town, quietly and muffled, up to this distance.
export function createAudio({preferences=AUDIO_DEFAULTS}={}){let prefs=audioPreferences(preferences);globalThis.nativeAudioPreferences=prefs;return {preferences:()=>prefs,configure:p=>{prefs=audioPreferences(p);globalThis.nativeAudioPreferences=prefs},reset(){},unlock(){},pause(){globalThis.nativeAudioFrame=null},resume(){},testSound(){prefs.enabled=true;globalThis.nativeAudioPreferences=prefs;globalThis.nativeTestSignal=true;return true},update(state,selected,active,scene,environment){globalThis.nativeAudioFrame={state,selected,active,scene,environment}}};}
