// «Проверка устройства» (Claude, 11.10.2026). A scripted, self-timed performance tour for real
// phones (Fold6 acceptance): each stage switches the camera/speed, waits a warm-up and then
// measures how often the game actually draws the map. Pure scheduler + statistics; app.js wires
// it to the renderer and restores the campaign afterwards.
export const DEVICE_STAGES=Object.freeze([
 {id:'overview',label:'Весь город'},
 {id:'centre',label:'Центр'},
 {id:'follow',label:'Слежение за патрулём'},
 {id:'quarter',label:'Квартал, близко'},
 {id:'speed4',label:'Центр, время ×4'}
]);

export function createDeviceTest({stages=DEVICE_STAGES,stageMs=10000,warmMs=2500,onStage=()=>{},onDone=()=>{}}={}){
 let index=-1,stageStart=0,last=null,samples=[],results=[],active=false;
 function begin(now,k){index=k;stageStart=now;last=null;samples=[];onStage(stages[k],k);}
 function close(){const draws=samples.filter(s=>s.drawn),intervals=[];for(let k=1;k<draws.length;k++)intervals.push(draws[k].at-draws[k-1].at);intervals.sort((a,b)=>a-b);
  const span=samples.length>1?(samples.at(-1).at-samples[0].at)/1000:0,pick=p=>intervals.length?intervals[Math.min(intervals.length-1,Math.floor(p*(intervals.length-1)))]:0;
  results.push({id:stages[index].id,label:stages[index].label,fps:span>0?Math.round(draws.length/span*10)/10:0,p50Ms:Math.round(pick(.5)),p95Ms:Math.round(pick(.95)),worstMs:Math.round(intervals.at(-1)??0),stalls:intervals.filter(v=>v>100).length,frames:draws.length});}
 return {
  start(now){results=[];active=true;begin(now,0);},
  cancel(){active=false;index=-1;},
  active:()=>active,
  stage:()=>active?{...stages[index],index,count:stages.length}:null,
  // Called once per animation frame; drawn=true when the map was actually redrawn.
  frame(now,drawn){if(!active)return;if(now-stageStart>=warmMs)samples.push({at:now,drawn:!!drawn});last=now;
   if(now-stageStart>=stageMs){close();if(index+1<stages.length)begin(now,index+1);else{active=false;onDone(results.slice());}}},
  results:()=>results.slice()
 };
}

// Plain-text report the player can copy into a chat; no campaign data, no network.
export function formatDeviceReport(results,info={}){
 const lines=[`Mercury Response · проверка устройства · ${info.version??''}`.trim(),`Экран ${info.width??'?'}×${info.height??'?'} · DPR ${info.dpr??'?'} · карта ${info.pixelWidth??'?'}×${info.pixelHeight??'?'} · лимит ${info.frameRate??'?'} к/с · графика ${info.quality??'?'}`];
 for(const r of results)lines.push(`${r.label}: ${r.fps} к/с · P95 ${r.p95Ms} мс · худший ${r.worstMs} мс · подвисаний >100 мс: ${r.stalls}`);
 const worst=results.reduce((a,r)=>Math.min(a,r.fps),Infinity);
 lines.push(Number.isFinite(worst)?(worst>=25?'Итог: плавно во всех видах.':worst>=15?'Итог: местами тяжело — пришлите этот текст разработчикам.':'Итог: тормозит — пришлите этот текст разработчикам.'):'Итог: нет данных.');
 if(info.agent)lines.push(info.agent);
 return lines.join('\n');
}
