import {buildingRise} from './world-scale.js';
// Cached screen-space building geometry. Does not alter simulation coordinates.
import {cachedBuildingLayout} from './building-layout.js';
import {quarterBuildings} from './quarter.js';
export function buildingOccluder(b,points,scale,zoom,layout=null){
 const ground=points.slice();if(ground.length>2&&Math.hypot(ground[0].x-ground.at(-1).x,ground[0].y-ground.at(-1).y)<.01)ground.pop();
 if(ground.length<3)return null;
 layout??=cachedBuildingLayout(b,quarterBuildings.get(String(b.id)));const rise=buildingRise(layout.height,scale,zoom);
 const top=ground.map(p=>({x:p.x,y:p.y-rise})),faces=[top];
 if(rise)for(let i=0;i<ground.length;i++){const j=(i+1)%ground.length;faces.push([ground[i],ground[j],top[j],top[i]]);}
 const xs=ground.map(p=>p.x),ys=ground.map(p=>p.y);
 if(zoom>3&&Math.max(...xs)-Math.min(...xs)>12&&Math.max(...ys)-Math.min(...ys)>9&&layout.pitched&&top.length===4){
 const t=top.slice();if(layout.rotateRoof)t.push(t.shift());const ridge=buildingRise(layout.roofPitch,scale,zoom),mid=(a,b)=>({x:(a.x+b.x)/2,y:(a.y+b.y)/2-ridge}),l=mid(t[0],t[3]),r=mid(t[1],t[2]);faces.push([t[0],l,t[3]],[t[1],t[2],r],[t[0],t[1],r,l],[l,r,t[2],t[3]]);
 }
 const all=faces.flat();return {ground,faces,box:[Math.min(...xs),Math.min(...all.map(p=>p.y)),Math.max(...xs),Math.max(...ys)]};
}
const candidateView=Symbol('candidateView');
export function frontDepth(ring,x){let front=-Infinity,a=ring.at(-1);for(const b of ring){const ax=a.x,bx=b.x,low=ax<bx?ax:bx,high=ax>bx?ax:bx;if(x>=low&&x<=high){const dx=bx-ax,y=dx<1e-8&&dx>-1e-8?(a.y>b.y?a.y:b.y):a.y+(b.y-a.y)*(x-ax)/dx;if(y>front)front=y;}a=b;}return front;}
export function foregroundBuildings(buildings,q,radius=28){const candidates=buildings[candidateView]?buildings[candidateView](q,radius):buildings.query?buildings.query(q,radius):buildings,result=[],left=q.x-radius,right=q.x+radius,top=q.y-radius,bottom=q.y+radius;for(const building of candidates){const box=building.box;if(right<box[0]||left>box[2]||bottom<box[1]||top>box[3])continue;const x=q.x<box[0]?box[0]:q.x>box[2]?box[2]:q.x;if(q.y<frontDepth(building.ground,x)-.25)result.push(building);}return result;}
// Native compiled masks are cached per immutable face; fallback retains the old calls.
const compiledMasks=new WeakMap(),faceBounds=new WeakMap();
function faceTouches(face,q,radius){let box=faceBounds.get(face);if(!box){let l=Infinity,t=Infinity,r=-Infinity,b=-Infinity;for(const p of face){l=Math.min(l,p.x);t=Math.min(t,p.y);r=Math.max(r,p.x);b=Math.max(b,p.y);}box=[l,t,r,b];faceBounds.set(face,box);}return box[0]<=q.x+radius&&box[2]>=q.x-radius&&box[1]<=q.y+radius&&box[3]>=q.y-radius;}

function faceMask(face,extent){let cached=compiledMasks.get(face);if(cached&&cached.extent===extent)return cached.path;const path=new Path2D();path.rect(-extent,-extent,extent*2,extent*2);face.forEach((p,i)=>i?path.lineTo(p.x,p.y):path.moveTo(p.x,p.y));path.closePath();compiledMasks.set(face,{extent,path});return path;}
// The outer clipping rectangle must cover the inverse-transformed viewport even
// during a jump from a close cached view to the whole city. Power-of-two buckets
// reuse compiled paths while the camera moves within the same conservative range.
function viewportExtent(offset,factor,width,height){const maximum=Math.max(2048,Math.abs((-100-offset.x)/factor),Math.abs((width+100-offset.x)/factor),Math.abs((-100-offset.y)/factor),Math.abs((height+100-offset.y)/factor));return 2**Math.ceil(Math.log2(maximum));}
// Each face is subtracted separately: overlapping roofs never cancel each other.
export const MAX_CLIP_FACES=48,MIN_OCCLUSION_FACTOR=.6;
export function drawOccluded(ctx,buildings,q,offset,width,height,draw,radius=28,{bounded=false,metrics=null}={}){
 const factor=Number.isFinite(offset.scale)&&offset.scale>0?offset.scale:1;
 const origin={x:(q.x-offset.x)/factor,y:(q.y-offset.y)/factor},support=(radius+2)/factor;
 if(factor<MIN_OCCLUSION_FACTOR){if(metrics)metrics.occlusionOverBudget=(metrics.occlusionOverBudget??0)+1;draw();return false;}
 const masks=foregroundBuildings(buildings,origin,radius/factor);if(metrics)metrics.occlusionQueries++;
 const apply=face=>{if(bounded&&!faceTouches(face,origin,support)){if(metrics)metrics.occlusionSkippedFaces++;return false;}if(metrics)metrics.occlusionFaces++;return true;};
 if(!masks.length){draw();return false;}
 // Clip budget: every face is a nested clip, and the browser rasterises the whole stack at
 // commit time. Far views and a stale snapshot shrunk after zooming out put thousands of faces
 // under one marker (3092 clips per frame on the city overview, >1 s per frame in Chromium with 4x CPU throttling;
 // the owner's Fold6 showed 8 FPS / P95 1125 ms in the same view).
 // There buildings are smaller than the marker, so drawing it unmasked is visually equivalent.
 const faces=[];if(factor>=MIN_OCCLUSION_FACTOR)for(const b of masks){for(const face of b.faces){if(apply(face))faces.push(face);}if(faces.length>MAX_CLIP_FACES)break;}
 if(!faces.length||faces.length>MAX_CLIP_FACES){if(metrics)metrics.occlusionOverBudget=(metrics.occlusionOverBudget??0)+1;draw();return false;}
 ctx.save();try{if(typeof globalThis.Path2D==='function'){const extent=viewportExtent(offset,factor,width,height);ctx.translate(offset.x,offset.y);if(factor!==1)ctx.scale(factor,factor);for(const face of faces)ctx.clip(faceMask(face,extent),'evenodd');if(factor!==1)ctx.scale(1/factor,1/factor);ctx.translate(-offset.x,-offset.y);draw();return true;}for(const face of faces){ctx.beginPath();ctx.rect(-100,-100,width+200,height+200);face.forEach((p,i)=>{const x=p.x*factor+offset.x,y=p.y*factor+offset.y;i?ctx.lineTo(x,y):ctx.moveTo(x,y);});ctx.closePath();ctx.clip('evenodd');}draw();}finally{ctx.restore();}return true;
}

// Rebuilt with the static city cache. Queries retain source order for stable clipping.
export function occluderCellSize(zoom){return zoom<4?24:zoom<12?48:96;}
export function createOccluderIndex(buildings,cellSize=96){const work=createOccluderIndexSlices(buildings,cellSize);let step;do{step=work.next();}while(!step.done);return step.value;}
export function* createOccluderIndexSlices(buildings,cellSize=96){
 const cells=new Map(),large=[];let references=0;
 for(let i=0;i<buildings.length;i++){const [l,t,r,b]=buildings[i].box,x0=Math.floor(l/cellSize),x1=Math.floor(r/cellSize),y0=Math.floor(t/cellSize),y1=Math.floor(b/cellSize);if((x1-x0+1)*(y1-y0+1)>256){large.push(i);yield;continue;}for(let y=y0;y<=y1;y++)for(let x=x0;x<=x1;x++){const key=x+':'+y;if(!cells.has(key))cells.set(key,[]);cells.get(key).push(i);references++;}yield;}
 // Cache only the conservative cell candidate list, never the exact moving-point result.
 const cache=new Map();let retained=0,hits=0,misses=0;const maxEntries=32,maxCandidates=32768,maxCandidateList=8192;
 const queryView=(q,radius=28)=>{const x0=Math.floor((q.x-radius)/cellSize),x1=Math.floor((q.x+radius)/cellSize),y0=Math.floor((q.y-radius)/cellSize),y1=Math.floor((q.y+radius)/cellSize),key=[x0,x1,y0,y1].join(':');let candidates=cache.get(key);
 if(candidates){hits++;cache.delete(key);cache.set(key,candidates);}else{misses++;const ids=new Set(large);for(let y=y0;y<=y1;y++)for(let x=x0;x<=x1;x++)for(const id of cells.get(x+':'+y)??[])ids.add(id);candidates=[...ids].sort((a,b)=>a-b).map(i=>buildings[i]);if(candidates.length<=maxCandidateList){while(cache.size&&(cache.size>=maxEntries||retained+candidates.length>maxCandidates)){const oldest=cache.keys().next().value;retained-=cache.get(oldest).length;cache.delete(oldest);}cache.set(key,candidates);retained+=candidates.length;}}
 return candidates;};
 // Public callers retain an independent array; the renderer's exact filter may read
 // the immutable internal view and avoids cloning thousands of references per actor.
 return {query:(q,radius=28)=>queryView(q,radius).slice(),[candidateView]:queryView,size:buildings.length,stats:()=>({cellSize,cells:cells.size,references,large:large.length,hits,misses,entries:cache.size,candidates:retained,maxEntries,maxCandidates,maxCandidateList})};
}
