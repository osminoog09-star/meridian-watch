// Android is already immersive. This control expands the map by hiding HUD chrome.
export function createFullscreen(doc,button,onEnter){
 let active=false;
 const paint=()=>{doc.body.classList.toggle('native-fullscreen',active);button.textContent=active?'Вернуть меню':'На весь экран'};
 const result={get active(){return active},toggle(){active=!active;paint();if(active)onEnter();},exit(){active=false;paint();}};
 button.onclick=()=>result.toggle();paint();return result;
}
