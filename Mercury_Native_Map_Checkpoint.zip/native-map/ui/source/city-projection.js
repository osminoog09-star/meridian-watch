// One orthographic ground projection for the whole game, not a demo viewer.
export const CITY_VIEW=Object.freeze({yaw:-.65,tilt:Math.sin(.8)});
export function groundVector(x,y,{yaw=0,tilt=1}={}){const c=Math.cos(yaw),s=Math.sin(yaw);return {x:x*c-y*s,y:(x*s+y*c)*tilt};}
export function groundInverse(x,y,{yaw=0,tilt=1}={}){const c=Math.cos(yaw),s=Math.sin(yaw),depth=y/tilt;return {x:x*c+depth*s,y:-x*s+depth*c};}
