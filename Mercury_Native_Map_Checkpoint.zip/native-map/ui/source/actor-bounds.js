import {actorScale} from './world-scale.js';
// Conservative ink radius in logical screen pixels, including shadows and sprite padding.
// Detailed poses/angles and fallback symbols are verified against projected model vertices.
export function actorOcclusionRadius(kind,scale,zoom,detail=true){if(!detail||zoom<4)return kind==='car'?16:12;const size=actorScale(scale,zoom);return kind==='car'?Math.max(16,size*4+4):Math.max(10,size*2+6);}
