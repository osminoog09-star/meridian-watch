// Shared original architecture families. Appearance is illustrative, not a survey.
export function architecture(b){let hash=0;for(const c of String(b.id))hash=(hash*31+c.charCodeAt(0))>>>0;
 const family=['industrial','warehouse'].includes(b.kind)?'utility':['commercial','retail'].includes(b.kind)?'shop':b.h>=5?'block':'town';
 const walls={utility:['#a4aaa2','#abb1a8'],shop:['#d2c4a6','#bcc9bd'],block:['#c4c8b9','#b4bcae'],town:['#d1bfa1','#c7b799','#b9c5b6','#bdad9c']};
 const roofs={utility:['#82918d','#a2b0a8'],shop:['#7b8f8a','#9daf9f'],block:['#828e88','#a0aca1'],town:[['#9b6854','#c68b69'],['#7d8e86','#a5b1a0'],['#b07c59','#d0a075']][hash%3]};
 return {plinth:'#77766d',trim:'#c8c1af',drain:'#676f70',glass:'#3e5d68',family,flat:family!=='town',wall:walls[family][hash%walls[family].length],roof:roofs[family],detail:hash};
}
