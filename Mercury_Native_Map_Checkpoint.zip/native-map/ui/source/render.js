import {nearestWalking,walkingRoute} from './walking.js';
export function createRenderer(canvas,onPick){
 let following=false,scene={x:1.55,y:2.52,zoom:6},walking=false,start=null;
 const queue=(op,value)=>globalThis.nativeMapCommands.push({op,value});
 globalThis.nativePick=onPick;
 globalThis.nativeCamera=s=>{scene={...scene,...s};globalThis.nativeScene=scene;following=!!s.following};
 globalThis.nativeWalkingPick=p=>{
  if(!walking)return;
  const point=nearestWalking(p);
  if(!point||Math.hypot(point.x-p.x,point.y-p.y)*1670>50)return;
  if(!start){start=point;queue('walking-route',[point]);}
  else{queue('walking-route',walkingRoute(start.id,point.id));start=null;}
 };
 const unfollow=op=>{following=false;queue(op)};
 return {scene:()=>scene,setScene:s=>scene=s,zoom:v=>queue('zoom',v),reset:()=>unfollow('reset'),city:()=>unfollow('city'),quarter:()=>unfollow('quarter'),follow:u=>{following=true;queue('follow',u?.id)},rotate:v=>queue('rotate',v),tilt:()=>queue('tilt'),north:()=>queue('north'),chase:u=>{following=true;queue('chase',u?.id)},locate:p=>{following=false;queue('locate',p)},isFollowing:()=>following,quality:v=>queue('quality',v),lighting:v=>queue('lighting',v),resolution:v=>queue('resolution',v),walking:v=>{walking=v;start=null;queue('walking',v)},cancel(){},suspend(){},idle(){},draw(){},stats:()=>globalThis.nativeRenderStats??{}};
}
