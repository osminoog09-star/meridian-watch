import {createFullscreen} from './fullscreen.js';
// Invert the orthographic ground projection so the ground follows the finger.
export function panGround(state,dx,dy,height){
 const scale=state.span/Math.max(1,height),c=Math.cos(state.yaw),s=Math.sin(state.yaw),depth=dy*scale/Math.sin(state.pitch);
 return [Math.max(-(state.panLimit??400),Math.min(state.panLimit??400,state.focus[0]-dx*scale*c+depth*s)),Math.max(-(state.panLimit??400),Math.min(state.panLimit??400,state.focus[1]+dx*scale*s+depth*c))];
}
export function setupViewerControls(doc,{draw,setPhase}){
 const fullscreen=doc.getElementById('viewerFullscreen'),pan=doc.getElementById('viewerPan'),phase=doc.getElementById('viewerPhase'),notice=doc.getElementById('viewerNotice');
 let moving=false;
 if(fullscreen)createFullscreen(doc,fullscreen,()=>{},message=>{notice.textContent=message;});
 if(pan)pan.onclick=()=>{moving=!moving;pan.setAttribute('aria-pressed',String(moving));pan.textContent=moving?'Палец: сдвиг':'Палец: поворот';notice.textContent=moving?'Перетаскивайте квартал одним пальцем. Два пальца — масштаб.':'Один палец — поворот и наклон. Два пальца — масштаб.';};
 if(phase)phase.onchange=()=>setPhase(phase.value);
 doc.addEventListener('fullscreenchange',draw);
 doc.addEventListener('keydown',e=>{if(e.key==='Escape'&&!doc.fullscreenElement&&doc.body?.classList?.contains('map-fullscreen'))fullscreen?.click();});
 return {get panning(){return moving;},syncPhase(value){if(phase)phase.value=value;}};
}
// Keep the ground point under a pinch/wheel anchor in place (until map bounds).
export function zoomAtGround(state,factor,x,y,height){if(![factor,x,y,height].every(Number.isFinite)||factor<=0||height<=0)return {span:state.span,focus:[...state.focus]};const span=Math.max(40,Math.min(state.maxSpan??1400,state.span*factor)),ratio=span/state.span;return {span,focus:panGround(state,x*(ratio-1),y*(ratio-1),height)};}
export function pinchGround(state,before,after,rect){const mid=p=>({x:(p[0].x+p[1].x)/2,y:(p[0].y+p[1].y)/2}),a=mid(before),b=mid(after),distance=p=>Math.hypot(p[1].x-p[0].x,p[1].y-p[0].y),d0=distance(before),d1=distance(after);if(d0<8||d1<8)return {span:state.span,focus:[...state.focus]};const zoom=zoomAtGround(state,d0/d1,a.x-(rect.left??0)-rect.width/2,a.y-(rect.top??0)-rect.height/2,rect.height);return {...zoom,focus:panGround({...state,...zoom},b.x-a.x,b.y-a.y,rect.height)};}
