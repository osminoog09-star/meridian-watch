// Opt-in browser measurements supplement (never replace) game RAF timings.
// No script URLs, task names, stacks or campaign data leave this module.
export function createBrowserStalls({Observer=globalThis.PerformanceObserver,limit=60}={}){
 let observer=null,generation=0,records=[],mode='disabled';
 const number=v=>Number.isFinite(v)?Math.round(Math.max(0,v)*10)/10:0;
 function stop(){generation++;observer?.disconnect();observer=null;mode='disabled';}
 function start(){
  stop();records=[];mode='unsupported';
  for(const type of ['long-animation-frame','longtask']){
   if(!Observer?.supportedEntryTypes?.includes(type))continue;
   const current=generation;
   try{
    observer=new Observer(list=>{
     if(current!==generation||mode!==type)return;
     for(const entry of list.getEntries().slice(-limit)){
      if(!Number.isFinite(entry.duration)||entry.duration<50)continue;
      const row={startMs:number(entry.startTime),durationMs:number(entry.duration)};
      if(type==='long-animation-frame'){
       row.blockingMs=number(entry.blockingDuration);
       // This interval includes style/layout and the rest of rendering; not GPU time.
       row.renderPhaseMs=entry.renderStart>0?number(entry.startTime+entry.duration-entry.renderStart):0;
       row.styleLayoutPhaseMs=entry.styleAndLayoutStart>0?number(entry.startTime+entry.duration-entry.styleAndLayoutStart):0;
       row.scriptMs=number((entry.scripts??[]).reduce((sum,s)=>sum+number(s.duration),0));
       row.forcedStyleLayoutMs=number((entry.scripts??[]).reduce((sum,s)=>sum+number(s.forcedStyleAndLayoutDuration),0));
      }
      records.push(row);if(records.length>limit)records.shift();
     }
    });
    observer.observe({type,buffered:false});mode=type;return;
   }catch{observer?.disconnect();observer=null;}
  }
 }
 return {start,stop,clear(){records=[];observer?.takeRecords?.();},report(){return {mode,samples:records.map(r=>({...r})),limit,meaning:'Browser main-thread stalls >=50 ms; includes menus. Not GPU timing. Empty/unsupported does not mean smooth rendering.'};}};
}
