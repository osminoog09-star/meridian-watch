import assert from 'node:assert/strict';
import fs from 'node:fs';
import {HEADLIGHTS,vehicleLighting} from './vehicle-lighting.js';
import {cityLighting,headlightBeams} from './source/lighting.js';
let fixtures=[];
for(const sun of [null,[420,1020],[240,1320]])for(let minute=0;minute<1440;minute+=15){
 const expected=cityLighting(minute,sun),actual=vehicleLighting(minute,sun);
 assert.equal(actual.darkness,expected.darkness);assert.equal(actual.name,expected.name);
 fixtures.push({minute,sun,darkness:expected.darkness});
}
for(const kind of ['sedan','suv']){
 const reference=headlightBeams({x:0,y:0},0,{scale:1,suv:kind==='suv',length:28});
 assert.deepEqual(HEADLIGHTS[kind].map(l=>l.origin),reference.map(l=>l.origin));
 assert.ok(HEADLIGHTS[kind][0].origin[1]<0&&HEADLIGHTS[kind][1].origin[1]>0);
}
fs.writeFileSync(new URL('./vehicle-lighting-fixtures.json',import.meta.url),JSON.stringify({headlights:HEADLIGHTS,clock:fixtures}));
console.log('Source vehicle lighting: 288 seasonal clock samples, two original emitter positions per model PASSED');
