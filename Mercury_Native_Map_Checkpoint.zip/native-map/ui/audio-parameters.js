import {engineSound,ENGINE_WAVE,SIREN_WAVE,sirenFrequency,spatial,footstepShape,radioPattern,serviceSirenFrequency,distanceCutoff,talkEnvelope,gust,lapping} from './source/sound-synth.js';
import {weatherSound,timeAmbience,transportTone,engineWobble,birdCall,fireworksTime,fireworkBurst} from './source/audio-design.js';
import {placeAt,surfaceAt,SPACES} from './source/acoustics.js';
import {footstepEvent} from './source/footsteps.js';
import {doorSoundEvent} from './source/vehicle-doors.js';
import {urgentMovement} from './source/response-priority.js';
import {environmentMix} from './source/quarter.js';
import {crowdNear} from './source/onlookers.js';
import {MAP_METRES} from './source/world-scale.js';
let lastRadio='',previousIds=new Set(),steps,doors,lastStep=-10,nextBird=0,nextFirework=0,burst=0,lastScene=0,nextSceneRadio=0;
const nearest=(items,scene)=>items.sort((a,b)=>Math.hypot(a.x-scene.x,a.y-scene.y)-Math.hypot(b.x-scene.x,b.y-scene.y))[0];
const gainAt=(item,scene)=>item?Math.max(spatial(item,scene).gain,.07*Math.max(0,1-Math.hypot(item.x-scene.x,item.y-scene.y)*MAP_METRES/2500)):0;
export function audioParameters(frame,prefs,time,scene){
 const s=frame?.state;const active=!!(s&&frame.active&&prefs?.enabled),shots=[];if(globalThis.nativeTestSignal){globalThis.nativeTestSignal=false;return {active:true,master:prefs?.master??.55,beds:[],tones:[],shots:[{hz:660,length:.12,level:.4},{hz:880,length:.12,delay:.12,level:.4}]};}if(!active){steps=null;doors=null;if(s){previousIds=new Set(s.incidents.map(i=>i.id));lastRadio=s.radio?.[0]?.text??'';}return {active:false,master:0,beds:[],tones:[],shots:[]};}
 const env=frame.environment??{},place=placeAt(scene.x,scene.y),room=SPACES[place.space],weather=weatherSound(env.weather),amb=timeAmbience(env.date,env.event),mix=environmentMix(scene,s.population?.residents),duck=env.ducked?.35:1,near=Math.min(1,Math.max(0,(scene.zoom-1)/10));
 const crowd=crowdNear(s.incidents,scene,{minute:env.date?.minute,weather:env.weather,event:env.event});
 const incident=nearest(s.incidents.filter(i=>['decision','working'].includes(i.state)&&Math.hypot(i.x-scene.x,i.y-scene.y)*MAP_METRES<150),scene);
 const talking=incident&&incident.talk?.stage!==undefined;
 const beds=[{level:(.55+.45*(1-near))*amb.traffic*weather.traffic*.07,hz:450,brown:true},{level:Math.min(1,mix.traffic*1.5+.15*near)*amb.traffic*weather.traffic*.06,hz:900,brown:true},{level:Math.min(2,(.25+.5*gust(time))*(.6+.4*(1-near))*weather.wind)*.085,hz:380+520*gust(time)},{level:mix.water*lapping(time)*.06,hz:850},{level:weather.rain*.045*2.5,hz:2000},{level:Math.max(amb.crowd,Math.min(1.2,crowd/5))*.04,hz:650},{level:talking?talkEnvelope(time)*.09:0,hz:1200}].map(b=>({...b,level:b.level*prefs.environment*6*duck}));
 const u=s.units.find(u=>u.id===frame.selected),vehicle=s.vehicles?.find(v=>v.id===u?.vehicleId),sound=engineSound(u?.currentSpeedKmh??0,{type:vehicle?.type,moving:!!u?.route?.length,on:!!u&&!u.foot&&['idle','patrol','responding','returning','transporting','proactive'].includes(u.status)}),position=spatial(u,scene);
 beds.push({level:sound.noise*prefs.engine*position.gain*.5,hz:Math.max(90,sound.hz*2.2),brown:true});
 const tones=[{hz:sound.hz,level:sound.level*prefs.engine*position.gain*5*engineWobble(vehicle?.wear,time)*(env.ducked?.5:1),cutoff:sound.cutoff,pan:position.pan,wave:ENGINE_WAVE}];
 const police=nearest(s.units.filter(u=>u.route?.length&&urgentMovement(s,u)),scene),target=police?.route?.at(-1),metres=target?Math.hypot(target.x-police.x,target.y-police.y)*MAP_METRES:Infinity,mode=transportTone(police,null,time,0,!!police,metres).sirenMode;
 tones.push({hz:sirenFrequency(mode,time),level:.32*prefs.siren*gainAt(police,scene),cutoff:Math.min(4200,distanceCutoff(gainAt(police,scene))),pan:spatial(police,scene).pan,wave:SIREN_WAVE});
 for(const kind of ['ambulance','rescue']){const service=nearest((s.services??[]).filter(v=>v.kind===kind&&v.status==='responding'&&v.route?.length),scene);tones.push({hz:serviceSirenFrequency(kind,time),level:.26*prefs.siren*gainAt(service,scene),pan:spatial(service,scene).pan,cutoff:Math.min(3000,distanceCutoff(gainAt(service,scene))),wave:SIREN_WAVE});}
 const step=footstepEvent(steps,s,scene);steps=step.next;if(step.event&&time-lastStep>.36){lastStep=time;const shape=footstepShape(surfaceAt(place,env.weather),burst++);shots.push({noise:true,hz:shape.hz,shape:shape.shape,length:shape.length,level:shape.level*step.event.level*prefs.environment*5});}
 const door=doorSoundEvent(doors,s,frame.selected,scene);doors=door.next;if(door.event)shots.push({hz:95,length:.16,shape:[[.005,1],[.05,.3],[.16,0]],level:prefs.environment*door.event.level});
 const radio=s.radio?.[0]?.text??'';if(radio!==lastRadio){lastRadio=radio;const pattern=radioPattern(radio);shots.push({noise:true,hz:1350,length:pattern.duration+.12,shape:[[.015,.55],[.05,.5],...pattern.syllables.flatMap(x=>[[x.t+.02,x.level*.8],[x.t+.08,x.level*.25]]),[pattern.duration,.15],[pattern.duration+.02,.5],[pattern.duration+.09,.35]],level:prefs.radio*.8*6});shots.push({hz:1650,length:.07,delay:pattern.duration+.13,level:prefs.radio*.4});}
 const fresh=s.incidents.filter(i=>!previousIds.has(i.id));previousIds=new Set(s.incidents.map(i=>i.id));if(fresh.length)shots.push({hz:fresh.some(i=>[2,5].includes(i.type))?1100:880,length:.12,level:prefs.radio*.2});
 if(incident&&incident.id!==lastScene){lastScene=incident.id;nextSceneRadio=time+2;}if(incident&&time>=nextSceneRadio&&!env.ducked){nextSceneRadio=time+8;const pattern=radioPattern('scene '+incident.id);shots.push({noise:true,hz:1500,length:pattern.duration,shape:pattern.syllables.map(x=>[x.t,x.level]),level:prefs.radio*.15});}
 if(time>=nextBird&&amb.birds>0&&!weather.rain&&scene.zoom>=8){const bird=birdCall(burst++);nextBird=time+bird.gap;for(let k=0;k<bird.notes;k++)shots.push({hz:bird.from,to:bird.to,length:.09,delay:k*.12,shape:[[.015,1],[.08,0]],level:prefs.environment*amb.birds*.08});}
 if(time>=nextFirework&&fireworksTime(env.date)){const fire=fireworkBurst(burst++);nextFirework=time+fire.gap;shots.push({noise:true,hz:fire.hz*4,length:.45,shape:[[.01,1],[.08,.5],[.2,.25]],level:prefs.environment*.1});if(fire.thump)shots.push({hz:70,length:.3,level:prefs.environment*.3});}
 return {active,master:prefs.master,beds,tones,shots,room};
}
