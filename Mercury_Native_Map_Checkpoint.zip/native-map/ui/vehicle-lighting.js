import {cityLighting,headlightBeams} from './source/lighting.js';
// Original two-emitter layout in world metres (source model scale 1).
export const HEADLIGHTS=Object.fromEntries(['sedan','suv'].map(kind=>[kind,headlightBeams({x:0,y:0},0,{scale:1,suv:kind==='suv',length:28}).map(beam=>({origin:beam.origin,height:.65,range:28,angle:Math.atan(.12)*180/Math.PI}))]));
export function vehicleLighting(minute,sun){return {...cityLighting(minute,sun),headlights:HEADLIGHTS};}
