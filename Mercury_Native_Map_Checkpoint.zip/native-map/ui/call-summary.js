// Claude 17.10.2026 (owner: «информационная панель перегружена и не даёт нужной инфы: на каком я вызове — ссора или
// пьяный водитель, мои действия, сколько времени пойдёт»). One short, structured summary of the call that matters —
// the selected one, else the one the player's own crew works on — for the native call card and the map card:
// what it is, what is going on, what the crew does, how far along it is and how long it will take.
import * as sim from './source/sim.js';
import {PHASES,sceneAnchor} from './source/scenes.js';
import {currentStage,scriptFor} from './source/dialogues.js';
import {WORLD_SECONDS_PER_TICK_SECOND,SPEED_KMH} from './source/transport.js';
import {MAP_METRES} from './source/world-scale.js';
const tickMin=ticks=>Math.max(0,ticks)*WORLD_SECONDS_PER_TICK_SECOND/60;
const STATE={waiting:'ждёт экипаж',assigned:'экипаж едет',onscene:'на месте',resolved:'закрыт',missed:'сорван'};
const UNIT={responding:'едет на вызов',decision:'на месте, ждёт вашего решения',working:'работает на месте',transporting:'везёт в участок',returning:'возвращается'};
const PERSON={waiting:'ждёт',missing:'разыскивается',found:'найден',fleeing:'уезжает',stopping:'останавливается',stopped:'остановлен',resolved:'помощь оказана',left:'ушёл'};
// progress samples per call: the real pace (crew, skills, weather) instead of a guess
const pace=new Map();
function routeMetres(u){let m=0,x=u.x,y=u.y;for(const p of u.route??[]){m+=Math.hypot(p.x-x,p.y-y);x=p.x;y=p.y;}return m*MAP_METRES;}
// selected===null: the call of the player's own crew (the map card: «мне нужно знать, что делает мой»); a number: that call
export function callSummary(state,selected=null){
 const own=state.units.find(u=>u.id===1),live=i=>i&&!['resolved','missed'].includes(i.state);
 const i=selected!=null?state.incidents.find(x=>x.id===selected&&live(x)):(own?.incident!=null?state.incidents.find(x=>x.id===own.incident&&live(x)):null);
 if(!i)return null;
 const t=sim.TYPES[i.type],crews=state.units.filter(u=>u.incident===i.id),mine=crews.find(u=>u.id===1)??crews[0]??null;
 let arrive=null;if(mine&&mine.status==='responding'&&mine.route?.length)arrive=Math.max(1,Math.round(routeMetres(mine)/(SPEED_KMH.response*1000/60)));
 // the pace of the work: progress per tick, measured over the last samples
 const now=state.time+(state.shift-1)*1e4,prev=pace.get(i.id);let rate=null;
 if(prev&&now>prev.at&&i.progress>prev.progress)rate=(i.progress-prev.progress)/(now-prev.at);
 if(!prev||now-prev.at>6)pace.set(i.id,{at:now,progress:i.progress,rate:rate??prev?.rate??null});
 rate=rate??prev?.rate??null;
 if(pace.size>40)for(const k of [...pace.keys()].slice(0,pace.size-40))pace.delete(k);
 const pct=Math.max(0,Math.min(100,Math.round(i.progress/t.duration*100)));
 const left=i.progress>0&&rate>0?Math.max(1,Math.round(tickMin((t.duration-i.progress)/rate))):i.progress>0||mine?.status==='working'?Math.max(1,Math.round(tickMin(t.duration-i.progress))):null;
 const option=t.options?.find(o=>o[1]===i.decision);
 const stage=currentStage(i);
 // what the crew did last and what comes next, in the words of the scene
 const last=i.talk?.choices?.at(-1),script=scriptFor(i),lastOption=last?script?.find(st=>st.stage===last.stage)?.options?.find(o=>o.id===last.id):null;
 const action=lastOption?lastOption.label:option?option[0]:null;
 const result=last?.line??i.scene?.reason??null,next=stage?stage.title:null,waitingYou=mine?.id===1&&mine.status==='decision'||(mine?.id===1&&!mine.auto&&!!stage&&mine.status==='working');
 const people=(i.scene?.participants??[]).filter(a=>a.visible).slice(0,4).map(a=>({name:a.name,role:a.role,status:PERSON[a.status]??a.status}));
 const services=(state.services??[]).filter(a=>a.incident===i.id).map(a=>({kind:a.kind,status:a.status}));
 return {id:i.id,title:sim.callName(i),brief:sim.callBrief(i),severity:t.severity,state:STATE[i.state]??i.state,
  phase:i.scene?PHASES[i.scene.phase]??null:null,result,next,waitingYou,tension:i.scene?Math.round(i.scene.tension):null,
  crew:mine?{id:mine.id,name:mine.name,mine:mine.id===1,status:(UNIT[mine.status]??sim.unitReason(state,mine))+(mine.auto&&['working','responding'].includes(mine.status)?' · решает сам (автомат)':''),auto:!!mine.auto}:null,
  crews:crews.length,arrive,action,progress:pct,left,deadline:Math.max(0,Math.round(tickMin(t.limit-i.age))),people,services,
  armed:!!i.armed,backup:!!i.backupRequested&&crews.length<2,anchor:sceneAnchor(i)};
}
