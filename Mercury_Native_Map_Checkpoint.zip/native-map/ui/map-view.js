import {crewPresentation} from './source/crew.js';
import {sceneAnchor} from './source/scenes.js';
import {emergencyLights} from './source/lighting.js';
import {residentPosition} from './source/population.js';
import {WALK_STATUSES} from './source/visits.js';
import {vehicleDoors} from './source/vehicle-doors.js';
import {vehicleStyle} from './vehicle-style.js';

// Read-only presentation: use the same visibility and anchors as the original map.
export function mapActors(state) {
 return {
  units: state.units.map(u => ({
   id:u.id,x:u.x,y:u.y,status:u.status,incident:u.incident,route:u.route,
   target:u.route?.[0],heading:u.renderHeading??u.heading??0,
   people:u.people,vehicleId:u.vehicleId,foot:u.foot,doors:vehicleDoors(u),emergency:emergencyLights(u,state),
   crew:u.people.map((_,index)=>{
    const activity=crewPresentation(state,u,index);
    return {...activity,...(activity.position??{x:u.x-0.001*(index+1),y:u.y}),unitId:u.id};
   }).filter(a=>a.visible)
  })),
  vehicles:state.vehicles.map(v=>({...v,nativeStyle:vehicleStyle(v)})),services:state.services??[],
  residents:(state.population?.residents??[]).filter(r=>
   WALK_STATUSES.includes(r.status)||r.status==='recovering'||
   (r.route?.length&&r.status!=='incident'&&!['home','work'].includes(r.status))
  ).map(r=>({...r,...residentPosition(r)})),
  incidents:state.incidents.filter(i=>!['resolved','missed'].includes(i.state)).map(i=>({
   id:i.id,x:i.x,y:i.y,state:i.state,type:i.type,anchor:sceneAnchor(i),
   participants:(i.scene?.participants??[]).filter(a=>a.visible)
  }))
 };
}
