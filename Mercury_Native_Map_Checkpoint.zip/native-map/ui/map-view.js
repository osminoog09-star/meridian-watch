import {crewPresentation} from './source/crew.js';
import {sceneAnchor} from './source/scenes.js';
import {emergencyLights} from './source/lighting.js';
import {residentPosition,residentProfile} from './source/population.js';
import {WALK_STATUSES} from './source/visits.js';
import {vehicleDoors} from './source/vehicle-doors.js';
import {vehicleStyle} from './vehicle-style.js';
import {heroLook} from './source/hero.js';
import {humanStyle} from './human-style.js';
import {GBR_BASE,prefectureOn} from './source/sim.js';
import {streetLife,streetPending} from './source/cityday.js';
/* Claude 17.10 (Release O3 «Живой город»): citizens of the registry on the streets near the camera, refreshed twice a second */
let street=[],streetAt=-1;const PALETTE=['#c6a7e9','#ddcfa6','#9bbade','#ccaaa7','#a9d3b4','#e0c08a','#b7b7c9','#d7a3b8'];
function citizensNear(state){const el=state.population?.elapsed??0,scene=globalThis.nativeScene;if(!scene||state.mode==='chief'&&state.setupPending)return [];const key=Math.round(el*2)+'|'+Math.round(scene.x*400)+'|'+Math.round(scene.y*400)+'|'+Math.round(scene.zoom??0);if(key!==streetAt||streetPending()){streetAt=key;const radius=Math.min(.35,Math.max(260,1.6*6500/Math.max(.2,scene.zoom??6))/1670);/* the same circle in which live_actors.gd draws people */street=streetLife(el,scene,{rain:globalThis.nativeAudioFrame?.environment?.weather==='rain',routes:1,radius});}return street.map(p=>({...p,status:p.car?'citizenCar':'citizenWalk',nativeStyle:humanStyle(false,PALETTE[p.id%PALETTE.length]),vehicleStyle:vehicleStyle({color:PALETTE[(p.id>>3)%PALETTE.length]},false)}));}
/* Claude 17.10 (Release R1): the prefecture's rapid response team is somewhere in the city even when no call needs it — its car stands at the base */
const standbyTeam=state=>prefectureOn(state)&&!(state.services??[]).some(a=>a.kind==='gbr')?[{id:0,kind:'gbr',x:GBR_BASE.x+0.0006,y:GBR_BASE.y,route:[],status:'standby',heading:0,standby:true}]:[];

// Read-only presentation: use the same visibility and anchors as the original map.
export function mapActors(state) {
 return {
  units: state.units.map(u => ({
   id:u.id,x:u.x,y:u.y,status:u.status,incident:u.incident,route:u.route,
   target:u.route?.[0],heading:u.renderHeading??u.heading??0,
   people:u.people,vehicleId:u.vehicleId,foot:u.foot,doors:vehicleDoors(u),emergency:emergencyLights(u,state),
   crew:u.people.map((_,index)=>{
    const activity=crewPresentation(state,u,index);
    return {...activity,...(activity.position??{x:u.x-0.001*(index+1),y:u.y}),unitId:u.id,nativeStyle:humanStyle(true,undefined,u.agency??state.agency,state.mode==='career'&&u.id===1&&index===0?heroLook(state.hero):null)};
   }).filter(a=>a.visible)
  })),
  vehicles:state.vehicles.map(v=>({...v,nativeStyle:vehicleStyle(v)})),services:[...(state.services??[]),...standbyTeam(state)].map(a=>a.kind==='police'||a.kind==='lead'?{...a,nativeStyle:vehicleStyle({paint:'white',lights:'redblue'}),emergency:a.kind==='lead'?a.status==='responding':a.status!=='returning'}:a.kind==='gbr'||a.kind==='kk'?{...a,nativeStyle:vehicleStyle({paint:a.kind==='kk'?'grey':'black',lights:'blue'}),emergency:!a.standby&&a.status!=='returning'}:a),/* Release K: a city patrol at a joint scene */
  residents:(state.population?.residents??[]).filter(r=>
   WALK_STATUSES.includes(r.status)||r.status==='recovering'||
   (r.route?.length&&r.status!=='incident'&&!['home','work'].includes(r.status))
  ).map(r=>({...r,...residentPosition(r),walking:['walkVisit','walkBack'].includes(r.status)&&!!r.route?.length,nativeStyle:humanStyle(false,residentProfile(r.id)?.color),vehicleStyle:vehicleStyle({color:residentProfile(r.id)?.color},false)})),
  citizens:citizensNear(state),
  incidents:state.incidents.filter(i=>!['resolved','missed'].includes(i.state)).map(i=>({
   id:i.id,x:i.x,y:i.y,state:i.state,type:i.type,anchor:sceneAnchor(i),
   participants:(i.scene?.participants??[]).filter(a=>a.visible).map(a=>({...a,nativeStyle:humanStyle(false,residentProfile(a.residentId)?.color),walking:!!a.route?.length}))
  }))
 };
}
