import {crewPresentation} from './source/crew.js';
import {sceneAnchor} from './source/scenes.js';
import {emergencyLights} from './source/lighting.js';
import {residentPosition,residentProfile} from './source/population.js';
import {WALK_STATUSES} from './source/visits.js';
import {vehicleDoors} from './source/vehicle-doors.js';
import {vehicleStyle} from './vehicle-style.js';
import {humanStyle} from './human-style.js';

// Read-only presentation: use the same visibility and anchors as the original map.
export function mapActors(state) {
 return {
  units: state.units.map(u => ({
   id:u.id,x:u.x,y:u.y,status:u.status,incident:u.incident,route:u.route,
   target:u.route?.[0],heading:u.renderHeading??u.heading??0,
   people:u.people,vehicleId:u.vehicleId,foot:u.foot,doors:vehicleDoors(u),emergency:emergencyLights(u,state),
   crew:u.people.map((_,index)=>{
    const activity=crewPresentation(state,u,index);
    return {...activity,...(activity.position??{x:u.x-0.001*(index+1),y:u.y}),unitId:u.id,nativeStyle:humanStyle(true,undefined,u.agency??state.agency)};
   }).filter(a=>a.visible)
  })),
  vehicles:state.vehicles.map(v=>({...v,nativeStyle:vehicleStyle(v)})),services:(state.services??[]).map(a=>a.kind==='police'?{...a,nativeStyle:vehicleStyle({paint:'white',lights:'redblue'}),emergency:a.status!=='returning'}:a.kind==='gbr'||a.kind==='kk'?{...a,nativeStyle:vehicleStyle({paint:a.kind==='kk'?'grey':'black',lights:'blue'}),emergency:a.status!=='returning'}:a),/* Release K: a city patrol at a joint scene */
  residents:(state.population?.residents??[]).filter(r=>
   WALK_STATUSES.includes(r.status)||r.status==='recovering'||
   (r.route?.length&&r.status!=='incident'&&!['home','work'].includes(r.status))
  ).map(r=>({...r,...residentPosition(r),walking:['walkVisit','walkBack'].includes(r.status)&&!!r.route?.length,nativeStyle:humanStyle(false,residentProfile(r.id)?.color),vehicleStyle:vehicleStyle({color:residentProfile(r.id)?.color},false)})),
  incidents:state.incidents.filter(i=>!['resolved','missed'].includes(i.state)).map(i=>({
   id:i.id,x:i.x,y:i.y,state:i.state,type:i.type,anchor:sceneAnchor(i),
   participants:(i.scene?.participants??[]).filter(a=>a.visible).map(a=>({...a,nativeStyle:humanStyle(false,residentProfile(a.residentId)?.color),walking:!!a.route?.length}))
  }))
 };
}
