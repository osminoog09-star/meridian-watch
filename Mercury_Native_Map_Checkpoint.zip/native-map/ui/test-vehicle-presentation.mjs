// Claude 16.10 (Release O): a chief campaign is earned in a career — these scenarios start from an earned one.
import fs from 'node:fs';
import vm from 'node:vm';
import assert from 'node:assert/strict';
import {MODELS,posedVertex} from './source/models.js';
import {vehicleStyle} from './vehicle-style.js';
import {vehicleDoors} from './source/vehicle-doors.js';
import {LIVERIES} from './source/garage.js';
for(const [paint,livery] of Object.entries(LIVERIES)){
 const style=vehicleStyle({paint});assert.equal(style.palette.paint,livery.paint);assert.equal(style.palette.stripe,livery.stripe);
}
const fixtures=[];
for(const kind of ['sedan','suv'])for(const kit of ['base','aid','search']){
 const model=MODELS[kind],style=vehicleStyle({paint:'yellow',kit,lights:'blue'});
 const included=model.faces.filter(f=>!['aid','search'].includes(f.group)||f.group===kit);
 const counts=Object.fromEntries(['body','leftDoor','rightDoor'].map(part=>[part,included.filter(f=>part==='body'?!['leftDoor','rightDoor'].includes(f.group):f.group===part).reduce((n,f)=>n+(f.v.length-2)*3,0)]));
 const samples=[];
 for(const side of ['left','right'])for(const amount of [0,.5,1]){
  const face=model.faces.find(f=>f.group===side+'Door');const id=face.v[0];
  const p=model.vertices[id],expected=posedVertex(model,face,id,{doors:{[side]:amount}});
  samples.push({side,amount,point:[p[0],p[2],p[1]],expected:[expected[0],expected[2],expected[1]]});
 }
 fixtures.push({kind,style,counts,samples});
}
assert.deepEqual(vehicleDoors({foot:{phase:'exit',timer:.04,actors:[{},{}]}}),{left:1,right:1});
assert.deepEqual(vehicleDoors({foot:{phase:'onScene',timer:0,actors:[{},{}]}}),{left:0,right:0});
fs.writeFileSync(new URL('./vehicle-fixtures.json',import.meta.url),JSON.stringify(fixtures));
const c=vm.createContext({console});vm.runInContext(fs.readFileSync(new URL('./ui-bundle.js',import.meta.url),'utf8'),c);
const call=r=>JSON.parse(c.MercuryUI.call(JSON.stringify(r)));const event=(domId,value)=>call({op:'event',domId,event:value===undefined?'click':'change',...(value===undefined?{}:{value})});
call({op:'initialize',storage:{'mercury-chief-unlocked':"{\"police\": {\"first\": \"Анна\", \"last\": \"Тамм\", \"gender\": \"f\", \"age\": 41, \"skin\": 1, \"hair\": \"bun\", \"hairColor\": 1, \"build\": \"average\", \"beard\": false, \"glasses\": false}, \"rescue\": {\"first\": \"Анна\", \"last\": \"Тамм\", \"gender\": \"f\", \"age\": 41, \"skin\": 1, \"hair\": \"bun\", \"hairColor\": 1, \"build\": \"average\", \"beard\": false, \"glasses\": false}, \"ems\": {\"first\": \"Анна\", \"last\": \"Тамм\", \"gender\": \"f\", \"age\": 41, \"skin\": 1, \"hair\": \"bun\", \"hairColor\": 1, \"build\": \"average\", \"beard\": false, \"glasses\": false}, \"dispatch\": {\"first\": \"Анна\", \"last\": \"Тамм\", \"gender\": \"f\", \"age\": 41, \"skin\": 1, \"hair\": \"bun\", \"hairColor\": 1, \"build\": \"average\", \"beard\": false, \"glasses\": false}}"}});event('startChief');for(let i=0;i<4;i++)event('wizardNext');event('departmentBtn');let s=event('edit-car-1');
const flat=nodes=>nodes.flatMap(n=>[n,...flat(n.children??[])]);const preview=()=>flat(s.tree).find(n=>n.domId==='garageModel').preview;
assert.equal(preview().kind,'sedan');const angle=preview().options.angle;
s=event('rotateLeft');assert.ok(preview().options.angle<angle);
s=event('carPaint','yellow');assert.equal(preview().options.palette.paint,LIVERIES.yellow.paint);
s=event('carKit','search');assert.equal(preview().options.kit,'search');
const before=call({op:'state'});assert.notEqual(before.vehicles[0].paint,'yellow','preview is not a save');
s=event('saveCarBtn');assert.equal(call({op:'state'}).vehicles[0].paint,'yellow');
assert.equal(s.view.vehicles[0].nativeStyle.palette.paint,LIVERIES.yellow.paint);
console.log('Garage rotate/preview/save/map style and source door fixtures PASSED');
