import fs from 'node:fs';import vm from 'node:vm';import assert from 'node:assert/strict';
const c=vm.createContext({console});vm.runInContext(fs.readFileSync(new URL('./ui-bundle.js',import.meta.url),'utf8'),c);
const requests=[],call=r=>{requests.push(r);return JSON.parse(c.MercuryUI.call(JSON.stringify(r)))};
const flat=nodes=>nodes.flatMap(n=>[n,...flat(n.children??[])]);let s=call({op:'initialize',storage:{}});const event=(domId,props={})=>s=call({op:'event',domId,event:'click',...props});
event('startChief');for(let i=0;i<4;i++)event('wizardNext');call({op:'pick',hit:{kind:'unit',id:1}});event('autoSetting',{event:'change',checked:false});event('settingsBtn');event('settingsWorldRate',{event:'change',value:'45'});event('applyAudio');await Promise.resolve();await Promise.resolve();s=call({op:'snapshot'});const speed=flat(s.tree).find(n=>n.text==='60×');call({op:'event',id:speed.id,event:'click'});
let frames=0;for(;frames<3000;frames++){s=call({op:'frame',seconds:1/30,full:true});if(flat(s.tree).some(n=>n.domId==='decisionBtn'))break;const waiting=s.view.incidents.find(i=>i.state==='waiting');if(waiting&&['patrol','idle'].includes(s.view.units[0]?.status)){s=call({op:'pick',hit:{kind:'incident',id:waiting.id}});const dispatch=flat(s.tree).find(n=>n.domId==='dispatchBtn');if(dispatch&&!dispatch.disabled)event('dispatchBtn');}}
if(frames>=3000)console.log({status:s.status,view:s.view.units,time:s.view.time,ended:s.view.ended,incidents:s.view.incidents.slice(0,3)});assert.ok(frames<3000,'waiting decision');event('decisionBtn');let choices=0;
for(;choices<3;choices++){
 const option=flat(s.tree).find(n=>n.tag==='button'&&n.classes.includes('talk-option')&&!n.disabled);assert.ok(option,'stage '+choices);s=call({op:'event',id:option.id,event:'click'});
}
const expected=call({op:'state'}),incident=expected.incidents.find(i=>i.talk?.choices.length===3);assert.ok(incident,'three dialogue stages recorded');
fs.writeFileSync(new URL('./manual-call-trace.json',import.meta.url),JSON.stringify([{mode:'chief-manual-three-stage',requests,expected}]));console.log({frames,choices,incident:incident.id,status:expected.units[0].status});
