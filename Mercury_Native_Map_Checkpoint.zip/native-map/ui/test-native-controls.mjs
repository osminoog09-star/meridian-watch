import fs from 'node:fs';
import vm from 'node:vm';
import assert from 'node:assert/strict';
const context=vm.createContext({console});
vm.runInContext(fs.readFileSync(new URL('./ui-bundle.js',import.meta.url),'utf8'),context);
const call=request=>JSON.parse(context.MercuryUI.call(JSON.stringify(request)));
const find=(nodes,id)=>nodes.flatMap(n=>[n,...flatten(n.children??[])]).find(n=>n.domId===id);
const flatten=nodes=>nodes.flatMap(n=>[n,...flatten(n.children??[])]);
call({op:'initialize'});
call({op:'event',domId:'startCareer',event:'click'});
call({op:'event',domId:'closeModal',event:'click'});
let state=call({op:'pick',hit:{kind:'unit',id:1}});
for(const id of ['identity','serviceBtn','units','unitSettings','autoSetting','zoneSetting','restBtn','tipCard','tipOk']) assert.ok(find(state.tree,id),`Missing rendered control ${id}`);
state=call({op:'event',id:find(state.tree,'autoSetting').id,event:'change',checked:false});
assert.equal(JSON.parse(context.MercuryUI.call('{"op":"state"}')).units[0].auto,false);
state=call({op:'event',id:find(state.tree,'tipOk').id,event:'click'});
assert.equal(find(state.tree,'tipCard'),undefined);
for(const id of ['serviceBtn','reportBtn','settingsBtn','journalBtn','helpBtn']){
 state=call({op:'event',domId:id,event:'click'});assert.equal(state.tree[0].tag,'dialog');
 assert.ok(find(state.tree,'closeModal'));
 state=call({op:'event',id:find(state.tree,'closeModal').id,event:'click'});
}
console.log('Native control coverage: unit controls visible/actionable, tip dismissal, five modal screens passed');
