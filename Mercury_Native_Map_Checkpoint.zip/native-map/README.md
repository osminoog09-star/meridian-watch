# Mercury Response — native Godot migration, game 0.9.2-a

Godot 4.7.2 Compatibility renders the map and native Controls. QuickJS runs the original simulation and gameplay handlers (Claude C2/E included). Linkedom is a semantic event/layout adapter; no WebView renders the game. The read-only Android WebView is used solely to recover legacy localStorage.

Current deliverable: 0.3.0-native-scenes-test, versionCode11, signed with the existing certificate. This is a test APK; stable feed remains0.2.9. Exact identity is in native-scenes-release.json. Full physical acceptance has NOT been completed.

## Verified paths

- Original call anchors/active visibility, incident participants/pursuit cars, crew visibility, selected road route, all patrol arrows/IDs/selection and matching map hit targets. Police sedan/SUV model selection.

- Career and chief: scheduled12h shift, report, next shift, exact save/restart/export/import. Native replay1064requests includes a manually dispatched call with three dialogue choices; final states match Node within1e-8.
-12legacy fixtures, corrupt-input guard, native save backup recovery.
- Native menus: source handlers, semantic cards/details/tables, disabled/readonly inputs, huge text/contrast, decision jump, native clipboard. Touch/inertia keeps child identity; page scroll and fixed close remain stable.
- HUD at360/740 logical pixels, weather, FPS below clock, radio,52px controls, fullscreen map/return.
- Camera commands survive autosave/Promise settlement; city/quarter/reset/locate stop following.
- Graphics quality/shadows/LOD and adaptive 3D resolution are connected. Source walking network/Dijkstra path selection is native.
-53bridge segments give actors matching deck elevation. Distinct ambulance/rescue bodies, source onlookers, bounded rain/snow/wind,192night windows/48lamps,128New Year sparks. Effects do not consume simulation RNG.
- Native diagnostics exports Godot frame intervals and Android memory/battery temperature/thermal status when available. Device tour cancellation/restoration and clipboard verified with synthetic timing fixtures; these are NOT Fold6 performance measurements.

## Remaining acceptance and limitations

- Fold6: both physical displays, long shift30+FPS/memory/thermal, touch feel, visual overlap, audio listening/background recovery, actual legacy WebView origin migration, file picker and installer. No device is connected here.
- Full visual equivalence with every original screen has not been established. Headless layout/logic tests are not GPU screenshot tests.
- Night lighting uses bounded emissive geometry and surface patches, not dynamic street-light shadow casting. Bridge approaches still use the existing source deck geometry; no new ramp reconstruction. Source feature completion must not be inferred from this list.
- Keep migration-gate.json false until acceptance. Do not publish this APK to the stable feed or merge directly into main.

## Reproduction

`cd ui && npm ci && npm run build`

Run Node tests `test-ui.mjs`, `test-native-controls.mjs`, `test-full-cycle.mjs`, `test-manual-call.mjs`, `test-native-diagnostics.mjs` from `ui/`. Generate traces before `scripts/verify_full_ui_cycle.gd`.

Godot command: `godot --headless --path . --script scripts/verify_full_ui_cycle.gd`. Scene tests `verify_native_hud.gd`, `verify_native_scroll.gd`, `verify_native_map_controls.gd`, `verify_native_effects.gd` require trailing `-- --native-ui`.

`tools/export_test_apk.py` stages an unsigned APK from a previously verified native Android host template. Signing material is external and never included. Verify signer,16KiB alignment, ZIP integrity and byte equality of runtime bundles before delivery.
