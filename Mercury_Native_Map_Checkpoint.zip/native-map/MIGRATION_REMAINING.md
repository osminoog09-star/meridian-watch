# Migration first — owner instruction, 2026-10-14

Do not start new roadmap features until the existing game is fully transferred and accepted. The stable release gate remains false. Gameplay additions by Claude must be preserved, not replaced with a new game.

Completed source transfers are recorded with tests in COLLAB_LOG.md. They do not establish physical device or visual acceptance.

Current remaining work:

- Audit all model previews and human poses against the original presentation; transfer source walking/gesture animation, resident colours and emergency/headlight effects that are still simplified.
- Complete bridge approach geometry without changing road routing or cutting corners.
- Audit every menu with actual rendered images at both Fold6 aspect ratios; logic/layout tests alone are insufficient.
- Verify actual WebView save recovery, native save round trip, audio after background, file picker and APK installer on Android.
- Measure long-shift frame intervals, memory and thermal behaviour on both Fold6 displays. No connected Fold6 is available in this environment.

Vehicle liveries/equipment/hinged doors and garage preview are being transferred in the current package. Per-frame authoritative actor/camera updates replace the native presentation's 10Hz sampling; simulation timing and routes remain unchanged.
