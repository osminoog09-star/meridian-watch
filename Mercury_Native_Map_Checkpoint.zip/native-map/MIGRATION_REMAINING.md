# Migration first — owner instruction, 2026-10-14

Do not start new roadmap features until the existing game is fully transferred and accepted. The stable release gate remains false. Gameplay additions by Claude must be preserved, not replaced with a new game.

Completed source transfers are recorded with tests in COLLAB_LOG.md. They do not establish physical device or visual acceptance.

Current remaining work:

- Visually accept native headlight/beacon illumination and finish luminous lamp surfaces/tail-light appearance against the original. Bounded native light sources and seasonal dawn/dusk transitions now have automated coverage. Human poses, walking phase, resident colours and previews have source/numerical coverage; GPU visual acceptance is still open.
- Visually accept the connected bridge approaches on-device. Geometry and actor heights now share profiles; source road routing is unchanged and 4055 height samples pass.
- Audit every menu with actual rendered images at both Fold6 aspect ratios; logic/layout tests alone are insufficient.
- Verify actual WebView save recovery, native save round trip, audio after background, file picker and APK installer on Android.
- Measure long-shift frame intervals, memory and thermal behaviour on both Fold6 displays. No connected Fold6 is available in this environment.

Vehicle liveries/equipment/hinged doors, garage preview, human poses/colours and connected bridge approaches are transferred in source with automated coverage. Per-frame authoritative actor/camera updates replace the native presentation's 10Hz sampling; simulation timing and routes remain unchanged.

2026-10-15 regression: retained native patrol buttons clicked detached source DOM elements. Fixed semantic live-target resolution; Node and actual Godot button viewport input tests select patrol 2 and follow it at 360/740 px. This closes a specific automated regression, not physical touch acceptance.
