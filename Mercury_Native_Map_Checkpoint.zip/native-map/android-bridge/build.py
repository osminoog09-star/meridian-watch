from pathlib import Path
import os,subprocess,zipfile
root=Path(__file__).resolve().parent
android=Path(os.environ['ANDROID_JAR']);godot=Path(os.environ['GODOT_ANDROID_AAR']);ecj=Path(os.environ['ECJ_JAR']);build=root/'build';classes=build/'classes';classes.mkdir(parents=True,exist_ok=True)
with zipfile.ZipFile(godot) as z:(build/'godot-classes.jar').write_bytes(z.read('classes.jar'))
subprocess.run(['java','-jar',str(ecj),'-encoding','UTF-8','-source','8','-target','8','-bootclasspath',str(android)+os.pathsep+os.environ['ANDROID_LAMBDA_STUBS'],'-classpath',str(build/'godot-classes.jar'),'-d',str(classes),*[str(f) for f in (root/'src').rglob('*.java')]],check=True)
with zipfile.ZipFile(build/'classes.jar','w',zipfile.ZIP_DEFLATED) as z:
 for f in classes.rglob('*.class'):z.write(f,str(f.relative_to(classes)))
output=root.parent/'addons/mercury_android/MercuryAndroid.aar';output.parent.mkdir(parents=True,exist_ok=True)
with zipfile.ZipFile(output,'w',zipfile.ZIP_DEFLATED) as z:
 z.write(build/'classes.jar','classes.jar');z.write(root/'AndroidManifest.xml','AndroidManifest.xml');z.writestr('proguard.txt','-keep class com.mercurypolice.response.** { *; }\n')
print(output)
