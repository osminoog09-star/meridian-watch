package com.mercurypolice.response;
import android.app.AlertDialog;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.Signature;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.widget.Toast;
import org.json.JSONObject;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.concurrent.*;
final class ApkUpdater {
    private static final String ORIGIN="https://meridian-watch.osminoog09.chatgpt.site";
    private static final String FEED=ORIGIN+"/downloads/android/update.json";
    private static final int INSTALL_PERMISSION=21;
    interface Host { boolean isActive(); void saveForUpdate(Runnable continuation); }
    private final Activity activity;
    private final Host host;
    private final Handler main=new Handler(Looper.getMainLooper());
    private final ExecutorService worker=Executors.newSingleThreadExecutor();
    private boolean busy,closed,dialogOpen,awaitingPermission;
    private int offered;
    private PackageInfo readyInfo;
    private final File ready;
    ApkUpdater(Activity a, Host h){activity=a;host=h;ready=new File(a.getFilesDir(),"update.apk");}
    private void toast(String s){Toast.makeText(activity,s,Toast.LENGTH_LONG).show();}
    private long code(PackageInfo p){return Build.VERSION.SDK_INT>=28?p.getLongVersionCode():p.versionCode;}
    private int flags(){return Build.VERSION.SDK_INT>=28?PackageManager.GET_SIGNING_CERTIFICATES:PackageManager.GET_SIGNATURES;}
    private Signature[] signatures(PackageInfo p){return Build.VERSION.SDK_INT>=28?p.signingInfo.getApkContentsSigners():p.signatures;}
    private boolean valid(File f,int version) {
        try{PackageManager pm=activity.getPackageManager();PackageInfo own=pm.getPackageInfo(activity.getPackageName(),flags());PackageInfo candidate=pm.getPackageArchiveInfo(f.getAbsolutePath(),flags());return candidate!=null && own.packageName.equals(candidate.packageName) && code(candidate)>code(own) && (version==0 || code(candidate)==version) && Arrays.equals(signatures(own),signatures(candidate));}catch(Exception e){return false;}
    }
    private HttpURLConnection connection(String url) throws Exception {
        URI uri=new URI(url);if(!"https".equals(uri.getScheme()) || !"meridian-watch.osminoog09.chatgpt.site".equals(uri.getHost()) || (uri.getPort()!=-1&&uri.getPort()!=443) || uri.getRawUserInfo()!=null || !uri.getPath().startsWith("/downloads/android/"))throw new IOException("Invalid update URL");
        HttpURLConnection c=(HttpURLConnection)new URL(url).openConnection();c.setInstanceFollowRedirects(false);c.setConnectTimeout(15000);c.setReadTimeout(20000);c.setRequestProperty("Cache-Control","no-cache");if(c.getResponseCode()!=200){c.disconnect();throw new IOException("Update server unavailable");}return c;
    }
    void check(boolean manual){
        if(closed||busy)return;
        busy=true;
        worker.execute(()->{
            if(ready.isFile()&&valid(ready,0)) {
                final PackageInfo cached=activity.getPackageManager().getPackageArchiveInfo(ready.getAbsolutePath(),0);
                main.post(()->{busy=false;readyInfo=cached;if(!closed)offer(manual);});return;
            }
            boolean downloaded=false,latest=false;String failure="";HttpURLConnection c=null;File temp=new File(activity.getFilesDir(),"update.part");
            try {
                c=connection(FEED+"?check="+System.currentTimeMillis());ByteArrayOutputStream bytes=new ByteArrayOutputStream();try(InputStream in=c.getInputStream()){byte[] b=new byte[4096];int n;while((n=in.read(b))!=-1){if(bytes.size()+n>65536)throw new IOException();bytes.write(b,0,n);}}c.disconnect();c=null;
                JSONObject feed=new JSONObject(new String(bytes.toByteArray(),StandardCharsets.UTF_8));int version=feed.getInt("versionCode");long installed=code(activity.getPackageManager().getPackageInfo(activity.getPackageName(),0));
                if(version<=installed)latest=true;
                else {
                    long length=feed.getLong("bytes");String expected=feed.getString("sha256");if(length<1||length>100*1024*1024||!expected.matches("[0-9a-f]{64}"))throw new IOException();
                    c=connection(feed.getString("url"));MessageDigest digest=MessageDigest.getInstance("SHA-256");long count=0;
                    try(InputStream in=c.getInputStream();OutputStream out=new FileOutputStream(temp)){byte[] buffer=new byte[32768];int n;while((n=in.read(buffer))!=-1){if(Thread.currentThread().isInterrupted())throw new IOException();count+=n;if(count>length)throw new IOException();digest.update(buffer,0,n);out.write(buffer,0,n);}}
                    StringBuilder actual=new StringBuilder();for(byte b:digest.digest())actual.append(String.format(java.util.Locale.ROOT,"%02x",b&255));
                    if(count!=length||!actual.toString().equals(expected)||!valid(temp,version))throw new IOException("Invalid update package");
                    if(!temp.renameTo(ready))throw new IOException();downloaded=true;
                }
            }catch(Exception e){failure="Не удалось проверить или скачать APK. Повторим позже; игра продолжает работать.";}finally{if(c!=null)c.disconnect();temp.delete();}
            final PackageInfo prepared=downloaded?activity.getPackageManager().getPackageArchiveInfo(ready.getAbsolutePath(),0):null;
            final boolean done=downloaded,upToDate=latest;final String message=failure;
            main.post(()->{busy=false;readyInfo=prepared;if(closed||!host.isActive())return;if(done)offer(manual);else if(manual)toast(upToDate?"Установлена последняя версия приложения":message);});
        });
    }
    private void offer(boolean manual){
        if(closed||!host.isActive()||dialogOpen||readyInfo==null||!ready.isFile())return;
        PackageInfo candidate=readyInfo;int version=candidate.versionCode;if(!manual&&offered==version)return;offered=version;dialogOpen=true;
        new AlertDialog.Builder(activity).setTitle("Обновление приложения "+candidate.versionName).setMessage("APK уже скачан и проверен. Установить обновление? Сохранения останутся. Android попросит подтверждение.").setPositiveButton("Установить",(d,w)->install()).setNegativeButton("Позже",null).setOnDismissListener(d->dialogOpen=false).show();
    }
    private void install(){
        if(closed||busy)return;busy=true;
        worker.execute(()->{final boolean verified=valid(ready,0);main.post(()->{busy=false;if(closed||!host.isActive())return;if(!verified){readyInfo=null;toast("Пакет обновления не прошёл проверку");return;}host.saveForUpdate(()->installSaved());});});
    }
    private void installSaved(){
        if(!activity.getPackageManager().canRequestPackageInstalls()){
            awaitingPermission=true;
            try{activity.startActivityForResult(new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,Uri.parse("package:"+activity.getPackageName())),INSTALL_PERMISSION);}catch(Exception e){awaitingPermission=false;toast("Откройте настройки разрешения установки для Mercury Response");}return;
        }
        try{Intent i=new Intent(Intent.ACTION_VIEW);i.setDataAndType(Uri.parse("content://com.mercurypolice.response.updates/update.apk"),"application/vnd.android.package-archive");i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);activity.startActivity(i);}catch(Exception e){toast("Не удалось открыть установщик Android");}
    }
    void activityResult(int request){if(request==INSTALL_PERMISSION&&awaitingPermission){awaitingPermission=false;if(activity.getPackageManager().canRequestPackageInstalls())install();else toast("Установка не разрешена. Можно повторить через меню приложения.");}}
    void resume(){if(!awaitingPermission)main.post(()->offer(false));}
    void close(){closed=true;worker.shutdownNow();main.removeCallbacksAndMessages(null);}
}
