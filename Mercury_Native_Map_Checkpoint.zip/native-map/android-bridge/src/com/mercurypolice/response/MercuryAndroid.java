package com.mercurypolice.response;
import android.app.Activity;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.*;
import android.webkit.*;
import android.widget.Toast;
import android.util.DisplayMetrics;
import org.json.*;
import org.godotengine.godot.Godot;
import org.godotengine.godot.plugin.*;
import java.util.*;
import java.io.ByteArrayInputStream;
public final class MercuryAndroid extends GodotPlugin implements ApkUpdater.Host {
 private final Handler main=new Handler(Looper.getMainLooper());
 private ApkUpdater updater;private boolean active=false,closed=false;private Runnable afterSave;private WebView legacy;private boolean migrating=false;
 private final Runnable poll=()->{if(!closed&&active){ensureUpdater();updater.check(false);main.postDelayed(this.pollAgain,300000);}};
 private final Runnable pollAgain=()->{if(!closed&&active){ensureUpdater();updater.check(false);main.postDelayed(this.pollAgain,300000);}};
 public MercuryAndroid(Godot godot){super(godot);}
 @Override public String getPluginName(){return "MercuryAndroid";}
 @Override public Set<SignalInfo> getPluginSignals(){Set<SignalInfo> signals=new HashSet<>();signals.add(new SignalInfo("legacy_storage_ready",String.class,String.class));signals.add(new SignalInfo("save_before_update"));return signals;}
 private void ensureUpdater(){if(updater==null)updater=new ApkUpdater(getActivity(),this);}
 @Override public boolean isActive(){return active&&!closed;}
 @Override public void saveForUpdate(Runnable continuation){afterSave=continuation;emitSignal("save_before_update");main.postDelayed(()->{if(afterSave!=null){afterSave=null;Toast.makeText(getActivity(),"Сохранение не подтверждено — установка отложена",Toast.LENGTH_LONG).show();}},10000);}
 @UsedByGodot public void savedForUpdate(boolean success){main.post(()->{Runnable next=afterSave;afterSave=null;if(success&&next!=null)next.run();});}
 @UsedByGodot public void checkUpdates(boolean manual){main.post(()->{ensureUpdater();updater.check(manual);});}
 @Override public void onMainResume(){active=true;ensureUpdater();updater.resume();main.removeCallbacks(poll);main.removeCallbacks(pollAgain);main.postDelayed(poll,10000);}
 @Override public void onMainPause(){active=false;main.removeCallbacks(poll);main.removeCallbacks(pollAgain);}
 @Override public void onMainDestroy(){closed=true;if(updater!=null)updater.close();main.removeCallbacksAndMessages(null);destroyLegacyView();}
 @Override public void onMainActivityResult(int request,int result,Intent data){if(updater!=null)updater.activityResult(request);}
 private int migrationGeneration=0;
 private static final String LEGACY_ORIGIN="https://mercurypolice.com/game/";
 private static final int MAX_STORAGE_CHARS=16*1024*1024, CHUNK_CHARS=65536;
 @UsedByGodot public void readLegacyStorage(){main.post(()->{
  if(migrating||closed)return;
  migrating=true;final int generation=++migrationGeneration;
  try {
   legacy=new WebView(getActivity());
   WebSettings settings=legacy.getSettings();settings.setJavaScriptEnabled(true);settings.setDomStorageEnabled(true);settings.setAllowFileAccess(false);settings.setAllowContentAccess(false);
   // Attach a transparent view: DOM storage must run in the original HTTPS origin.
   legacy.setAlpha(0f);
   getActivity().addContentView(legacy,new android.view.ViewGroup.LayoutParams(1,1));
   legacy.setWebViewClient(new WebViewClient(){
    private boolean reading=false;
    @Override public boolean shouldOverrideUrlLoading(WebView view,WebResourceRequest request){return !LEGACY_ORIGIN.equals(request.getUrl().toString());}
    @Override public WebResourceResponse shouldInterceptRequest(WebView view,WebResourceRequest request){
     if(request.isForMainFrame()&&LEGACY_ORIGIN.equals(request.getUrl().toString()))
      return new WebResourceResponse("text/html","UTF-8",new ByteArrayInputStream("<!doctype html><html><body></body></html>".getBytes(java.nio.charset.StandardCharsets.UTF_8)));
     return new WebResourceResponse("text/plain","UTF-8",403,"Blocked",Collections.emptyMap(),new ByteArrayInputStream(new byte[0]));
    }
    @Override public void onPageFinished(WebView view,String url){
     if(!migrating||generation!=migrationGeneration||reading||!LEGACY_ORIGIN.equals(url))return;
     reading=true;
     String script="(()=>{try{const out={};for(const key of ['meridian-watch-v1','meridian-watch-v1-backup','meridian-watch-audio-v1','meridian-watch-a11y-v1','meridian-watch-graphics-v1','meridian-watch-lighting-v1','mercury-frame-rate','mercury-world-rate','mercury-adaptive-resolution','mercury-diagnostics']){const value=localStorage.getItem(key);if(value!==null)out[key]=value;}window.__mercuryLegacy=JSON.stringify(out);return {length:window.__mercuryLegacy.length};}catch(e){return {error:String(e.name)};}})()";
     view.evaluateJavascript(script,raw->{
      if(!migrating||generation!=migrationGeneration)return;
      try {
       JSONObject info=new JSONObject(raw);int length=info.optInt("length",-1);
       if(length<0)throw new IllegalStateException("ORIGIN_STORAGE");
       if(length>MAX_STORAGE_CHARS)throw new IllegalStateException("STORAGE_TOO_LARGE");
       readLegacyChunk(view,generation,length,new StringBuilder());
      }catch(Exception e){finishMigration("{}","Не удалось открыть старое хранилище ("+e.getMessage()+"). Исходные данные не изменены.");}
     });
    }
   });
   legacy.loadUrl(LEGACY_ORIGIN);
   main.postDelayed(()->{if(migrating&&generation==migrationGeneration)finishMigration("{}","Истекло время чтения старого сохранения. Можно повторить перенос.");},60000);
  }catch(Exception e){finishMigration("{}","Не удалось запустить перенос ("+e.getClass().getSimpleName()+").");}
 });}
 private void readLegacyChunk(WebView view,int generation,int length,StringBuilder result){
  if(!migrating||generation!=migrationGeneration)return;
  int start=result.length(),end=Math.min(length,start+CHUNK_CHARS);
  view.evaluateJavascript("window.__mercuryLegacy.slice("+start+","+end+")",raw->{
   if(!migrating||generation!=migrationGeneration)return;
   try {
    Object value=new JSONArray("["+raw+"]").get(0);
    if(!(value instanceof String)||((String)value).length()!=end-start)throw new IllegalStateException("CHUNK_LENGTH");
    result.append((String)value);
    if(result.length()<length){readLegacyChunk(view,generation,length,result);return;}
    String text=result.toString();new JSONObject(text);finishMigration(text,"");
   }catch(Exception e){finishMigration("{}","Не удалось прочитать часть сохранения (CHUNK). Исходные данные не изменены.");}
  });
 }
 private void destroyLegacyView(){
  if(legacy==null)return;
  legacy.stopLoading();
  if(legacy.getParent() instanceof android.view.ViewGroup)((android.view.ViewGroup)legacy.getParent()).removeView(legacy);
  legacy.destroy();legacy=null;
 }
 private void finishMigration(String json,String error){if(!migrating)return;migrating=false;destroyLegacyView();emitSignal("legacy_storage_ready",json,error);}
 @UsedByGodot public void vibratePattern(String json){main.post(()->{try{JSONArray input=new JSONArray(json);int count=Math.min(16,input.length());long[] pattern=new long[count+1];for(int k=0;k<count;k++)pattern[k+1]=Math.max(0,Math.min(1000,input.getLong(k)));Vibrator vibrator=(Vibrator)getActivity().getSystemService(Activity.VIBRATOR_SERVICE);if(Build.VERSION.SDK_INT>=26)vibrator.vibrate(VibrationEffect.createWaveform(pattern,-1));else vibrator.vibrate(pattern,-1);}catch(Exception e){}});}
 @UsedByGodot public String deviceDiagnostics(){try{JSONObject out=new JSONObject();Debug.MemoryInfo memory=new Debug.MemoryInfo();Debug.getMemoryInfo(memory);out.put("processPssBytes",memory.getTotalPss()*1024L);out.put("model",Build.MODEL);out.put("android",Build.VERSION.RELEASE);DisplayMetrics display=getActivity().getResources().getDisplayMetrics();out.put("width",display.widthPixels);out.put("height",display.heightPixels);out.put("densityDpi",display.densityDpi);Intent battery=getActivity().registerReceiver(null,new IntentFilter(Intent.ACTION_BATTERY_CHANGED));if(battery!=null)out.put("batteryTemperatureC",battery.getIntExtra(BatteryManager.EXTRA_TEMPERATURE,0)/10.0);if(Build.VERSION.SDK_INT>=29)out.put("thermalStatus",((PowerManager)getActivity().getSystemService(Activity.POWER_SERVICE)).getCurrentThermalStatus());return out.toString();}catch(Exception e){return "{}";}}
}
