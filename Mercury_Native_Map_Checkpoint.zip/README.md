# Mercury native migration — 0.9.0-a checkpoint

Godot 4.7.2 Compatibility. Entire source city: 14431 buildings, 7282 roads, 747 streamed chunks, distant LOD. Full native QuickJS simulation uses reviewed sim.js and its source imports. All game logic remains in the original modules; no browser is used by the native scene.

36 state comparisons against Node passed, including both roles/schedules, ×1…×60 and actual 0.7/0.8 saves. Native checksummed save + backup recovery, including rewriting after corruption, passed. Linux tick P95 ~0.55ms is not phone FPS. Linux x86_64 and Android arm64 GDExtension binaries included; Android execution has not been tested.

Run project.godot. The pilot career panel supports calls/decisions/rest/save/next shift, but is not the finished UI. No complete native sound, mobile save migration, APK updater, people/services/weather/fireworks or Fold6 thermal acceptance yet. Do not replace stable APK 0.2.7 with this checkpoint.

Checks: node --test tests/geometry.test.mjs; Godot --headless --path . -- --verify-map; Godot --headless --path . --script scripts/verify_full_city.gd; Godot --headless --path . --script scripts/verify_simulation.gd. Scene smoke: --headless --quit-after 120.

Regenerate map: node export-map.mjs /absolute/game/source; repeat with --full-city. Rebuild bundle: npm exec --yes --package=esbuild@0.28.2 -- esbuild simulation/core-entry.js --bundle --format=iife --global-name=MercuryCore --target=es2020 --outfile=simulation/game-core.js. Original simulation sources are copied under simulation/source, preserving relative imports. QuickJS/Godot C++ sources and licenses are in runtime-source; see BUILD.md.

2026-10-12 update: includes reviewed Claude B/C/A source 195295b (47 files), 525 JS checks and renewed 36 native state comparisons. Native bystanders, dialogue choices, map panning and patrol follow added. Still incomplete; stable APK unchanged.

2026-10-12 Claude (branch claude/native-sync): simulation/source synced to 0.9.2-a + Claude F–J (apply-claude-092.sh, claude/release-j cd0c6f7): 59 modules, new arcs/rescue/rescue-scenes/agency/ems/ems-scenes/dispatch. game-core.js and modules.json rebuilt with the esbuild command above. make-parity-fixtures.mjs adds rescue/ambulance (career, chief), 112 desk (career, with operator commands) and a city story fixture: native QuickJS 42/42 full-state parity on Linux (Godot 4.7.2 headless, verify_simulation.gd).
