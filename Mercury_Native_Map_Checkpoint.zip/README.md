# Mercury native migration — 0.9.0-a checkpoint

Godot 4.7.2 Compatibility. Entire source city: 14431 buildings, 7282 roads, 747 streamed chunks, distant LOD. Full native QuickJS simulation uses reviewed sim.js and its source imports. All game logic remains in the original modules; no browser is used by the native scene.

36 state comparisons against Node passed, including both roles/schedules, ×1…×60 and actual 0.7/0.8 saves. Native checksummed save + backup recovery, including rewriting after corruption, passed. Linux tick P95 ~0.55ms is not phone FPS. Linux x86_64 and Android arm64 GDExtension binaries included; Android execution has not been tested.

Run project.godot. The pilot career panel supports calls/decisions/rest/save/next shift, but is not the finished UI. No complete native sound, mobile save migration, APK updater, people/services/weather/fireworks or Fold6 thermal acceptance yet. Do not replace stable APK 0.2.7 with this checkpoint.

Checks: node --test tests/geometry.test.mjs; Godot --headless --path . -- --verify-map; Godot --headless --path . --script scripts/verify_full_city.gd; Godot --headless --path . --script scripts/verify_simulation.gd. Scene smoke: --headless --quit-after 120.

Regenerate map: node export-map.mjs /absolute/game/source; repeat with --full-city. Rebuild bundle: npm exec --yes --package=esbuild@0.28.2 -- esbuild simulation/core-entry.js --bundle --format=iife --global-name=MercuryCore --target=es2020 --outfile=simulation/game-core.js. Original simulation sources are copied under simulation/source, preserving relative imports. QuickJS/Godot C++ sources and licenses are in runtime-source; see BUILD.md.
