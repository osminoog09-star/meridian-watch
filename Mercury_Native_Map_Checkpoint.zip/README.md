# Native map migration checkpoint

Godot 4.7.2 Compatibility; separate prototype, not included in stable APK 0.2.6.

307 exact building contours with walls, windows and roofs; 548 source roads clipped into 2441 segments in 64 chunks. Metres, shared buildingLayout/streetStyle and OSM attribution retained. Full 13908-node directed graph uses corrected time weights. Sedan model, road-speed movement, zoom arrow below 14px, 52px controls and touch camera included.

Validation: 3 geometry tests, 307 roofs with no triangulation failures, 12 exact-ID route reference comparisons, patrol speed and route completion. Terrain has 65 mesh instances (including ground). CPU headless construction 101ms; this is not device FPS.

Run Godot --headless --path . -- --verify-map. Regenerate assets with node export-map.mjs /absolute/game/source. No full simulation, saves, updater or Android export yet; mobile rendering and visual acceptance remain required before replacing the stable game.
