# Mercury native map — checkpoint after APK 0.2.7

Godot 4.7.2 Compatibility. Separate incomplete migration; not included in stable APK.

307 exact source footprints, 548 roads, 64 chunks. Raised curbs and sidewalk strips. Explicit no/separate tags prevent duplicate sidewalks; unknown widths/layouts marked illustrative. No invented traffic crossings.

Actual 0.9.0-a road graph 13908 nodes, corrected speed.kmh time cost and service ×4. Sedan, marker below 14px, 52px controls, speeds ×1/2/4/10/30/60. FPS/P95/static memory below the prototype clock; 600-frame ring. Godot memory measurement is not whole Android process RSS or temperature.

Checks: node --test tests/geometry.test.mjs; Godot --headless --path . -- --verify-map. 4 geometry tests, 12 routing references, all 307 roofs, movement invariant at 15/60 frames per second for all six speeds. Actual mobile GPU, both Fold6 displays and thermal acceptance remain untested.

Regenerate: node export-map.mjs /absolute/game/source. Full simulation, R1–R26, saves, game UI and audio still require migration. This project must not replace the stable APK until complete parity passes.
