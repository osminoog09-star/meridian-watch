// 0.6.2 «Бюджет и доверие с последствиями» (Claude, 11.10.2026). The city council funds the next
// shift by public trust; neglected districts cost extra. The existing maintenance subsidy still
// guarantees that a campaign can never get stuck without money.
import {DISTRICT_IDS} from './calls.js';
import {districtName} from './fiction.js';
export const GRANT_RULES=Object.freeze({neutralTrust:60,perPoint:5,min:-100,max:200,districtFloor:40,districtPenalty:25});
export function cityGrant(s){
 const r=GRANT_RULES,trust=Number.isFinite(s.trust)?s.trust:r.neutralTrust,trustPart=Math.max(r.min,Math.min(r.max,Math.round((trust-r.neutralTrust)*r.perPoint)));
 const weak=DISTRICT_IDS.filter(id=>(s.districts?.[id]??trust)<r.districtFloor),penalty=-Math.min(100,weak.length*r.districtPenalty);
 const lines=[`Доверие города ${Math.round(trust)}%: ${trustPart>=0?'+':''}${trustPart}`];if(weak.length)lines.push(`Жалобы жителей (${weak.map(id=>districtName(id)).join(', ')}): ${penalty}`);
 return {trustPart,penalty,total:trustPart+penalty,weak,lines};
}
