// R14 «Итоги службы» (Claude, 11.10.2026): the campaign keeps a short record of every shift, sums up
// each calendar month and hands out awards the way a real department does — a thank-you from the
// prefect for a month without failed calls, a city certificate for public trust, a badge for 100
// closed calls, a traffic police thank-you for drunk drivers taken off the road at checkpoints.
// Roster campaigns only. Pure rules; sim.js calls them in nextShift.
import {shiftDate} from './season.js';
import {shiftKind} from './schedule.js';
export const HISTORY_LIMIT=120;
export const MONTHS=Object.freeze(['январь','февраль','март','апрель','май','июнь','июль','август','сентябрь','октябрь','ноябрь','декабрь']);
export const monthOf=index=>{const d=shiftDate(index);return {key:d.year*12+d.month,label:`${MONTHS[d.month]} ${d.year}`};};
// One line per finished shift (the closed state `s`), kept in `s.shiftLog` (`s.history` is the call list).
export function shiftRecord(s,{tasks=0,drunk=0}={}){const d=shiftDate(s.shift-1);return {shift:s.shift,date:d.label,kind:shiftKind(s.shift-1),month:d.year*12+d.month,resolved:s.resolved,missed:s.missed,trust:Math.round(s.trust),money:Math.round(s.mode==='chief'?s.budget:(s.life?.money??0)),xp:Math.round(s.xp),tasks,drunk};}
export function monthSummary(history,key,label){const list=history.filter(r=>r.month===key);if(!list.length)return null;const resolved=list.reduce((n,r)=>n+r.resolved,0),missed=list.reduce((n,r)=>n+r.missed,0),best=list.slice().sort((a,b)=>b.resolved-a.resolved||a.missed-b.missed)[0];
 return {key,label,shifts:list.length,resolved,missed,rate:resolved+missed?Math.round(resolved/(resolved+missed)*100):100,trustFrom:list[0].trust,trustTo:list.at(-1).trust,tasks:list.reduce((n,r)=>n+r.tasks,0),drunk:list.reduce((n,r)=>n+r.drunk,0),best:{shift:best.shift,date:best.date,resolved:best.resolved}};}
// Awards: `month` ones are checked when a month closes, the rest after every shift.
export const AWARDS=Object.freeze([
 {id:'first-month',label:'Первый месяц службы',about:'Отработан первый календарный месяц по графику.',month:true,test:({summary})=>!!summary},
 {id:'clean-month',label:'Благодарность префекта',about:'Месяц без сорванных вызовов (не меньше 6 смен).',month:true,repeat:true,test:({summary})=>summary&&summary.shifts>=6&&summary.missed===0},
 {id:'trust-90',label:'Почётная грамота города',about:'Доверие жителей 90% и выше в конце месяца.',month:true,test:({s})=>s.trust>=90},
 {id:'clean-record',label:'Безупречная служба',about:'Три месяца подряд без обоснованных жалоб.',month:true,test:({stats})=>stats.cleanMonths>=3},
 {id:'calls-100',label:'Знак «100 закрытых вызовов»',about:'100 вызовов закрыто с начала службы.',test:({stats})=>stats.calls>=100},
 {id:'calls-500',label:'Знак «500 закрытых вызовов»',about:'500 вызовов закрыто с начала службы.',test:({stats})=>stats.calls>=500},
 {id:'sober-10',label:'Благодарность дорожной полиции',about:'10 пьяных водителей сняты с дороги на рейдах «Трезвый водитель».',test:({stats})=>stats.drunk>=10}
]);
const AWARD_IDS=new Set(AWARDS.map(a=>a.id));
export const AWARD_REWARD=Object.freeze({xp:50,budget:500});
export const AWARD_LIMIT=40;
export function newAwards(ctx,had=[]){const got=new Set(had.map(a=>a.id));return AWARDS.filter(a=>(ctx.summary?true:!a.month)&&(a.repeat||!got.has(a.id))&&a.test(ctx));}
export const emptyStats=()=>({calls:0,drunk:0,founded:0,monthFounded:0,cleanMonths:0});
const int=x=>Number.isInteger(x)&&x>=0&&x<1e7;
export function validHistory(s){const h=s.shiftLog,a=s.awards,st=s.stats,m=s.monthReport;
 if(h!==undefined&&!(Array.isArray(h)&&h.length<=HISTORY_LIMIT&&h.every(r=>r&&int(r.shift)&&typeof r.date==='string'&&r.date.length<=10&&['day','night'].includes(r.kind)&&int(r.month)&&int(r.resolved)&&int(r.missed)&&Number.isFinite(r.trust)&&Number.isFinite(r.money)&&Number.isFinite(r.xp)&&int(r.tasks)&&int(r.drunk))))return false;
 if(a!==undefined&&!(Array.isArray(a)&&a.length<=AWARD_LIMIT&&a.every(x=>x&&AWARD_IDS.has(x.id)&&int(x.shift)&&(x.month===undefined||typeof x.month==='string'&&x.month.length<=30))))return false;
 if(st!==undefined&&!(st&&['calls','drunk','founded','monthFounded','cleanMonths'].every(k=>int(st[k]))))return false;
 if(m!==undefined&&!(m&&int(m.shift)&&typeof m.label==='string'&&m.label.length<=30&&int(m.shifts)&&int(m.resolved)&&int(m.missed)&&int(m.rate)&&m.rate<=100&&Array.isArray(m.awards)&&m.awards.every(id=>AWARD_IDS.has(id))))return false;
 return true;}
export const awardInfo=id=>AWARDS.find(a=>a.id===id)??null;
