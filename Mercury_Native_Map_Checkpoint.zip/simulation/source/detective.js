// R25 «Криминальная полиция» (Claude, 12.10.2026). A career officer with the rank «Старший сотрудник»
// and the investigator course can move from patrol to the criminal police (role `detective`). The
// officer no longer takes patrol calls: the shift is spent on a case file — burglary series, car thefts,
// a phone-fraud organiser, an assault in the park, arson of bins. Each case is built step by step:
// talk to witnesses and canvass the district, collect camera footage, check the databases at the
// station; with enough evidence the suspect can be detained. Cases that are not solved in time go
// cold. Steps are crew tasks on the map (patrolwork.js `case-*`); results are hashes of the case id
// and step number (no rng). Case file lives in `life.cases`.
import {DISTRICT_IDS} from './calls.js';
export const CASE_KINDS=Object.freeze({
 burglary:{title:'Серия краж из квартир',about:'Днём, пока хозяева на работе, вскрывают квартиры на первых этажах.',need:70,hard:1},
 cars:{title:'Угоны машин',about:'За неделю угнаны три машины одной марки — похоже на заказ.',need:75,hard:1.1},
 fraud:{title:'Организатор телефонных мошенников',about:'Курьеров задерживали, но кто их отправляет? Нужно выйти на организатора.',need:80,hard:1.2},
 assault:{title:'Нападение в парке',about:'Вечером в парке избили и ограбили прохожего. Есть приметы и время.',need:65,hard:.9},
 arson:{title:'Поджоги мусорных контейнеров',about:'Пятый поджог за месяц в одном районе — жители боятся за машины и дома.',need:65,hard:.9}
});
export const CASE_KIND_IDS=Object.freeze(Object.keys(CASE_KINDS));
// Evidence each step adds (range), its place and time are in patrolwork.js TASKS.
export const CASE_STEPS=Object.freeze({'case-witnesses':[4,9],'case-cameras':[3,8],'case-database':[2,5]});// a case takes about three shifts
export const DETECTIVE=Object.freeze({openCases:3,limit:8,lifetime:10,coldTrust:-1,solveXp:120,solveTrust:1.5,solveDistrict:4,failedArrest:-20,diminish:.03});
const hash=(a,b)=>{let h=Math.imul((a|0)+131,2654435761)^Math.imul((b|0)+29,1597334677);h^=h>>>15;h=Math.imul(h,2246822519);return ((h^h>>>13)>>>0)/4294967296;};
export const isDetective=(s,u)=>s?.mode==='career'&&s.life?.role==='detective'&&u?.id===1;
export function openCases(life){return (life?.cases??[]).filter(c=>c.status==='open');}
// New cases at the start of a detective's shift (up to three open at once).
export function newCases(life,seed,shift){if(!Array.isArray(life.cases))life.cases=[];const made=[];let k=0;
 while(openCases(life).length<DETECTIVE.openCases&&k<6){const id=(life.nextCase=(life.nextCase??0)+1),r=hash(seed+id*7,shift);const open=openCases(life).map(c=>c.kind);let ki=Math.floor(r*CASE_KIND_IDS.length);for(let n=0;n<CASE_KIND_IDS.length&&open.includes(CASE_KIND_IDS[ki]);n++)ki=(ki+1)%CASE_KIND_IDS.length;const kind=CASE_KIND_IDS[ki],district=DISTRICT_IDS[Math.floor(hash(id,seed)*DISTRICT_IDS.length)];
  const c={id,kind,district,opened:shift,deadline:shift+DETECTIVE.lifetime,evidence:0,steps:0,status:'open'};life.cases.push(c);made.push(c);k++;}
 if(life.cases.length>DETECTIVE.limit)life.cases.splice(0,life.cases.length-DETECTIVE.limit);return made;}
// Evidence from a step; repeating the same kind of work brings less.
export function stepEvidence(c,step){const [lo,hi]=CASE_STEPS[step]??[0,0],base=lo+hash(c.id*31+c.steps,step.length)*(hi-lo);return Math.round(base*Math.max(.4,1-c.steps*DETECTIVE.diminish/CASE_KINDS[c.kind].hard));}
export const arrestReady=c=>c.status==='open'&&c.evidence>=CASE_KINDS[c.kind].need;
// The detention succeeds with a probability equal to the evidence share above the need.
export const arrestSucceeds=c=>hash(c.id,c.steps+77)<Math.min(.95,.55+(c.evidence-CASE_KINDS[c.kind].need)/60);
// Next step an autonomous detective takes: detain when ready, otherwise the cheapest evidence first.
export function autoCaseStep(life){const list=openCases(life).sort((a,b)=>b.evidence-a.evidence||a.deadline-b.deadline);const c=list[0];if(!c)return null;
 if(arrestReady(c))return {caseId:c.id,step:'case-arrest'};const order=['case-witnesses','case-cameras','case-database'];return {caseId:c.id,step:order[c.steps%order.length]};}
export function validCases(life){const c=life?.cases;return c===undefined||Array.isArray(c)&&c.length<=DETECTIVE.limit&&c.every(x=>x&&Number.isInteger(x.id)&&Object.hasOwn(CASE_KINDS,x.kind)&&DISTRICT_IDS.includes(x.district)&&Number.isInteger(x.opened)&&Number.isInteger(x.deadline)&&Number.isFinite(x.evidence)&&x.evidence>=0&&x.evidence<=100&&Number.isInteger(x.steps)&&x.steps>=0&&['open','solved','cold'].includes(x.status));}
