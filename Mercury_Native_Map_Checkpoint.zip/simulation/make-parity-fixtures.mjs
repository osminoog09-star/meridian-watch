import fs from 'node:fs';
import {dispatch} from './core-entry.js';
const oldFixtures=JSON.parse(fs.readFileSync(new URL('./parity-fixtures.json',import.meta.url))).filter(f=>f.version);
const fixtures=[];
for(const mode of ['career','chief'])for(const scheduled of [false,true])for(const seed of [7182,123,9001]){
 const requests=[{op:'create',mode,seed,options:scheduled?{schedule:'ppa'}:{}}];dispatch(requests[0]);
 if(mode==='chief'){
  let s=JSON.parse(dispatch({op:'state'}));let hire={op:'command',name:'hireOfficer',args:[s.candidates[0].id]};dispatch(hire);requests.push(hire);s=JSON.parse(dispatch({op:'state'}));let patrol={op:'command',name:'createPatrol',args:[s.officers[0].id,null,s.vehicles[0].id]};dispatch(patrol);requests.push(patrol);
 }
 const initial=dispatch({op:'save'});requests.push({op:'load',save:initial});dispatch(requests.at(-1));
 for(let i=0;i<300;i++){const q={op:'tick',dt:[.1,.25,.5][i%3]};dispatch(q);requests.push(q);}
 fixtures.push({mode,scheduled,seed,requests,expected:JSON.parse(dispatch({op:'save'}))});
}
for(const mode of ['career','chief'])for(const speed of [1,2,4,10,30,60]){
 const requests=[{op:'create',mode,seed:7182,options:{schedule:'ppa'}}];dispatch(requests[0]);
 if(mode==='chief'){
  let s=JSON.parse(dispatch({op:'state'}));let hire={op:'command',name:'hireOfficer',args:[s.candidates[0].id]};dispatch(hire);requests.push(hire);s=JSON.parse(dispatch({op:'state'}));let patrol={op:'command',name:'createPatrol',args:[s.officers[0].id,null,s.vehicles[0].id]};dispatch(patrol);requests.push(patrol);
 }
 for(let i=0;i<300;i++){const q={op:'tick',dt:.1};dispatch(q);requests.push(q);}
 for(let i=0;i<180;i++){const q={op:'frame',seconds:1/60,speed};dispatch(q);requests.push(q);}
 fixtures.push({mode,scheduled:true,seed:7182,speed,requests,expected:JSON.parse(dispatch({op:'save'}))});
}
// Claude F–J (12.10.2026): the separate services — rescue and ambulance (career and chief) and the 112 desk
// (career, with the operator's own decisions), plus a city story after the first week (Release F).
for(const service of ['rescue','ems','dispatch'])for(const mode of service==='dispatch'?['career']:['career','chief']){
 const requests=[{op:'create',mode,seed:4242,options:{schedule:'ppa',service}}];dispatch(requests[0]);const run=q=>{dispatch(q);requests.push(q);};
 if(mode==='chief'){let s=JSON.parse(dispatch({op:'state'}));for(const c of s.candidates.slice(0,4))run({op:'command',name:'hireOfficer',args:[c.id]});s=JSON.parse(dispatch({op:'state'}));run({op:'command',name:'createPatrol',args:[s.officers[0].id,s.officers[1].id,s.vehicles[0].id]});run({op:'command',name:'createPatrol',args:[s.officers[2].id,s.officers[3].id,s.vehicles[1].id]});}
 const initial=dispatch({op:'save'});run({op:'load',save:initial});
 for(let i=0;i<600;i++){run({op:'tick',dt:[.1,.25,.5][i%3]});
  if(service==='dispatch'&&i%20===0){const s=JSON.parse(dispatch({op:'state'}));if(s.desk.player==null){const r=s.incidents.find(x=>x.call?.status==='ringing');if(r){run({op:'command',name:'takeCall',args:[r.id]});run({op:'command',name:'askCaller',args:[r.id,i%40?'injured':'breath']});run({op:'command',name:'instructCaller',args:[r.id,['cpr','side','leave','away','still','gas'][i%6]]});run({op:'command',name:'pickRoute',args:[r.id,['police','rescue','ems'][(i/20)%3|0],'ABCD'[(i/20)%4|0]]});run({op:'command',name:'sendCall',args:[r.id]});}}}
  if(service!=='dispatch'&&mode==='career'&&i%50===0){const s=JSON.parse(dispatch({op:'state'}));const u=s.units.find(x=>x.id===1),inc=s.incidents.find(x=>x.id===u?.incident);if(inc?.talk)run({op:'command',name:'chooseTalk',args:[1,'treat']});}}
 run({op:'nextShift',options:{}});for(let i=0;i<120;i++)run({op:'tick',dt:.5});
 fixtures.push({mode,scheduled:true,seed:4242,service,requests,expected:JSON.parse(dispatch({op:'save'}))});
}
{const requests=[{op:'create',mode:'chief',seed:7182,options:{schedule:'ppa'}}];dispatch(requests[0]);const run=q=>{dispatch(q);requests.push(q);};let s=JSON.parse(dispatch({op:'state'}));for(const c of s.candidates.slice(0,2))run({op:'command',name:'hireOfficer',args:[c.id]});s=JSON.parse(dispatch({op:'state'}));run({op:'command',name:'createPatrol',args:[s.officers[0].id,s.officers[1].id,s.vehicles[0].id]});
 for(let k=0;k<9;k++){for(let i=0;i<40;i++)run({op:'tick',dt:.5});run({op:'nextShift',options:{}});}for(let i=0;i<300;i++)run({op:'tick',dt:.5});
 fixtures.push({mode:'chief',scheduled:true,seed:7182,story:true,requests,expected:JSON.parse(dispatch({op:'save'}))});}
for(const old of oldFixtures){for(const request of old.requests)dispatch(request);fixtures.push({...old,expected:JSON.parse(dispatch({op:'save'}))});}
fs.writeFileSync(new URL('./parity-fixtures.json',import.meta.url),JSON.stringify(fixtures));console.log(fixtures.length);
