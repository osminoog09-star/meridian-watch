import fs from 'node:fs';
import {dispatch} from './core-entry.js';
import * as old070 from '../../release027/legacy070real/dist/sim.js';
import * as old080 from '../../release027/legacy080/dist/sim.js';
const fixtures=[];
for(const mode of ['career','chief'])for(const scheduled of [false,true])for(const seed of [7182,123,9001]){
 const requests=[{op:'create',mode,seed,options:scheduled?{schedule:'ppa'}:{}}];dispatch(requests[0]);
 if(mode==='chief'){
  let s=JSON.parse(dispatch({op:'state'}));let hire={op:'command',name:'hireOfficer',args:[s.candidates[0].id]};dispatch(hire);requests.push(hire);s=JSON.parse(dispatch({op:'state'}));let patrol={op:'command',name:'createPatrol',args:[s.officers[0].id,null,s.vehicles[0].id]};dispatch(patrol);requests.push(patrol);
 }
 const initial=dispatch({op:'save'});requests.push({op:'load',save:initial});dispatch(requests.at(-1));
 for(let i=0;i<300;i++){const q={op:'tick',dt:[.1,.25,.5][i%3]};dispatch(q);requests.push(q);}
 fixtures.push({mode,scheduled,seed,requests,expected:JSON.parse(dispatch({op:'save'}))});
}
for(const mode of ['career','chief'])for(const speed of [1,2,4,10,30,60]){
 const requests=[{op:'create',mode,seed:7182,options:{schedule:'ppa'}}];dispatch(requests[0]);
 if(mode==='chief'){
  let s=JSON.parse(dispatch({op:'state'}));let hire={op:'command',name:'hireOfficer',args:[s.candidates[0].id]};dispatch(hire);requests.push(hire);s=JSON.parse(dispatch({op:'state'}));let patrol={op:'command',name:'createPatrol',args:[s.officers[0].id,null,s.vehicles[0].id]};dispatch(patrol);requests.push(patrol);
 }
 for(let i=0;i<300;i++){const q={op:'tick',dt:.1};dispatch(q);requests.push(q);}
 for(let i=0;i<180;i++){const q={op:'frame',seconds:1/60,speed};dispatch(q);requests.push(q);}
 fixtures.push({mode,scheduled:true,seed:7182,speed,requests,expected:JSON.parse(dispatch({op:'save'}))});
}
for(const [version,old] of [['0.7.0-a',old070],['0.8.0-a1',old080]])for(const mode of ['career','chief'])for(const seed of [7182,123,9001]){
 const oldState=old.createGame(mode,seed,version==='0.8.0-a1'?{schedule:'ppa'}:{});
 if(mode==='chief'){old.hireOfficer(oldState,oldState.candidates[0].id);old.createPatrol(oldState,oldState.officers[0].id,null,oldState.vehicles[0].id);}
 for(let i=0;i<200;i++)old.tick(oldState,.1);
 const requests=[{op:'load',save:old.serialize(oldState)}];dispatch(requests[0]);
 for(let i=0;i<100;i++){const q={op:'tick',dt:.1};dispatch(q);requests.push(q);}
 fixtures.push({mode,seed,version,requests,expected:JSON.parse(dispatch({op:'save'}))});
}
fs.writeFileSync(new URL('./parity-fixtures.json',import.meta.url),JSON.stringify(fixtures));console.log(fixtures.length);
