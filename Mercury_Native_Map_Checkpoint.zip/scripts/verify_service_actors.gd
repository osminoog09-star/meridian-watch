extends SceneTree
# Claude (12.10.2026): service vehicles on the native map — model by vehicle type, livery by paint.
func _initialize() -> void:
 var actors = load("res://scripts/live_actors.gd").new()
 root.add_child(actors)
 actors._ready()
 var types := ["sedan","suv","engine","ladder","tanker","ambulance","resus","rapid"]
 var paints := ["white","navy","red","red","red","ems","ems","ems"]
 var units: Array = []
 var vehicles: Array = []
 for index in range(types.size()):
  units.append({"id":index+2,"x":1.55+index*0.0005,"y":2.52,"vehicleId":index+1,"heading":0.3})
  vehicles.append({"id":index+1,"type":types[index],"paint":paints[index]})
 actors.refresh({"units":units,"vehicles":vehicles,"services":[],"residents":[]},-1,Vector3.ZERO,500.0)
 var visible := 0
 var expected := ["sedan|","suv|navy","engine|red","ladder|red","tanker|red","ambulance|ems","resus|ems","suv|ems"]
 for index in range(types.size()):
  var car: MeshInstance3D = actors.cars[index]
  if not car.visible or car.mesh==null or car.mesh.get_surface_count()<1:
   push_error("car %d not drawn" % index)
   quit(1)
   return
  if car.mesh!=actors.shared[expected[index]]:
   push_error("car %d wrong model %s" % [index,types[index]])
   quit(2)
   return
  visible += 1
 var lit: Array = []
 for unit in units:
  var copy: Dictionary = unit.duplicate()
  copy["lights"] = int(unit.id)%2==0
  lit.append(copy)
 actors.refresh({"units":lit,"vehicles":vehicles},-1,Vector3.ZERO,500.0)
 var beacons := 0
 for light in actors.beacons:
  if light.visible:
   beacons += 1
 if beacons!=4:
  push_error("beacons %d" % beacons)
  quit(4)
  return
 var first: Color = actors.beacons[0].light_color
 for step in range(3):
  actors._process(0.1)
 if actors.beacon_modes[0]=="redblue" and actors.beacons[0].light_color==first:
  push_error("police beacons must alternate")
  quit(5)
  return
 actors.refresh({"units":units},-1,Vector3.ZERO,500.0)
 if actors.cars[2].mesh!=actors.shared["sedan|"]:
  push_error("view without vehicles must fall back to the sedan")
  quit(3)
  return
 print(JSON.stringify({"service_vehicle_models":visible,"shared_meshes":actors.shared.size(),"flashing_beacons":beacons}))
 quit(0)
