extends SceneTree
var scene: Node
func _initialize() -> void:
 call_deferred("verify")
func require(condition: bool,message: String) -> bool:
 if not condition:
  push_error(message)
  quit(1)
 return condition
func verify() -> void:
 scene = load("res://main.tscn").instantiate()
 root.add_child(scene)
 await process_frame
 if not require(scene.campaign_ready,"Campaign initialization failed"):
  return
 var ui = scene.native_ui
 var campaign = scene.campaign
 campaign._legacy_storage_ready("{}","Test WebView unavailable")
 ui.signature = ""
 ui.refresh()
 if not require(ui.scroll.get_theme_stylebox("panel") is StyleBoxFlat,"Recovery must have opaque panel"):
  return
 var recover: Button
 for child in ui.root.get_children():
  if child is Button and child.text.begins_with("Начать без переноса"):
   recover = child
 if not require(recover!=null,"Recovery action missing"):
  return
 recover.pressed.emit()
 if not require(campaign.migration_error.is_empty() and not campaign.migration_pending,"Recovery still blocks simulation"):
  return
 campaign.action({"op":"event","domId":"startCareer","event":"click"})
 campaign.action({"op":"event","domId":"closeModal","event":"click"})
 ui.signature = ""
 ui.refresh()
 if not require(ui.get_child_count()>1,"Game HUD missing after recovery"):
  return
 campaign.action({"op":"event","domId":"settingsBtn","event":"click"})
 ui.signature = ""
 ui.refresh()
 if not require(ui.get_child_count()==1,"Map controls overlap settings modal"):
  return
 campaign.action({"op":"event","domId":"closeModal","event":"click"})
 ui.signature = ""
 ui.refresh()
 if not require(ui.get_child_count()>1,"HUD not restored after modal"):
  return
 for zoom in [35,90,650,14000,16000]:
  scene.distance = zoom
  scene.update_camera()
  if not require(scene.camera.far/scene.camera.near<5000,"Camera depth precision regression"):
   return
 print("Startup recovery: rendered button opens career; settings isolate/restore HUD; camera zoom precision passed")
 quit(0)
