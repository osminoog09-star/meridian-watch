extends Node3D
# Claude (12.10.2026): fire and smoke over burning calls, bounded like weather_effects.gd. The size of the
# flames follows the rescue fire model (i.fire.size 0–100); a police «дым из окна» call smokes until the
# rescuers are done. Visual clock only — never touches the simulation.
const MAX_FIRES := 8
const FLAMES_PER_FIRE := 6
const PUFFS_PER_FIRE := 12
var flames := MultiMeshInstance3D.new()
var smoke := MultiMeshInstance3D.new()
var flame_mesh := MultiMesh.new()
var smoke_mesh := MultiMesh.new()
var fires: Array = []
var clock := 0.0
var enabled := true
func _make(target: MultiMeshInstance3D,multi: MultiMesh,count: int,colour: Color) -> void:
 multi.transform_format = MultiMesh.TRANSFORM_3D
 multi.instance_count = count
 multi.visible_instance_count = 0
 var mesh := BoxMesh.new()
 mesh.size = Vector3.ONE
 multi.mesh = mesh
 var material := StandardMaterial3D.new()
 material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
 material.albedo_color = colour
 target.multimesh = multi
 target.material_override = material
 target.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
 add_child(target)
func _ready() -> void:
 _make(flames,flame_mesh,MAX_FIRES*FLAMES_PER_FIRE,Color("ff8a2a"))
 _make(smoke,smoke_mesh,MAX_FIRES*PUFFS_PER_FIRE,Color("5b6168"))
func world(p: Dictionary) -> Vector3:
 return Vector3((float(p.get("x",1.55))-1.55)*1670,0.04,(float(p.get("y",2.52))-2.52)*1670)
func configure(incidents: Array,centre: Vector3,camera_distance: float,effects_enabled: bool = true) -> void:
 enabled = effects_enabled
 fires.clear()
 var radius := maxf(150,camera_distance*1.8)
 for incident in incidents:
  if fires.size()>=MAX_FIRES or not enabled:
   break
  if str(incident.get("state","")) in ["resolved","missed"]:
   continue
  var size := 0.0
  if typeof(incident.get("fire"))==TYPE_DICTIONARY:
   size = clampf(float(incident.fire.get("size",0)),0,100)
  elif incident.get("smoke",false):
   size = 35.0
  if size<=0:
   continue
  var position := world(incident)
  if position.distance_to(centre)>radius:
   continue
  fires.append({"position":position,"size":size,"seed":float(int(incident.get("id",0))%97)})
 flame_mesh.visible_instance_count = fires.size()*FLAMES_PER_FIRE
 smoke_mesh.visible_instance_count = fires.size()*PUFFS_PER_FIRE
 animate(0.0)
func animate(delta: float) -> void:
 if fires.is_empty():
  return
 clock += clampf(delta,0,0.1)
 for f in range(fires.size()):
  var fire: Dictionary = fires[f]
  var scale: float = 0.4+float(fire.size)/100.0*1.6
  var base: Vector3 = fire.position
  for k in range(FLAMES_PER_FIRE):
   var phase := fmod(clock*1.7+float(k)*0.37+float(fire.seed)*0.11,1.0)
   var offset := Vector3(sin(float(k)*2.1+float(fire.seed))*1.4*scale,1.5+phase*3.0*scale,cos(float(k)*1.7)*1.4*scale)
   var size := Vector3.ONE*(1.4-phase)*1.3*scale
   flame_mesh.set_instance_transform(f*FLAMES_PER_FIRE+k,Transform3D(Basis(Vector3.UP,clock*2+float(k)).scaled(size),base+offset))
  for k in range(PUFFS_PER_FIRE):
   var phase := fmod(clock*0.18+float(k)/PUFFS_PER_FIRE+float(fire.seed)*0.03,1.0)
   var drift := Vector3(sin(float(k)*1.3)*2.0+phase*9.0,6.0+phase*34.0*scale,cos(float(k)*0.9)*2.0+phase*4.0)
   var size := Vector3.ONE*(1.2+phase*5.5)*scale
   smoke_mesh.set_instance_transform(f*PUFFS_PER_FIRE+k,Transform3D(Basis(Vector3.UP,float(k)).scaled(size),base+drift))
func diagnostics() -> Dictionary:
 return {"fires":fires.size(),"flames":flame_mesh.visible_instance_count,"puffs":smoke_mesh.visible_instance_count,"capacity":MAX_FIRES,"enabled":enabled}
