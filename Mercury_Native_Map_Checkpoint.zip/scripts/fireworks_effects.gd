extends Node3D
# Claude (12.10.2026): New Year fireworks over the city (the same window as the sound in audio-design.js:
# 31 December 23:45 – 1 January 01:30). Bounded MultiMesh like weather_effects.gd; visual clock only.
const BURSTS := 6
const SPARKS := 24
const COLOURS := [Color("ff5a4f"),Color("ffd166"),Color("7bdff2"),Color("b388ff"),Color("80ed99"),Color("ffffff")]
var sparks := MultiMeshInstance3D.new()
var instances := MultiMesh.new()
var active := false
var enabled := true
var clock := 0.0
var extent := 300.0
func _ready() -> void:
 instances.transform_format = MultiMesh.TRANSFORM_3D
 instances.use_colors = true
 instances.instance_count = BURSTS*SPARKS
 instances.visible_instance_count = 0
 var mesh := BoxMesh.new()
 mesh.size = Vector3.ONE
 instances.mesh = mesh
 var material := StandardMaterial3D.new()
 material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
 material.vertex_color_use_as_albedo = true
 sparks.multimesh = instances
 sparks.material_override = material
 sparks.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
 add_child(sparks)
func configure(on: bool,centre: Vector3,camera_distance: float,effects_enabled: bool = true) -> void:
 enabled = effects_enabled
 active = on and enabled
 extent = clampf(camera_distance*0.7,120,700)
 position = Vector3(centre.x,0,centre.z)
 instances.visible_instance_count = BURSTS*SPARKS if active else 0
 animate(0.0)
func animate(delta: float) -> void:
 if not active:
  return
 clock += clampf(delta,0,0.1)
 for b in range(BURSTS):
  var cycle := 2.6+float(b)*0.37
  var rnd := floorf((clock+float(b)*0.9)/cycle)
  var t := fmod(clock+float(b)*0.9,cycle)/cycle
  var seed := fmod(rnd*0.618+float(b)*0.271,1.0)
  var origin := Vector3((seed*2-1)*extent*0.6,70+seed*40,(fmod(seed*7.3,1.0)*2-1)*extent*0.6)
  var colour: Color = COLOURS[int(seed*997+rnd)%COLOURS.size()]
  for k in range(SPARKS):
   var a := float(k)/SPARKS*TAU
   var up := sin(float(k)*1.7)*0.6
   var direction := Vector3(cos(a)*cos(up),sin(up),sin(a)*cos(up))
   var spread := 0.0 if t<0.25 else (t-0.25)/0.75
   var p: Vector3 = origin+Vector3(0,(t/0.25-1)*40,0) if t<0.25 else origin+direction*spread*28-Vector3(0,spread*spread*14,0)
   var size: float = 1.2 if t<0.25 else maxf(0.05,1.6*(1-spread))
   var index := b*SPARKS+k
   instances.set_instance_transform(index,Transform3D(Basis().scaled(Vector3.ONE*size),p))
   instances.set_instance_color(index,colour if t>=0.25 else Color("fff3c4"))
func diagnostics() -> Dictionary:
 return {"active":active,"sparks":instances.visible_instance_count,"capacity":BURSTS*SPARKS,"enabled":enabled}
