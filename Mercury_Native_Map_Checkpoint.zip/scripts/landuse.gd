extends MeshInstance3D
var failed_polygons := 0
func _ready() -> void:
 var areas = JSON.parse_string(FileAccess.get_file_as_string("res://assets/landuse.json"))
 var tool := SurfaceTool.new()
 tool.begin(Mesh.PRIMITIVE_TRIANGLES)
 var palette := {"water":"#497c99","beach":"#bfba8c","park":"#658957","grass":"#7d9461","forest":"#416a49","wood":"#416a49","scrub":"#6f8252","garden":"#768f62","pitch":"#6f995c","cemetery":"#658060","residential":"#929387","industrial":"#8a8b82"}
 for area in areas:
  var polygon := PackedVector2Array()
  for p in area.p:
   polygon.append(Vector2(p[0],p[1]))
  var triangles := Geometry2D.triangulate_polygon(polygon)
  if triangles.is_empty():
   failed_polygons += 1
   continue
  var color := Color(palette.get(area.kind,"#788763"))
  for index in range(0,triangles.size(),3):
   tool.set_normal(Vector3.UP)
   tool.set_color(color)
   for offset in [0,2,1]:
    var p := polygon[triangles[index+offset]]
    tool.add_vertex(Vector3(p.x,-0.02 if area.kind=="water" else -0.01,p.y))
 tool.index()
 mesh = tool.commit()
 var material := StandardMaterial3D.new()
 material.vertex_color_use_as_albedo = true
 material.roughness = 0.9
 material.cull_mode = BaseMaterial3D.CULL_DISABLED
 material_override = material
