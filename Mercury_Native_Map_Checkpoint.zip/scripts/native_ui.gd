extends Control
var controller: RefCounted
var frame_report: Dictionary = {}
var signature := ""
var root := VBoxContainer.new()
var scroll := ScrollContainer.new()
var file_dialog: FileDialog
var pending_file: Dictionary = {}
func _ready() -> void:
 set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
 mouse_filter = Control.MOUSE_FILTER_IGNORE
 scroll.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
 scroll.offset_left = 8
 scroll.offset_right = -8
 scroll.offset_top = 8
 scroll.offset_bottom = -8
 root.size_flags_horizontal = Control.SIZE_EXPAND_FILL
 scroll.add_child(root)
 add_child(scroll)
func event(node: Dictionary,kind: String,value: Variant = null,checked: Variant = null) -> void:
 var request := {"op":"event","id":node.get("id"),"domId":node.get("domId"),"event":kind}
 if value!=null:
  request.value = value
 if checked!=null:
  request.checked = checked
 controller.action(request)
 signature = ""
 refresh()
func text_of(node: Dictionary) -> String:
 if node.get("tag")=="#text":
  return str(node.get("text",""))
 var output := str(node.get("text",""))
 if output.is_empty():
  for child in node.get("children",[]):
   output += text_of(child)+" "
 return output.strip_edges()
func label(text: String,large: bool = false) -> Label:
 var item := Label.new()
 item.text = text
 item.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
 item.size_flags_horizontal = Control.SIZE_EXPAND_FILL
 var classes: String = controller.snapshot.get("bodyClasses","")
 var scale: float = 1.3 if classes.contains("a11y-text-huge") else (1.15 if classes.contains("a11y-text-large") else 1.0)
 item.add_theme_font_size_override("font_size",int((22 if large else 16)*scale))
 return item
func widget(node: Dictionary) -> Control:
 var tag: String = node.get("tag","")
 if tag=="#text":
  return label(str(node.text))
 if tag in ["button","a"]:
  var button := Button.new()
  button.text = text_of(node)
  button.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
  button.custom_minimum_size = Vector2(52,52)
  button.size_flags_horizontal = Control.SIZE_EXPAND_FILL
  button.disabled = node.get("disabled",false)
  button.pressed.connect(func(): event(node,"click"))
  return button
 if tag=="input" and node.get("type") in ["checkbox","radio"]:
  var toggle := CheckButton.new()
  toggle.button_pressed = node.get("checked",false)
  toggle.custom_minimum_size = Vector2(52,52)
  toggle.toggled.connect(func(on): event(node,"change",null,on))
  return toggle
 if tag=="input" and node.get("type")=="range":
  var slider := HSlider.new()
  slider.custom_minimum_size = Vector2(120,52)
  slider.min_value = float(node.get("min",0))
  slider.max_value = float(node.get("max",100))
  slider.step = maxf(0.01,float(node.get("step",1)))
  slider.value = float(node.get("value",0))
  slider.value_changed.connect(func(value): event(node,"input",value))
  return slider
 if tag=="select":
  var options := OptionButton.new()
  options.custom_minimum_size = Vector2(120,52)
  for child in node.get("children",[]):
   if child.get("tag")=="option":
    options.add_item(text_of(child))
    options.set_item_metadata(options.item_count-1,child.get("value",""))
    if str(child.get("value"))==str(node.get("value")):
     options.select(options.item_count-1)
  options.item_selected.connect(func(index): event(node,"change",options.get_item_metadata(index)))
  return options
 if tag=="input" and node.get("type")=="file":
  var button := Button.new()
  button.text = "Открыть файл сохранения"
  button.custom_minimum_size = Vector2(52,52)
  button.pressed.connect(func(): choose_file(node,false))
  return button
 if tag in ["input","textarea"]:
  var input := LineEdit.new()
  input.text = str(node.get("value",""))
  input.custom_minimum_size = Vector2(120,52)
  input.text_changed.connect(func(value): event(node,"input",value))
  input.text_submitted.connect(func(value): event(node,"change",value))
  return input
 if tag=="svg":
  var image := Image.new()
  if image.load_svg_from_string(node.get("markup",""))==OK:
   var texture := TextureRect.new()
   texture.texture = ImageTexture.create_from_image(image)
   texture.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
   texture.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
   texture.custom_minimum_size = Vector2(250,170)
   return texture
  return label("График не загрузился")
 if tag in ["h1","h2","h3","h4","p","small","span","strong","b","li"]:
  if not has_control(node):
   return label(text_of(node),tag.begins_with("h"))
 var box := VBoxContainer.new()
 box.size_flags_horizontal = Control.SIZE_EXPAND_FILL
 box.add_theme_constant_override("separation",6)
 for child in node.get("children",[]):
  var item = widget(child)
  if item!=null:
   box.add_child(item)
 return box
func has_control(node: Dictionary) -> bool:
 for child in node.get("children",[]):
  if child.get("tag") in ["input","select","button","textarea","svg"] or has_control(child):
   return true
 return false
func choose_file(node: Dictionary,saving: bool) -> void:
 if file_dialog!=null:
  file_dialog.queue_free()
 pending_file = node
 file_dialog = FileDialog.new()
 file_dialog.access = FileDialog.ACCESS_FILESYSTEM
 file_dialog.file_mode = FileDialog.FILE_MODE_SAVE_FILE if saving else FileDialog.FILE_MODE_OPEN_FILE
 file_dialog.use_native_dialog = true
 file_dialog.filters = PackedStringArray(["*.json ; Сохранение Mercury"])
 file_dialog.file_selected.connect(func(path):
  if saving:
   var file := FileAccess.open(path,FileAccess.WRITE)
   if file!=null:
    file.store_string(str(controller.snapshot.get("download",{}).get("parts",[]).reduce(func(a,b): return a+str(b),"")))
    controller.action({"op":"consume-download"})
  else:
   var text := FileAccess.get_file_as_string(path)
   if text.length()<=1048576:
    controller.action({"op":"file","domId":pending_file.domId,"text":text})
  signature = "")
 add_child(file_dialog)
 file_dialog.popup_centered_ratio(0.8)
func refresh() -> void:
 if controller==null or not is_inside_tree():
  return
 var focus := get_viewport().gui_get_focus_owner()
 if focus is LineEdit or focus is TextEdit:
  return
 var tree: Array = controller.snapshot.get("tree",[])
 var next := JSON.stringify(tree)
 if next==signature:
  return
 signature = next
 var top := scroll.scroll_vertical
 for child in root.get_children():
  root.remove_child(child)
  child.queue_free()
 var modal: bool = tree.size()>0 and tree[0].get("tag")=="dialog"
 if modal:
  scroll.show()
  scroll.offset_top = 8
  scroll.offset_bottom = -8
  for node in tree:
   root.add_child(widget(node))
 else:
  for child in get_children():
   if child!=scroll and child!=file_dialog:
    remove_child(child)
    child.queue_free()
  var view: Dictionary = controller.view()
  var minute := int(view.get("absoluteMinute",0))%1440
  var top_box := VBoxContainer.new()
  top_box.position = Vector2(8,8)
  top_box.size = Vector2(maxf(300,size.x-16),128)
  top_box.add_child(label("Смена %d · %02d:%02d · доверие %s" % [view.get("shift",1),minute/60,minute%60,str(view.get("trust",""))],true))
  top_box.add_child(label("%.1f FPS · P95 %.1f мс" % [frame_report.get("fps",0),frame_report.get("p95_ms",0)]))
  var menu_row := HBoxContainer.new()
  for id in ["mobileMenu","reportBtn","settingsBtn"]:
   var item := find_node(tree,id)
   if not item.is_empty():
    menu_row.add_child(widget(item))
  top_box.add_child(menu_row)
  add_child(top_box)
  var bottom := VBoxContainer.new()
  bottom.position = Vector2(8,maxf(200,size.y-120))
  bottom.size = Vector2(maxf(300,size.x-16),112)
  var speed_row := HBoxContainer.new()
  speed_row.add_theme_constant_override("separation",2)
  var pause := find_node(tree,"pauseBtn")
  if not pause.is_empty():
   speed_row.add_child(widget(pause))
  for node in collect_speed_nodes(tree):
   speed_row.add_child(widget(node))
  bottom.add_child(speed_row)
  var nav_node := find_class(tree,"mobile-nav")
  var nav_row := HBoxContainer.new()
  for node in nav_node.get("children",[]):
   var button = widget(node)
   if button is Button:
    button.add_theme_font_size_override("font_size",12)
    nav_row.add_child(button)
  bottom.add_child(nav_row)
  add_child(bottom)
  var tab: String = controller.snapshot.get("status",{}).get("tab","map")
  scroll.visible = tab in ["units","calls"]
  scroll.offset_top = 140
  scroll.offset_bottom = -132
  if tab=="units":
   root.add_child(widget(find_node(tree,"units")))
  elif tab=="calls":
   root.add_child(widget(find_node(tree,"calls")))
   root.add_child(widget(find_node(tree,"callDetail")))
  else:
   var map_buttons := VBoxContainer.new()
   map_buttons.position = Vector2(maxf(8,size.x-88),140)
   map_buttons.size = Vector2(80,400)
   var controls := find_class(tree,"map-controls")
   for node in controls.get("children",[]):
    var item = widget(node)
    if item is Button:
     item.add_theme_font_size_override("font_size",13)
     map_buttons.add_child(item)
   add_child(map_buttons)
 scroll.set_deferred("scroll_vertical",top)
 if controller.snapshot.get("download")!=null and file_dialog==null:
  choose_file({},true)
func find_node(nodes: Array,id: String) -> Dictionary:
 for node in nodes:
  if node.get("domId")==id:
   return node
  var found := find_node(node.get("children",[]),id)
  if not found.is_empty():
   return found
 return {}
func find_class(nodes: Array,name: String) -> Dictionary:
 for node in nodes:
  if str(node.get("classes","")).split(" ").has(name):
   return node
  var found := find_class(node.get("children",[]),name)
  if not found.is_empty():
   return found
 return {}
func collect_speed_nodes(nodes: Array) -> Array:
 var output: Array = []
 for node in nodes:
  if node.get("tag")=="button" and str(node.get("text","")).ends_with("×"):
   output.append(node)
  output.append_array(collect_speed_nodes(node.get("children",[])))
 return output
