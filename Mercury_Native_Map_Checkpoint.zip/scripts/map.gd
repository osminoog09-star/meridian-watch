extends Node3D
const Geometry = preload("res://scripts/city_geometry.gd")
const Patrol = preload("res://scripts/patrol.gd")
const Marker = preload("res://scripts/patrol_marker.gd")
const Metrics = preload("res://scripts/frame_metrics.gd")
const GAME_SPEEDS = [1,2,4,10,30,60]
var metrics = Metrics.new()
var clock_label: Label
var fps_label: Label
var elapsed := 0.0
var reporting := 0.0
var patrol: Node3D
const RoadGraph = preload("res://scripts/road_graph.gd")
var camera: Camera3D
var yaw := 0.0
var distance := 650.0
var focus := Vector3.ZERO
var touches: Dictionary = {}
var geometry = Geometry.new()
var tile_count := 0
var stats: Dictionary = {}
func _ready() -> void:
 var began := Time.get_ticks_msec()
 var data = JSON.parse_string(FileAccess.get_file_as_string("res://assets/map.json"))
 var ground := MeshInstance3D.new()
 var plane := PlaneMesh.new()
 plane.size = Vector2(1200,1200)
 ground.mesh = plane
 var ground_mat := StandardMaterial3D.new()
 ground_mat.albedo_color = Color("68785e")
 ground.material_override = ground_mat
 ground.position.y = -0.05
 add_child(ground)
 var mat := StandardMaterial3D.new()
 mat.vertex_color_use_as_albedo = true
 mat.roughness = 0.9
 for tile in data.chunks:
  add_child(geometry.chunk(tile,mat))
  tile_count += 1
 var environment := WorldEnvironment.new()
 environment.environment = Environment.new()
 environment.environment.background_mode = Environment.BG_COLOR
 environment.environment.background_color = Color("a2bcc9")
 environment.environment.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
 environment.environment.ambient_light_color = Color("cbd9df")
 environment.environment.ambient_light_energy = 0.55
 add_child(environment)
 var sun := DirectionalLight3D.new()
 sun.rotation_degrees = Vector3(-45,-30,0)
 sun.shadow_enabled = true
 add_child(sun)
 camera = Camera3D.new()
 camera.far = 2500
 camera.current = true
 add_child(camera)
 update_camera()
 patrol = Patrol.new()
 add_child(patrol)
 var hud := CanvasLayer.new()
 var text := Label.new()
 text.text = "MERCURY · нативная карта\nПоворот: движение пальцем · масштаб: два пальца\n© OpenStreetMap contributors · стенд, не готовая игра"
 text.position = Vector2(16,16)
 hud.add_child(text)
 var marker = Marker.new()
 marker.camera = camera
 marker.patrol = patrol
 hud.add_child(marker)
 clock_label = Label.new()
 clock_label.position = Vector2(16,78)
 hud.add_child(clock_label)
 fps_label = Label.new()
 fps_label.position = Vector2(16,99)
 hud.add_child(fps_label)
 var speeds := HBoxContainer.new()
 speeds.position = Vector2(16,182)
 for speed in GAME_SPEEDS:
  var speed_button := Button.new()
  speed_button.text = "×"+str(speed)
  speed_button.custom_minimum_size = Vector2(52,52)
  speed_button.pressed.connect(func(): patrol.time_scale = speed)
  speeds.add_child(speed_button)
 hud.add_child(speeds)
 var row := HBoxContainer.new()
 row.position = Vector2(16,126)
 for action in ["−","+","Центр","Патруль"]:
  var button := Button.new()
  button.text = action
  button.custom_minimum_size = Vector2(52,52)
  button.pressed.connect(func():
   if action=="Центр":
    focus = Vector3.ZERO
    distance = 650
   elif action=="Патруль":
    focus = patrol.position
    distance = 90
   else:
    distance = clampf(distance*(1.2 if action=="−" else 0.8),35,1200)
   update_camera())
  row.add_child(button)
 hud.add_child(row)
 add_child(hud)
 stats = {"tiles":tile_count,"mesh_instances":tile_count+1,"buildings":int(data.buildingCount),"roads":int(data.roads),"road_segments":int(data.segments),"triangles":geometry.triangles,"roofs":geometry.roofs,"failed_roofs":geometry.failed_roofs,"roof_area":geometry.roof_area,"expected_roof_area":geometry.expected_area,"construction_ms":Time.get_ticks_msec()-began}
 if "--verify-map" in OS.get_cmdline_user_args():
  verify()
func _process(delta: float) -> void:
 metrics.add(delta)
 elapsed += delta*patrol.time_scale
 reporting += delta
 clock_label.text = "Стенд · %02d:%02d · ×%d" % [int(elapsed/3600)%24,int(elapsed/60)%60,int(patrol.time_scale)]
 if reporting>=0.5:
  var report: Dictionary = metrics.report()
  fps_label.text = "%.1f FPS · P95 %.1f мс · память %.1f МБ" % [report.fps,report.p95_ms,report.static_memory_bytes/1048576.0]
  reporting = 0.0
func verify() -> void:
 var failed := false
 if not geometry.failed_roofs.is_empty() or absf(geometry.roof_area-geometry.expected_area)>0.01 or geometry.roofs!=stats.buildings:
  failed = true
 var graph = RoadGraph.new()
 graph.load_graph("res://assets/routes.json")
 var golden = JSON.parse_string(FileAccess.get_file_as_string("res://assets/route-golden.json"))
 var passed := 0
 for item in golden:
  var result: Dictionary = graph.route(str(item.start),str(item.goal))
  if result.is_empty() or absf(float(result.weight)-float(item.weight))>0.00000001:
   failed = true
   push_error("Native routing parity failed "+str(item)+" result "+str(result.get("weight",-1)))
  else:
   passed += 1
 stats["route_parity_passed"] = passed
 stats["route_nodes"] = graph.nodes.size()
 var route = patrol.route
 patrol.set_process(false)
 var start_position: Vector3 = patrol.position
 patrol.advance(0.1)
 var speed_error: float = absf(patrol.travelled-float(route[1].kmh)/3.6*0.1)
 if speed_error>0.0001:
  failed = true
 stats["patrol_distance_error_m"] = speed_error
 patrol.advance(10000)
 if not patrol.finished:
  failed = true
 stats["patrol_route_finished"] = patrol.finished
 var partition_errors: Array = []
 for speed in GAME_SPEEDS:
  patrol.reset_route()
  for frame in range(120):
   patrol.advance(speed/60.0)
  var fine_position: Vector3 = patrol.position
  var fine_travel: float = patrol.travelled
  patrol.reset_route()
  for frame in range(30):
   patrol.advance(speed/15.0)
  var error: float = fine_position.distance_to(patrol.position)
  partition_errors.append(error)
  if error>0.002 or absf(fine_travel-patrol.travelled)>0.002:
   failed = true
 stats["speed_partition_errors_m"] = partition_errors
 var test_metrics = Metrics.new()
 for frame in range(900):
  test_metrics.add(1.0/60.0)
 var metrics_result: Dictionary = test_metrics.report()
 if metrics_result.samples!=600 or absf(metrics_result.fps-60.0)>0.0001:
  failed = true
 stats["metrics_bounded_samples"] = metrics_result.samples
 patrol.position = start_position
 var file := FileAccess.open("res://verification.json",FileAccess.WRITE)
 file.store_string(JSON.stringify(stats,"  "))
 print(JSON.stringify(stats))
 get_tree().quit(1 if failed else 0)
func update_camera() -> void:
 camera.position = focus+Vector3(sin(yaw)*distance,distance*0.75,cos(yaw)*distance)
 camera.look_at(focus)
func _unhandled_input(event: InputEvent) -> void:
 if event is InputEventScreenTouch:
  if event.pressed:
   touches[event.index] = event.position
  else:
   touches.erase(event.index)
 if event is InputEventScreenDrag:
  if touches.size()==2 and touches.has(event.index):
   var ids := touches.keys()
   var other = ids[1] if ids[0]==event.index else ids[0]
   var old_length: float = touches[event.index].distance_to(touches[other])
   var new_length: float = event.position.distance_to(touches[other])
   if new_length>10 and old_length>10:
    distance = clampf(distance*old_length/new_length,35,1200)
  elif touches.size()<=1:
   yaw -= event.relative.x*0.005
  touches[event.index] = event.position
  update_camera()
 if event is InputEventMouseMotion and event.button_mask & MOUSE_BUTTON_MASK_LEFT:
  yaw -= event.relative.x*0.005
  update_camera()
 if event is InputEventMouseButton and event.pressed:
  if event.button_index==MOUSE_BUTTON_WHEEL_UP:
   distance = maxf(35,distance*0.9)
  elif event.button_index==MOUSE_BUTTON_WHEEL_DOWN:
   distance = minf(1200,distance*1.1)
  update_camera()
