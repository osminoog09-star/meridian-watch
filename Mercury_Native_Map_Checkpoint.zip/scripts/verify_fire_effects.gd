extends SceneTree
# Claude (12.10.2026): bounded fire and smoke over burning calls.
func _initialize() -> void:
 verify.call_deferred()
func verify() -> void:
 var effect = load("res://scripts/fire_effects.gd").new()
 root.add_child(effect)
 var incidents: Array = []
 for k in range(12):
  incidents.append({"id":k+1,"x":1.55+k*0.0004,"y":2.52,"state":"onscene","fire":{"size":10+k*7}})
 incidents.append({"id":40,"x":1.55,"y":2.52,"state":"onscene","smoke":true})
 incidents.append({"id":41,"x":1.55,"y":2.52,"state":"resolved","fire":{"size":80}})
 incidents.append({"id":42,"x":1.55,"y":2.52,"state":"onscene","fire":{"size":0}})
 effect.configure(incidents,Vector3.ZERO,300)
 for i in range(30):
  effect.animate(1.0/30)
 var d: Dictionary = effect.diagnostics()
 assert(d.fires==effect.MAX_FIRES,"bounded fires")
 assert(d.flames==effect.MAX_FIRES*effect.FLAMES_PER_FIRE and d.puffs==effect.MAX_FIRES*effect.PUFFS_PER_FIRE)
 for i in range(d.flames):
  assert(effect.flame_mesh.get_instance_transform(i).origin.is_finite())
 for i in range(d.puffs):
  assert(effect.smoke_mesh.get_instance_transform(i).origin.is_finite())
 effect.configure([{"id":1,"x":1.55,"y":2.52,"state":"onscene","fire":{"size":0}},{"id":2,"x":1.55,"y":2.52,"state":"missed","fire":{"size":50}}],Vector3.ZERO,300)
 assert(effect.diagnostics().fires==0,"no flames when out or closed")
 effect.configure([{"id":3,"x":1.55,"y":2.52,"state":"onscene","smoke":true}],Vector3.ZERO,300,false)
 assert(effect.diagnostics().fires==0,"disabled effects")
 effect.configure([{"id":4,"x":9.0,"y":9.0,"state":"onscene","fire":{"size":60}}],Vector3.ZERO,100)
 assert(effect.diagnostics().fires==0,"culled far away")
 print(JSON.stringify({"fire_effects":"bounded 8 fires, finite transforms, out/closed/disabled/far culled"}))
 quit(0)
