extends SceneTree
var scene: Node
var frames := 0
func _initialize() -> void:
 scene = load("res://main.tscn").instantiate()
 root.add_child.call_deferred(scene)
func _process(_delta: float) -> bool:
 frames += 1
 if frames==3:
  scene.campaign.invoke({"op":"event","domId":"startCareer","event":"click"})
  scene.campaign.invoke({"op":"event","domId":"closeModal","event":"click"})
  scene.native_ui.signature = ""
 if frames==10:
  scene.campaign.invoke({"op":"event","domId":"settingsBtn","event":"click"})
 if frames==20:
  scene.campaign.invoke({"op":"event","domId":"closeModal","event":"click"})
 if frames==50:
  print("Native UI scene: welcome,career/map/settings exercised")
  quit(0)
 return false
