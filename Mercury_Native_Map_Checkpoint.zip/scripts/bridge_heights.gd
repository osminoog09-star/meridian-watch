extends RefCounted
# Claude (12.10.2026): height of the ground under an actor — 2.5 m on a bridge deck (city_geometry.gd), else 0.
# assets/bridges.json comes from export-bridges.mjs (a few dozen segments: a linear scan is enough).
var decks: Array = []
var height := 2.5
func _init() -> void:
 var data = JSON.parse_string(FileAccess.get_file_as_string("res://assets/bridges.json"))
 if typeof(data)!=TYPE_DICTIONARY:
  return
 height = float(data.get("height",2.5))
 for deck in data.get("decks",[]):
  decks.append({"a":Vector2(float(deck.a[0]),float(deck.a[1])),"b":Vector2(float(deck.b[0]),float(deck.b[1])),"half":float(deck.half)})
func at(position: Vector3) -> float:
 var p := Vector2(position.x,position.z)
 for deck in decks:
  var a: Vector2 = deck.a
  var b: Vector2 = deck.b
  var ab := b-a
  var t := 0.0 if ab.length_squared()<0.0001 else clampf((p-a).dot(ab)/ab.length_squared(),0,1)
  if p.distance_to(a+ab*t)<=float(deck.half):
   return height
 return 0.0
