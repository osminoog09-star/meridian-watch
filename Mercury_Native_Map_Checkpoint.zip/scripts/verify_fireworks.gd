extends SceneTree
# Claude (12.10.2026): bounded New Year fireworks.
func _initialize() -> void:
 verify.call_deferred()
func verify() -> void:
 var effect = load("res://scripts/fireworks_effects.gd").new()
 root.add_child(effect)
 effect.configure(true,Vector3(300,0,-100),400)
 for i in range(240):
  effect.animate(1.0/30)
  for k in range(effect.instances.visible_instance_count):
   assert(effect.instances.get_instance_transform(k).origin.is_finite())
 assert(effect.diagnostics().sparks==effect.BURSTS*effect.SPARKS)
 effect.configure(false,Vector3.ZERO,400)
 assert(effect.diagnostics().sparks==0)
 effect.configure(true,Vector3.ZERO,400,false)
 assert(effect.diagnostics().sparks==0,"disabled effects")
 print(JSON.stringify({"fireworks":"6 bursts x 24 sparks, 8 s animated, finite, off outside New Year and when effects are disabled"}))
 quit(0)
