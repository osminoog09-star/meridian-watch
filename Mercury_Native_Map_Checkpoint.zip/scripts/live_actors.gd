extends Node3D
const MAX_CARS := 64
const MAX_PEOPLE := 128
const Geometry = preload("res://scripts/city_geometry.gd")
var bridges = preload("res://scripts/bridge_heights.gd").new()
var models: Dictionary
var shared: Dictionary = {}
var cars: Array[MeshInstance3D] = []
var people: Array[MeshInstance3D] = []
var materials: Dictionary = {}
# Claude (12.10.2026): flashing beacons of crews driving to urgent calls (lighting.js emergencyLights), at most 8 near the camera.
const MAX_BEACONS := 8
var beacons: Array[OmniLight3D] = []
var beacon_modes: Array[String] = []
var beacon_clock := 0.0
# Claude (12.10.2026): service liveries baked into the shared meshes (garage.js LIVERIES: paint, stripe).
const LIVERIES := {"red":["#c0392b","#e8c53a"],"ems":["#e8d93a","#2f8f4e"],"navy":["#6d8eaf","#e0e6df"],"black":["#48535b","#b8c2c8"],"yellow":["#e2cf4c","#2d5fa8"],"grey":["#8a9399","#8a9399"]}
func model(kind: String,livery: String = "") -> Mesh:
 if not LIVERIES.has(livery):
  livery = ""
 var key := kind+"|"+livery
 if shared.has(key):
  return shared[key]
 var data: Dictionary = models[kind]
 var builder := SurfaceTool.new()
 builder.begin(Mesh.PRIMITIVE_TRIANGLES)
 var geometry = Geometry.new()
 var palette := {"paint":"#d0d9de","trim":"#414b53","plate":"#f2f3e9","glass":"#274855","seal":"#273039","metal":"#89949a","stripe":"#295696","tire":"#252a2d","headlight":"#fff1bd","taillight":"#b73734","rubber":"#273039","beaconA":"#397fe6","beaconB":"#4385f1","skin":"#d2aa8d","uniform":"#28435c","cloth":"#8d786e","pants":"#3a4654","shoe":"#252a2d","hair":"#44372f"}
 if livery!="":
  palette.paint = LIVERIES[livery][0]
  palette.stripe = LIVERIES[livery][1]
 for face in data.faces:
  var vertices: Array[Vector3] = []
  for index in face.v:
   var p = data.vertices[index]
   vertices.append(Vector3(p[0],p[2],p[1]))
  if vertices.size()<3:
   continue
  var normal := -(vertices[1]-vertices[0]).cross(vertices[2]-vertices[0]).normalized()
  for index in range(1,vertices.size()-1):
   geometry.triangle(builder,vertices[0],vertices[index],vertices[index+1],Color(palette.get(face.material,"#777e87")),normal)
 builder.index()
 shared[key] = builder.commit()
 return shared[key]
func _ready() -> void:
 models = JSON.parse_string(FileAccess.get_file_as_string("res://assets/actor-models.json"))
 for kind in ["police","civilian","ambulance","rescue"]:
  var material := StandardMaterial3D.new()
  material.vertex_color_use_as_albedo = true
  material.roughness = 0.7
  material.albedo_color = Color("ffe58f") if kind=="ambulance" else (Color("ef8d5a") if kind=="rescue" else Color.WHITE)
  materials[kind] = material
 for index in range(MAX_CARS):
  var actor := MeshInstance3D.new()
  actor.mesh = model("sedan")
  actor.visible = false
  add_child(actor)
  cars.append(actor)
 for index in range(MAX_BEACONS):
  var light := OmniLight3D.new()
  light.omni_range = 26.0
  light.light_energy = 2.2
  light.shadow_enabled = false
  light.visible = false
  add_child(light)
  beacons.append(light)
  beacon_modes.append("redblue")
 for index in range(MAX_PEOPLE):
  var actor := MeshInstance3D.new()
  actor.mesh = model("civilian")
  actor.visible = false
  actor.material_override = materials.civilian
  add_child(actor)
  people.append(actor)
# Claude: rescue trucks and ambulances use their own models; the doctor's rapid car uses the SUV.
func vehicle_model(vehicle: Dictionary) -> String:
 var type := str(vehicle.get("type","sedan"))
 if type=="rapid":
  return "suv"
 return type if models.has(type) else "sedan"
func _process(delta: float) -> void:
 beacon_clock += clampf(delta,0,0.1)
 _flash()
func _flash() -> void:
 var on := fmod(beacon_clock,0.5)<0.25
 for index in range(MAX_BEACONS):
  if not beacons[index].visible:
   continue
  var blue := Color("3d7cff")
  beacons[index].light_color = blue if beacon_modes[index]=="blue" or on else Color("ff3b3b")
  beacons[index].light_energy = 2.2 if on or beacon_modes[index]!="blue" else 0.4
func world(p: Dictionary) -> Vector3:
 var position := Vector3((float(p.get("x",1.55))-1.55)*1670,0.04,(float(p.get("y",2.52))-2.52)*1670)
 position.y += bridges.at(position)
 return position
func refresh(view: Dictionary,selected: int,focus: Vector3,distance: float) -> void:
 var car_count := 0
 var beacon_count := 0
 var person_count := 0
 var radius := maxf(120,distance*1.6)
 var poses: Array = []
 var vehicles := {}
 for vehicle in view.get("vehicles",[]):
  vehicles[int(vehicle.get("id",-1))] = vehicle
 for unit in view.get("units",[]):
  if int(unit.id)!=selected:
   poses.append({"pose":unit,"kind":"police","model":vehicle_model(vehicles.get(int(unit.get("vehicleId",-1)),{})),"livery":str(vehicles.get(int(unit.get("vehicleId",-1)),{}).get("paint","")),"beacon":str(vehicles.get(int(unit.get("vehicleId",-1)),{}).get("lights","redblue"))})
  if typeof(unit.get("foot"))==TYPE_DICTIONARY:
   for person in unit.foot.get("actors",[]):
    if person_count>=MAX_PEOPLE:
     break
    var position: Vector3 = world(person)
    if position.distance_to(focus)>radius:
     continue
    var actor := people[person_count]
    actor.mesh = model("officer")
    actor.position = position
    actor.rotation.y = -float(person.get("heading",0))
    actor.visible = true
    person_count += 1
 for service in view.get("services",[]):
  poses.append({"pose":service,"kind":service.get("kind","ambulance"),"model":"suv"})
 for resident in view.get("residents",[]):
  if resident.get("status") in ["home","work"]:
   continue
  if resident.get("status") in ["toHome","toWork","toVisit","fromVisit"]:
   poses.append({"pose":resident,"kind":"civilian","model":"sedan"})
  elif person_count<MAX_PEOPLE:
   var position: Vector3 = world(resident)
   if position.distance_to(focus)>radius:
    continue
   var actor := people[person_count]
   actor.mesh = model("civilian")
   actor.position = position
   actor.rotation.y = -float(resident.get("heading",0))
   actor.visible = true
   person_count += 1
 for item in poses:
  if car_count>=MAX_CARS:
   break
  var position: Vector3 = world(item.pose)
  if position.distance_to(focus)>radius:
   continue
  var car := cars[car_count]
  car.mesh = model(item.model,str(item.get("livery","")))
  car.material_override = materials.get(item.kind,materials.police)
  car.position = position
  car.rotation.y = -float(item.pose.get("heading",item.pose.get("renderHeading",0)))
  if typeof(item.pose.get("target"))==TYPE_DICTIONARY:
   var direction: Vector3 = world(item.pose.target)-position
   if direction.length()>0.01:
    car.rotation.y = -atan2(direction.z,direction.x)
  car.visible = true
  car_count += 1
  if bool(item.pose.get("lights",false)) and beacon_count<MAX_BEACONS:
   var light: OmniLight3D = beacons[beacon_count]
   light.position = position+Vector3(0,3.4,0)
   light.visible = true
   beacon_modes[beacon_count] = str(item.get("beacon","redblue"))
   beacon_count += 1
 for index in range(car_count,MAX_CARS):
  cars[index].visible = false
 for index in range(beacon_count,MAX_BEACONS):
  beacons[index].visible = false
 _flash()
 for index in range(person_count,MAX_PEOPLE):
  people[index].visible = false
