extends RefCounted
const Save = preload("res://scripts/campaign_save.gd")
var runtime: RefCounted
var snapshot: Dictionary = {}
var store = Save.new()
var elapsed := 0.0
var snapshot_elapsed := 0.0
var initialized := false
func initialize(storage_override: Variant = null) -> bool:
 if not ClassDB.class_exists("QuickJS"):
  return false
 store.path = "user://mercury-native-ui-storage.json"
 var saved: String = store.read_save()
 var storage = JSON.parse_string(saved) if not saved.is_empty() else {}
 if typeof(storage)!=TYPE_DICTIONARY:
  storage = {}
 if typeof(storage_override)==TYPE_DICTIONARY:
  storage = storage_override
 runtime = ClassDB.instantiate("QuickJS")
 if not runtime.load_file("res://ui/ui-bundle.js"):
  push_error(runtime.get_error())
  return false
 initialized = invoke({"op":"initialize","storage":storage})!=null
 return initialized
func invoke(request: Dictionary) -> Variant:
 var raw = runtime.eval("MercuryUI.call("+JSON.stringify(JSON.stringify(request))+")")
 if not runtime.get_error().is_empty():
  push_error(runtime.get_error())
  return null
 if runtime.has_method("run_jobs"):
  var jobs: int = runtime.run_jobs(128)
  if jobs<0:
   push_error(runtime.get_error())
   return null
  if jobs>0:
   raw = runtime.eval("JSON.stringify(MercuryUI.snapshot())")
 var result = JSON.parse_string(str(raw))
 if typeof(result)==TYPE_DICTIONARY:
  snapshot.merge(result,true)
 return result
func advance(delta: float,_speed: int = 1) -> Dictionary:
 if not initialized:
  return {}
 elapsed += delta
 snapshot_elapsed += delta
 var full := snapshot_elapsed>=0.2
 var result = invoke({"op":"frame","seconds":delta,"full":full})
 if full:
  snapshot_elapsed = 0
 if elapsed>=10:
  save()
  elapsed = 0
 return result if typeof(result)==TYPE_DICTIONARY else {}
func view() -> Dictionary:
 return snapshot.get("view",{})
func save() -> Error:
 if not initialized:
  return ERR_UNCONFIGURED
 invoke({"op":"snapshot"})
 return store.write_save(JSON.stringify(snapshot.get("storage",{})))
func action(request: Dictionary) -> void:
 invoke(request)
 save()
func background() -> void:
 invoke({"op":"background"})
 save()
