extends RefCounted
const Save = preload("res://scripts/campaign_save.gd")
var runtime: RefCounted
var snapshot: Dictionary = {}
var store = Save.new()
var elapsed := 0.0
var snapshot_elapsed := 0.0
var initialized := false
var android: Object
var migration_pending := false
var migration_error := ""
var legacy_payload := ""
func initialize(storage_override: Variant = null) -> bool:
 if not ClassDB.class_exists("QuickJS"):
  return false
 store.path = "user://mercury-native-ui-storage.json"
 var saved: String = store.read_save()
 var storage = JSON.parse_string(saved) if not saved.is_empty() else {}
 if typeof(storage)!=TYPE_DICTIONARY:
  storage = {}
 if typeof(storage_override)==TYPE_DICTIONARY:
  storage = storage_override
 runtime = ClassDB.instantiate("QuickJS")
 if not runtime.load_file("res://ui/ui-bundle.js"):
  push_error(runtime.get_error())
  return false
 initialized = invoke({"op":"initialize","storage":storage})!=null
 if initialized and storage_override==null and Engine.has_singleton("MercuryAndroid"):
  android = Engine.get_singleton("MercuryAndroid")
  if not android.is_connected("legacy_storage_ready",_legacy_storage_ready):
   android.connect("legacy_storage_ready",_legacy_storage_ready)
   android.connect("save_before_update",_save_before_update)
  if saved.is_empty():
   migration_pending = true
   android.readLegacyStorage()
 return initialized
func invoke(request: Dictionary) -> Variant:
 var raw = runtime.eval("MercuryUI.call("+JSON.stringify(JSON.stringify(request))+")")
 if not runtime.get_error().is_empty():
  push_error(runtime.get_error())
  return null
 if runtime.has_method("run_jobs"):
  var jobs: int = runtime.run_jobs(128)
  if jobs<0:
   push_error(runtime.get_error())
   return null
  if jobs>0:
   raw = runtime.eval("JSON.stringify(MercuryUI.snapshot())")
 var result = JSON.parse_string(str(raw))
 if typeof(result)==TYPE_DICTIONARY:
  snapshot.merge(result,true)
 return result
func advance(delta: float,_speed: int = 1) -> Dictionary:
 if not initialized or migration_pending or not migration_error.is_empty():
  return {}
 elapsed += delta
 snapshot_elapsed += delta
 var full := snapshot_elapsed>=0.2
 var result = invoke({"op":"frame","seconds":delta,"full":full})
 if full:
  snapshot_elapsed = 0
 if elapsed>=10:
  save()
  elapsed = 0
 for signal_pattern in snapshot.get("signals",[]):
  if Engine.has_singleton("MercuryAndroid"):
   Engine.get_singleton("MercuryAndroid").vibratePattern(JSON.stringify(signal_pattern))
  else:
   Input.vibrate_handheld(140)
 snapshot["signals"] = []
 return result if typeof(result)==TYPE_DICTIONARY else {}
func view() -> Dictionary:
 return snapshot.get("view",{})
func save() -> Error:
 if not initialized or migration_pending or not migration_error.is_empty():
  return ERR_UNCONFIGURED
 invoke({"op":"snapshot"})
 return store.write_save(JSON.stringify(snapshot.get("storage",{})))
func action(request: Dictionary) -> void:
 invoke(request)
 save()
func background() -> void:
 invoke({"op":"background"})
 save()

func _legacy_storage_ready(raw: String,error: String) -> void:
 migration_pending = false
 legacy_payload = raw
 if not error.is_empty():
  migration_error = error
  return
 var storage = JSON.parse_string(raw)
 if typeof(storage)!=TYPE_DICTIONARY:
  migration_error = "Старое хранилище не прочитано"
  return
 var has_old_save: bool = storage.has("meridian-watch-v1") or storage.has("meridian-watch-v1-backup")
 if not initialize(storage):
  migration_error = "Старое сохранение не загружено"
  return
 if has_old_save and not snapshot.get("status",{}).get("hadSave",false):
  migration_error = "Старое сохранение не прошло проверку. Оно сохранено без изменений."
  return
 migration_error = ""
 save()
func continue_without_migration() -> void:
 var backup = Save.new()
 backup.path = "user://mercury-legacy-storage-preserved.json"
 if not legacy_payload.is_empty() and backup.write_save(legacy_payload)!=OK:
  migration_error = "Не удалось сохранить копию старых данных"
  return
 migration_error = ""
 migration_pending = false
 initialize({})
 save()
func _save_before_update() -> void:
 background()
 var success: bool = save()==OK
 android.savedForUpdate(success)
func check_updates() -> void:
 if Engine.has_singleton("MercuryAndroid"):
  Engine.get_singleton("MercuryAndroid").checkUpdates(true)
func device_report() -> Dictionary:
 if Engine.has_singleton("MercuryAndroid"):
  var report = JSON.parse_string(Engine.get_singleton("MercuryAndroid").deviceDiagnostics())
  if typeof(report)==TYPE_DICTIONARY:
   return report
 return {}
