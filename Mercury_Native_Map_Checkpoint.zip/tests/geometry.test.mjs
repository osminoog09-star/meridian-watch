import test from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs';
import {clipSegment,ringArea} from '../geometry.mjs';
const map=JSON.parse(fs.readFileSync(new URL('../assets/map.json',import.meta.url)));
test('clipping includes crossing roads with both endpoints outside',()=>{
 assert.deepEqual(clipSegment([-2,0],[2,0],[-1,-1,1,1]),[[-1,0],[1,0]]);
 assert.equal(clipSegment([-2,2],[2,2],[-1,-1,1,1]),null);
 assert.deepEqual(clipSegment([0,-2],[0,2],[-1,-1,1,1]),[[0,-1],[0,1]]);
});
test('tile split preserves road length and does not duplicate border runs',()=>{
 const a=[-150,20],b=[150,20],pieces=[];
 for(let x=-2;x<2;x++){const p=clipSegment(a,b,[x*100,0,(x+1)*100,100]);if(p)pieces.push(p);}
 assert.equal(pieces.reduce((s,[a,b])=>s+Math.hypot(b[0]-a[0],b[1]-a[1]),0),300);
});
test('native export retains complex source footprints and bounded drivable widths',()=>{
 const ids=new Set();let concave=0;
 for(const tile of map.chunks){for(const b of tile.buildings){assert.ok(!ids.has(b.id));ids.add(b.id);assert.ok(b.height>0);assert.ok(ringArea(b.ring)>0);if(b.ring.length>4)concave++;}
  for(const r of tile.roads){assert.ok(r.width>0);if(r.drive)assert.ok(r.edgeWidth>r.width);else if(!r.bridge)assert.equal(r.edgeWidth,r.width);for(const p of [r.a,r.b])assert.ok(p.every(n=>Math.abs(n)<=400.00001));}
 }assert.equal(ids.size,map.buildingCount);assert.ok(concave>20);assert.ok(map.chunks.length<=64);
});
