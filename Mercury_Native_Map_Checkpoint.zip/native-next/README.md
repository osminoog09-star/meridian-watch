# Native map migration checkpoint

Godot 4.7.2 Compatibility. Separate work in progress after APK 0.2.5 release; not part of the stable APK and not a finished game.

470 source roads and 282 buildings around the existing quarter origin; 13908 graph nodes exported from the reviewed 0.8.0-a geography module, including direction, speed and time-based edge weight w. Geometry uses metres (1670m per source unit). OSM attribution retained in map.json.

Headless import and scene startup passed. Visual appearance / GPU performance / Android export have not been checked. Buildings are bounding-box placeholders, roads require clipping, actual profiles/curbs and batching before visual acceptance. This checkpoint deliberately has no simulation, saves or updater.

Open project.godot; headless verification: godot --headless --path native-next -- --verify-map.

Export script imports the adjacent release025 source tree; adjust the explicit source path when moving it. Next: exact building geometry, chunk batching and mobile camera; transfer all simulation contracts before replacing stable APK. Preserve vehicle arrow below 14px, 52px controls and time-based routing.
