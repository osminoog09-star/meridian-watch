extends Node3D
# Source coordinates are metres. Rendering is independent from the WebView.
var camera: Camera3D
var yaw := 0.0
var distance := 650.0
func _ready() -> void:
 var data = JSON.parse_string(FileAccess.get_file_as_string("res://assets/map.json"))
 var ground := MeshInstance3D.new()
 var plane := PlaneMesh.new()
 plane.size = Vector2(1200, 1200)
 ground.mesh = plane
 ground.material_override = material(Color("62765b"))
 ground.position.y = -0.05
 add_child(ground)
 var surface := SurfaceTool.new()
 surface.begin(Mesh.PRIMITIVE_TRIANGLES)
 for road in data.roads:
  var points = road.p
  for i in range(1, points.size()):
   var a := Vector3(points[i-1][0], 0.05, points[i-1][1])
   var b := Vector3(points[i][0], 0.05, points[i][1])
   if a.distance_to(b) < 0.01:
    continue
   var side := (b-a).normalized().cross(Vector3.UP) * (2.0 if road.kind == "service" else 3.5)
   for v in [a-side,a+side,b+side,a-side,b+side,b-side]:
    surface.add_vertex(v)
 surface.generate_normals()
 var streets := MeshInstance3D.new()
 streets.mesh = surface.commit()
 streets.material_override = material(Color("333b40"))
 add_child(streets)
 for building in data.buildings:
  var low := Vector2(INF,INF)
  var high := Vector2(-INF,-INF)
  for p in building.p:
   low = low.min(Vector2(p[0],p[1]))
   high = high.max(Vector2(p[0],p[1]))
  var size := high-low
  if size.x < 1.0 or size.y < 1.0:
   continue
  var block := MeshInstance3D.new()
  var box := BoxMesh.new()
  box.size = Vector3(size.x, 9.0, size.y)
  block.mesh = box
  block.position = Vector3((low.x+high.x)/2,4.5,(low.y+high.y)/2)
  block.material_override = material(Color("c6bca6"))
  add_child(block)
 var light := DirectionalLight3D.new()
 light.rotation_degrees = Vector3(-45,-30,0)
 light.shadow_enabled = true
 add_child(light)
 camera = Camera3D.new()
 camera.far = 3000
 camera.current = true
 add_child(camera)
 update_camera()
 print("Native map loaded: ",data.roads.size()," roads, ",data.buildings.size()," buildings")
 if "--verify-map" in OS.get_cmdline_user_args():
  get_tree().quit()
func material(color: Color) -> StandardMaterial3D:
 var m := StandardMaterial3D.new()
 m.albedo_color = color
 return m
func update_camera() -> void:
 camera.position = Vector3(sin(yaw)*distance,distance*0.75,cos(yaw)*distance)
 camera.look_at(Vector3.ZERO)
func _unhandled_input(event: InputEvent) -> void:
 if event is InputEventScreenDrag:
  yaw -= event.relative.x * 0.005
  update_camera()
 if event is InputEventMagnifyGesture:
  distance = clampf(distance / event.factor,100,1200)
  update_camera()
 if event is InputEventMouseMotion and event.button_mask & MOUSE_BUTTON_MASK_LEFT:
  yaw -= event.relative.x * 0.005
  update_camera()
