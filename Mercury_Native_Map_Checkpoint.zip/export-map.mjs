import fs from 'node:fs';
import path from 'node:path';
import {pathToFileURL,fileURLToPath} from 'node:url';
import {clipSegment,bounds,intersects} from './geometry.mjs';
import {sidewalkProfile} from './street-profile.mjs';
const output=path.dirname(fileURLToPath(import.meta.url));
const root=path.resolve(process.argv[2]??'release027/meridian-watch-claude-sound-quality');
const module=n=>import(pathToFileURL(path.join(root,'dist',n)));
const [{default:city},{ROAD_NODES,roadRoute},{buildingLayout},{streetStyle},{QUARTER}]=await Promise.all(['city-data.js','geography.js','building-layout.js','street-art.js','quarter.js'].map(module));
const origin=[1.55,2.52],scale=1670,extent=400,tileSize=100,box=[-extent,-extent,extent,extent];
const point=p=>[(p[0]-origin[0])*scale,(p[1]-origin[1])*scale];
const metadata=new Map(QUARTER.buildings.map(b=>[String(b.id),b]));
const buildings=city.buildings.map(b=>{
 const layout=buildingLayout(b,metadata.get(String(b.id)));
 return {id:b.id,...layout,ring:layout.ring.map(point)};
}).filter(b=>b.ring.length>=3&&intersects(bounds(b.ring),box));
const chunks=new Map();
const chunk=(x,y)=>{const key=`${x},${y}`;if(!chunks.has(key))chunks.set(key,{key,roads:[],buildings:[]});return chunks.get(key);};
for(const b of buildings){const q=bounds(b.ring);chunk(Math.floor((q[0]+q[2])/2/tileSize),Math.floor((q[1]+q[3])/2/tileSize)).buildings.push(b);}
let roads=0,segments=0;
for(const road of city.roads){
 const art=streetStyle(road,scale,1),p=road.p.map(point);let used=false;
 for(let i=1;i<p.length;i++){
  const clipped=clipSegment(p[i-1],p[i],box);if(!clipped)continue;
  const q=bounds(clipped);
  for(let x=Math.max(-4,Math.floor(q[0]/tileSize));x<=Math.min(3,Math.floor(q[2]/tileSize));x++)for(let y=Math.max(-4,Math.floor(q[1]/tileSize));y<=Math.min(3,Math.floor(q[3]/tileSize));y++){
   const run=clipSegment(...clipped,[x*tileSize,y*tileSize,(x+1)*tileSize,(y+1)*tileSize]);if(!run)continue;
   if(Math.floor((run[0][0]+run[1][0])/2/tileSize)!==x||Math.floor((run[0][1]+run[1][1])/2/tileSize)!==y)continue;
   chunk(x,y).roads.push({id:road.id,a:run[0],b:run[1],width:art.width,edgeWidth:art.edgeWidth,color:art.color,edge:art.edge,drive:road.drive,bridge:road.bridge,sidewalk:sidewalkProfile(road,art.source),surface:art.surface});segments++;used=true;
  }
 }if(used)roads++;
}
const graph={sourceCommit:'e55a47a + Codex 0.9.0-a integration',origin,metersPerUnit:scale,nodes:ROAD_NODES};
const byId=new Map(ROAD_NODES.map(n=>[n.id,n]));
// Reference Dijkstra works on IDs: coincident OSM nodes must not be merged by position.
function referenceCost(start,goal){
 const costs=new Map([[start,0]]),queue=[[0,start]];
 while(queue.length){
  const [cost,id]=queue.shift();if(cost!==costs.get(id))continue;if(id===goal)return cost;
  for(const e of byId.get(id).edges){const next=cost+e.w;if(next>=(costs.get(e.id)??Infinity))continue;costs.set(e.id,next);
   let lo=0,hi=queue.length;while(lo<hi){const m=(lo+hi)>>1;if(queue[m][0]<=next)lo=m+1;else hi=m;}queue.splice(lo,0,[next,e.id]);
  }
 }throw Error('Unreachable reference route');
}
const golden=[];
for(let i=0;i<12;i++){
 const a=ROAD_NODES[(i*1069+37)%ROAD_NODES.length],b=ROAD_NODES[(i*1511+781)%ROAD_NODES.length];
 golden.push({start:a.id,goal:b.id,weight:referenceCost(a.id,b.id)});
}
fs.mkdirSync(path.join(output,'assets'),{recursive:true});
const {MODELS}=await module('models.js');
fs.writeFileSync(path.join(output,'assets/sedan.json'),JSON.stringify(MODELS.sedan));
const {nearestRoad}=await module('geography.js');
const start=nearestRoad({x:origin[0],y:origin[1]}),target=nearestRoad({x:origin[0]+120/scale,y:origin[1]+90/scale});
const demo=[{x:start.x,y:start.y},...roadRoute(start,target)];
fs.writeFileSync(path.join(output,'assets/patrol.json'),JSON.stringify(demo.map(p=>({p:point([p.x,p.y]),kmh:Math.min(30,p.roadSpeed?.kmh??30)}))));

fs.writeFileSync(path.join(output,'assets/map.json'),JSON.stringify({schema:2,source:city.source,date:city.date,origin,metersPerUnit:scale,extent,tileSize,roads,segments,buildingCount:buildings.length,chunks:[...chunks.values()]}));
fs.writeFileSync(path.join(output,'assets/routes.json'),JSON.stringify(graph));
fs.writeFileSync(path.join(output,'assets/route-golden.json'),JSON.stringify(golden));
console.log(JSON.stringify({roads,segments,buildings:buildings.length,chunks:chunks.size,routeNodes:ROAD_NODES.length}));
