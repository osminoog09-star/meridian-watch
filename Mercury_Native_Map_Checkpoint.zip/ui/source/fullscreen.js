export function createFullscreen(doc,button,onEnter){let active=false;return {get active(){return active},toggle(){active=!active;onEnter();},exit(){active=false;}};}
