// Claude (12.10.2026): the native UI with the separate services — rescue, ambulance and the 112 desk.
import fs from 'node:fs';import vm from 'node:vm';import assert from 'node:assert/strict';
const bundle=fs.readFileSync(new URL('./ui-bundle.js',import.meta.url),'utf8');let context;
const call=r=>JSON.parse(context.MercuryUI.call(JSON.stringify(r)));
const find=(nodes,pred)=>{for(const n of nodes??[]){if(pred(n))return n;const r=find(n.children,pred);if(r)return r;}return null;};
const text=n=>n?.tag==='#text'?n.text:(n?.text||'')+(n?.children??[]).map(text).join(' ');
const click=(s,pred,why,scope)=>{const root=scope?find(s.tree,x=>x.domId===scope):null;const n=find(root?[root]:s.tree,pred);assert.ok(n,why);return call({op:'event',id:n.id,event:'click'});};
const state=()=>JSON.parse(context.MercuryUI.call('{"op":"state"}'));
for(const [label,agency] of [['Спасатели','rescue'],['Скорая','ems'],['112','dispatch']]){
 context=vm.createContext({console});vm.runInContext(bundle,context);let s=call({op:'initialize'});s=click(s,n=>n.tag==='button'&&n.text===label,label);
 s=call({op:'event',domId:'startCareer',event:'click'});assert.equal(state().agency,agency);
 if(find(s.tree,n=>n.domId==='closeModal'))s=call({op:'event',domId:'closeModal',event:'click'});
 for(let n=0;n<900;n++)s=call({op:'frame',seconds:1/30,full:n%60===0});
 if(agency==='dispatch'){let done=false;
  for(let n=0;n<6000&&!done;n++){s=call({op:'frame',seconds:1});const ring=state().incidents.find(i=>i.call?.status==='ringing');if(!ring)continue;
   s=call({op:'snapshot'});{const tab=find(s.tree,x=>x.tag==='button'&&/Вызовы/.test(text(x))&&(x.classes??'').length>=0&&find([x],y=>y.tag==='#text'&&/Вызовы/.test(y.text)));if(tab)s=call({op:'event',id:tab.id,event:'click'});}const item=find(s.tree,x=>x.tag==='button'&&(x.classes??'').includes('desk-call')&&text(x).includes(String(ring.id).padStart(3,'0'))&&text(x).includes('ЗВОНОК'));assert.ok(item,'ringing call in the list');s=call({op:'event',id:item.id,event:'click'});
   s=call({op:'event',domId:'takeCallBtn',event:'click'});assert.equal(state().desk.player,ring.id);
   s=click(s,x=>x.tag==='button'&&/\?$/.test(x.text),'a question','callDetail');s=click(s,x=>x.tag==='button'&&x.text==='Скорая','service','callDetail');s=click(s,x=>x.tag==='button'&&x.text==='A','priority','callDetail');
   s=call({op:'event',domId:'sendCallBtn',event:'click'});const st=state();assert.equal(st.incidents.find(i=>i.id===ring.id).call.status,'routed');assert.equal(st.desk.player,null);assert.ok(JSON.stringify(s.tree).includes('Линия 112'),'desk line');done=true;}
  assert.ok(done,'took a call');console.log('  112 desk: answered, asked, routed through native widgets');}
 s=call({op:'background'});assert.equal(s.status.paused,true);assert.equal(JSON.parse(s.storage['meridian-watch-v1']).agency,agency);
 console.log(`Native UI ${agency}: start, 900 frames, saved`);}
