// Claude (12.10.2026): bridge decks for actors (cars and people stand on the 2.5 m deck that
// city_geometry.gd draws). Run after export-map.mjs: node export-bridges.mjs
import fs from 'node:fs';
const city=JSON.parse(fs.readFileSync(new URL('./assets/city.json',import.meta.url)));
const decks=[];for(const chunk of city.chunks)for(const r of chunk.roads)if(r.bridge)decks.push({a:r.a.map(v=>Math.round(v*100)/100),b:r.b.map(v=>Math.round(v*100)/100),half:Math.round((Math.max(r.width,r.edgeWidth??r.width)/2+.6)*100)/100,drive:!!r.drive});
fs.writeFileSync(new URL('./assets/bridges.json',import.meta.url),JSON.stringify({height:2.5,decks}));console.log('bridge decks',decks.length,'drive',decks.filter(d=>d.drive).length);
