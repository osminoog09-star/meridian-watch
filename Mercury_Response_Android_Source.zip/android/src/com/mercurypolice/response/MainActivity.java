package com.mercurypolice.response;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.util.Base64;
import android.view.Gravity;
import android.view.View;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.webkit.ConsoleMessage;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class MainActivity extends Activity {
    private static final String GAME = "https://mercurypolice.com/game/";
    private static final int FILE_UPLOAD = 10, FILE_EXPORT = 11;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final ExecutorService network = Executors.newSingleThreadExecutor();
    private WebView web;
    private FrameLayout frame;
    private LinearLayout root, toolbar, error;
    private TextView title;
    private View custom;
    private WebChromeClient.CustomViewCallback customCallback;
    private ValueCallback<Uri[]> fileCallback;
    private byte[] pendingExport;
    private String currentVersion = "", offeredVersion = "";
    private boolean checking, foreground, destroyed;
    private final Runnable periodic = new Runnable() {
        public void run() {
            if (!foreground || destroyed) return;
            checkVersion(false);
            handler.postDelayed(this, 300000);
        }
    };

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(17,28,35));
        toolbar = new LinearLayout(this);
        toolbar.setGravity(Gravity.CENTER_VERTICAL);
        title = new TextView(this);
        title.setText("M  Mercury Response");
        title.setTextColor(Color.rgb(89,213,207));
        title.setTextSize(16);
        title.setPadding(dp(12),0,0,0);
        toolbar.addView(title, new LinearLayout.LayoutParams(0,dp(48),1));
        Button menu = new Button(this);
        menu.setText("⋮");
        menu.setContentDescription("Меню приложения");
        menu.setOnClickListener(v -> showMenu());
        toolbar.addView(menu,new LinearLayout.LayoutParams(dp(58),dp(48)));
        root.addView(toolbar);
        frame = new FrameLayout(this);
        root.addView(frame,new LinearLayout.LayoutParams(-1,0,1));
        web = new WebView(this);
        web.setBackgroundColor(Color.rgb(17,28,35));
        frame.addView(web,new FrameLayout.LayoutParams(-1,-1));
        error = new LinearLayout(this);
        error.setOrientation(LinearLayout.VERTICAL);
        error.setGravity(Gravity.CENTER);
        error.setPadding(dp(24),dp(24),dp(24),dp(24));
        error.setBackgroundColor(Color.rgb(17,28,35));
        TextView message = new TextView(this);
        message.setText("Не удалось загрузить игру.\nПроверьте интернет и попробуйте снова.\nСохранения на этом устройстве остаются.");
        message.setTextColor(Color.WHITE);
        message.setGravity(Gravity.CENTER);
        message.setTextSize(18);
        error.addView(message);
        Button retry = new Button(this);
        retry.setText("Повторить");
        retry.setOnClickListener(v -> loadGame());
        error.addView(retry);
        error.setVisibility(View.GONE);
        frame.addView(error,new FrameLayout.LayoutParams(-1,-1));
        setContentView(root);
        if (Build.VERSION.SDK_INT >= 30) {
            root.setOnApplyWindowInsetsListener((v,insets) -> {
                android.graphics.Insets bars = insets.getInsets(WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout());
                v.setPadding(bars.left,bars.top,bars.right,bars.bottom);
                return insets;
            });
        } else root.setFitsSystemWindows(true);
        WebSettings settings = web.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(true);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setSafeBrowsingEnabled(true);
        settings.setMediaPlaybackRequiresUserGesture(true);
        settings.setCacheMode(WebSettings.LOAD_DEFAULT);
        settings.setUserAgentString(settings.getUserAgentString()+" MercuryResponseAndroid/0.1.0");
        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view,WebResourceRequest request) {
                Uri uri=request.getUrl();
                if (trusted(uri.toString())) return false;
                if (request.isForMainFrame() && ("https".equals(uri.getScheme()) || "http".equals(uri.getScheme()))) {
                    try { startActivity(new Intent(Intent.ACTION_VIEW,uri)); } catch (Exception ignored) { toast("Не удалось открыть ссылку"); }
                }
                return true;
            }
            @Override public void onPageFinished(WebView view,String url) {
                if (!trusted(url)) return;
                view.evaluateJavascript("document.querySelector('.build')?.textContent || ''", value -> {
                    String decoded = decode(value);
                    Matcher m=Pattern.compile("([0-9]+\\.[0-9]+\\.[0-9]+(?:-[A-Za-z0-9.]+)?)").matcher(decoded);
                    if (m.find()) currentVersion=m.group(1);
                    title.setText("M  Mercury Response"+(currentVersion.isEmpty()?"":" · "+currentVersion));
                });
                // Preserve the game's Blob exports using Android's user-selected document destination.
                view.evaluateJavascript("(()=>{if(window.__mercuryExport)return;window.__mercuryExport=true;const send=async a=>{try{const b=await(await fetch(a.href)).blob();if(b.size>8388608)throw Error('too large');const r=new FileReader();r.onload=()=>console.info('MERCURY_EXPORT:'+JSON.stringify({name:a.download||'mercury-export.json',data:String(r.result).split(',')[1]}));r.readAsDataURL(b);}catch(x){console.info('MERCURY_EXPORT_ERROR');}};const original=HTMLAnchorElement.prototype.click;HTMLAnchorElement.prototype.click=function(){if(this.hasAttribute('download')&&this.href.startsWith('blob:')){send(this);return;}return original.call(this);};document.addEventListener('click',e=>{const a=e.target.closest?.('a[download]');if(!a||!a.href.startsWith('blob:'))return;e.preventDefault();e.stopImmediatePropagation();send(a);},true);})()",null);
            }
            @Override public void onReceivedError(WebView view,WebResourceRequest req,WebResourceError failure) {
                if (req.isForMainFrame()) error.setVisibility(View.VISIBLE);
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override public void onShowCustomView(View view,CustomViewCallback callback) {
                if (custom!=null) { callback.onCustomViewHidden(); return; }
                custom=view; customCallback=callback;
                toolbar.setVisibility(View.GONE);
                web.setVisibility(View.GONE);
                frame.addView(view,new FrameLayout.LayoutParams(-1,-1));
                fullscreen(true);
            }
            @Override public void onHideCustomView() {
                if (custom==null) return;
                frame.removeView(custom);custom=null;
                web.setVisibility(View.VISIBLE);toolbar.setVisibility(View.VISIBLE);
                fullscreen(false);
                if(customCallback!=null)customCallback.onCustomViewHidden();
                customCallback=null;
            }
            @Override public boolean onShowFileChooser(WebView view,ValueCallback<Uri[]> callback,FileChooserParams params) {
                if (fileCallback!=null) fileCallback.onReceiveValue(null);
                fileCallback=callback;
                Intent intent=new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);intent.setType("*/*");
                try { startActivityForResult(intent,FILE_UPLOAD); } catch (Exception e) { fileCallback.onReceiveValue(null);fileCallback=null;toast("Выбор файла недоступен"); }
                return true;
            }
            @Override public boolean onConsoleMessage(ConsoleMessage message) {
                if(!trusted(web.getUrl()))return false;
                String value=message.message();
                if(value.equals("MERCURY_EXPORT_ERROR")) { toast("Не удалось подготовить экспорт");return true; }
                if(!value.startsWith("MERCURY_EXPORT:"))return false;
                try {
                    JSONObject data=new JSONObject(value.substring(15));
                    if(data.getString("data").length()>12000000)throw new Exception();
                    pendingExport=Base64.decode(data.getString("data"),Base64.DEFAULT);
                    String name=data.optString("name","mercury-export.json").replaceAll("[^A-Za-z0-9._-]","_");
                    Intent intent=new Intent(Intent.ACTION_CREATE_DOCUMENT);
                    intent.addCategory(Intent.CATEGORY_OPENABLE);intent.setType("application/json");
                    intent.putExtra(Intent.EXTRA_TITLE,name);
                    startActivityForResult(intent,FILE_EXPORT);
                } catch(Exception e) { pendingExport=null;toast("Экспорт не удался"); }
                return true;
            }
        });
        loadGame();
    }
    private int dp(int value) { return Math.round(value*getResources().getDisplayMetrics().density); }
    private boolean trusted(String url) {
        if(url==null)return false;
        Uri u=Uri.parse(url);
        return "https".equals(u.getScheme()) && "mercurypolice.com".equals(u.getHost()) && (u.getPort()==-1||u.getPort()==443) && u.getPath()!=null && u.getPath().startsWith("/game/");
    }
    private String decode(String value) {
        try { return new org.json.JSONArray("["+value+"]").getString(0); } catch(Exception e) { return ""; }
    }
    private void toast(String value) { Toast.makeText(this,value,Toast.LENGTH_LONG).show(); }
    private void loadGame() {
        error.setVisibility(View.GONE);
        web.loadUrl(GAME+"?app=android&reload="+System.currentTimeMillis());
    }
    private void saveThenReload() {
        if(!trusted(web.getUrl())) { loadGame();return; }
        web.evaluateJavascript("(()=>{document.getElementById('saveBtn')?.click();return document.getElementById('toast')?.textContent==='Смена сохранена на этом устройстве';})()",value -> {
            if("true".equals(value))loadGame();
            else new AlertDialog.Builder(this).setTitle("Сохранение не найдено").setMessage("Продолжить перезагрузку игры?").setPositiveButton("Перезагрузить",(d,w)->loadGame()).setNegativeButton("Остаться",null).show();
        });
    }
    private void showMenu() {
        new AlertDialog.Builder(this).setTitle("Mercury Response · Android 0.1.0")
            .setItems(new String[]{"Проверить обновление игры","Сохранить и перезагрузить","Полный экран","О приложении"},(dialog,which)->{
                if(which==0)checkVersion(true);
                if(which==1)new AlertDialog.Builder(this).setMessage("Сохранить смену и загрузить текущую версию с сайта?").setPositiveButton("Обновить",(d,w)->saveThenReload()).setNegativeButton("Отмена",null).show();
                if(which==2){toolbar.setVisibility(View.GONE);fullscreen(true);toast("Кнопка Назад вернёт меню");}
                if(which==3)new AlertDialog.Builder(this).setTitle("Mercury Response").setMessage("Android-оболочка 0.1.0\nИгра: "+currentVersion+"\n\nИгровые обновления загружаются с mercurypolice.com/game/. Для запуска нужен интернет. Сохранения хранятся в приложении; удаление приложения удалит их. Перенос из браузера: Отчёт → экспорт / импорт.\n\nAPK-оболочка обновляется отдельной установкой. Обёртка не меняет производительность игрового движка.").setPositiveButton("Понятно",null).show();
            }).show();
    }
    private void checkVersion(boolean manual) {
        if(checking||destroyed)return;
        checking=true;
        network.execute(()->{
            String found="";boolean ok=false;
            HttpURLConnection connection=null;
            try {
                connection=(HttpURLConnection)new URL(GAME+"index.html?android-version="+System.currentTimeMillis()).openConnection();
                connection.setConnectTimeout(12000);connection.setReadTimeout(12000);
                connection.setRequestProperty("Cache-Control","no-cache");connection.setInstanceFollowRedirects(false);
                if(connection.getResponseCode()!=200)throw new Exception();
                ByteArrayOutputStream bytes=new ByteArrayOutputStream();
                try(InputStream in=connection.getInputStream()) {
                    byte[] buffer=new byte[4096];int n;
                    while((n=in.read(buffer))!=-1) { if(bytes.size()+n>262144)throw new Exception();bytes.write(buffer,0,n); }
                }
                Matcher matcher=Pattern.compile("ПРОТОТИП\\s+([0-9]+\\.[0-9]+\\.[0-9]+(?:-[A-Za-z0-9.]+)?)").matcher(new String(bytes.toByteArray(),StandardCharsets.UTF_8));
                if(matcher.find()){found=matcher.group(1);ok=true;}
            } catch(Exception ignored) {} finally { if(connection!=null)connection.disconnect(); }
            final String version=found;final boolean success=ok;
            handler.post(()->{
                checking=false;
                if(destroyed||!foreground)return;
                if(!success){if(manual)toast("Сервер недоступен. Текущая смена продолжается.");return;}
                if(!currentVersion.isEmpty()&&!version.equals(currentVersion)) {
                    if(manual || !version.equals(offeredVersion)) {
                        offeredVersion=version;
                        new AlertDialog.Builder(this).setTitle("Доступна игра "+version).setMessage("Сохранить смену и загрузить обновление? Можно продолжить текущую игру.").setPositiveButton("Обновить",(d,w)->saveThenReload()).setNegativeButton("Позже",null).show();
                    }
                } else if(manual)toast("Установлена текущая веб-версия"+(version.isEmpty()?"":" "+version));
            });
        });
    }
    private void fullscreen(boolean active) {
        if(Build.VERSION.SDK_INT>=30) {
            WindowInsetsController control=getWindow().getInsetsController();
            if(control!=null){control.setSystemBarsBehavior(WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);if(active)control.hide(WindowInsets.Type.systemBars());else control.show(WindowInsets.Type.systemBars());}
        } else getWindow().getDecorView().setSystemUiVisibility(active?5894:0);
    }
    @Override public void onBackPressed() {
        if(custom!=null){web.getWebChromeClient().onHideCustomView();return;}
        if(toolbar.getVisibility()!=View.VISIBLE){toolbar.setVisibility(View.VISIBLE);fullscreen(false);return;}
        web.evaluateJavascript("(()=>{const d=document.querySelector('dialog[open]');if(d){document.getElementById('closeModal')?.click();return true;}return false;})()",value->{
            if("true".equals(value))return;
            if(web.canGoBack())web.goBack();else new AlertDialog.Builder(this).setMessage("Сохранить смену и закрыть приложение?").setPositiveButton("Закрыть",(d,w)->web.evaluateJavascript("document.getElementById('saveBtn')?.click()",v->finish())).setNegativeButton("Играть",null).show();
        });
    }
    @Override protected void onActivityResult(int request,int result,Intent intent) {
        super.onActivityResult(request,result,intent);
        if(request==FILE_UPLOAD&&fileCallback!=null) {
            fileCallback.onReceiveValue(result==RESULT_OK&&intent!=null&&intent.getData()!=null?new Uri[]{intent.getData()}:null);fileCallback=null;
        }
        if(request==FILE_EXPORT) {
            if(result==RESULT_OK&&intent!=null&&intent.getData()!=null&&pendingExport!=null) {
                try(OutputStream output=getContentResolver().openOutputStream(intent.getData())) {if(output==null)throw new Exception();output.write(pendingExport);toast("Файл сохранён");}catch(Exception e){toast("Не удалось сохранить файл");}
            }
            pendingExport=null;
        }
    }
    @Override protected void onResume() {
        super.onResume();foreground=true;if(web!=null)web.onResume();handler.removeCallbacks(periodic);handler.postDelayed(periodic,60000);
    }
    @Override protected void onPause() {
        foreground=false;handler.removeCallbacks(periodic);
        if(web!=null){if(trusted(web.getUrl()))web.evaluateJavascript("document.getElementById('saveBtn')?.click()",null);web.onPause();}
        super.onPause();
    }
    @Override protected void onDestroy() {
        destroyed=true;handler.removeCallbacksAndMessages(null);network.shutdownNow();
        if(fileCallback!=null)fileCallback.onReceiveValue(null);
        if(web!=null){frame.removeView(web);web.destroy();}
        super.onDestroy();
    }
}
