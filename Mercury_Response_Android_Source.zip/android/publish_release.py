#!/usr/bin/env python3
"""Stage the signed complete-game APK and its public update feed for Sites publication."""
import argparse, hashlib, json, shutil, xml.etree.ElementTree as ET
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--dist',type=Path,required=True);p.add_argument('--apk',type=Path);args=p.parse_args()
root=Path(__file__).resolve().parent
manifest=ET.parse(root/'AndroidManifest.xml').getroot();ns='{http://schemas.android.com/apk/res/android}'
name=manifest.attrib[ns+'versionName'];code=int(manifest.attrib[ns+'versionCode'])
apk=args.apk or root/f'Mercury_Response_{name}.apk'
sub= args.dist/'downloads'/'android';sub.mkdir(parents=True,exist_ok=True)
previous=sub/'update.json'
if previous.exists():
    old=json.loads(previous.read_text())
    if int(old['versionCode'])>code:raise SystemExit('Refusing version rollback')
file=sub/apk.name
if apk.resolve()!=file.resolve():shutil.copyfile(apk,file)
feed={'package':'com.mercurypolice.response','versionCode':code,'versionName':name,'gameVersion':'0.6.0-a','url':'https://meridian-watch.osminoog09.chatgpt.site/downloads/android/'+file.name,'bytes':file.stat().st_size,'sha256':hashlib.sha256(file.read_bytes()).hexdigest(),'notes':'Игра включена в APK; автоматическое скачивание полных обновлений.'}
previous.write_text(json.dumps(feed,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(feed,ensure_ascii=False))
