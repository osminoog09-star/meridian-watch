#!/usr/bin/env python3
"""Runtime asset closure for the APK (Claude, 11.10.2026).

The Android shell serves any file under assets/game/, but the game itself only loads
index.html, the files it references and the static/dynamic ES-module import graph that
starts there. Developer pages (audits, prototypes, map notes, roadmap) are not part of the
game and some still carry real place names, which the owner does not want shipped.

Usage: python3 android/runtime_assets.py [dist]   -> prints the closure, one name per line.
"""
import re, sys
from pathlib import Path

HTML_REF = re.compile(r'''(?:src|href)\s*=\s*["']([^"'#?]+)''')
JS_IMPORT = re.compile(r'''(?:\bimport\b|\bexport\b)[^'"]*?\bfrom\s*['"](\./[^'"]+)['"]|\bimport\s*['"](\./[^'"]+)['"]|\bimport\(\s*['"](\./[^'"]+)['"]\s*\)''')
CSS_URL = re.compile(r'''url\(\s*['"]?(?!data:|https?:)([^'")]+)''')


def closure(dist):
    dist = Path(dist)
    seen, queue = set(), ['index.html']
    while queue:
        name = queue.pop()
        if name in seen:
            continue
        path = dist / name
        if not path.is_file():
            raise FileNotFoundError(f'runtime asset referenced but missing: {name}')
        seen.add(name)
        text = path.read_text(encoding='utf-8', errors='replace') if path.suffix in {'.html', '.js', '.css'} else ''
        refs = []
        if path.suffix == '.html':
            refs = [r for r in HTML_REF.findall(text) if not re.match(r'^(?:[a-z]+:|//)', r)]
        elif path.suffix == '.js':
            refs = [next(g for g in m if g) for m in JS_IMPORT.findall(text)]
        elif path.suffix == '.css':
            refs = CSS_URL.findall(text)
        for ref in refs:
            ref = ref.removeprefix('./')
            if '/' in ref or ref.startswith('..'):
                continue  # only flat dist/ assets are packaged
            if not (dist / ref).is_file():
                raise FileNotFoundError(f'{name} references a missing runtime asset: {ref}')
            queue.append(ref)
    return sorted(seen)


if __name__ == '__main__':
    for name in closure(sys.argv[1] if len(sys.argv) > 1 else Path(__file__).resolve().parent.parent / 'dist'):
        print(name)
