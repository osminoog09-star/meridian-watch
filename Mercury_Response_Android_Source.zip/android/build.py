#!/usr/bin/env python3
"""Build the signed APK using official Android SDK tools."""
import os, subprocess, zipfile
from pathlib import Path
root = Path(__file__).resolve().parent
sdk = Path(os.environ['ANDROID_SDK_ROOT'])
tools = sdk / 'build-tools' / os.environ.get('ANDROID_BUILD_TOOLS', '35.0.0')
platform = sdk / 'platforms' / 'android-35' / 'android.jar'
build = root / 'build'
classes = build / 'classes'
classes.mkdir(parents=True, exist_ok=True)
def run(*args):
    subprocess.run([str(a) for a in args], check=True)
sources = sorted((root / 'src').rglob('*.java'))
boot = str(platform) + os.pathsep + str(tools / 'core-lambda-stubs.jar')
if os.environ.get('ECJ_JAR'):
    run('java', '-jar', os.environ['ECJ_JAR'], '-encoding', 'UTF-8', '-source', '8', '-target', '8', '-bootclasspath', boot, '-d', classes, *sources)
else:
    run('javac', '-encoding', 'UTF-8', '-source', '8', '-target', '8', '-bootclasspath', boot, '-d', classes, *sources)
run(tools / 'aapt2', 'compile', '--dir', root / 'res', '-o', build / 'resources.zip')
run(tools / 'aapt2', 'link', '-o', build / 'unsigned.apk', '--manifest', root / 'AndroidManifest.xml', '-I', platform, build / 'resources.zip')
run(tools / 'd8', '--min-api', '26', '--lib', platform, '--output', build, *sorted(classes.rglob('*.class')))
with zipfile.ZipFile(build / 'unsigned.apk', 'a', zipfile.ZIP_DEFLATED) as apk:
    for dex in sorted(build.glob('classes*.dex')):
        apk.write(dex, dex.name)
run(tools / 'zipalign', '-f', '4', build / 'unsigned.apk', build / 'aligned.apk')
output = root / 'Mercury_Response_0.1.0.apk'
run(tools / 'apksigner', 'sign', '--ks', os.environ['MERCURY_KEYSTORE'], '--ks-key-alias', 'mercury-response', '--ks-pass', 'env:MERCURY_KEYSTORE_PASSWORD', '--key-pass', 'env:MERCURY_KEYSTORE_PASSWORD', '--out', output, build / 'aligned.apk')
run(tools / 'apksigner', 'verify', '--verbose', output)
run(tools / 'aapt2', 'dump', 'badging', output)
print(output)
