import test from 'node:test';import assert from 'node:assert/strict';
import {createGame,nextShift,serialize,deserialize,hireOfficer,createPatrol} from '../dist/sim.js';
import {shiftRecord,monthSummary,newAwards,emptyStats,monthOf,AWARDS,AWARD_REWARD,HISTORY_LIMIT} from '../dist/history.js';
// R14 «Итоги службы»: shift log, month results and awards (Claude, 11.10.2026).
const roll=(s,n,each=()=>{})=>{for(let k=0;k<n;k++){each(s);s.ended=true;s=nextShift(s);}return s;};

test('a shift record and a month summary add up',()=>{
 const s=createGame('career',7182,{schedule:'ppa'});s.resolved=20;s.missed=2;const r=shiftRecord(s,{tasks:3,drunk:1});
 assert.equal(r.shift,1);assert.equal(r.date,'12.10');assert.equal(r.kind,'day');assert.equal(r.resolved,20);assert.equal(r.tasks,3);
 const log=[r,{...r,shift:2,resolved:10,missed:0,trust:90},{...r,shift:3,month:r.month+1}];const m=monthSummary(log,r.month,'октябрь 2026');
 assert.equal(m.shifts,2);assert.equal(m.resolved,30);assert.equal(m.missed,2);assert.equal(m.rate,94);assert.equal(m.best.shift,1);assert.equal(monthSummary(log,999,'x'),null);
 assert.equal(monthOf(0).label,'октябрь 2026');
});

test('awards: month ones only at month end, one-off ones once, the clean month repeats',()=>{
 const stats={...emptyStats(),calls:120,drunk:3},s={trust:95};const ids=a=>a.map(x=>x.id);
 assert.deepEqual(ids(newAwards({s,stats,summary:null})),['calls-100']);
 const summary={shifts:12,missed:0};assert.deepEqual(ids(newAwards({s,stats,summary})).sort(),['calls-100','clean-month','first-month','trust-90'].sort());
 const had=[{id:'first-month'},{id:'clean-month'},{id:'trust-90'},{id:'calls-100'}];assert.deepEqual(ids(newAwards({s,stats,summary},had)),['clean-month'],'only the repeatable one again');
 assert.ok(AWARDS.every(a=>a.label&&a.about.length>20));
});

test('roster shifts build the log, close the month with results and pay the award',()=>{
 let s=createGame('career',7182,{schedule:'ppa'});const xp0=s.xp;
 s=roll(s,11,x=>{x.resolved=20;x.missed=0;});assert.equal(s.shiftLog.length,11);assert.equal(s.monthReport,undefined);assert.equal(s.stats.calls,220);
 assert.ok(s.awards.some(a=>a.id==='calls-100'));
 s=roll(s,1,x=>{x.resolved=20;x.missed=0;});assert.equal(monthOf(s.shift-1).label,'ноябрь 2026');
 assert.equal(s.monthReport.label,'октябрь 2026');assert.equal(s.monthReport.shifts,12);assert.equal(s.monthReport.rate,100);
 for(const id of ['first-month','clean-month'])assert.ok(s.awards.some(a=>a.id===id&&a.month==='октябрь 2026'),id);
 assert.ok(s.xp>=xp0+AWARD_REWARD.xp*3,'awards add experience in a career');assert.ok(s.logs.some(l=>/Итоги месяца/.test(l.text)));
 const back=deserialize(serialize(s));assert.equal(back.shiftLog.length,12);
 const bad=JSON.parse(serialize(s));bad.awards.push({id:'medal-of-nothing',shift:1});assert.throws(()=>deserialize(JSON.stringify(bad)));
 const bad2=JSON.parse(serialize(s));bad2.shiftLog[0].resolved=-1;assert.throws(()=>deserialize(JSON.stringify(bad2)));
});

test('a chief gets a budget bonus, the log is bounded, old campaigns keep no log',()=>{
 let s=createGame('chief',7182,{schedule:'ppa'});hireOfficer(s,1);hireOfficer(s,2);createPatrol(s,s.officers[0].id,s.officers[1].id,1);
 s=roll(s,11,x=>{x.resolved=12;});const before=s.budget;s=roll(s,1,x=>{x.resolved=12;});
 assert.ok(s.awards.some(a=>a.id==='first-month'));assert.ok(s.logs.some(l=>/Награда: Первый месяц/.test(l.text)));void before;
 assert.ok(s.finance.opening===s.budget);
 const long=createGame('career',7182,{schedule:'ppa'});long.shiftLog=Array.from({length:HISTORY_LIMIT},(_,k)=>({...shiftRecord(long),shift:k+1}));long.ended=true;assert.equal(nextShift(long).shiftLog.length,HISTORY_LIMIT);
 let legacy=createGame('career',7182);legacy=roll(legacy,2);assert.equal(legacy.shiftLog,undefined);assert.equal(legacy.awards,undefined);
});
