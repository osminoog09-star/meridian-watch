import test from 'node:test';import assert from 'node:assert/strict';
import {cityGrant,GRANT_RULES} from '../dist/economy.js';import {createGame,nextShift,financialSummary,transact} from '../dist/sim.js';
// 0.6.2: city funding by trust, district complaints, no dead-end campaign.
test('grant follows trust within limits and neglected districts cost extra',()=>{
 const at=(trust,districts)=>cityGrant({trust,districts}).total;
 assert.equal(at(60),0);assert.equal(at(80),100);assert.equal(at(100),GRANT_RULES.max);assert.equal(cityGrant({trust:0}).trustPart,GRANT_RULES.min);assert.equal(cityGrant({trust:0}).total,GRANT_RULES.min-100);
 const g=cityGrant({trust:80,districts:{centre:30,ulejoe:35,raama:80}});assert.equal(g.penalty,-50);assert.equal(g.total,50);assert.match(g.lines[1],/Жалобы жителей/);
});
test('next shift books the grant as its own line and the report forecasts it',()=>{
 const s=createGame();s.trust=90;const fin=financialSummary(s);assert.equal(fin.grant,150);const n=nextShift(s);
 const entry=n.previousReport.finance;assert.ok(entry.income>=150);assert.equal(n.budget,s.budget+150-240);
});
test('low trust and an empty budget never strand the campaign',()=>{
 const s=createGame();s.trust=5;transact(s,-s.budget,'test','Расход');const n=nextShift(s);assert.equal(n.budget,0);assert.ok(n.budget>=0);
 assert.ok(financialSummary(n).balance>=0);
});
