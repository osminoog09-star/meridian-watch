import test from 'node:test';import assert from 'node:assert/strict';
import {createGame,spawnIncident,tick,serialize,deserialize,nextShift} from '../dist/sim.js';
import {CASE_LIMIT,custodyFor} from '../dist/calls.js';
import {NODES} from '../dist/geography.js';
// 0.7.0 step 3: «Дела смены» — every closed call leaves a bounded case record.

function solve(variant,want=()=>true){
 for(let seed=1;seed<80;seed++){const s=createGame();s.seed=seed;s.nextIncident=9000;const anchor=NODES[(seed*7)%NODES.length];
  const i=spawnIncident(s,null,{variant,point:{x:anchor.x,y:anchor.y}});
  for(let k=0;k<6000&&!['resolved','missed'].includes(i.state);k++)tick(s,.1);
  if(['resolved','missed'].includes(i.state)&&want(i))return {s,i};}
 return null;
}

test('a closed call is filed with name, district, decision and status',()=>{
 const r=solve('noise-flat');assert.ok(r);const {s,i}=r;const c=s.cases?.find(x=>x.id===i.id);assert.ok(c,'case recorded');
 assert.equal(typeof c.name,'string');assert.ok(c.name.length>0);assert.equal(typeof c.district,'string');assert.equal(c.success,i.state==='resolved');
 assert.equal(typeof c.status,'string');if(!c.success)assert.equal(c.status,'Не раскрыто');
 assert.ok(c.outcome.length<=160);
});

test('an arrest case is marked as handed over after the report',()=>{
 const r=solve('street-fight',i=>i.state==='resolved'&&custodyFor(i.variant,i.decision));assert.ok(r);const {s,i}=r;
 const c=s.cases.find(x=>x.id===i.id);assert.equal(c.custody,'arrest');assert.equal(c.status,'Задержанный в пути в участок');
 const u=s.units.find(x=>x.transport?.from===i.id);assert.ok(u);
 for(let k=0;k<20000&&u.transport;k++)tick(s,.1);assert.equal(u.transport,null);assert.equal(c.status,'Передано дежурному');
});

test('cases survive save/load, bad records are rejected, list is bounded and resets next shift',()=>{
 const r=solve('noise-flat');assert.ok(r);const {s}=r;
 const n=deserialize(serialize(s));assert.deepEqual(n.cases,s.cases);
 const bad=JSON.parse(serialize(s));bad.cases[0].status=42;assert.throws(()=>deserialize(JSON.stringify(bad)));
 const old=JSON.parse(serialize(s));delete old.cases;assert.doesNotThrow(()=>deserialize(JSON.stringify(old)),'old saves without cases still load');
 const big=JSON.parse(serialize(s));big.cases=Array.from({length:CASE_LIMIT+1},()=>({...s.cases[0]}));assert.throws(()=>deserialize(JSON.stringify(big)));
 for(let k=0;k<CASE_LIMIT+5;k++){const i=spawnIncident(s,0);i.state='onscene';}
 for(let k=0;k<6000&&s.incidents.some(i=>!['resolved','missed'].includes(i.state));k++)tick(s,.1);
 assert.ok(s.cases.length<=CASE_LIMIT);
 s.ended=true;assert.equal(nextShift(s).cases,undefined);
});
