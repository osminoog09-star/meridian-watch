import test from 'node:test';import assert from 'node:assert/strict';
import {createGame,tick,nextShift,serialize,deserialize,spawnIncident,assign,unitReason} from '../dist/sim.js';
import {ROUTINE,briefingFor} from '../dist/routine.js';
import {NODES} from '../dist/geography.js';
// R2 «Распорядок смены»: briefing with lookouts, vehicle acceptance, meal break, reports.

const roster=()=>createGame('career',7182,{schedule:'ppa'});

test('a roster shift starts with a briefing and two lookouts; legacy shifts do not',()=>{
 const s=roster();assert.ok(s.units.every(u=>u.status==='briefing'));assert.equal(s.bolo.length,2);assert.notEqual(s.bolo[0].variant,s.bolo[1].variant);
 assert.deepEqual(briefingFor(7182,1),briefingFor(7182,1));assert.match(unitReason(s,s.units[0]),/Инструктаж/);
 assert.ok(s.logs.some(l=>/Инструктаж: ориентировки/.test(l.text)));
 for(let k=0;k<ROUTINE.briefing*10+5;k++)tick(s,.1);assert.ok(s.units.every(u=>u.status!=='briefing'));
 assert.ok(s.logs.some(l=>/машина принята|приёмка машины/.test(l.text)));
 const legacy=createGame();assert.equal(legacy.bolo,undefined);assert.ok(legacy.units.every(u=>u.status==='patrol'));
});

test('half-empty tank at acceptance: refuel before patrol',()=>{
 const s=roster();const v=s.vehicles.find(x=>x.id===s.units[0].vehicleId);v.fuel=20;
 for(let k=0;k<ROUTINE.briefing*10+5;k++)tick(s,.1);assert.equal(s.units[0].status,'servicing');assert.equal(v.service.kind,'fuel');
});

test('meal break in a calm moment, interrupted by an urgent call, and reports at the end',()=>{
 const s=roster();s.nextIncident=9000;for(let k=0;k<ROUTINE.mealFrom*10+20&&!s.units.some(u=>u.status==='break');k++)tick(s,.1);
 const u=s.units.find(x=>x.status==='break');assert.ok(u,'someone takes the meal break');const before=Math.max(...u.officerIds.map(id=>s.officers.find(o=>o.id===id).fatigue));
 for(let k=0;k<100;k++)tick(s,.1);const after=Math.max(...u.officerIds.map(id=>s.officers.find(o=>o.id===id).fatigue));assert.ok(after<before,'the break restores');
 spawnIncident(s,4);tick(s,.1);assert.notEqual(u.status,'break','urgent call interrupts the meal');assert.equal(u.mealDone,true);
 assert.doesNotThrow(()=>deserialize(serialize(s)));
 for(let k=0;k<9700&&!s.ended;k++)tick(s,.1);assert.ok(s.logs.some(l=>/рапорты/.test(l.text))||s.units.some(x=>x.status==='reports'));
});

test('a lookout matches the first call of its kind: faster work and trust',()=>{
 const s=roster();s.nextIncident=9000;for(let k=0;k<ROUTINE.briefing*10+5;k++)tick(s,.1);const b=s.bolo[0];const n=NODES[30];
 const i=spawnIncident(s,null,{variant:b.variant,point:{x:n.x,y:n.y}});assert.equal(i.bolo,b.id);assert.equal(b.matched,i.id);
 const j=spawnIncident(s,null,{variant:b.variant,point:{x:n.x,y:n.y}});assert.equal(j.bolo,undefined,'only the first matching call');
 const bad=JSON.parse(serialize(s));bad.bolo[0].matched='x';assert.throws(()=>deserialize(JSON.stringify(bad)));
});

test('the player can interrupt the routine with a direct order',()=>{
 const s=roster();s.nextIncident=9000;const n=NODES[25];const i=spawnIncident(s,null,{variant:'noise-flat',point:{x:n.x,y:n.y}});
 assert.equal(s.units[0].status,'briefing');assert.equal(assign(s,1,i.id),true);assert.equal(s.units[0].incident,i.id);assert.ok(s.logs.some(l=>/прерываем инструктаж/.test(l.text)));
 const next=nextShift((()=>{s.ended=true;return s;})());assert.ok(next.units.every(u=>u.status==='briefing'));assert.equal(next.bolo.length,2);
});
