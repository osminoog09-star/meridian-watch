import test from 'node:test';import assert from 'node:assert/strict';
import {createGame,tick,nextShift,serialize,deserialize,hireOfficer,createPatrol,changeCrew,setOfficerDuty,sendToCourse,requestTransfer,buyPersonal,shiftWages,reserveOfficers,repairVehicle,buyUpgrade,startPatrolTask,setRole} from '../dist/sim.js';
import {DUTY,onDuty,dutyWage,STAFF_COURSES,studyBlocker,knows,PURCHASES,purchaseBlocker,TRANSFER,WORKSHOP,validService2} from '../dist/service2.js';
import {crewFits} from '../dist/calls.js';
import {ROLES,COURSES,roleBlocker,LIVING} from '../dist/life.js';
import {shiftKind} from '../dist/schedule.js';
import {UPGRADES} from '../dist/upgrades.js';
// Release C2 «Служба 2.1» (Claude, 12.10.2026).
const skip=s=>{s.ended=true;return nextShift(s);};
function chief(n=6){const s=createGame('chief',4242,{schedule:'ppa'});for(const c of [...s.candidates].slice(0,n))hireOfficer(s,c.id);createPatrol(s,s.officers[0].id,s.officers[1].id,1);createPatrol(s,s.officers[2].id,s.officers[3].id,2);s.setupPending=false;return s;}

test('duty plan: days-only skips nights, light duty rests every fourth shift, pay follows the plan',()=>{
 const o={id:3,salary:40};assert.ok(onDuty(o,0,'night'));assert.equal(onDuty({...o,duty:'days'},2,'night'),false);assert.ok(onDuty({...o,duty:'days'},0,'day'));
 const light=[0,1,2,3,4,5,6,7].filter(k=>!onDuty({...o,duty:'light'},k,'day'));assert.equal(light.length,2,'two shifts of eight');
 assert.equal(dutyWage({...o,duty:'light'},1),30);assert.equal(dutyWage({...o,duty:'days'},1.2),40);assert.equal(dutyWage(o,1.2),48);
 const s=chief();const before=shiftWages(s);assert.equal(setOfficerDuty(s,s.officers[0].id,'light').ok,true);assert.ok(shiftWages(s)<before);
 assert.equal(setOfficerDuty(s,s.officers[0].id,'full').ok,true);assert.equal(s.officers[0].duty,undefined,'full is the default');assert.equal(shiftWages(s),before);
 assert.equal(setOfficerDuty(s,999,'days').ok,false);assert.equal(setOfficerDuty(createGame('chief',1),1,'days').ok,false,'roster campaigns only');
});

test('officers off today are covered from the reserve; the home crew comes back next shift',()=>{
 let s=chief(),cover=0,back=0;const a=s.officers[0];setOfficerDuty(s,a.id,'days');
 for(let k=0;k<8;k++){s=skip(s);const u=s.units.find(x=>x.id===1),night=shiftKind(s.shift-1)==='night';
  if(night){assert.ok(!u.officerIds.includes(a.id),'not on nights');assert.deepEqual(u.homeCrew,[a.id,s.officers[1].id]);assert.equal(u.officerIds.length,2,'covered from the reserve');cover++;}
  else{assert.ok(u.officerIds.includes(a.id),'back on days');assert.equal(u.homeCrew,undefined);back++;}
  assert.ok(validService2(s));deserialize(serialize(s));}
 assert.ok(cover>=2&&back>=2);
});

test('without a reserve the crew goes out alone, and with nobody left the officer is called in',()=>{
 let s=chief(4);const [a,b]=s.officers;setOfficerDuty(s,a.id,'days');for(let k=0;k<8&&shiftKind(s.shift-1)!=='night';k++)s=skip(s);
 assert.equal(shiftKind(s.shift-1),'night');assert.deepEqual(s.units.find(x=>x.id===1).officerIds,[b.id],'alone');
 let t=chief(4);setOfficerDuty(t,t.officers[0].id,'days');setOfficerDuty(t,t.officers[1].id,'days');let called=false;
 for(let k=0;k<8&&!called;k++){t=skip(t);if(shiftKind(t.shift-1)==='night'){const v=t.units.find(x=>x.id===1);assert.equal(v.officerIds.length,1,'one is called in');called=true;}}assert.ok(called);
});

test('a manual crew change during the shift is kept (no stale home crew)',()=>{
 let s=chief();setOfficerDuty(s,s.officers[0].id,'days');for(let k=0;k<8;k++){s=skip(s);if(s.units[0].homeCrew)break;}const u=s.units[0];assert.ok(u.homeCrew);
 for(let k=0;k<400&&!['patrol','idle'].includes(u.status);k++)tick(s,.1);const free=reserveOfficers(s)[0];const r=changeCrew(s,u.id,u.officerIds[1],free.id);assert.equal(r.ok,true,r.message);assert.equal(u.homeCrew,undefined);const crew=[...u.officerIds];const n=skip(s);assert.deepEqual(n.units[0].officerIds.filter(id=>crew.includes(id)).length>=1,true);assert.ok(n.units[0].officerIds.includes(free.id)||n.units[0].homeCrew?.includes(free.id),'the chief\'s choice stands, not the old home crew');
});

test('staff training: from the reserve, costs money, takes shifts, gives a second specialty or skill',()=>{
 let s=chief();s.budget=5000;const r=s.officers.find(o=>!s.units.some(u=>u.officerIds.includes(o.id))),inCrew=s.officers[0];
 assert.match(studyBlocker(s,inCrew,'search'),/резерв/);const course=Object.keys(STAFF_COURSES).find(id=>STAFF_COURSES[id].key&&!knows(r,STAFF_COURSES[id].key));
 const budget=s.budget;assert.equal(sendToCourse(s,r.id,course).ok,true);assert.equal(s.budget,budget-STAFF_COURSES[course].price);assert.equal(sendToCourse(s,r.id,'skill').ok,false,'one course at a time');
 assert.ok(!reserveOfficers(s).some(o=>o.id===r.id),'not available while studying');assert.equal(createPatrol(s,r.id,null,s.vehicles.at(-1).id).ok,false);
 for(let k=0;k<STAFF_COURSES[course].shifts;k++)s=skip(s);const o=s.officers.find(x=>x.id===r.id);assert.equal(o.study,undefined);assert.ok(o.extra.includes(STAFF_COURSES[course].key));
 assert.ok(crewFits([o],{negotiation:0,search:2,traffic:1,investigation:3}[STAFF_COURSES[course].key]),'the second specialty counts for the crew');
 const sk=o.skill;assert.equal(sendToCourse(s,o.id,'skill').ok,true);s=skip(s);assert.ok(s.officers.find(x=>x.id===o.id).skill>sk);
 assert.equal(sendToCourse(s,o.id,course).ok,false,'already known');assert.ok(validService2(s));deserialize(serialize(s));
});

test('workshop: repairs cheaper and faster, cars serviced between shifts',()=>{
 assert.ok(UPGRADES.workshop);let s=chief();s.budget=20000;const v=s.vehicles[0];v.wear=40;const plain=chief();plain.budget=20000;plain.vehicles[0].wear=40;
 const b0=plain.budget;repairVehicle(plain,plain.vehicles[0].id);const full=b0-plain.budget;assert.equal(buyUpgrade(s,'workshop').ok,true);const b1=s.budget;repairVehicle(s,v.id);assert.equal(b1-s.budget,Math.round(full*WORKSHOP.repairCost));
 assert.ok(s.vehicles[0].service.left<plain.vehicles[0].service.left);
 const t=chief();t.budget=20000;buyUpgrade(t,'workshop');t.vehicles[1].wear=30;const u=chief();u.vehicles[1].wear=30;assert.ok(skip(t).vehicles[1].wear<skip(u).vehicles[1].wear);
});

test('career transfer: a request, three shifts of waiting, refused after a D attestation; road police',()=>{
 assert.ok(ROLES.traffic&&COURSES.traffic);let s=createGame('career',4242,{schedule:'ppa'});s.rank=1;assert.match(requestTransfer(s,'traffic').message,/курс/);s.life.courses.traffic=s.shift;
 assert.equal(requestTransfer(s,'traffic').ok,true);assert.equal(s.life.role??null,null,'not yet');const ready=s.life.transfer.ready;assert.equal(ready,s.shift+TRANSFER.wait);
 for(let k=0;k<TRANSFER.wait&&s.shift<ready;k++){s=skip(s);s.rank=1;}assert.equal(s.life.role,'traffic');
 let d=createGame('career',4242,{schedule:'ppa'});d.rank=1;d.life.courses.traffic=1;d.life.attestations=[{grade:'D',score:40,label:'x'}];requestTransfer(d,'traffic');for(let k=0;k<TRANSFER.wait;k++){d=skip(d);d.rank=1;}assert.equal(d.life.role??null,null,'refused');assert.equal(d.life.transfer,null);
 assert.equal(requestTransfer(s,null).ok,true);assert.equal(s.life.role,null,'back to patrol at once');
 assert.equal(requestTransfer(createGame('chief',1,{schedule:'ppa'}),'traffic').ok,false);
});

test('road police find more on raids',()=>{
 const run=role=>{const s=createGame('career',4242,{schedule:'ppa'});s.rank=1;if(role){s.life.courses.traffic=1;setRole(s,role);}const u=s.units[0];u.auto=false;s.nextIncident=9000;for(let k=0;k<300;k++)tick(s,.1);
  const r=startPatrolTask(s,1,'speed-check');if(!r.ok)return null;for(let k=0;k<6000&&u.task;k++)tick(s,.1);const done=(s.patrolDone??s.tasksDone??[]);return s;};
 const a=run(null),b=run('traffic');assert.ok(a&&b);const found=s=>JSON.stringify(s.logs.map(l=>l.text).filter(t=>/протоколов за превышение/.test(t)));const n=x=>+(found(x).match(/превышение: (\d+)/)?.[1]??-1);
 assert.ok(n(b)>n(a)&&n(a)>=0,`${n(a)} → ${n(b)}`);
});

test('personal goals: buy with savings, a flat lowers the monthly costs, the car shortens the commute',()=>{
 let s=createGame('career',4242,{schedule:'ppa'});assert.match(purchaseBlocker(s.life,'car'),/Нужно/);s.life.money=25000;
 assert.equal(buyPersonal(s,'apartment').ok,true);assert.equal(s.life.money,25000-PURCHASES.apartment.price);assert.equal(buyPersonal(s,'apartment').ok,false);assert.equal(buyPersonal(s,'car').ok,true);
 let paid=null;for(let k=0;k<40&&paid===null;k++){const m=s.life.money;s.life.sleepDebt=50;const n=skip(s);if(n.logs.some(l=>/Ипотека/.test(l.text)))paid=true;else{assert.ok(n.life.sleepDebt<=50+40,'');}s=n;}assert.ok(paid,'monthly costs now as a mortgage');
 assert.ok(PURCHASES.apartment.living<LIVING.monthly);assert.ok(validService2(s));deserialize(serialize(s));
 const bad=JSON.parse(serialize(s));bad.life.owned={yacht:true};assert.throws(()=>deserialize(JSON.stringify(bad)));
});
