import test from 'node:test';import assert from 'node:assert/strict';
import {createAudio} from '../dist/audio.js';
import {transportTone,sirenMode,SIREN_MODES,YELP_METRES,weatherSound,fireworksTime,fireworkBurst} from '../dist/audio-design.js';
import {dateOf} from '../dist/season.js';
// R11 «Звук службы» (Claude, 11.10.2026): siren modes, weather in sound, New Year fireworks.
function fake(){const nodes=[];let osc=0,sources=0;const param=()=>({value:0,setTargetAtTime(v){this.value=v},setValueAtTime(v){this.value=v},linearRampToValueAtTime(v){this.value=v}});
 return {state:'suspended',currentTime:1,sampleRate:200,destination:{},nodes,get osc(){return osc},get sources(){return sources},createGain(){const n={gain:param(),connect(){},disconnect(){}};nodes.push(n);return n},createOscillator(){osc++;return {frequency:param(),connect(){},disconnect(){},start(){},stop(){}}},createBuffer:(_,len)=>({getChannelData:()=>new Float32Array(len)}),createBiquadFilter:()=>({frequency:{value:0},Q:{value:0},connect(){}}),createBufferSource(){sources++;return {connect(){},disconnect(){},start(){},stop(){}}},async resume(){this.state='running'},async suspend(){this.state='suspended'}};}
const state=()=>({shift:1,mode:'career',resolved:0,incidents:[],units:[{id:1,x:1.5,y:2.6,route:[{x:1.6,y:2.6}],status:'responding'}]});
const scene={x:1.504031,y:2.608911,zoom:22};

test('wail on open road, yelp in a pursuit and over the last 200 m',()=>{
 const u={route:[{}],status:'responding'};assert.equal(sirenMode(u),'wail');assert.equal(sirenMode(u,YELP_METRES-1),'yelp');assert.equal(sirenMode({...u,pursuing:true},5000),'yelp');
 const far=[],near=[];for(let t=0;t<1;t+=.05){far.push(transportTone(u,null,t,30,true,1000).sirenHz);near.push(transportTone(u,null,t,30,true,50).sirenHz);}
 const swings=a=>a.slice(1).filter((v,k)=>Math.sign(v-a[k])!==Math.sign(a[k]-(a[k-1]??a[k]))).length;assert.ok(swings(near)>swings(far),'yelp sweeps faster');
 for(const hz of near)assert.ok(hz>=700-SIREN_MODES.yelp.depth&&hz<=700+SIREN_MODES.yelp.depth);
 assert.equal(transportTone(u,null,0,30,true).sirenMode,'wail','default without distance is wail');
});

test('weather shapes the ambience: rain adds hiss, wind gusts, snow muffles traffic',()=>{
 assert.deepEqual(weatherSound('clear'),{rain:0,wind:1,traffic:1});assert.deepEqual(weatherSound(undefined),{rain:0,wind:1,traffic:1});
 assert.ok(weatherSound('rain').rain>0);assert.ok(weatherSound('wind').wind>1.5);assert.ok(weatherSound('snow').traffic<.6);
});

test('a rain channel appears only when it rains and silences on pause',async()=>{
 const ctx=fake(),a=createAudio({preferences:{enabled:true},createContext:()=>ctx}),s=state();await a.unlock();
 a.update(s,1,true,scene,{weather:'clear'});const before=ctx.nodes.length;a.update(s,1,true,scene,{weather:'rain'});assert.equal(ctx.nodes.length,before+1,'one extra gain for rain');
 const rain=ctx.nodes.at(-1);assert.ok(rain.gain.value>0);a.update(s,1,true,scene,{weather:'rain'});assert.equal(ctx.nodes.length,before+1,'created once');
 a.update(s,1,true,scene,{weather:'clear'});assert.equal(rain.gain.value,0);a.pause();assert.ok(ctx.nodes.every(n=>n.gain.value===0));
 const windy=fake(),b=createAudio({preferences:{enabled:true},createContext:()=>windy});await b.unlock();b.update(s,1,true,scene,{weather:'wind'});const clear=fake(),c=createAudio({preferences:{enabled:true},createContext:()=>clear});await c.unlock();c.update(s,1,true,scene,{weather:'clear'});
 assert.ok(b.channels().wind>c.channels().wind*1.5,'gusts are louder in wind');
});

test('fireworks only on New Year night and bursts are bounded',async()=>{
 const at=(m,d,min)=>({month:m,dayOfMonth:d,minute:min});
 assert.equal(fireworksTime(at(11,31,23*60+50)),true);assert.equal(fireworksTime(at(0,1,30)),true);assert.equal(fireworksTime(at(11,31,22*60)),false);assert.equal(fireworksTime(at(0,1,120)),false);assert.equal(fireworksTime(at(6,10,23*60+50)),false);assert.equal(fireworksTime(null),false);
 for(let n=0;n<50;n++){const b=fireworkBurst(n);assert.ok(b.gap>=.5&&b.gap<=2.7&&b.hz>=220&&b.hz<640);}assert.deepEqual(fireworkBurst(7),fireworkBurst(7));
 const abs=1440*(2+80)+23*60+50;assert.equal(dateOf(abs).month,11);assert.equal(dateOf(abs).dayOfMonth,31,'campaign day 80 is New Year’s Eve');
 const ctx=fake(),a=createAudio({preferences:{enabled:true},createContext:()=>ctx}),s=state();await a.unlock();const env={weather:'clear',date:at(11,31,23*60+55)};
 const src0=ctx.sources;a.update(s,1,true,scene,env);assert.equal(ctx.sources,src0+1,'a burst');a.update(s,1,true,scene,env);assert.equal(ctx.sources,src0+1,'waits for the gap');
 ctx.currentTime+=3;a.update(s,1,true,scene,env);assert.equal(ctx.sources,src0+2);
 ctx.currentTime+=3;a.update(s,1,true,scene,{weather:'clear',date:at(0,2,0)});assert.equal(ctx.sources,src0+2,'quiet on 2 January');
});

// R22: time and place in the sound, crowd at events, worn engines.
import {timeAmbience,birdCall,engineWobble} from '../dist/audio-design.js';
test('night streets are quiet, birds sing on spring days only, a crowd murmurs at events',()=>{
 const day={month:4,dayOfMonth:10,minute:8*60},night={...day,minute:3*60},winter={month:0,dayOfMonth:10,minute:12*60};
 assert.ok(timeAmbience(night).traffic<timeAmbience(day).traffic);assert.ok(timeAmbience(day).birds>0);assert.equal(timeAmbience(night).birds,0);assert.equal(timeAmbience(winter).birds,0);
 assert.equal(timeAmbience(day,'football').crowd,1);assert.equal(timeAmbience(day,'storm').crowd,0);assert.deepEqual(timeAmbience(null),{traffic:1,birds:0,crowd:0});
 for(let n=0;n<40;n++){const b=birdCall(n);assert.ok(b.gap>=2&&b.gap<=8&&b.to>b.from&&b.notes>=2);}
 assert.equal(engineWobble(0,1.3),1);let max=0;for(let t=0;t<10;t+=.01)max=Math.max(max,Math.abs(engineWobble(100,t)-1));assert.ok(max>.2&&max<=.35);
});
test('the crowd channel and birdsong come only with their time and place',async()=>{
 const ctx=fake(),a=createAudio({preferences:{enabled:true},createContext:()=>ctx}),s=state();await a.unlock();const near={...scene,zoom:12};
 const spring={month:4,dayOfMonth:10,minute:9*60};const n0=ctx.nodes.length;a.update(s,1,true,near,{weather:'clear',date:{...spring,minute:3*60}});assert.equal(ctx.nodes.length,n0,'no crowd, no birds at night');
 const osc0=ctx.osc;a.update(s,1,true,near,{weather:'clear',date:spring});assert.ok(ctx.osc>osc0,'a bird sings on a spring morning');
 a.update(s,1,true,near,{weather:'clear',date:spring,event:'football'});assert.equal(ctx.nodes.length>n0,true,'crowd channel added');
});
