import test from 'node:test';import assert from 'node:assert/strict';
import {createDeviceTest,formatDeviceReport,DEVICE_STAGES} from '../dist/device-test.js';
// «Проверка устройства»: scheduler and report are pure and deterministic.
function run(intervalFor){const stages=[];let done=null;const t=createDeviceTest({stageMs:1000,warmMs:200,onStage:s=>stages.push(s.id),onDone:r=>done=r});let now=0;t.start(now);
 for(let k=0;k<100000&&t.active();k++){now+=16;t.frame(now,(Math.floor(now/intervalFor(stages.at(-1)))!==Math.floor((now-16)/intervalFor(stages.at(-1)))));}return {stages,done};}
test('runs every stage in order and measures draw rate per stage',()=>{
 const {stages,done}=run(id=>id==='overview'?100:33);assert.deepEqual(stages,DEVICE_STAGES.map(s=>s.id));assert.equal(done.length,DEVICE_STAGES.length);
 const overview=done.find(r=>r.id==='overview'),centre=done.find(r=>r.id==='centre');assert.ok(overview.fps<12&&overview.fps>8,String(overview.fps));assert.ok(centre.fps>25);assert.ok(overview.p95Ms>=95);
});
test('stalls above 100 ms are counted and cancel stops the tour',()=>{const t=createDeviceTest({stageMs:1000,warmMs:0});t.start(0);t.frame(10,true);t.frame(300,true);t.frame(320,true);t.cancel();assert.equal(t.active(),false);
 const r=run(()=>150).done;assert.ok(r.every(x=>x.stalls>0));});
test('report text is copy-friendly and gives a verdict',()=>{const text=formatDeviceReport([{label:'Весь город',fps:40,p95Ms:30,worstMs:60,stalls:0},{label:'Центр',fps:12,p95Ms:120,worstMs:400,stalls:3}],{version:'ПРОТОТИП 0.6.0-c',width:904,height:1074,dpr:2.6,frameRate:30,quality:'models'});
 assert.match(text,/Весь город: 40 к\/с/);assert.match(text,/тормозит/);assert.ok(!/Pärnu|Пярну/.test(text));});
