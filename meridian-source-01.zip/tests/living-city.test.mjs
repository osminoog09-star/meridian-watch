import test from 'node:test';import assert from 'node:assert/strict';
import {placeAt,surfaceAt,impulseResponse,SPACES,CELL_METRES} from '../dist/acoustics.js';
import {footstepShape,FOOTSTEP,serviceSirenFrequency,SERVICE_SIREN,distanceCutoff,talkEnvelope,sceneRadioGap} from '../dist/sound-synth.js';
import {onlookersFor,crowdSize,streetFactor,crowdNear,ONLOOKERS} from '../dist/onlookers.js';
import {factsFor} from '../dist/dialogues.js';
import {createAudio,FAR_SIREN_METRES} from '../dist/audio.js';
import {NODES} from '../dist/geography.js';
import {MAP_METRES} from '../dist/world-scale.js';
// Release A «Живой город» — Claude's part (12.10.2026): sound of the place, other services, people at calls.
const node=id=>NODES.find(n=>n.id===id);

test('the map decides the place: dense centre echoes like a yard, the meadow is a park; weather decides the ground',()=>{
 const c=node('centre'),p=node('papiniidu');assert.equal(placeAt(c.x,c.y).space,'yard');assert.equal(placeAt(p.x,p.y).space,'park');
 assert.equal(placeAt(c.x,c.y),placeAt(c.x+1/MAP_METRES,c.y),'cached per cell');assert.equal(placeAt(NaN,1).space,'street');
 const kinds=new Set(NODES.map(n=>placeAt(n.x,n.y).space));assert.ok(kinds.size>=4,[...kinds].join());
 assert.equal(surfaceAt(placeAt(c.x,c.y),'snow'),'snow');assert.equal(surfaceAt(placeAt(c.x,c.y),'rain'),'wet');assert.equal(surfaceAt(placeAt(p.x,p.y),'clear'),'grass');assert.equal(surfaceAt(placeAt(c.x,c.y),'clear'),'asphalt');
 assert.ok(SPACES.yard.decay>SPACES.street.decay&&SPACES.street.decay>SPACES.park.decay&&SPACES.yard.wet>SPACES.park.wet);assert.ok(CELL_METRES>=20);
});

test('reverb: deterministic stereo impulse response that decays, longer in a yard',()=>{
 const [l,r]=impulseResponse(8000,'yard'),[l2]=impulseResponse(8000,'yard'),[p]=impulseResponse(8000,'park');
 assert.deepEqual(l,l2);assert.notDeepEqual(l,r,'two different channels');assert.equal(l.length,Math.round(8000*SPACES.yard.decay));assert.ok(p.length<l.length);
 const e=(a,b)=>{let s=0;for(let k=a;k<b;k++)s+=l[k]*l[k];return s;};assert.ok(e(l.length*.85|0,l.length)<e(0,l.length*.15|0)/50,'the tail dies away');
 assert.ok([...l].every(Number.isFinite)&&Math.max(...l.map(Math.abs))<=1.2);
});

test('footsteps by surface, ambulance and rescue tones, distance muffles, voices and portable radio stay bounded',()=>{
 const snow=footstepShape('snow',1),asphalt=footstepShape('asphalt',1);assert.ok(snow.shape.length>asphalt.shape.length&&snow.length>asphalt.length&&snow.hz<asphalt.hz);
 for(const k of Object.keys(FOOTSTEP)){const f=footstepShape(k,3);assert.ok(f.shape.every(([t,v])=>t>=0&&t<=f.length&&v>=0&&v<=1));}
 assert.equal(footstepShape('nope').hz>0,true);
 const amb=new Set([0,.3,.6,.9].map(t=>serviceSirenFrequency('ambulance',t)));assert.deepEqual([...amb].sort(),[SERVICE_SIREN.ambulance.hi,SERVICE_SIREN.ambulance.lo].sort());
 assert.ok(serviceSirenFrequency('rescue',0)<serviceSirenFrequency('ambulance',0),'the rescue truck is deeper');
 assert.ok(distanceCutoff(1)>distanceCutoff(.1)&&distanceCutoff(0)===700&&distanceCutoff(1)===9000&&distanceCutoff(NaN)===700);
 for(let t=0;t<20;t+=.13){const v=talkEnvelope(t);assert.ok(v>=0&&v<=1);}for(let n=0;n<20;n++)assert.ok(sceneRadioGap(n)>=6&&sceneRadioGap(n)<=14);
});

test('onlookers gather after a call, fewer at night and in rain, more on a match day; none for a car chase',()=>{
 const crash={id:41,type:1,variant:'crash',state:'onscene',x:1.5,y:2.6,age:60},day={minute:14*60,weather:'clear'};const before=JSON.stringify(crash);
 const full=onlookersFor(crash,day);assert.ok(full.length>=3&&full.length<=ONLOOKERS.max,String(full.length));assert.equal(JSON.stringify(crash),before,'presentation only');
 assert.ok(onlookersFor({...crash,age:1},day).length<full.length,'they gather over minutes');assert.deepEqual(onlookersFor(crash,day),full,'deterministic');
 assert.ok(crowdSize(crash,{minute:3*60})<crowdSize(crash,day));assert.ok(crowdSize(crash,{...day,weather:'rain'})<crowdSize(crash,day));assert.ok(crowdSize(crash,{...day,event:'football'})>=crowdSize(crash,day));
 assert.equal(crowdSize({...crash,type:5,variant:'drunk-driver'},day),0);assert.equal(crowdSize({...crash,state:'resolved'},day),0);assert.ok(streetFactor(3*60)<streetFactor(15*60));
 const d=o=>Math.hypot(o.x-crash.x,o.y-crash.y)*MAP_METRES;assert.ok(full.every(o=>d(o)>=ONLOOKERS.ring[0]-1e-6&&d(o)<=ONLOOKERS.ring[1]+1e-6));
 const cordon=onlookersFor({...crash,decision:'secure'},day);assert.ok(cordon.every(o=>d(o)>=ONLOOKERS.cordon[0]-1e-6),'the cordon pushes them back');
 let id=1;while(!factsFor({id}).witness)id++;const asked={...crash,id,talk:{stage:1}},w=onlookersFor(asked,day).find(o=>o.role==='witness');assert.ok(w&&Math.abs(Math.hypot(w.x-crash.x,w.y-crash.y)*MAP_METRES-ONLOOKERS.witnessMetres)<1e-6,'the witness steps up');
 assert.equal(onlookersFor({...crash,id,talk:{stage:0}},day).some(o=>o.role==='witness'),false);
 assert.ok(crowdNear([crash],{x:crash.x,y:crash.y},day)>crowdNear([crash],{x:crash.x+40/MAP_METRES,y:crash.y},day));assert.equal(crowdNear([crash],{x:crash.x+1,y:crash.y},day),0);
});

function fake(){const param=()=>({value:0,setTargetAtTime(v){this.value=v},setValueAtTime(v){this.value=v},linearRampToValueAtTime(v){this.value=v}});const log={osc:0,bursts:0,irs:0,oscs:[]};
 const ctx={state:'running',currentTime:1,sampleRate:8000,destination:{},log,
  createGain(){return {gain:param(),connect(){},disconnect(){}}},createOscillator(){log.osc++;const o={frequency:param(),connect(){},disconnect(){},start(){},stop(){}};log.oscs.push(o);return o},
  createBiquadFilter(){return {type:'',frequency:param(),Q:param(),connect(){}}},createStereoPanner(){return {pan:param(),connect(){}}},createBuffer(c,len){return {length:len,getChannelData:()=>new Float32Array(len)}},
  createBufferSource(){return {connect(){},disconnect(){},start(){if(!this.loop)log.bursts++},stop(){}}},createConvolver(){const c={connect(){}};Object.defineProperty(c,'buffer',{set(){log.irs++},get(){return null}});return c},async resume(){}};return ctx;}
const base=(x,y)=>({shift:1,mode:'career',resolved:0,incidents:[],units:[{id:1,x,y,route:[],status:'working'},{id:2,x,y,route:[],status:'patrol'}],vehicles:[],radio:[],population:{residents:[]},services:[],time:0});

test('audio: steps are noise bursts with echo, the place sets the reverb once, other services get their own siren',async()=>{
 const c=node('centre'),p=node('papiniidu'),ctx=fake(),a=createAudio({preferences:{enabled:true},createContext:()=>ctx});await a.unlock();const sc={x:c.x,y:c.y,zoom:12},s=base(c.x,c.y);a.reset(s);
 const osc0=ctx.log.osc;s.population.residents=[{id:3,x:c.x,y:c.y,status:'walkVisit'}];a.update(s,1,true,sc,{weather:'clear'});ctx.currentTime+=.5;s.population.residents[0].x+=.0001;a.update(s,1,true,sc,{weather:'clear'});
 assert.ok(ctx.log.bursts>=1,'a step');assert.equal(ctx.log.osc,osc0,'no oscillator per step');assert.equal(ctx.log.irs,1,'the yard reverb is built once');
 ctx.currentTime+=.1;a.update(s,1,true,{x:p.x,y:p.y,zoom:12},{});assert.equal(ctx.log.irs,1,'rebuilt at most every 1.5 s');ctx.currentTime+=2;a.update(s,1,true,{x:p.x,y:p.y,zoom:12},{});assert.equal(ctx.log.irs,2,'the park sounds different');
 const before=ctx.log.osc;s.services=[{id:1,kind:'ambulance',status:'responding',x:c.x,y:c.y,route:[{x:c.x+.1,y:c.y}]}];ctx.currentTime+=.05;a.update(s,1,true,sc,{});
 assert.equal(ctx.log.osc,before+1,'the service siren voice appears with the first ambulance');const sv=ctx.log.oscs.at(-1);assert.ok([SERVICE_SIREN.ambulance.hi,SERVICE_SIREN.ambulance.lo].includes(sv.frequency.value));
 s.services=[];ctx.currentTime+=.05;a.update(s,1,true,sc,{});a.update(s,1,true,sc,{});assert.equal(ctx.log.osc,before+1,'one voice is reused');
});

test('audio: a siren across town is quiet and muffled; a call the camera looks at has voices, a crowd and a portable radio',async()=>{
 const c=node('centre'),ctx=fake(),a=createAudio({preferences:{enabled:true},createContext:()=>ctx});await a.unlock();const sc={x:c.x,y:c.y,zoom:9},s=base(c.x,c.y);a.reset(s);
 const u=s.units[1];Object.assign(u,{status:'responding',incident:9,route:[{x:c.x+1,y:c.y}],x:c.x+1500/MAP_METRES,y:c.y});s.incidents=[{id:9,type:4,state:'assigned',units:[2],x:c.x+1,y:c.y}];
 a.update(s,1,true,sc,{});const far=a.voices().siren;assert.ok(far>0,'heard at 1.5 km');u.x=c.x+5/MAP_METRES;ctx.currentTime+=.1;a.update(s,1,true,sc,{});const near=a.voices().siren;assert.ok(near>far*3,`${near} vs ${far}`);
 u.x=c.x+(FAR_SIREN_METRES+500)/MAP_METRES;ctx.currentTime+=.1;a.update(s,1,true,sc,{});assert.ok(a.voices().siren<far/5,'too far: practically silent');
 s.incidents=[{id:7,type:1,variant:'crash',state:'onscene',x:c.x,y:c.y,age:60,units:[1],talk:{stage:1,choices:[],evidence:0,pace:1,complaint:1,bond:0,trust:0,followUp:1,sets:{}}}];Object.assign(s.units[0],{incident:7,status:'working'});Object.assign(u,{status:'patrol',route:[],incident:null});
 const b0=ctx.log.bursts;for(let k=0;k<60;k++){ctx.currentTime+=.1;a.update(s,1,true,sc,{date:{minute:14*60},weather:'clear'});}
 const ch=a.channels();assert.ok('talk' in ch&&'crowd' in ch,'voices and crowd layers exist');assert.ok(ch.crowd>0);assert.ok(ctx.log.bursts>b0,'the portable radio squawks');
});
