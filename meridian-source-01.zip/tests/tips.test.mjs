import test from 'node:test';import assert from 'node:assert/strict';
import {createGame,tick,nextShift,serialize,deserialize} from '../dist/sim.js';
import {nextTip,markTip,TIPS,validTips} from '../dist/tips.js';
// R23 «Подсказки новичку» (Claude, 11.10.2026).
test('tips come one at a time when they first matter, are remembered and can be switched off',()=>{
 let s=createGame('career',7182,{schedule:'ppa'});assert.equal(nextTip(s).id,'briefing');markTip(s,'briefing');
 for(let k=0;k<4000&&nextTip(s)===null;k++)tick(s,.25);const t=nextTip(s);assert.ok(t&&t.id!=='briefing',t?.id);
 markTip(s,t.id);markTip(s,t.id);assert.equal(s.tipsSeen.filter(x=>x===t.id).length,1);
 s.ended=true;const n=nextShift(s);assert.ok(n.tipsSeen.includes('briefing'));assert.doesNotThrow(()=>deserialize(serialize(n)));
 markTip(n,null,true);assert.equal(nextTip(n),null);assert.equal(nextShift({...n,ended:true}).tipsOff,true);
 const bad=JSON.parse(serialize(n));bad.tipsSeen=['nope'];assert.throws(()=>deserialize(JSON.stringify(bad)));
 assert.equal(nextTip(createGame('career',7182)),null,'old campaigns get no tips');
 for(const x of TIPS)assert.ok(x.text.length>40&&x.title);assert.ok(validTips({}));
});
