import test from 'node:test';import assert from 'node:assert/strict';
import data from '../dist/city-data.js';
import {drawBuilding,buildingStyle} from '../dist/city-art.js';
test('all real city footprints render finite geometry at city and street detail without mutation',()=>{
 const before=JSON.stringify(data.buildings);let vertices=0;
 const check=(...args)=>{assert.ok(args.every(Number.isFinite));vertices++;};
 const ctx={beginPath(){},closePath(){},fill(){},stroke(){},moveTo:check,lineTo:check,fillRect:check};
 for(const zoom of [1,5,32])for(const b of data.buildings){const scale=80*zoom;drawBuilding(ctx,b,b.p.map(([x,y])=>({x:x*scale,y:y*scale})),scale,zoom);}
 assert.ok(vertices>10000);assert.equal(JSON.stringify(data.buildings),before);
});
test('illustrative materials are stable across frames and industrial roofs stay flat',()=>{
 for(const b of data.buildings.slice(0,100))assert.deepEqual(buildingStyle(b),buildingStyle(structuredClone(b)));
 assert.equal(buildingStyle({id:1,kind:'warehouse',h:1}).flat,true);
 assert.doesNotThrow(()=>drawBuilding({},{h:1,id:1},[],80,5));
});
