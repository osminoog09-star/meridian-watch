import test from 'node:test';import assert from 'node:assert/strict';
import {pinkNoise,brownNoise,seamlessLoop,noiseLoop,gust,lapping,engineSound,sirenFrequency,SIREN_RANGE,spatial,radioPattern} from '../dist/sound-synth.js';
import {createAudio} from '../dist/audio.js';
// R26 «Звук: качество и реализм» (Claude, 12.10.2026).
const energy=(x,step)=>{let e=0;for(let k=step;k<x.length;k++){const d=x[k]-x[k-step];e+=d*d;}return e/x.length;};
test('noise beds: pink/brown are bounded, darker than white, and loop without a click',()=>{
 const p=pinkNoise(48000),b=brownNoise(48000);for(const x of [p,b])assert.ok(x.every(v=>Math.abs(v)<=.5+1e-9));
 // High-frequency content (sample-to-sample difference) is much lower for brown than for pink.
 assert.ok(energy(b,1)<energy(p,1)*.5);
 const loop=noiseLoop('pink',8000),seam=Math.abs(loop[0]-loop.at(-1)),typical=energy(loop,1)**.5;assert.ok(seam<typical*4,`seam ${seam} vs step ${typical}`);
 const s=seamlessLoop(new Float32Array(100).map((_,k)=>k),10);assert.equal(s.length,90);
 for(let t=0;t<300;t+=.37){const g=gust(t),l=lapping(t);assert.ok(g>=0&&g<=1&&l>0&&l<1.1);}
});
test('engine: idle when standing, rpm climbs within a gear and drops on a shift, SUV deeper',()=>{
 const idle=engineSound(0,{moving:false}),off=engineSound(30,{on:false});assert.equal(idle.rpm,800);assert.ok(idle.level>0&&idle.level<.03);assert.equal(off.level,0);
 const a=engineSound(10,{moving:true}),b=engineSound(17,{moving:true}),c=engineSound(19,{moving:true});assert.ok(b.rpm>a.rpm,'climbs in 1st');assert.ok(c.rpm<b.rpm,'drops after shifting to 2nd');assert.equal(c.gear,2);
 assert.ok(engineSound(50,{moving:true,type:'suv'}).hz<engineSound(50,{moving:true}).hz);for(let v=0;v<140;v+=3){const e=engineSound(v,{moving:true});assert.ok(e.rpm>=800&&e.rpm<=4000&&e.cutoff>200);}
});
test('siren: wail rises slowly and falls faster within 650–1450 Hz, yelp sweeps ~3 times a second',()=>{
 let lo=Infinity,hi=0;for(let t=0;t<10;t+=.01){const f=sirenFrequency('wail',t);lo=Math.min(lo,f);hi=Math.max(hi,f);}assert.ok(lo>=SIREN_RANGE.lo-1&&hi<=SIREN_RANGE.hi+1&&hi-lo>700);
 const rise=sirenFrequency('wail',SIREN_RANGE.wail*.25),fall=sirenFrequency('wail',SIREN_RANGE.wail*.8);assert.ok(rise>SIREN_RANGE.lo&&fall>SIREN_RANGE.lo);
 let resets=0,prev=sirenFrequency('yelp',0);for(let t=.005;t<1;t+=.005){const f=sirenFrequency('yelp',t);if(f<prev-200)resets++;prev=f;}assert.ok(resets>=2&&resets<=4,String(resets));
});
test('space and radio: stereo by position, quieter far away; radio syllables are deterministic',()=>{
 const scene={x:1,y:1,zoom:10};const left=spatial({x:.95,y:1},scene),right=spatial({x:1.05,y:1},scene),far=spatial({x:1.3,y:1.3},scene),centre=spatial({x:1,y:1},scene);
 assert.ok(left.pan<0&&right.pan>0);assert.ok(far.gain<centre.gain*.2);assert.deepEqual(spatial(null,scene),{pan:0,gain:1});
 const r=radioPattern('Принял, выдвигаемся.');assert.deepEqual(r,radioPattern('Принял, выдвигаемся.'));assert.ok(r.duration>=.5&&r.duration<=2.2&&r.syllables.length>3);assert.ok(radioPattern('x'.repeat(500)).duration<=2.2);
});
function fake(){const nodes=[];let osc=0,src=0,resumes=0;const param=()=>({value:0,setTargetAtTime(v){this.value=v},setValueAtTime(v){this.value=v},linearRampToValueAtTime(v){this.value=v}});
 return {state:'suspended',currentTime:1,sampleRate:200,destination:{},nodes,get osc(){return osc},get resumes(){return resumes},createGain(){const n={gain:param(),connect(){},disconnect(){}};nodes.push(n);return n},createOscillator(){osc++;return {frequency:param(),connect(){},disconnect(){},start(){},stop(){}}},createBuffer:(_,n)=>({getChannelData:()=>new Float32Array(n)}),createBiquadFilter:()=>({frequency:param(),Q:param(),connect(){}}),createBufferSource(){src++;return {connect(){},disconnect(){},start(){},stop(){}}},createStereoPanner(){const n={pan:param(),connect(){}};return n;},async resume(){resumes++;this.state='running'},async suspend(){this.state='suspended'}};}
const units=()=>[{id:1,x:1,y:1,route:[{x:1.2,y:1}],status:'patrol',currentSpeedKmh:40},{id:2,x:1.05,y:1,route:[{x:1.3,y:1}],status:'responding',incident:5,currentSpeedKmh:60}];
const state=()=>({shift:1,mode:'career',resolved:0,incidents:[{id:5,type:4,state:'assigned',units:[2]}],units:units(),vehicles:[]});
test('sound comes back by itself after the app was in the background; dialogs duck instead of mute',async()=>{
 const ctx=fake(),a=createAudio({preferences:{enabled:true},createContext:()=>ctx}),s=state(),scene={x:1,y:1,zoom:10};await a.unlock();a.reset(s);a.update(s,1,true,scene);
 ctx.state='suspended';const r0=ctx.resumes;a.update(s,1,true,scene);assert.equal(ctx.resumes,r0+1,'update tries to resume a suspended context');a.update(s,1,true,scene);assert.equal(ctx.resumes,r0+1,'not more often than every 1.5 s');
 ctx.state='running';a.update(s,1,true,scene,{ducked:true});assert.ok(Object.values(a.channels()).some(v=>v>0),'the city keeps sounding under a dialog');
});
test('the siren of the nearest responding crew is heard even when another crew is selected',async()=>{
 const ctx=fake(),a=createAudio({preferences:{enabled:true},createContext:()=>ctx}),s=state(),scene={x:1,y:1,zoom:10};await a.unlock();a.reset(s);a.update(s,1,true,scene);
 const v=a.voices();assert.ok(v.siren>0,'siren of crew 02 while crew 01 is selected');assert.ok(v.sirenHz>=650&&v.sirenHz<=1450);assert.ok(v.engine>0,'engine of the selected car');
 s.units[1].status='working';s.units[1].route=[];a.update(s,1,true,scene);assert.equal(a.voices().siren,0,'siren stops when the crew arrives');
});
