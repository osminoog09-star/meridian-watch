import test from 'node:test';import assert from 'node:assert/strict';
import {createGame,hireOfficer,createPatrol,tick,nextShift,serialize,deserialize,spawnIncident,repairVehicle,setVehicleExtra,PAINTS,HQ,unitReason,FUEL_STATIONS,buyVehicle} from '../dist/sim.js';
import {FUEL,WEAR,EXTRAS,LIVERIES,SLOTS,CAR_SPECS,consume,speedFactor,extraBonus,ensureVehicle,validVehicleState,repairCost,repairTime,vehicleView,rangeKm,averagePer100,toTicks} from '../dist/garage.js';
import {NODES} from '../dist/geography.js';
// 0.6.1 «Гараж»: fuel, wear, breakdown/tow, repair, trunk equipment, liveries, history.

function hire(s,id){assert.equal(hireOfficer(s,id).ok,true);return s.officers.at(-1).id;}
function chief(){const s=createGame('chief');const a=hire(s,1),b=hire(s,2);assert.equal(createPatrol(s,a,b,1).ok,true);s.setupPending=false;s.nextIncident=9000;s.budget+=3000;s.finance.opening+=3000;return s;}
const near=(a,b)=>Math.hypot(a.x-b.x,a.y-b.y)<.02;

test('rules: realistic tanks and consumption, idling, wear, equipment, liveries',()=>{
 // Real-world class figures: sedan 55 l / 7.8 l per 100 km, SUV 70 l / 10.8 l per 100 km.
 assert.equal(CAR_SPECS.sedan.tank,55);assert.equal(CAR_SPECS.suv.tank,70);assert.ok(CAR_SPECS.sedan.per100>=6&&CAR_SPECS.sedan.per100<=9);assert.ok(CAR_SPECS.suv.per100>=9&&CAR_SPECS.suv.per100<=13);
 const v=ensureVehicle({id:1,type:'sedan'});assert.equal(v.fuel,55);const w0=v.wear;consume(v,100);assert.equal(v.km,100);assert.ok(Math.abs(v.fuel-(55-7.8))<1e-9);assert.ok(Math.abs(v.wear-(w0+100*WEAR.perKm))<1e-9);
 assert.ok(Math.abs(averagePer100(v)-7.8)<1e-9);assert.equal(averagePer100({id:9,km:800,litres:2,trackKm:5}),CAR_SPECS.sedan.per100,'too little tracked distance → spec');assert.ok(Math.abs(rangeKm(v)-(55-7.8)/7.8*100)<1e-6,'full tank ~700 km');
 consume(v,0,{idleHours:2});assert.ok(Math.abs(v.fuel-(55-7.8-2*CAR_SPECS.sedan.idlePerHour))<1e-9,'idling burns fuel');assert.equal(v.km,100);
 const suv=ensureVehicle({id:2,type:'suv'});assert.equal(suv.fuel,70);consume(suv,10,{pursuit:true});assert.ok(Math.abs(suv.fuel-(70-10*10.8/100*FUEL.pursuit))<1e-9);
 assert.ok(suv.wear>=(suv.id*7)%20+10*WEAR.perKm*WEAR.pursuit-1e-9);
 assert.equal(speedFactor({wear:WEAR.slow-1}),1);assert.equal(speedFactor({wear:WEAR.slow}),WEAR.slowFactor);
 assert.equal(extraBonus({extras:['medkit']},'crash'),EXTRAS.medkit.bonus);assert.equal(extraBonus({extras:['medkit','cones']},'crash'),EXTRAS.medkit.bonus,'best item, no stacking');assert.equal(extraBonus({extras:['medkit']},'noise-flat'),1);
 for(const [k,l] of Object.entries(LIVERIES))assert.equal(PAINTS[k],l.paint);
 assert.equal(validVehicleState({id:1,type:'sedan',extras:['medkit','cones']}),false,'sedan has one slot');assert.equal(validVehicleState({id:1,type:'suv',extras:['medkit','cones']}),true);
 assert.equal(validVehicleState({id:1,fuel:60}),false,'over a 55 l tank');assert.equal(validVehicleState({id:1,type:'suv',fuel:60}),true);assert.equal(validVehicleState({id:1,paint:'pink'}),false);assert.equal(validVehicleState({id:1,service:{kind:'wash',left:1}}),false);
 assert.equal(SLOTS.suv,2);assert.ok(repairCost({wear:50})>0&&repairTime({wear:50})>repairTime({wear:0}));
 const raw={id:3};const view=vehicleView(raw);assert.equal(view.fuel,55);assert.deepEqual(raw,{id:3},'view does not mutate');
 const s=createGame('chief');s.budget+=5000;s.finance.opening+=5000;hireOfficer(s,1);assert.equal(buyVehicle(s,'suv').ok,true);assert.equal(s.vehicles.at(-1).fuel,70);
 assert.equal(FUEL_STATIONS.length,3);for(const st of FUEL_STATIONS)assert.match(st.name,/^АЗС «/);
});

test('quarter tank: crew drives to the nearest filling station, pays per litre and returns to patrol',()=>{
 const s=chief(),u=s.units[0],v=s.vehicles.find(x=>x.id===u.vehicleId);v.fuel=55*FUEL.lowShare-1;const budget=s.budget;
 tick(s,.1);assert.equal(u.status,'servicing');assert.equal(v.service.kind,'fuel');const st=FUEL_STATIONS[v.service.station];assert.ok(st);assert.match(unitReason(s,u),/АЗС/);
 for(let k=0;k<4000&&u.status==='servicing'&&u.route.length;k++)tick(s,.1);assert.ok(near(u,st),'at the station');
 for(let k=0;k<4000&&u.status==='servicing';k++)tick(s,.1);
 assert.equal(u.status,'patrol');assert.equal(v.fuel,55);assert.equal(v.service,null);assert.ok(s.budget<budget,'fuel was paid');
 const paid=s.finance.entries.find(e=>e.category==='fuel');assert.ok(paid&&-paid.amount>=Math.round(41*FUEL.pricePerLitre*.9),'about 41 litres paid');assert.match(v.history[0].text,/Заправка \d+\.\d л/);
 assert.ok(s.radio.some(r=>/заправ|Бак|топлив/i.test(r.text)));
});

test('an empty tank stops the car until a canister arrives',()=>{
 const s=chief(),u=s.units[0],v=s.vehicles.find(x=>x.id===u.vehicleId);const n=NODES[(NODES.length/3)|0];
 const i=spawnIncident(s,null,{variant:'blocked-exit',point:{x:n.x,y:n.y}});for(let k=0;k<20&&u.incident!==i.id;k++)tick(s,.1);v.fuel=.0001;
 for(let k=0;k<200&&u.status!=='servicing';k++)tick(s,.1);assert.equal(v.service.kind,'canister');assert.equal(u.incident,null);
 for(let k=0;k<toTicks(FUEL.canisterMinutes)*10+20&&v.service?.kind==='canister';k++)tick(s,.1);assert.ok(v.fuel>0);
 for(let k=0;k<20&&!(v.service?.kind==='fuel');k++)tick(s,.1);assert.equal(v.service?.kind,'fuel','goes on to refuel');
});

test('breakdown: the crew leaves the call, the car is towed, repaired and returns',()=>{
 const s=chief(),u=s.units[0],v=s.vehicles.find(x=>x.id===u.vehicleId);const n=NODES[(NODES.length/2)|0];
 const i=spawnIncident(s,null,{variant:'blocked-exit',point:{x:n.x,y:n.y}});for(let k=0;k<20&&u.incident!==i.id;k++)tick(s,.1);assert.equal(u.incident,i.id);
 v.wear=WEAR.broken-.001;for(let k=0;k<200&&u.status!=='servicing';k++)tick(s,.1);
 assert.equal(u.status,'servicing');assert.equal(v.service.kind,'tow');assert.equal(u.incident,null);assert.ok(!i.units.includes(u.id));
 for(let k=0;k<toTicks(WEAR.towMinutes)*10+20&&v.service?.kind==='tow';k++)tick(s,.1);assert.equal(v.service.kind,'repair');assert.ok(near(u,HQ),'towed to the station');
 assert.ok(s.finance.entries.some(e=>e.category==='repair'));
 for(let k=0;k<3000&&u.status==='servicing';k++)tick(s,.1);assert.equal(u.status,'patrol');assert.equal(v.wear,0);
 assert.ok(v.history.some(h=>/Поломка/.test(h.text)));
});

test('planned repair, equipment slots and parked repairs',()=>{
 const s=chief(),u=s.units[0],v=s.vehicles.find(x=>x.id===u.vehicleId),spare=s.vehicles.find(x=>x.id!==u.vehicleId);
 assert.equal(repairVehicle(createGame(),1).ok,false,'career has no garage control');
 v.wear=50;const cost=repairCost(v);const before=s.budget;assert.equal(repairVehicle(s,v.id).ok,true);assert.equal(s.budget,before-cost);assert.equal(u.status,'servicing');assert.equal(repairVehicle(s,v.id).ok,false);
 for(let k=0;k<4000&&u.status==='servicing';k++)tick(s,.1);assert.equal(v.wear,0);assert.equal(u.status,'patrol');
 spare.wear=30;assert.equal(repairVehicle(s,spare.id).ok,true);assert.equal(createPatrol(s,hire(s,3),0,spare.id).ok,false,'car in repair cannot form a patrol');
 for(let k=0;k<1000&&spare.service;k++)tick(s,.1);assert.equal(spare.service,null);assert.equal(spare.wear,0);
 assert.equal(setVehicleExtra(s,v.id,'medkit',true).ok,true);assert.equal(setVehicleExtra(s,v.id,'cones',true).ok,false,'sedan: one slot');
 assert.equal(setVehicleExtra(s,v.id,'medkit',false).ok,true);assert.deepEqual(v.extras,[]);assert.equal(setVehicleExtra(s,v.id,'laser',true).ok,false);
});

test('equipment really speeds up matching calls',()=>{
 const run=extras=>{const s=chief(),u=s.units[0],v=s.vehicles.find(x=>x.id===u.vehicleId);v.extras=extras;const n=NODES[50];
  const i=spawnIncident(s,null,{variant:'fire-smoke',point:{x:n.x,y:n.y}});let ticks=0;for(;ticks<8000&&!['resolved','missed'].includes(i.state);ticks++)tick(s,.1);return {ticks,state:i.state};};
 const plain=run([]),equipped=run(['extinguisher']);assert.equal(plain.state,'resolved');assert.equal(equipped.state,'resolved');assert.ok(equipped.ticks<plain.ticks,`${equipped.ticks} < ${plain.ticks}`);
});

test('garage state is saved, validated and carried between shifts',()=>{
 const s=chief(),v=s.vehicles[0];v.km=500;v.wear=60;v.fuel=30;v.litres=40;v.extras=['cones'];
 const n=deserialize(serialize(s));assert.deepEqual(n.vehicles,s.vehicles);
 const bad=JSON.parse(serialize(s));bad.vehicles[0].wear=-5;assert.throws(()=>deserialize(JSON.stringify(bad)));
 const old=JSON.parse(serialize(s));for(const x of old.vehicles){delete x.km;delete x.fuel;delete x.wear;delete x.extras;delete x.history;delete x.service;}assert.doesNotThrow(()=>deserialize(JSON.stringify(old)));
 s.ended=true;const next=nextShift(s),nv=next.vehicles.find(x=>x.id===v.id);assert.equal(nv.km,500);assert.equal(nv.wear,60,'chief: wear stays until repaired');assert.equal(nv.fuel,30,'fuel is not refilled for free between shifts');
 nv.extras.push('medkit');assert.deepEqual(v.extras,['cones'],'deep copy between shifts');
 const c=createGame();c.vehicles[0].wear=70;c.ended=true;assert.equal(nextShift(c).vehicles[0].wear,30,'career: department service between shifts');
});

test('cars waiting for each other at a junction do not stand forever',()=>{
 // Regression seen in a five-shift run: two crews near the station yielded to each other forever.
 let s=createGame();for(let k=0;k<4;k++){for(let t=0;t<4800&&!s.ended;t++)tick(s,.1);s.ended=true;s=nextShift(s);}
 const stopped=new Map();let worst=0;
 for(let t=0;t<1500;t++){tick(s,.1);for(const u of s.units){const waiting=u.route.length&&u.status==='responding'&&(u.currentSpeedKmh||0)<.1;stopped.set(u.id,waiting?(stopped.get(u.id)??0)+1:0);worst=Math.max(worst,stopped.get(u.id));}}
 assert.ok(worst<300,`a responding crew stood still for ${worst} ticks`);
});
