import test from 'node:test';
import assert from 'node:assert/strict';
import {planTraffic,TRAFFIC} from '../dist/traffic.js';
import {advanceVehicle} from '../dist/transport.js';
import {MAP_METRES} from '../dist/world-scale.js';

const m=value=>value/MAP_METRES;
const vehicle=(id,x,target=100,speed=30)=>({id,x:m(x),y:0,heading:0,motionSpeedKmh:speed,route:[{x:m(target),y:0,roadSpeed:{kmh:50,source:'osm'}}]});
const item=(entity,desired=30,emergency=false)=>({entity,id:entity.id,desired,emergency});

test('following vehicle reduces target and never overtakes a slower lead on one segment',()=>{
 const lead=vehicle('lead',30,1000,12),follow=vehicle('follow',15,1000,30),cars=[item(lead,12),item(follow,30)];
 let minimum=Infinity;for(let k=0;k<80;k++){planTraffic(cars);advanceVehicle(lead,1/45,lead.trafficTargetKmh);advanceVehicle(follow,1/45,follow.trafficTargetKmh);minimum=Math.min(minimum,(lead.x-follow.x)*MAP_METRES);assert.ok(follow.x<=lead.x+1e-10);}
 assert.ok(minimum>=TRAFFIC.minimumGap);assert.ok(['Держит дистанцию','Ожидает свободный участок',null].includes(follow.trafficReason));
});

test('queue planner chooses the nearest lead and clears stale reasons',()=>{
 const first=vehicle('first',30),second=vehicle('second',24),third=vehicle('third',20);planTraffic([item(first),item(second),item(third)]);
 assert.equal(third.trafficLeadId,'second');assert.ok(third.trafficTargetKmh<30);third.route=[];planTraffic([item(first),item(second),item(third)]);assert.equal(third.trafficReason,null);assert.equal(third.yieldingToEmergency,false);
});

test('civilian yields to an approaching emergency vehicle without blocking its target speed',()=>{
 const civilian=vehicle('civilian',30),unit=vehicle('unit',10);const result=planTraffic([item(civilian,30),item(unit,60,true)]);
 assert.equal(civilian.yieldingToEmergency,true);assert.equal(civilian.trafficTargetKmh,TRAFFIC.yieldSpeed);assert.equal(civilian.trafficLeadId,'unit');assert.equal(unit.trafficTargetKmh,60);assert.equal(result.find(x=>x.id==='civilian').reason,'Уступает экстренному экипажу');
});

test('opposite destinations are not treated as the same lane and planning is position-read-only',()=>{
 const a=vehicle('a',10,100),b=vehicle('b',12,0),before=[a.x,a.y,b.x,b.y,a.route.length,b.route.length];planTraffic([item(a),item(b)]);assert.equal(a.trafficReason,null);assert.equal(b.trafficReason,null);assert.deepEqual([a.x,a.y,b.x,b.y,a.route.length,b.route.length],before);
});

test('queue remains continuous when the leader has crossed a short route node',()=>{
 const follow=vehicle('follow',0,10,30);follow.route.push({x:m(20),y:0},{x:m(30),y:0});const lead=vehicle('lead',15,20,12);lead.route.push({x:m(30),y:0});planTraffic([item(follow,30),item(lead,12)]);assert.equal(follow.trafficLeadId,'lead');assert.equal(follow.trafficReason,'Держит дистанцию');assert.ok(follow.trafficTargetKmh<30);
});

test('conflicting approaches receive one deterministic junction priority',()=>{
 const west=vehicle('west',-12,0,30);west.route=[{x:0,y:0},{x:m(20),y:0}];const south={...vehicle('south',0,0,30),x:0,y:m(-12),heading:Math.PI/2,route:[{x:0,y:0},{x:0,y:m(20)}]};planTraffic([item(west),item(south)]);const waiting=[west,south].filter(v=>v.trafficReason==='Пропускает на перекрёстке');assert.equal(waiting.length,1);assert.ok(waiting[0].trafficTargetKmh<30);
});

test('emergency approach wins a junction and a temporary stopped patrol blocks its lane',()=>{
 const emergency=vehicle('emergency',-12,0,30);emergency.route=[{x:0,y:0},{x:m(20),y:0}];const civilian={...vehicle('civilian',0,0,30),x:0,y:m(-12),heading:Math.PI/2,route:[{x:0,y:0},{x:0,y:m(20)}]};planTraffic([item(civilian),item(emergency,60,true)]);assert.equal(emergency.trafficReason,null);assert.equal(civilian.trafficReason,'Пропускает на перекрёстке');const follower=vehicle('follower',10,20,30),stopped={id:'stopped',x:m(20),y:0,heading:0,route:[],motionSpeedKmh:0};planTraffic([item(follower),{entity:stopped,id:'stopped',desired:0,emergency:false,blocking:true}]);assert.equal(follower.trafficLeadId,'stopped');assert.ok(follower.trafficTargetKmh<30);
});

test('vehicles clear a multi-node crossing in order without entering together or deadlocking',()=>{
 const west=vehicle('west',-100,100,30);west.route=[{x:m(-50),y:0},{x:0,y:0},{x:m(100),y:0}];
 const south={...vehicle('south',0,100,30),x:0,y:m(-100),heading:Math.PI/2,route:[{x:0,y:m(-50)},{x:0,y:0},{x:0,y:m(100)}]};
 const cars=[item(west),item(south)];let waited=false,heldAfterCrossing=false;
 for(let k=0;k<20;k++){
  planTraffic(k%2?cars.slice().reverse():cars);waited||=cars.some(({entity})=>entity.trafficReason==='Пропускает на перекрёстке');
  if(Math.hypot(west.x,west.y)*MAP_METRES<=TRAFFIC.junctionClearance&&west.x>0)heldAfterCrossing||=south.trafficReason==='Пропускает на перекрёстке';
  if(Math.hypot(south.x,south.y)*MAP_METRES<=TRAFFIC.junctionClearance&&south.y>0)heldAfterCrossing||=west.trafficReason==='Пропускает на перекрёстке';
  const inside=cars.filter(({entity})=>Math.hypot(entity.x,entity.y)*MAP_METRES<8);assert.ok(inside.length<=1,'two vehicles occupied the conflict area');
  for(const {entity} of cars)advanceVehicle(entity,.1,entity.trafficTargetKmh);
 }
 assert.ok(waited);assert.ok(heldAfterCrossing);assert.equal(west.route.length,0);assert.equal(south.route.length,0);
});

test('close yielding car does not make the emergency unit brake in the corridor',()=>{
 const civilian=vehicle('civilian',30),unit=vehicle('unit',25);planTraffic([item(civilian),item(unit,60,true)]);
 assert.equal(civilian.trafficReason,'Уступает экстренному экипажу');assert.equal(civilian.yieldingToEmergency,true);assert.equal(unit.trafficTargetKmh,60);assert.equal(unit.trafficReason,null);
});

test('emergency vehicle crosses first dynamically and both approaches resume',()=>{
 const civilian=vehicle('civilian',-100,100,30);civilian.route=[{x:m(-50),y:0},{x:0,y:0},{x:m(100),y:0}];
 const emergency={...vehicle('emergency',0,100,30),x:0,y:m(-100),heading:Math.PI/2,route:[{x:0,y:m(-50)},{x:0,y:0},{x:0,y:m(100)}]};
 const cars=[item(civilian),item(emergency,60,true)];let emergencyDone=-1,civilianDone=-1;
 for(let k=0;k<20;k++){planTraffic(cars);const inside=cars.filter(({entity})=>Math.hypot(entity.x,entity.y)*MAP_METRES<8);assert.ok(inside.length<=1);for(const {entity} of cars)advanceVehicle(entity,.1,entity.trafficTargetKmh);if(!emergency.route.length&&emergencyDone<0)emergencyDone=k;if(!civilian.route.length&&civilianDone<0)civilianDone=k;}
 assert.ok(emergencyDone>=0&&civilianDone>emergencyDone);assert.equal(civilian.route.length,0);assert.equal(emergency.route.length,0);
});

test('junction ownership saves and resumes with an identical future',()=>{
 const west=vehicle('west',-100,100,30);west.route=[{x:m(-50),y:0},{x:0,y:0},{x:m(100),y:0}];const south={...vehicle('south',0,100,30),x:0,y:m(-100),heading:Math.PI/2,route:[{x:0,y:m(-50)},{x:0,y:0},{x:0,y:m(100)}]};const cars=[item(west),item(south)];
 for(let k=0;k<3;k++){planTraffic(cars);for(const {entity} of cars)advanceVehicle(entity,.1,entity.trafficTargetKmh);}const resumed=structuredClone([west,south]),copy=[item(resumed[0]),item(resumed[1])];
 for(let k=0;k<8;k++){planTraffic(cars);planTraffic(copy);for(const {entity} of cars)advanceVehicle(entity,.1,entity.trafficTargetKmh);for(const {entity} of copy)advanceVehicle(entity,.1,entity.trafficTargetKmh);}assert.deepEqual(resumed,[west,south]);
});
