import test from 'node:test';import assert from 'node:assert/strict';
import {ROAD_NODES,routeWeight} from '../dist/geography.js';
test('real graph uses roadSpeed objects for travel-time weights',()=>{
 let explicit=0;for(const n of ROAD_NODES)for(const e of n.edges){
  if(e.speed.kmh===30)continue;explicit++;
  const penalty=e.w/e.d/(50/e.speed.kmh);
  assert.ok([1,1.15,1.8,4].some(p=>Math.abs(p-penalty)<1e-8));
 }assert.ok(explicit>100);
});
test('numeric and structured road speeds produce identical weights',()=>{
 for(const kmh of [15,20,30,50,70,90])for(const kind of ['service','secondary','living_street'])assert.equal(routeWeight(1,{kmh},kind),routeWeight(1,kmh,kind));
 assert.ok(routeWeight(1,{kmh:70},'secondary')<routeWeight(1,{kmh:20},'residential'));
});
