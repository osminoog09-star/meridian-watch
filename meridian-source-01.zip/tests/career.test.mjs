import test from 'node:test';
import assert from 'node:assert/strict';
import {createGame,canControl,configurePatrolArea,setUnitAutomation,spawnIncident,assign,decide,tick,nextShift,serialize,deserialize} from '../dist/sim.js';
import {serviceSummary} from '../dist/career.js';

function advance(s,seconds){for(let i=0;i<seconds*10;i++)tick(s,.1);}

test('career rank gates are enforced by simulation functions',()=>{
 const s=createGame(),own=s.units[0],peer=s.units[1];
 assert.equal(canControl(s,own),true);
 assert.equal(canControl(s,peer),false);
 assert.equal(configurePatrolArea(s,own.id,'west',own.cross),false);
 assert.equal(setUnitAutomation(s,peer.id,false),false);
 s.rank=1;assert.equal(configurePatrolArea(s,own.id,'west',own.cross),true);
 assert.equal(configurePatrolArea(s,own.id,'west',false),false);
 s.rank=2;assert.equal(canControl(s,peer),true);assert.equal(setUnitAutomation(s,peer.id,false),true);
 s.rank=3;assert.equal(configurePatrolArea(s,peer.id,'east',false),true);
});

test('promotion and service result are recorded from a real completed call',()=>{
 const s=createGame();s.xp=120;s.units.forEach(u=>u.auto=false);s.nextIncident=999;
 const i=spawnIncident(s,0);Object.assign(s.units[0],{x:i.x,y:i.y});
 assert.equal(assign(s,1,i.id),true);advance(s,1);assert.equal(decide(s,1,'talk'),true);advance(s,30);
 const summary=serviceSummary(s);assert.equal(s.rank,1);assert.equal(summary.events[0].incident,i.id);assert.equal(summary.events[0].success,true);assert.ok(summary.promotions.some(p=>p.rank===1));
});

test('service history persists across save and next shift without aliases',()=>{
 const s=createGame();s.service.events.push({incident:1,name:'Проверка',success:true,shift:1,time:10,xp:30,rank:0});s.nextId=2;s.time=480;s.ended=true;
 const restored=deserialize(serialize(s)),n=nextShift(restored);assert.deepEqual(n.service,s.service);n.service.events[0].name='Изменено';assert.equal(s.service.events[0].name,'Проверка');
});

test('old career save migrates at its current rank and corrupt service data is rejected',()=>{
 const old=createGame();old.xp=320;old.rank=2;old.time=80;delete old.service;
 const migrated=deserialize(JSON.stringify(old));assert.equal(migrated.service.legacy,true);assert.equal(migrated.service.promotions[0].rank,2);assert.equal(migrated.service.events.length,0);
 migrated.service.events.push({incident:999,name:'Ложная запись',success:true,shift:1,time:80,xp:320,rank:2});assert.throws(()=>deserialize(JSON.stringify(migrated)));
});
