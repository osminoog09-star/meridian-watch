import test from 'node:test';import assert from 'node:assert/strict';
import {createGame,spawnIncident,tick,serialize,deserialize,nextShift,callName,districtOf,districtTrust,ensureDistricts} from '../dist/sim.js';
import {followUpChance,FOLLOW_UPS,DISTRICT_IDS,variantById} from '../dist/calls.js';
// «Последствия» v2: follow-up calls and district trust.

test('rules point to real variants and chances follow outcome, backup and district trust',()=>{
 for(const [from,r] of Object.entries(FOLLOW_UPS)){assert.ok(variantById(from),from);assert.ok(variantById(r.next),r.next);}
 assert.ok(followUpChance('noise-flat',false,'talk',70)>followUpChance('noise-flat',true,'talk',70));
 assert.ok(followUpChance('domestic',true,'backup',70)<followUpChance('domestic',true,'talk',70));
 assert.ok(followUpChance('drunk-driver',false,'chase',20)>followUpChance('drunk-driver',false,'chase',90));
 assert.equal(followUpChance('crash',false,'secure',10),0);
});

test('a lost call can come back as a repeat call at the same place, marked in its name',()=>{
 let found=null;
 for(let seed=1;seed<40&&!found;seed++){const s=createGame();s.seed=seed;s.nextIncident=1e4;for(const u of s.units)u.auto=false;const anchor=spawnIncident(s,5);s.incidents=[];
  const i=spawnIncident(s,null,{variant:'drunk-driver',point:{x:anchor.x,y:anchor.y}});for(let k=0;k<3000&&i.state!=='missed';k++)tick(s,.1);
  if(s.followUps.length)found={s,i};}
 assert.ok(found,'a follow-up is queued for some seed');const {s,i}=found,f=s.followUps[0];
 assert.equal(f.variant,'crash');assert.equal(f.from,i.id);assert.equal(f.x,i.x);
 for(let k=0;k<2000&&!s.incidents.some(x=>x.followUp);k++)tick(s,.1);
 const repeat=s.incidents.find(x=>x.followUp);assert.ok(repeat);assert.match(callName(repeat),/^Повторно: /);assert.equal(repeat.x,i.x);
});
test('district trust moves with outcomes, carries into the next shift and survives save/load',()=>{
 const s=createGame();s.nextIncident=1e4;for(const u of s.units)u.auto=false;const i=spawnIncident(s,0),d=districtOf(i);const before=districtTrust(s,d);
 for(let k=0;k<3000&&i.state!=='missed';k++)tick(s,.1);assert.equal(i.state,'missed');assert.ok(districtTrust(s,d)<before);
 const n=deserialize(serialize(s));assert.deepEqual(n.districts,s.districts);
 s.ended=true;const next=nextShift(s);assert.deepEqual(next.districts,s.districts);assert.deepEqual(next.followUps??[],[]);
});

test('repeat calls are released when due, at most six active calls, and broken data is rejected',()=>{
 const s=createGame();s.nextIncident=1e4;ensureDistricts(s);const p=spawnIncident(s,0);s.incidents=[];
 s.followUps.push({at:s.time+1,variant:'noise-flat',x:p.x,y:p.y,from:7,reason:'Соседи звонят снова: музыка не прекратилась.'});
 tick(s,.5);assert.equal(s.incidents.length,0);tick(s,1);assert.equal(s.incidents.length,1);assert.equal(s.incidents[0].followUp.from,7);assert.equal(s.followUps.length,0);
 assert.match(s.logs.map(l=>l.text).join('\n'),/повторный вызов/);
 const raw=JSON.parse(serialize(s));raw.districts={nowhere:50};assert.throws(()=>deserialize(JSON.stringify(raw)));
 const raw2=JSON.parse(serialize(s));raw2.followUps=[{at:5,variant:'unknown',x:p.x,y:p.y,from:1,reason:'x'}];assert.throws(()=>deserialize(JSON.stringify(raw2)));
 assert.deepEqual(Object.keys(ensureDistricts(createGame())).sort(),[...DISTRICT_IDS].sort());
});

test('old saves without districts or follow-ups still load',()=>{const s=createGame();const raw=JSON.parse(serialize(s));delete raw.districts;delete raw.followUps;const n=deserialize(JSON.stringify(raw));assert.equal(districtTrust(n,'centre'),n.trust);});
