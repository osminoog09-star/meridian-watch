import test from 'node:test';import assert from 'node:assert/strict';
import {createGame,tick,nextShift,serialize,deserialize,spawnIncident,setRole} from '../dist/sim.js';
import {ROLES,roleBlocker,roleBonus,roleLeadBonus,COURSES} from '../dist/life.js';
import {leadFor,needsAmbulanceFor,medicalText} from '../dist/calls.js';
import {SHIFT_TICKS} from '../dist/schedule.js';
import {NODES} from '../dist/geography.js';
// R6 roles, investigations that outlive a roster shift, more medical cases.

const roster=()=>createGame('career',7182,{schedule:'ppa'});
const finish=s=>{for(let k=0;k<SHIFT_TICKS*10+10&&!s.ended;k++)tick(s,.1);return s;};

test('roles need rank, course and (for rapid response) fitness and valid shooting',()=>{
 const s=roster();assert.match(roleBlocker(s.life,'k9',0,1),/звание/);assert.match(roleBlocker(s.life,'k9',1,1),/курс/);
 s.life.courses.k9=1;assert.equal(roleBlocker(s.life,'k9',1,1),null);
 s.life.courses.tactics=1;s.life.fitness=50;assert.match(roleBlocker(s.life,'rapid',2,1),/форма/);s.life.fitness=80;assert.equal(roleBlocker(s.life,'rapid',2,1),null);
 assert.equal(setRole(s,'k9').ok,false,'rank 0');s.rank=1;assert.equal(setRole(s,'k9').ok,true);assert.equal(s.life.role,'k9');
 assert.equal(roleBonus(s.life,'missing-elder'),ROLES.k9.bonus['missing-elder']);assert.equal(roleBonus(s.life,'crash'),1);assert.ok(roleLeadBonus(s.life)>0);
 assert.equal(setRole(createGame(),'k9').ok,false,'legacy campaigns have no roles');
 assert.doesNotThrow(()=>deserialize(serialize(s)));const bad=JSON.parse(serialize(s));bad.life.role='sniper';assert.throws(()=>deserialize(JSON.stringify(bad)));
 for(const r of Object.values(ROLES))assert.ok(COURSES[r.course]);
});

test('dog handler finds more theft leads',()=>{
 let plain=0,dog=0;for(let id=1;id<=300;id++){if(leadFor({variant:'shoplift',id,decision:null}).found)plain++;if(leadFor({variant:'shoplift',id,decision:null},.2).found)dog++;}assert.ok(dog>plain);
});

test('a role really speeds up the player crew',()=>{
 const run=role=>{const s=roster();s.nextIncident=9000;for(let k=0;k<200;k++)tick(s,.1);if(role){s.rank=2;s.life.courses.tactics=1;s.life.fitness=80;assert.equal(setRole(s,role).ok,true);}
  for(const u of s.units)if(u.id!==1)u.zone='west',u.cross=false;const n=NODES[20];const i=spawnIncident(s,null,{variant:'street-fight',point:{x:n.x,y:n.y}});let k=0;for(;k<20000&&!['resolved','missed'].includes(i.state);k++)tick(s,.1);return {k,units:i.units};};
 const a=run(null),b=run('rapid');if(a.units.includes(1)&&b.units.includes(1))assert.ok(b.k<=a.k,`${b.k} <= ${a.k}`);
});

test('open investigations and their leads move to the next roster shift',()=>{
 let s=roster();s.nextIncident=9000;const units=s.units;s.units=[];let id=1;while(!leadFor({variant:'shoplift',id,decision:'check'}).found)id++;s.nextId=id;
 const i=spawnIncident(s,null,{variant:'shoplift',point:{x:NODES[40].x,y:NODES[40].y}});i.decision='check';for(let k=0;k<6000&&i.state!=='missed';k++)tick(s,.1);s.units=units;
 assert.match(s.cases.find(c=>c.id===i.id).status,/Розыск/);s.followUps=s.followUps.map(f=>f.variant==='suspect-found'?{...f,at:s.shiftLength+500}:f);
 finish(s);const n=nextShift(s);const c=n.cases.find(x=>x.id===i.id);assert.ok(c,'case carried');assert.equal(c.fromShift,1);
 assert.ok(n.followUps.some(f=>f.from===i.id&&f.variant==='suspect-found'&&f.at<200),'lead comes early in the next shift');
 assert.doesNotThrow(()=>deserialize(serialize(n)));
 const legacy=createGame();legacy.cases=[{...c,fromShift:undefined}];legacy.ended=true;assert.equal(nextShift(legacy).cases,undefined,'legacy campaigns unchanged');
});

test('more medical cases, decided by call id',()=>{
 assert.equal(needsAmbulanceFor({variant:'domestic',id:4}),true);assert.equal(needsAmbulanceFor({variant:'domestic',id:5}),false);
 assert.equal(needsAmbulanceFor({variant:'missing-elder',id:6}),true);assert.equal(needsAmbulanceFor({variant:'crash',id:7}),true);assert.equal(needsAmbulanceFor({variant:'noise-flat',id:6}),false);
 assert.match(medicalText({variant:'missing-elder'}),/переохлаждение/);
});
