import test from 'node:test';import assert from 'node:assert/strict';
import {createGame,tick,nextShift,spawnIncident,TRUST_BALANCE} from '../dist/sim.js';
import {NODES} from '../dist/geography.js';
// R15 «Баланс доверия» (Claude, 11.10.2026): trust no longer sticks at 100% in 12-hour roster shifts.
function resolveOne(s){for(const u of s.units)u.tasksToday=99;s.nextIncident=9000;const n=NODES[(s.seed*7)%NODES.length];const i=spawnIncident(s,null,{variant:'animal-road',point:{x:n.x,y:n.y}});
 for(let k=0;k<20000&&!['resolved','missed'].includes(i.state);k++)tick(s,.1);return i;}

test('a good call adds less the higher trust is (roster); legacy keeps +2',()=>{
 const gain=(trust,opt)=>{for(let seed=1;seed<40;seed++){const s=createGame('career',seed,opt);s.trust=trust;const before=s.trust;const i=resolveOne(s);if(i.state==='resolved'&&!i.medical&&!i.rescue&&!i.bolo)return s.trust-before;}return null;};
 const low=gain(60,{schedule:'ppa'}),high=gain(95,{schedule:'ppa'}),legacy=gain(60,{});
 assert.ok(low>0&&high>0&&high<low/3,`${low} ${high}`);assert.equal(legacy,2);
 assert.ok(low<=2*TRUST_BALANCE.gain*40/TRUST_BALANCE.span+1e-9);
});

test('between roster shifts trust drifts toward neutral; legacy does not drift',()=>{
 const s=createGame('career',7182,{schedule:'ppa'});s.trust=100;s.ended=true;const n=nextShift(s);
 assert.equal(n.trust,100+(TRUST_BALANCE.neutral-100)*TRUST_BALANCE.drift);
 const d=Object.keys(s.districts??{})[0];if(d){const t=createGame('career',7182,{schedule:'ppa'});t.districts[d]=100;t.ended=true;assert.ok(nextShift(t).districts[d]<100);}
 const low=createGame('career',7182,{schedule:'ppa'});low.trust=40;low.ended=true;assert.ok(nextShift(low).trust>40,'bad opinion also fades');
 const legacy=createGame('career',7182);legacy.trust=100;legacy.ended=true;assert.equal(nextShift(legacy).trust,100);
});
