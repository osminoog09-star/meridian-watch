import test from 'node:test';import assert from 'node:assert/strict';
import {createGame,spawnIncident,tick,serialize,deserialize,nextShift,FIRE_STATION,serviceStatus} from '../dist/sim.js';
import {needsRescue,RESCUE_TEAM,SERVICE_LIMIT,variantById} from '../dist/calls.js';
import {NODES} from '../dist/geography.js';
// 0.7.2 v1: rescuers — station -> safe zone -> work (faster under police cordon) -> station.

const fresh=seed=>{const s=createGame();s.seed=seed;s.nextIncident=9000;return s;};
const at=k=>({x:NODES[k].x,y:NODES[k].y});

test('which calls need rescuers',()=>{
 assert.equal(variantById('fire-smoke').type,1);
 assert.equal(needsRescue({variant:'fire-smoke',id:1}),true);
 assert.equal(needsRescue({variant:'crash',id:3}),true);assert.equal(needsRescue({variant:'crash',id:4}),false);
 assert.equal(needsRescue({variant:'noise-flat',id:3}),false);
});

test('a fire alerts rescuers at once; they secure, work, finish and return to the station',()=>{
 const s=fresh(5);const i=spawnIncident(s,null,{variant:'fire-smoke',point:at(40)});
 const a=s.services.find(x=>x.kind==='rescue');assert.ok(a);assert.equal(i.rescue,'called');assert.equal(a.status,'responding');assert.ok(Math.hypot(a.x-FIRE_STATION.x,a.y-FIRE_STATION.y)<1e-9,'starts at the station');assert.match(serviceStatus(a),/едут/);
 const seen=new Set();for(let k=0;k<30000&&s.services.includes(a);k++){tick(s,.1);seen.add(a.status);}
 for(const st of ['responding','securing','working','returning'])assert.ok(seen.has(st),st);
 assert.equal(i.rescue,'done');assert.ok(!s.services.includes(a));
 const log=s.logs.map(l=>l.text).join('\n');assert.match(log,/Спасатели \d+: на месте/);assert.match(log,/возгорание потушено/);
});

test('police on scene speeds up the rescue work',()=>{
 const work=withCordon=>{const s=fresh(9);const i=spawnIncident(s,null,{variant:'fire-smoke',point:at(60)});const a=s.services.find(x=>x.kind==='rescue');
  if(!withCordon)s.units=[];
  let t0=null;for(let k=0;k<30000&&i.rescue!=='done';k++){tick(s,.1);if(a.status==='working'&&t0===null)t0=s.time;}
  return {span:s.time-t0,cordon:s.logs.some(l=>/полиция держит оцепление/.test(l.text))};};
 const a=work(true),b=work(false);assert.ok(Number.isFinite(a.span)&&Number.isFinite(b.span));
 assert.ok(a.cordon,'police held the cordon');assert.ok(a.span<b.span,'cordon makes work shorter');
 assert.ok(RESCUE_TEAM.cordonSpeed>1);
});

test('rescue state survives save/load, is validated and does not carry into the next shift',()=>{
 const s=fresh(3);spawnIncident(s,null,{variant:'fire-smoke',point:at(20)});for(let k=0;k<50;k++)tick(s,.1);
 const n=deserialize(serialize(s));assert.deepEqual(n.services,s.services);
 const bad=JSON.parse(serialize(s));bad.services[0].status='treating';assert.throws(()=>deserialize(JSON.stringify(bad)));
 const bad2=JSON.parse(serialize(s));bad2.incidents[0].rescue='maybe';assert.throws(()=>deserialize(JSON.stringify(bad2)));
 const many=JSON.parse(serialize(s));many.services=Array.from({length:SERVICE_LIMIT+1},(_,k)=>({...s.services[0],id:k+1}));assert.throws(()=>deserialize(JSON.stringify(many)));
 s.ended=true;assert.equal(nextShift(s).services,undefined);
});

test('a closed fire call with finished rescue files the case with the rescue mark',()=>{
 for(let seed=1;seed<40;seed++){const s=fresh(seed);const i=spawnIncident(s,null,{variant:'fire-smoke',point:at((seed*11)%NODES.length)});
  for(let k=0;k<30000&&!(['resolved','missed'].includes(i.state)&&i.rescue==='done');k++)tick(s,.1);
  const c=s.cases?.find(x=>x.id===i.id);assert.ok(c);if(i.rescue==='done'&&c.rescue){assert.equal(c.rescue,true);return;}}
 // Police may close before rescuers finish; then the case simply has no rescue mark.
});
