import test from 'node:test';import assert from 'node:assert/strict';
import {WEATHER,weatherFor,weatherFactor,variantWeights,VARIANTS} from '../dist/calls.js';
import {createGame,shiftWeather,serialize,deserialize} from '../dist/sim.js';
// «Погода смены»: deterministic per shift, changes the call mix, never the save format.
test('weather is fixed for a shift, varies across shifts and stays in its temperature range',()=>{
 const kinds=new Set();for(let shift=1;shift<=20;shift++){const w=weatherFor(7182,shift);assert.deepEqual(w,weatherFor(7182,shift));kinds.add(w.kind);const [lo,hi]=WEATHER[w.kind].temps;assert.ok(w.temp>=lo&&w.temp<=hi);}
 assert.ok(kinds.size>=3);
});
test('rain makes crashes more likely and yard parties rarer',()=>{
 const share=(id,w)=>{const ws=variantWeights(23*60,w),k=VARIANTS.findIndex(v=>v.id===id);return ws[k]/ws.reduce((a,b)=>a+b,0);};
 const rain={kind:'rain'},clear={kind:'clear'};assert.ok(share('crash',rain)>share('crash',clear));assert.ok(share('yard-company',rain)<share('yard-company',clear));assert.equal(weatherFactor(null,'crash'),1);
});
test('weather is derived, not stored: saves are unchanged and the shift decides it',()=>{const s=createGame();assert.equal(JSON.parse(serialize(s)).weather,undefined);assert.deepEqual(shiftWeather(deserialize(serialize(s))),shiftWeather(s));});
