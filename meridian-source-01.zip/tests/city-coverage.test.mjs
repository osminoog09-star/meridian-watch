import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {execFileSync} from 'node:child_process';
import data from '../dist/city-data.js';
import {GEO_BOUNDS,WORLD_BOUNDS,WORLD_SCALE,coverageInfo,containsWorldPoint,projectGeo,unprojectWorld} from '../dist/city-coverage.js';
import {ROAD_NODES,project} from '../dist/geography.js';
import {createCamera} from '../dist/camera.js';

const close=(a,b)=>assert.ok(Math.abs(a-b)<1e-9,`${a} != ${b}`);
test('coverage derives geographic and world bounds from the shipped OSM snapshot',()=>{
 assert.deepEqual(data.bbox,[GEO_BOUNDS.west,GEO_BOUNDS.south,GEO_BOUNDS.east,GEO_BOUNDS.north]);
 assert.deepEqual(WORLD_BOUNDS,{minX:0,minY:0,maxX:4.725,maxY:4.55});
 assert.deepEqual(coverageInfo(),{id:'parnu-core-2026-10',region:'Pärnumaa',place:'Pärnu',source:data.source,date:data.date,geo:{...GEO_BOUNDS},world:{...WORLD_BOUNDS},scale:{...WORLD_SCALE}});
 for(const [lon,lat] of [[GEO_BOUNDS.west,GEO_BOUNDS.north],[GEO_BOUNDS.east,GEO_BOUNDS.south],[24.499,58.384]]){
  const p=projectGeo(lon,lat),q=unprojectWorld(p.x,p.y);close(q.lon,lon);close(q.lat,lat);assert.deepEqual(project(lon,lat),p);
 }
 assert.ok(ROAD_NODES.every(containsWorldPoint));
 assert.equal(containsWorldPoint({x:-1e-6,y:1}),false);assert.equal(containsWorldPoint({x:1,y:WORLD_BOUNDS.maxY+1e-6}),false);
});

test('camera accepts an expanded regional coverage without changing the current default scale',()=>{
 const current=createCamera({x:2,y:2,zoom:1});current.viewport(510,500);close(current.scale(),100);
 const region={minX:-2,minY:-1,maxX:8,maxY:7},camera=createCamera({x:20,y:-20,zoom:1},{},region);camera.viewport(510,500);
 assert.deepEqual(camera.getView(),{x:8,y:-1,zoom:1,tracking:null});
 camera.focus({x:-50,y:50},2);assert.deepEqual(camera.getView(),{x:-2,y:7,zoom:2,tracking:null});
});

test('all OSM extractors use the shared Python projection contract',()=>{
 const result=JSON.parse(execFileSync('python',['-c',"import json,sys;sys.path.insert(0,'tools');from city_projection import BBOX,SCALE,project,world_bounds;print(json.dumps({'bbox':BBOX,'scale':SCALE,'centre':project(24.499,58.384),'world':world_bounds()}))"],{encoding:'utf8'}));
 assert.deepEqual(result,{bbox:data.bbox,scale:[35,65],centre:[1.54,2.665],world:[0,0,4.725,4.55]});
 for(const name of ['build-city.py','build-quarter.py','build-walking.py']){
  const source=fs.readFileSync(new URL('../tools/'+name,import.meta.url),'utf8');assert.match(source,/from city_projection import/);assert.doesNotMatch(source,/24\.455\)\*35|58\.425-/);
 }
});
