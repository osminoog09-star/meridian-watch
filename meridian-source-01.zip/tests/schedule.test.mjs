import test from 'node:test';import assert from 'node:assert/strict';
import {createGame,tick,nextShift,serialize,deserialize,spawnIncident} from '../dist/sim.js';
import {cityMinute,formatMinute} from '../dist/population.js';
import {SHIFT_TICKS,ROTA,shiftKind,shiftStartMinute,restBefore,nextShiftInfo,nightFatigueFactor,shiftStartElapsed} from '../dist/schedule.js';
// R1: realistic PPA roster — 12 h shifts, 2 day + 2 night, then 4 days off.

const clock=s=>formatMinute(cityMinute(s.population.elapsed));
function finish(s){for(let k=0;k<SHIFT_TICKS*10+10&&!s.ended;k++)tick(s,.1);assert.ok(s.ended);return s;}

test('calendar: 12-hour shifts, D-D-N-N, rest 12/24/12/96 hours',()=>{
 assert.equal(SHIFT_TICKS,960);assert.deepEqual(ROTA,['day','day','night','night']);
 assert.deepEqual([0,1,2,3,4].map(shiftKind),['day','day','night','night','day']);
 assert.deepEqual([1,2,3,4,5].map(i=>restBefore(i)/60),[12,24,12,96,12]);
 assert.equal(shiftStartMinute(0)%1440,8*60);assert.equal(shiftStartMinute(2)%1440,20*60);
 const n=nextShiftInfo(4);assert.equal(n.kind,'day');assert.equal(n.daysOff,4);assert.equal(n.restHours,96);
 assert.ok(shiftStartElapsed(0)>=0);
 assert.equal(nightFatigueFactor(12*60),1);assert.ok(nightFatigueFactor(4.5*60)>1.5);assert.ok(nightFatigueFactor(2*60)<nightFatigueFactor(4.5*60));assert.equal(nightFatigueFactor(9*60),1);
});

test('legacy campaigns are untouched; new scheduled ones start at 08:00 and last 12 hours',()=>{
 const legacy=createGame();assert.equal(legacy.shiftLength,480);assert.equal(legacy.schedule,undefined);assert.equal(clock(legacy),'17:00');
 const s=createGame('career',7182,{schedule:'ppa'});assert.equal(s.shiftLength,960);assert.equal(s.schedule,'ppa');assert.equal(clock(s),'08:00');
 assert.doesNotThrow(()=>deserialize(serialize(s)));
 const bad=JSON.parse(serialize(s));bad.shiftLength=480;assert.throws(()=>deserialize(JSON.stringify(bad)),'schedule and length must agree');
 const bad2=JSON.parse(serialize(legacy));bad2.shiftLength=960;assert.throws(()=>deserialize(JSON.stringify(bad2)));
});

test('the roster drives the city clock across shifts and days off',()=>{
 let s=createGame('career',7182,{schedule:'ppa'});const starts=[clock(s)];
 for(let k=0;k<4;k++){finish(s);assert.equal(clock(s),k<2?'20:00':'08:00');assert.doesNotThrow(()=>deserialize(serialize(s)),'a finished shift saves');spawnIncident(s,4);s=nextShift(s);starts.push(clock(s));
  assert.equal(s.incidents.length,0,'unfinished calls go to the next team');assert.ok(s.units.every(u=>u.status==='briefing'&&!u.foot&&u.incident===null),'new shift starts with the briefing');
  assert.doesNotThrow(()=>deserialize(serialize(s)),'residents resynced to a valid state');}
 assert.deepEqual(starts,['08:00','08:00','20:00','20:00','08:00']);
 assert.equal(s.shift,5);assert.equal(s.schedule,'ppa');assert.equal(s.shiftLength,960);
});

test('night duty tires crews faster than day duty',()=>{
 const gain=startShiftIndex=>{const s=createGame('career',7182,{schedule:'ppa'});s.nextIncident=9000;
  // Jump the city clock to 04:00 (night) or 12:00 (day) and measure fatigue over one world hour.
  const target=startShiftIndex==='night'?4*60:12*60,now=cityMinute(s.population.elapsed),delta=((target-now)+1440)%1440;s.population.elapsed+=delta*60/45;
  const before=s.units[0].fatigue;for(let k=0;k<800;k++)tick(s,.1);return s.units[0].fatigue-before;};
 assert.ok(gain('night')>gain('day')*1.2,`night ${gain('night')} vs day ${gain('day')}`);
});
