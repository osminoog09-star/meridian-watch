import test from 'node:test';import assert from 'node:assert/strict';
import {advanceRoute,advanceVehicle,travelDistance,createSimulationClock,worldMinutes,VEHICLE_DYNAMICS} from '../dist/transport.js';import {MAP_METRES} from '../dist/world-scale.js';import {createGame,tick,serialize,deserialize} from '../dist/sim.js';import {createCamera} from '../dist/camera.js';
const near=(a,b)=>assert.ok(Math.abs(a-b)<1e-8,`${a} != ${b}`);
test('km/h, world clock and route arc agree, including corners and arrival',()=>{const a={x:0,y:0,route:[{x:1,y:0},{x:1,y:2}]};let moved=0;for(let k=0;k<10;k++)moved+=advanceRoute(a,.1,60);near(moved*MAP_METRES,750);near(a.currentSpeedKmh,60);near(worldMinutes(1),.75);const b={x:0,y:0,route:[{x:.1,y:0},{x:.1,y:.1}]};near(advanceRoute(b,1,60),.2);assert.equal(b.route.length,0);assert.ok(b.currentSpeedKmh<60);advanceRoute(b,.1,60);assert.equal(b.currentSpeedKmh,0);});
test('x1 x2 x4 and 15/30/60 FPS yield identical simulation for identical world duration',()=>{let expected;for(const speed of [1,2,4])for(const fps of [15,30,60]){const s=createGame(),clock=createSimulationClock();let remaining=3/speed;while(remaining>1e-10){const dt=Math.min(1/fps,remaining);clock.advance(dt,speed,step=>tick(s,step));remaining-=dt;}const raw=serialize(s);expected??=raw;assert.equal(raw,expected);assert.deepEqual(deserialize(raw),s);}});
test('distance scales with acceleration at equal real duration; bounded stalls are accounted for',()=>{const distances=[];for(const speed of [1,2,4]){const a={x:0,y:0,route:[{x:10,y:0}]},clock=createSimulationClock();for(let k=0;k<30;k++)clock.advance(1/30,speed,dt=>advanceRoute(a,dt,30));distances.push(a.x);}near(distances[1],distances[0]*2);near(distances[2],distances[0]*4);const c=createSimulationClock();let total=0;c.advance(.2,4,dt=>total+=dt);near(total,.8);const r=c.advance(2,4,dt=>total+=dt);near(r.dropped,1.5);assert.equal(r.steps,20);c.reset();assert.equal(c.advance(.09,1,()=>{}).steps,0);});
test('close follow at x4 keeps a moving patrol in view without editing it',()=>{const c=createCamera();c.viewport(390,570);const u={id:1,x:1,y:2,currentSpeedKmh:30};c.focus(u,96,1);for(let k=0;k<60;k++){u.x+=travelDistance(30,4/60);const before=JSON.stringify(u);c.track([u],1/60,4);assert.equal(JSON.stringify(u),before);const p=c.screen(u);assert.ok(p.x>=0&&p.x<=390);} });
test('vehicle accelerates from rest continuously and is independent of caller chunking',()=>{
 const route=[{x:2,y:0,roadSpeed:{kmh:50,source:'osm'}}],a={x:0,y:0,route:structuredClone(route)},b={x:0,y:0,route:structuredClone(route)};
 advanceVehicle(a,1/45,50);near(a.motionSpeedKmh,VEHICLE_DYNAMICS.acceleration*3.6);assert.ok(a.currentSpeedKmh>0&&a.currentSpeedKmh<a.motionSpeedKmh);
 advanceVehicle(a,9/45,50);for(let k=0;k<10;k++)advanceVehicle(b,1/45,50);
 near(a.x,b.x);near(a.motionSpeedKmh,b.motionSpeedKmh);
});
test('vehicle brakes before a lower limit, slows for a corner and stops at route end',()=>{
 const metres=m=>m/MAP_METRES,limited={x:0,y:0,motionSpeedKmh:50,route:[{x:metres(200),y:0,roadSpeed:{kmh:50,source:'osm'}},{x:metres(500),y:0,roadSpeed:{kmh:20,source:'osm'}}]};
 while(limited.route.length>1)advanceVehicle(limited,1/45,60);assert.ok(limited.motionSpeedKmh<=20+1e-8);assert.equal(limited.roadLimitKmh,20);
 const corner={x:0,y:0,motionSpeedKmh:50,route:[{x:metres(100),y:0,roadSpeed:{kmh:50,source:'osm'}},{x:metres(100),y:metres(100),roadSpeed:{kmh:50,source:'osm'}}]};
 while(corner.route.length>1)advanceVehicle(corner,1/45,60);assert.ok(corner.motionSpeedKmh<=VEHICLE_DYNAMICS.sharpTurn+VEHICLE_DYNAMICS.acceleration*3.6+1e-8);
 while(corner.route.length)advanceVehicle(corner,1/45,60);near(corner.x,metres(100));near(corner.y,metres(100));assert.equal(corner.motionSpeedKmh,0);advanceVehicle(corner,1/45,60);assert.equal(corner.currentSpeedKmh,0);
});
test('real-time world clock advances physical metres with x1/x2/x4 and stable fixed sampling',()=>{
 for(const multiplier of [1,2,4])for(const fps of [15,30,60,144]){
  const car={x:0,y:0,route:[{x:10,y:0}]},clock=createSimulationClock({worldRate:1});let elapsed=0;
  for(let k=0;k<fps*60;k++)clock.advance(1/fps,multiplier,dt=>{elapsed+=dt;advanceRoute(car,dt,30);});
  near(elapsed*45,60*multiplier);near(car.x*MAP_METRES,500*multiplier);near(worldMinutes(elapsed),multiplier);near(clock.visualScale(multiplier),multiplier/45);
 }
});
test('changing pace preserves campaign and discards only partial clock quantum',()=>{const clock=createSimulationClock({worldRate:1}),s=createGame(),raw=serialize(s);clock.advance(.09,1,()=>assert.fail('early step'));clock.rate(45);assert.equal(clock.worldRate(),45);assert.equal(clock.visualScale(0),0);assert.equal(clock.advance(.09,1,()=>assert.fail('old remainder leaked')).steps,0);assert.equal(serialize(s),raw);});
test('duration labels use world seconds instead of internal campaign units',async()=>{const {formatWorldDuration}=await import('../dist/transport.js');assert.equal(formatWorldDuration(120),'1 ч 30 мин города');assert.equal(formatWorldDuration(1),'45 с города');assert.equal(formatWorldDuration(-1),'0 с города');});
