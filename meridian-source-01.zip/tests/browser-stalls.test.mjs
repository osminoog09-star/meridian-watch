import test from 'node:test';import assert from 'node:assert/strict';
import {createBrowserStalls} from '../dist/browser-stalls.js';
import {createDiagnostics} from '../dist/diagnostics.js';
function fake(types=['long-animation-frame']){return class Observer{static supportedEntryTypes=types;static instances=[];constructor(callback){this.callback=callback;this.constructor.instances.push(this);}observe(options){this.options=options;}disconnect(){this.disconnected=true;}takeRecords(){this.drained=true;}emit(entries){this.callback({getEntries:()=>entries});}};}
test('browser stalls opt in, remain bounded and never retain identifying script data',()=>{
 const Observer=fake(),d=createDiagnostics({Observer});assert.equal(Observer.instances.length,0);d.setEnabled(true);const o=Observer.instances[0];assert.deepEqual(o.options,{type:'long-animation-frame',buffered:false});
 o.emit(Array.from({length:90},(_,k)=>({startTime:k*100,duration:80,blockingDuration:15,renderStart:k*100+60,styleAndLayoutStart:k*100+65,scripts:[{duration:40,forcedStyleAndLayoutDuration:5,sourceURL:'https://private/token',name:'secret'}]})));
 const b=d.report().browser;assert.equal(b.samples.length,60);assert.equal(b.samples[0].startMs,3000);assert.equal(b.samples[0].renderPhaseMs,20);assert.equal(b.samples[0].styleLayoutPhaseMs,15);assert.equal(b.samples[0].forcedStyleLayoutMs,5);assert.ok(!JSON.stringify(b).includes('secret'));assert.ok(!JSON.stringify(b).includes('private'));
 b.samples[0].durationMs=0;assert.equal(d.report().browser.samples[0].durationMs,80);
 d.clear();assert.equal(d.report().browser.samples.length,0);assert.ok(o.drained);d.setEnabled(false);assert.ok(o.disconnected);o.emit([{duration:99}]);assert.equal(d.report().browser.samples.length,0);
 d.setEnabled(true);o.emit([{duration:99}]);assert.equal(d.report().browser.samples.length,0);
});
test('unsupported and task fallback explicitly differ from zero browser stalls',()=>{
 const absent=createBrowserStalls({Observer:null});absent.start();assert.equal(absent.report().mode,'unsupported');
 const Observer=fake(['longtask']),d=createBrowserStalls({Observer});d.start();Observer.instances[0].emit([{startTime:2,duration:70},{duration:NaN},{duration:1}]);assert.equal(d.report().mode,'longtask');assert.deepEqual(d.report().samples,[{startMs:2,durationMs:70}]);d.stop();assert.equal(d.report().mode,'disabled');
});
test('rejected animation-frame observer safely falls back and sanitizes numeric fields',()=>{
 const Base=fake(['long-animation-frame','longtask']);class Observer extends Base{observe(options){if(options.type==='long-animation-frame')throw Error('unavailable');super.observe(options);}}
 const d=createBrowserStalls({Observer});d.start();assert.equal(d.report().mode,'longtask');assert.ok(Observer.instances[0].disconnected);Observer.instances.at(-1).emit([{startTime:Infinity,duration:65}]);assert.equal(d.report().samples[0].startMs,0);
});
