import test from 'node:test';import assert from 'node:assert/strict';
import {createGame,spawnIncident,tick,serialize,deserialize,nextShift,HOSPITAL,serviceStatus} from '../dist/sim.js';
import {needsAmbulance,AMBULANCE} from '../dist/calls.js';import {NODES} from '../dist/geography.js';
// 0.7.1 v1: ambulance cycle hospital -> scene -> hospital.
function crash(){const s=createGame();s.nextIncident=9000;const n=NODES[30];return {s,i:spawnIncident(s,null,{variant:'crash',point:{x:n.x,y:n.y}})};}
test('only injury-type calls need an ambulance',()=>{assert.ok(needsAmbulance('crash')&&needsAmbulance('drunk-person'));assert.ok(!needsAmbulance('noise-flat')&&!needsAmbulance('shoplift'));});
test('ambulance is called on police arrival, treats, transports and leaves; trust bonus when in time',()=>{
 const {s,i}=crash();const seen=new Set();let trustAtFinish=null;
 for(let k=0;k<6000;k++){tick(s,.1);for(const a of s.services??[])seen.add(a.status);if(i.state==='resolved'&&trustAtFinish===null)trustAtFinish=s.trust;if(seen.has('handover')&&!(s.services??[]).length)break;}
 assert.deepEqual([...seen].sort(),['handover','responding','transporting','treating'].sort());assert.equal(i.medical,'treated');assert.equal((s.services??[]).length,0);
 const text=s.logs.map(l=>l.text).join('\n');assert.match(text,/Скорая 1: Пострадавшие в ДТП — выезжаем/);assert.match(text,/доставлен в больницу/);
});
test('ambulance state survives save/load, is validated and does not carry into the next shift',()=>{
 const {s}=crash();for(let k=0;k<4000&&!(s.services??[]).length;k++)tick(s,.1);assert.equal(s.services.length,1);assert.equal(serviceStatus(s.services[0]),'едет на вызов');
 const n=deserialize(serialize(s));assert.deepEqual(n.services,s.services);
 const bad=JSON.parse(serialize(s));bad.services[0].kind='taxi';assert.throws(()=>deserialize(JSON.stringify(bad)));
 s.ended=true;assert.equal(nextShift(s).services,undefined);
 assert.ok(Number.isFinite(HOSPITAL.x));assert.ok(AMBULANCE.maxActive>=1);
});
