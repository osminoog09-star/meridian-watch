import test from 'node:test';
import assert from 'node:assert/strict';
import {createNearestPoint} from '../dist/nearest-point.js';
import {ROAD_NODES,nearestRoad} from '../dist/geography.js';
const exhaustive=(p,list)=>list.reduce((a,b)=>Math.hypot(p.x-b.x,p.y-b.y)<Math.hypot(p.x-a.x,p.y-a.y)?b:a);
test('exact nearest road preserves original references across city and outside map',()=>{
 let seed=73;const rand=()=>((seed=Math.imul(seed,1664525)+1013904223>>>0)/2**32);
 for(let k=0;k<3000;k++){const p=k<500?ROAD_NODES[k%ROAD_NODES.length]:{x:rand()*8-2,y:rand()*8-2};assert.equal(nearestRoad(p),exhaustive(p,ROAD_NODES));}
});
test('nearest index keeps original tie order, duplicates, edges and narrow gaps',()=>{
 const points=[{x:1,y:0},{x:-1,y:0},{x:1,y:0},{x:0,y:2},{x:0,y:-2}];const find=createNearestPoint(points);
 for(const p of [{x:0,y:0},{x:1,y:0},{x:0,y:1},{x:0,y:-1},{x:1e-15,y:0},{x:-1e-15,y:0},{x:NaN,y:0}])assert.equal(find(p),exhaustive(p,points));
 assert.equal(createNearestPoint([points[0]])({x:99,y:99}),points[0]);
 assert.throws(()=>createNearestPoint([]));
});
