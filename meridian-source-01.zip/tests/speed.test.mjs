import test from 'node:test';import assert from 'node:assert/strict';
import {createSimulationClock,GAME_SPEEDS,stepFor,MAX_STEP,MAX_STEPS_PER_FRAME,WORLD_SECONDS_PER_TICK_SECOND} from '../dist/transport.js';
import {createGame,tick,serialize,deserialize} from '../dist/sim.js';
// R24 «Больше ускорения» (Claude, 11.10.2026): ×10/×30/×60 keep world time exact and the simulation sound.
const run=(rate,speed,fps,seconds)=>{const c=createSimulationClock({worldRate:rate});let world=0,maxSteps=0;for(let k=0;k<seconds*fps;k++){const r=c.advance(1/fps,speed,dt=>{world+=dt;});maxSteps=Math.max(maxSteps,r.steps);}return {world:world*WORLD_SECONDS_PER_TICK_SECOND,maxSteps};};

test('new speeds exist and the old ones keep the same step',()=>{
 assert.deepEqual(GAME_SPEEDS,[1,2,4,10,30,60]);for(const s of [1,2,4])assert.equal(stepFor(1,s),stepFor(1,1));
 assert.ok(stepFor(1,60)>stepFor(1,4));assert.ok(stepFor(45,60)<=MAX_STEP);
});

test('×10/×30/×60 advance world time by exactly speed × real time, at 15–60 FPS, within the step budget',()=>{
 for(const rate of [1,45])for(const speed of [10,30,60])for(const fps of [15,30,60]){const {world,maxSteps}=run(rate,speed,fps,20),want=20*speed*rate;
  assert.ok(maxSteps<=MAX_STEPS_PER_FRAME);if(rate===1||speed*rate/WORLD_SECONDS_PER_TICK_SECOND/fps<=MAX_STEP*MAX_STEPS_PER_FRAME)assert.ok(Math.abs(world-want)/want<.02,`${rate} ${speed} ${fps}: ${world} vs ${want}`);}
 const real=run(1,60,30,60).world;assert.ok(Math.abs(real-3600)<60,'×60 in real-time mode: one city hour per real minute');
});

test('a roster shift at the ×60 step gives the same kind of result as at ×1 and stays valid',()=>{
 const shift=step=>{const s=createGame('career',4242,{schedule:'ppa'});let stuck=0;const still=new Map();for(let k=0;k<s.shiftLength/step+5&&!s.ended;k++){tick(s,step);for(const u of s.units){const n=u.status==='responding'&&(u.currentSpeedKmh??0)<1&&!u.pullover?(still.get(u.id)??0)+step:0;still.set(u.id,n);if(n>30){stuck++;still.set(u.id,0);}}}
  assert.doesNotThrow(()=>deserialize(serialize(s)));return {resolved:s.resolved,missed:s.missed,stuck,time:s.time};};
 const slow=shift(.1),fast=shift(Math.max(stepFor(1,60),stepFor(45,60)));assert.equal(Math.max(stepFor(1,60),stepFor(45,60)),MAX_STEP);
 assert.equal(fast.stuck,0);assert.ok(Math.abs(fast.resolved-slow.resolved)<=Math.max(4,slow.resolved*.2),JSON.stringify({slow,fast}));assert.ok(fast.missed<=slow.missed+2);
});
