import test from 'node:test';import assert from 'node:assert/strict';
import {createGame,nextShift,serialize,deserialize,shiftWeather} from '../dist/sim.js';
import {specialEvent,EVENTS,EVENT_IDS} from '../dist/events.js';
import {VARIANTS,variantWeights,variantAllowed} from '../dist/calls.js';
import {makeGoals,goalValue,goalMet,goalLabel,GOAL_REWARD,validGoals} from '../dist/goals.js';
import {shiftDate,seasonOf,shiftEvent} from '../dist/season.js';
import {shiftKind} from '../dist/schedule.js';
// R18 «Крупные события смены» and R19 «План на месяц» (Claude, 11.10.2026).

test('city events follow the calendar and are deterministic',()=>{
 const seen={};for(let i=0;i<730;i++){const night=i%4>=2,e=specialEvent(i,night);assert.deepEqual(e,specialEvent(i,night));if(!e)continue;seen[e.id]=(seen[e.id]??0)+1;const season=seasonOf(shiftDate(i).month);
  if(e.id==='storm')assert.ok(['autumn','winter'].includes(season));if(e.id==='outage')assert.equal(season,'winter');if(e.id==='football')assert.equal(night,false);}
 for(const id of EVENT_IDS){assert.ok(seen[id]>0,id);assert.ok(EVENTS[id].about.length>30&&EVENTS[id].intensity>1);}
 const share=Object.values(seen).reduce((a,b)=>a+b,0)/730;assert.ok(share>.05&&share<.2,String(share));
});

test('a storm turns the weather to wind and brings its own calls; event calls never appear otherwise',()=>{
 let idx=0;while(specialEvent(idx,shiftKind(idx)==='night')?.id!=='storm'||shiftEvent(idx,shiftKind(idx)==='night'))idx++;const s=createGame('career',7182,{schedule:'ppa'});s.shift=idx+1;
 const w=shiftWeather(s);assert.equal(w.event.id,'storm');assert.equal(w.kind,'wind');const k=VARIANTS.findIndex(v=>v.id==='tree-down');assert.ok(variantWeights(12*60,w)[k]>0);
 const calm={kind:'clear',season:'autumn',event:null};for(const v of VARIANTS.filter(v=>v.events))assert.equal(variantAllowed(v,calm),false,v.id);
 assert.equal(variantAllowed(VARIANTS.find(v=>v.id==='fan-fight'),{kind:'clear',season:'autumn',event:{id:'football'}}),true);
});

test('a monthly plan is set at the start, shows live progress and pays at month end',()=>{
 let s=createGame('career',7182,{schedule:'ppa'});assert.ok(s.goals);assert.equal(s.goals.label,'октябрь 2026');assert.equal(s.goals.list.length,3);assert.ok(s.goals.list.every(g=>goalLabel(g).length>10));
 assert.ok(s.logs.some(l=>/План на октябрь/.test(l.text)));const missed=s.goals.list.find(g=>g.id==='missed');s.missed=2;assert.equal(goalValue(s,missed,s.goals.month),2);assert.ok(goalMet(missed,2));assert.equal(goalMet(missed,missed.target+1),false);
 const xp=s.xp;for(let k=0;k<12;k++){s.resolved=25;s.missed=0;s.trust=99;for(const d of Object.keys(s.districts))s.districts[d]=99;s.ended=true;s=nextShift(s);}
 const res=s.monthReport.goals;assert.ok(res&&res.length===3);const met=res.filter(r=>r.met).length;assert.ok(met>=2,JSON.stringify(res));
 assert.ok(s.life.money>0);assert.ok(s.xp>=xp+met*GOAL_REWARD.xp);assert.equal(s.goals.label,'ноябрь 2026','a new plan for the new month');
 assert.doesNotThrow(()=>deserialize(serialize(s)));const bad=JSON.parse(serialize(s));bad.goals.list[0].id='world-peace';assert.throws(()=>deserialize(JSON.stringify(bad)));
});

test('the chief gets budget for met goals; old campaigns have no plan',()=>{
 const s=createGame('chief',7182,{schedule:'ppa'});const g=makeGoals(s,0);assert.equal(g.list.find(x=>x.id==='missed').target,8);assert.ok(validGoals({goals:g}));
 assert.equal(createGame('career',7182).goals,undefined);
});
