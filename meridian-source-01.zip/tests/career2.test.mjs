import test from 'node:test';import assert from 'node:assert/strict';
import {createGame,tick,nextShift,serialize,deserialize,setShiftFocus,chooseCouncil,chooseLifeEvent,hireOfficer,createPatrol,startCaseStep} from '../dist/sim.js';
import {FOCUS,canSetFocus,attestation,ATTEST,LIFE_EVENTS,LIFE_EVENT_IDS,lifeEventFor,COUNCIL,morale,newCandidates,validCareer2} from '../dist/career2.js';
import {INTERVIEW_NEED,LAB,labResult,openCases} from '../dist/detective.js';
import {TASKS} from '../dist/patrolwork.js';
// Release C «Карьера и отделение 2.0» (Claude, 12.10.2026).
const skip=s=>{s.ended=true;return nextShift(s);};
function chief(){const s=createGame('chief',4242,{schedule:'ppa'});for(const c of [...s.candidates].slice(0,4))hireOfficer(s,c.id);createPatrol(s,s.officers[0].id,s.officers[1].id,1);createPatrol(s,s.officers[2].id,s.officers[3].id,2);s.setupPending=false;return s;}
const untilMonth=(s,pred,max=60)=>{for(let k=0;k<max&&!pred(s);k++)s=skip(s);return s;};

test('only a sergeant or the chief sets the shift focus',()=>{
 const s=createGame('career',4242,{schedule:'ppa'});assert.equal(canSetFocus(s),false);assert.equal(setShiftFocus(s,'traffic').ok,false);
 s.rank=3;assert.equal(setShiftFocus(s,'traffic').ok,true);assert.equal(s.shiftFocus,'traffic');
 assert.ok(s.prevention.some(p=>p.task==='breath-check')&&s.prevention.some(p=>p.task==='speed-check'),'traffic focus plans road raids');
 assert.equal(setShiftFocus(s,'nonsense').ok,false);
 const legacy=createGame('career',4242);legacy.rank=4;assert.equal(canSetFocus(legacy),false,'legacy campaigns unchanged');
 const c=chief();assert.equal(setShiftFocus(c,'response').ok,true);const n=skip(c);assert.equal(n.shiftFocus,'response','focus carries to the next shift');
 assert.deepEqual(Object.keys(FOCUS),['balanced','prevention','response','traffic']);
});

test('attestation grades the half-year honestly',()=>{
 assert.equal(attestation({resolved:60,missed:0,founded:0,coursesOk:true,bond:70,awards:2}).grade,'A');
 assert.equal(attestation({resolved:40,missed:10,founded:1,coursesOk:true,bond:50}).grade,'C');
 assert.equal(attestation({resolved:20,missed:30,founded:3,coursesOk:false,bond:30}).grade,'D');
 assert.equal(attestation({}).grade,'B','no calls: perfect rate, no extras');
 for(const g of Object.values(ATTEST.grades))assert.ok(g.label.length<=60);
});

test('a career officer is attested every six months and keeps the history valid',()=>{
 let s=createGame('career',4242,{schedule:'ppa'});s=untilMonth(s,x=>(x.life.attestations??[]).length>0,120);
 assert.equal(s.life.attestations.length,1);assert.equal(s.life.months%ATTEST.every,0);
 assert.ok(s.logs.some(l=>/Аттестация/.test(l.text)));assert.ok(validCareer2(s));
 const back=deserialize(serialize(s));assert.deepEqual(back.life.attestations,s.life.attestations);
});

test('life events: deterministic, answered or defaulted, integrity is caught',()=>{
 const ids=new Set();let hits=0;for(let k=0;k<600;k++){const id=lifeEventFor(4242,k);if(id){hits++;ids.add(id);}}
 assert.ok(hits>60&&hits<150,`about one in six shifts: ${hits}`);assert.equal(ids.size,LIFE_EVENT_IDS.length,'every situation appears');
 for(const e of Object.values(LIFE_EVENTS))assert.ok(e.options.length>=2);
 let s=createGame('career',4242,{schedule:'ppa'});s=untilMonth(s,x=>!!x.life.event,80);assert.ok(s.life.event,'a situation arrives');
 const money=s.life.money,ev=LIFE_EVENTS[s.life.event.id],o=ev.options[0];assert.equal(chooseLifeEvent(s,o.id).ok,true);assert.equal(s.life.event,null);
 if(o.fx.money)assert.equal(s.life.money,money+o.fx.money);assert.equal(chooseLifeEvent(s,o.id).ok,false,'answered once');
 s.life.event={id:'favour',shift:s.shift};chooseLifeEvent(s,'agree');assert.equal(s.life.integrity,1);
 const xp0=s.xp+500;s.xp=xp0;for(let k=0;k<12&&s.life.integrity;k++)s=skip(s);
 assert.equal(s.life.integrity,0,'internal control finds the breach');assert.ok(s.xp<xp0);assert.ok(s.logs.some(l=>/Внутренний контроль: выявлено/.test(l.text)));
 s.life.event={id:'car-broke',shift:s.shift};const m2=s.life.money;s=skip(s);assert.ok(s.life.money<=m2||s.life.event?.id!=='car-broke','an unanswered situation takes the safe default');
});

test('the chief meets the city council every month',()=>{
 let s=chief();s=untilMonth(s,x=>x.council?.choice==='pending',40);assert.equal(s.council.choice,'pending');
 const b=s.budget;s.trust=85;assert.equal(chooseCouncil(s,'ask').ok,true);assert.equal(s.budget,b+COUNCIL.ask.big);assert.equal(chooseCouncil(s,'report').ok,false,'one meeting per month');
 s=untilMonth(s,x=>x.council?.choice==='pending'&&x.council.month!==s.council.month,40);assert.equal(chooseCouncil(s,'promise').ok,true);assert.ok(s.promise.limit>=2);
 const month=s.promise.month;s=untilMonth(s,x=>x.council?.month>month,40);assert.ok(s.logs.some(l=>/обещание (выполнено|не выполнено)/i.test(l.text)),'the promise is checked');
 assert.ok(validCareer2(s));deserialize(serialize(s));
 assert.equal(chooseCouncil(createGame('career',4242,{schedule:'ppa'}),'ask').ok,false);
});

test('morale follows stress and low morale costs officers',()=>{
 const s=chief();for(const o of s.officers){o.stress=10;o.fatigue=10;}const hi=morale(s);for(const o of s.officers){o.stress=95;o.fatigue=90;}const lo=morale(s);
 assert.ok(hi>70&&lo<35,`${hi} vs ${lo}`);let n=s;for(let k=0;k<8;k++){for(const o of n.officers){o.stress=95;o.fatigue=90;}n=skip(n);}
 assert.equal(n.officers.length,3,'one exhausted officer resigns, not the whole department');assert.ok(Number.isInteger(n.lastQuit),'the resignation is remembered');assert.ok(validCareer2(n));deserialize(serialize(n));
});

test('a new candidate market every month',()=>{
 const a=newCandidates(4242,10,new Set()),b=newCandidates(4242,11,new Set());assert.equal(a.length,3);
 assert.notDeepEqual(a.map(x=>x.name),b.map(x=>x.name));assert.deepEqual(a,newCandidates(4242,10,new Set()),'deterministic');
 for(const c of a)assert.ok(c.skill>=.62&&c.skill<=.92&&c.fee>0&&c.salary>0);
});

test('validation rejects broken Release C state',()=>{
 const s=createGame('career',4242,{schedule:'ppa'});assert.ok(validCareer2(s));
 assert.equal(validCareer2({...s,shiftFocus:'x'}),false);assert.equal(validCareer2({...s,council:{choice:'steal',month:1,label:'a'}}),false);
 assert.equal(validCareer2({...s,life:{...s.life,event:{id:'nope',shift:1}}}),false);
 assert.equal(validCareer2({...s,life:{...s.life,attestations:[{grade:'F',score:1,label:'x'}]}}),false);
});

function detective(){let s=createGame('career',4242,{schedule:'ppa'});s=skip(s);s.life.role='detective';return skip(s);}
test('detective: interview needs evidence, forensics return next shift',()=>{
 assert.ok(TASKS['case-interview']?.case&&TASKS['case-forensics']?.case);
 let s=detective();const u=s.units[0];u.auto=false;for(let k=0;k<200;k++)tick(s,.1);const c=openCases(s.life)[0];c.evidence=INTERVIEW_NEED-5;
 assert.equal(startCaseStep(s,c.id,'case-interview').ok,false);c.evidence=INTERVIEW_NEED+5;const ev=c.evidence;
 assert.equal(startCaseStep(s,c.id,'case-interview').ok,true);for(let k=0;k<400&&u.task;k++)tick(s,.5);
 assert.ok(c.interviewed&&c.evidence>ev,'the interview adds evidence');assert.equal(startCaseStep(s,c.id,'case-interview').ok,false,'only once');
 const lab=labResult(c);assert.ok(lab>=LAB[0]&&lab<=LAB[1]);
 for(let k=0;k<100&&u.status!=='patrol';k++)tick(s,.5);assert.equal(startCaseStep(s,c.id,'case-forensics').ok,true);for(let k=0;k<400&&u.task;k++)tick(s,.5);assert.ok(c.labSent);
 const before=c.evidence,id=c.id;s=skip(s);const after=s.life.cases.find(x=>x.id===id);
 assert.ok(after.status!=='open'||after.evidence>before,'lab results arrive between shifts');deserialize(serialize(s));
});

test('the chief budget has a reserve: half the trust bonus above it, the rest returns at the year close',async()=>{
 const {reserveLimit,RESERVE,cityGrant}=await import('../dist/economy.js');const {shiftCost}=await import('../dist/sim.js');
 const run=extra=>{const s=chief();s.trust=90;s.budget=reserveLimit(shiftCost(s))+extra;const b=s.budget,g=cityGrant(s).total,c=shiftCost(s);return {d:skip(s).budget-b+c-g,g};};
 assert.equal(run(-1).d,0,'below the reserve: the full trust bonus');const r=run(5000);assert.ok(r.g>0);assert.equal(r.d,Math.round(r.g*RESERVE.overGrant)-r.g,'above: half');
 const legacy=createGame('chief',4242);legacy.trust=90;legacy.budget=50000;const lb=legacy.budget;assert.equal(skip(legacy).budget,lb+cityGrant(legacy).total-shiftCost(legacy),'legacy economy unchanged');
 let y=chief(),back=false;for(let k=0;k<220&&!back;k++){y.budget=40000;y.trust=90;y=skip(y);back=y.budget<30000;}
 assert.ok(back,'the year close returns the unspent rest');assert.ok(y.budget<=reserveLimit(shiftCost(y))+3000,'reserve plus the year-end rewards');
});

test('«Полицейский года»: the year closes with a summary and the award; a career officer answers for the own crew',()=>{
 let s=createGame('career',4242,{schedule:'ppa'}),got=false;for(let k=0;k<80&&!got;k++){s.resolved=30;s.missed=0;s.complaints=[{incident:1,unit:2,reason:'x',status:'проверка',district:'center'}];s=skip(s);got=s.awards.some(a=>a.id==='year-best');}
 assert.ok(got,'another crew\'s complaint does not take the award from the player');assert.equal(s.stats.yearResolved,0,'a new year starts from zero');assert.ok(validCareer2(s));deserialize(serialize(s));
});
