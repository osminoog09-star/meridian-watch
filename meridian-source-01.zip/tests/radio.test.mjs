import test from 'node:test';import assert from 'node:assert/strict';
import {createGame,spawnIncident,tick,serialize,deserialize,nextShift } from '../dist/sim.js';
import {callsign,serviceCallsign,radioText,pick,pushRadio,RADIO_LIMIT,RADIO_KINDS,DISPATCH} from '../dist/radio.js';
import {NODES} from '../dist/geography.js';
// Radio exchange by templates: callsigns, varied wording, deterministic, bounded and saved.

test('callsigns and wording are deterministic and varied',()=>{
 assert.equal(callsign({id:1}),'Меридиан-01');assert.equal(callsign({id:12}),'Меридиан-12');
 assert.equal(serviceCallsign({kind:'rescue',id:3}),'Спасатель-3');assert.equal(serviceCallsign({kind:'ambulance',id:2}),'Скорая-2');
 for(const kind of RADIO_KINDS){assert.equal(pick(kind,5,1),pick(kind,5,1));const x={call:'шум в квартире',place:'Центр'};
  const texts=new Set();for(let k=1;k<40;k++)texts.add(radioText(kind,k,1,'Меридиан-01',x));assert.ok(texts.size>=2,kind);
  for(const t of texts){assert.ok(t.length>3&&t.length<=200);assert.doesNotMatch(t,/undefined|null|NaN/);}}
 assert.equal(radioText('nope',1,1,'x'),'');
});

test('a call produces broadcast, dispatch, accept, arrival and clear lines ',()=>{
 const s=createGame();s.seed=11;s.nextIncident=9000;const n=NODES[30];
 const i=spawnIncident(s,null,{variant:'noise-flat',point:{x:n.x,y:n.y}});
 assert.equal(s.radio[0].from,DISPATCH);assert.match(s.radio[0].text,/громкая музыка в квартире/);
 for(let k=0;k<8000&&!['resolved','missed'].includes(i.state);k++)tick(s,.1);
 const lines=s.radio.map(r=>`${r.from}: ${r.text}`).reverse().join('\n');
 assert.match(lines,/Дежурный: Меридиан-\d\d/);assert.match(lines,/Меридиан-\d\d: (Принял|Понял|Принято)/);
 assert.match(lines,/Меридиан-\d\d: (На месте|Прибыли|На адресе|Подъехали)/);
 if(i.state==='resolved')assert.match(lines,/Меридиан-\d\d: (Свободны|Закончили|Освободились|Вызов закрыт)/);
});

test('radio is bounded, saved, validated and starts empty next shift',()=>{
 const s=createGame();for(let k=0;k<RADIO_LIMIT+10;k++)pushRadio(s,'Меридиан-01','Проверка связи '+k);
 assert.equal(s.radio.length,RADIO_LIMIT);assert.equal(s.radio[0].text,'Проверка связи '+(RADIO_LIMIT+9));
 const n=deserialize(serialize(s));assert.deepEqual(n.radio,s.radio);
 const bad=JSON.parse(serialize(s));bad.radio[0].text=5;assert.throws(()=>deserialize(JSON.stringify(bad)));
 const big=JSON.parse(serialize(s));big.radio.push({...s.radio[0]});assert.throws(()=>deserialize(JSON.stringify(big)));
 const old=JSON.parse(serialize(s));delete old.radio;assert.doesNotThrow(()=>deserialize(JSON.stringify(old)));
 s.ended=true;assert.equal(nextShift(s).radio,undefined);
});
