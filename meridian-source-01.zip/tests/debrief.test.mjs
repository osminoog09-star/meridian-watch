import test from 'node:test';import assert from 'node:assert/strict';
import {shiftDebrief} from '../dist/debrief.js';import {createGame,serialize,deserialize} from '../dist/sim.js';
// «Разбор смены»: short rule-based summary, read-only.
test('quiet shift gives weather, a neutral tip and no warnings',()=>{const s=createGame(),before=serialize(s),d=shiftDebrief(s);assert.match(d.weather,/°$/);assert.deepEqual(d.attention,[]);assert.ok(d.tip.length>10);assert.equal(serialize(s),before);});
test('missed and repeat calls are named and drive the mentor tip',()=>{const s=createGame();s.resolved=1;s.missed=3;s.history=[{id:1,name:'Семейный конфликт',success:false,time:5,outcome:''},{id:2,name:'Повторно: Громкая музыка в квартире',success:false,time:9,outcome:''},{id:3,name:'Кража велосипеда',success:true,time:11,outcome:''}];
 const d=shiftDebrief(s);assert.match(d.attention[0],/Пропущено: 3 — Семейный конфликт/);assert.ok(d.attention.some(t=>/Повторные вызовы: 1/.test(t)));assert.match(d.tip,/Пропусков больше/);});
test('custody count and district gap show up; counter is validated in saves',()=>{const s=createGame();s.resolved=6;s.custodyDone=2;s.districts={centre:90,ulejoe:40,raama:70,beach:70,mai:70,papiniidu:70,vana:70,raekula:70};
 const d=shiftDebrief(s);assert.ok(d.good.includes('Доведено до участка: 2'));assert.ok(d.attention.some(t=>/Проблемный район: Заречье \(40%\)/.test(t)));assert.match(d.tip,/Заречье/);
 assert.equal(deserialize(serialize(s)).custodyDone,2);const bad=JSON.parse(serialize(s));bad.custodyDone=-1;assert.throws(()=>deserialize(JSON.stringify(bad)));});
