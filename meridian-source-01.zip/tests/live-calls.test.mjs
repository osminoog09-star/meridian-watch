import test from 'node:test';import assert from 'node:assert/strict';
import {createGame,spawnIncident,assign,hireOfficer,createPatrol,serialize,deserialize,callName,callBrief,canRedirect,unitFitsCall,TYPES,tick} from '../dist/sim.js';
import {VARIANTS,pickVariant,variantWeights,hourBucket,placeNodes,defaultVariant} from '../dist/calls.js';
import {NODES,byId} from '../dist/geography.js';
// «Живые вызовы» v1: variants, crew fit and redirect.

test('variants cover every call mechanic and keep the original wording as default',()=>{
 for(let t=0;t<TYPES.length;t++){const v=defaultVariant(t);assert.ok(v,'type '+t);assert.equal(v.name,TYPES[t].name);assert.equal(v.brief,TYPES[t].brief);}
 assert.equal(new Set(VARIANTS.map(v=>v.id)).size,VARIANTS.length);
});

test('time of day shifts the mix: flat noise and drunk drivers peak at night, shoplifting by day',()=>{
 assert.deepEqual([hourBucket(23*60),hourBucket(3*60),hourBucket(18*60),hourBucket(12*60)],['night','night','evening','day']);
 const share=(id,minute)=>{const w=variantWeights(minute),k=VARIANTS.findIndex(v=>v.id===id);return w[k]/w.reduce((a,b)=>a+b,0);};
 assert.ok(share('noise-flat',23*60)>share('noise-flat',12*60));assert.ok(share('drunk-driver',1*60)>share('drunk-driver',13*60));assert.ok(share('shoplift',12*60)>share('shoplift',23*60));
 // Public order is the most common group at night, like the PPA statistics.
 const n=2000,count={};for(let k=0;k<n;k++){const v=pickVariant((k+.5)/n,23*60);count[v.type]=(count[v.type]??0)+1;}
 assert.ok(count[0]>=Math.max(...Object.values(count)));
});

test('random calls get a matching variant and a place of the preferred kind; explicit types stay classic',()=>{
 const s=createGame();for(let k=0;k<40;k++)spawnIncident(s);
 for(const i of s.incidents){const v=VARIANTS.find(v=>v.id===i.variant);assert.equal(v.type,i.type);assert.equal(callName(i),v.name);assert.equal(callBrief(i),v.brief);}
 assert.ok(new Set(s.incidents.map(i=>i.variant)).size>=6);
 const classic=spawnIncident(createGame(),4);assert.equal(callName(classic),TYPES[4].name);
 const homes=placeNodes(NODES,'residential',byId('centre'));assert.ok(homes.length<NODES.length&&homes.every(n=>['residential','living_street','unclassified','service'].includes(n.kind)));
});

test('variant survives save/load and a foreign variant is rejected',()=>{
 const s=createGame();spawnIncident(s);const n=deserialize(serialize(s));assert.equal(n.incidents[0].variant,s.incidents[0].variant);
 const bad=JSON.parse(serialize(s));bad.incidents[0].variant=VARIANTS.find(v=>v.type!==bad.incidents[0].type).id;assert.throws(()=>deserialize(JSON.stringify(bad)));
});

test('a crew still driving to a minor call can be redirected to a more urgent one',()=>{
 const s=createGame(),u=s.units[1];u.auto=false;const minor=spawnIncident(s,0),urgent=spawnIncident(s,4),same=spawnIncident(s,0);s.nextIncident=999;
 assert.equal(assign(s,u.id,minor.id,true),true);assert.equal(u.status,'responding');
 assert.equal(canRedirect(s,u,same),false);assert.equal(assign(s,u.id,same.id,true),false);
 assert.equal(canRedirect(s,u,urgent),true);assert.equal(assign(s,u.id,urgent.id,true),true);
 assert.equal(u.incident,urgent.id);assert.deepEqual(minor.units,[]);assert.equal(minor.state,'waiting');assert.match(s.logs.map(l=>l.text).join('\n'),/снят с вызова/);
});

test('automation redirects a free-of-scene crew to an unattended urgent call',()=>{
 const s=createGame();s.nextIncident=999;for(const u of s.units)u.auto=true;
 const minors=s.units.map(()=>spawnIncident(s,0));s.units.forEach((u,k)=>assert.equal(assign(s,u.id,minors[k].id,true),true));
 const urgent=spawnIncident(s,4);for(let k=0;k<40&&!urgent.units.length;k++)tick(s,.1);
 assert.equal(urgent.units.length,1);
});

test('a crew whose specialty matches the call is marked as fitting',()=>{
 const s=createGame('chief');for(const id of [1,4])assert.equal(hireOfficer(s,id).ok,true);
 const [anna,ilya]=s.officers;assert.equal(createPatrol(s,anna.id,null,1).ok,true);assert.equal(createPatrol(s,ilya.id,null,2).ok,true);
 const talk=spawnIncident(s,0);assert.equal(unitFitsCall(s,s.units[0],talk),true);assert.equal(unitFitsCall(s,s.units[1],talk),false);
});
