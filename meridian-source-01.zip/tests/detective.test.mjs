import test from 'node:test';import assert from 'node:assert/strict';
import {createGame,tick,nextShift,serialize,deserialize,startCaseStep,setRole,spawnIncident} from '../dist/sim.js';
import {CASE_KINDS,newCases,stepEvidence,arrestReady,autoCaseStep,openCases,DETECTIVE,validCases} from '../dist/detective.js';
import {ROLES,COURSES,roleBlocker} from '../dist/life.js';
import {NODES} from '../dist/geography.js';
// R25 «Криминальная полиция» (Claude, 12.10.2026).
function detective(){let s=createGame('career',4242,{schedule:'ppa'});s.ended=true;s=nextShift(s);s.life.role='detective';s.ended=true;return nextShift(s);}

test('the role needs the senior rank and the investigator course',()=>{
 assert.ok(ROLES.detective&&COURSES.investigation);const life={courses:{firearms:1,fitness:1},fitness:60};
 assert.match(roleBlocker(life,'detective',1,2),/звание/);assert.match(roleBlocker(life,'detective',2,2),/курс/);
 assert.equal(roleBlocker({...life,courses:{...life.courses,investigation:2}},'detective',2,2),null);
});

test('a detective gets a case file and works it instead of patrol calls',()=>{
 let s=detective();assert.equal(openCases(s.life).length,DETECTIVE.openCases);assert.equal(new Set(openCases(s.life).map(c=>c.kind)).size,3,'different kinds');
 const n=NODES[30];const i=spawnIncident(s,null,{variant:'noise-flat',point:{x:n.x,y:n.y}});
 for(let k=0;k<2200&&!s.ended;k++)tick(s,.5);
 assert.ok(!i.units.includes(1),'patrol calls go to other crews');assert.ok(s.life.cases.some(c=>c.steps>0),'steps were taken');assert.ok(s.life.cases.some(c=>c.evidence>0));
 assert.doesNotThrow(()=>deserialize(serialize(s)));
 let solved=0;for(let k=0;k<5;k++){s.ended=true;s=nextShift(s);for(let t=0;t<2200&&!s.ended;t++)tick(s,.5);solved=s.life.cases.filter(c=>c.status==='solved').length;}
 assert.ok(solved>=1&&solved<=6,`solved ${solved} in 6 shifts`);
});

test('manual steps, arrest only with enough evidence, cases go cold after the deadline',()=>{
 let s=detective();const u=s.units[0];u.auto=false;for(let k=0;k<200;k++)tick(s,.1);const c=openCases(s.life)[0];
 assert.match(startCaseStep(s,c.id,'case-arrest').message,/Мало улик/);assert.equal(startCaseStep(s,c.id,'case-cameras').ok,true);assert.equal(u.task.caseId,c.id);
 const ev=c.evidence;for(let k=0;k<4000&&u.status==='proactive';k++)tick(s,.1);assert.ok(c.evidence>ev);
 c.evidence=CASE_KINDS[c.kind].need+10;assert.ok(arrestReady(c));assert.equal(autoCaseStep(s.life).step,'case-arrest');
 for(const x of openCases(s.life))x.deadline=s.shift-1;s.ended=true;const n=nextShift(s);assert.ok(n.life.cases.some(x=>x.status==='cold'));assert.equal(openCases(n.life).length,DETECTIVE.openCases,'new cases replace cold ones');
 const bad=JSON.parse(serialize(n));bad.life.cases[0].kind='heist';assert.throws(()=>deserialize(JSON.stringify(bad)));
 assert.ok(stepEvidence({id:1,kind:'burglary',steps:0},'case-witnesses')>=stepEvidence({id:1,kind:'burglary',steps:30},'case-witnesses'),'repeating work brings less');
 assert.equal(startCaseStep(createGame('career',1,{schedule:'ppa'}),1,'case-cameras').ok,false,'a patrol officer has no cases');assert.ok(validCases({}));
});
