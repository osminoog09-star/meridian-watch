import test from 'node:test';import assert from 'node:assert/strict';
import {createGame,nextShift,serialize,deserialize} from '../dist/sim.js';
import {ensurePartner,partnerPace,partnerComplaints,bondAfterShift,nextPartner,BOND,TRAITS,PARTNERS,MENTOR} from '../dist/partner.js';
import {callNews,newsRoom,pushNews,validNews,NEWS_PER_SHIFT,MEDIA} from '../dist/news.js';
import {freeBlocks} from '../dist/life.js';
// R16 «Напарник» and R17 «Город пишет» (Claude, 11.10.2026).
const roll=(s,n,each=()=>{})=>{for(let k=0;k<n;k++){each(s);s.ended=true;s=nextShift(s);}return s;};

test('the mentor stays for the probation month, then a regular partner takes over',()=>{
 let s=createGame('career',7182,{schedule:'ppa'});s=roll(s,1);assert.equal(s.life.partner.name,MENTOR.name);
 s.xp=5000;s=roll(s,5);assert.equal(s.life.partner.trait,'mentor','not before a month');
 s=roll(s,6);const p=s.life.partner;assert.notEqual(p.trait,'mentor');assert.ok(PARTNERS.some(x=>x.name===p.name));assert.equal(p.bond,BOND.newPartner);
 assert.equal(s.units[0].people[1],p.name);assert.equal(s.officers.find(o=>o.id===s.units[0].officerIds[1]).name,p.name);
 assert.ok(s.logs.some(l=>/Стажировка окончена/.test(l.text)));assert.doesNotThrow(()=>deserialize(serialize(s)));
});

test('bond: closed calls build it (slower near the top), failures and complaints wear it down; pace follows',()=>{
 const p={name:'X',trait:'calm',bond:50,since:1,low:0};const up=bondAfterShift({...p},{calls:20});const upHigh=bondAfterShift({...p,bond:90},{calls:20});assert.ok(up>upHigh&&upHigh>0);
 assert.ok(bondAfterShift({...p},{calls:0,missed:3,founded:1})<0);
 assert.equal(partnerPace({...p,bond:80},0),BOND.strongPace*BOND.traitPace);assert.equal(partnerPace({...p,bond:80},5),BOND.strongPace);assert.equal(partnerPace({...p,bond:10},3),BOND.weakPace);
 assert.equal(partnerComplaints({trait:'steady'}),.7);assert.equal(partnerComplaints({trait:'calm'}),1);
 for(const id of Object.keys(TRAITS))assert.ok(TRAITS[id].about.length>20);assert.notEqual(nextPartner(1,2,'Марко Кукк').name,'Марко Кукк');
});

test('an evening with the partner raises the bond; a broken pair asks for a transfer',()=>{
 let s=createGame('career',7182,{schedule:'ppa'});s=roll(s,4);const blocks=freeBlocks(s.shift);ensurePartner(s.life);const before=s.life.partner.bond;
 s.ended=true;const plan=Array.from({length:blocks.days},()=>({activity:'partner'}));const n=nextShift(s,{plan});assert.ok(n.life.partner.bond>=before+BOND.activity);
 let t=createGame('career',7182,{schedule:'ppa'});t=roll(t,13);const name=t.life.partner.name;t.life.partner.bond=5;t.life.partner.low=1;t=roll(t,1);
 assert.notEqual(t.life.partner.name,name);assert.ok(t.logs.some(l=>/попросил\(а\) перевода/.test(l.text)));
 const bad=JSON.parse(serialize(t));bad.life.partner.bond=140;assert.throws(()=>deserialize(JSON.stringify(bad)));
});

test('the city writes about notable calls, not routine ones, and only a few good stories per shift',()=>{
 const good=callNews({id:5,variant:'missing-child'},true,{district:'Центр',minutes:40});assert.ok(good&&good.tone==='good'&&MEDIA.includes(good.media));
 assert.equal(callNews({id:5,variant:'noise-flat'},true),null);assert.equal(callNews({id:5,variant:'missing-child'},false,{district:'Центр'}).tone,'bad');
 const s={shift:3,time:10};for(let k=0;k<10;k++){const it={title:'t'+k,tone:'good',media:MEDIA[0]};if(newsRoom(s,it))pushNews(s,it);}assert.equal(s.news.length,NEWS_PER_SHIFT);
 assert.ok(newsRoom(s,{title:'x',tone:'bad',media:MEDIA[0]}),'failures always make the news');assert.ok(validNews(s));
 assert.equal(validNews({news:[{shift:1,time:0,title:'x',tone:'good',media:'Fake TV'}]}),false);
});

test('news carries over between roster shifts; old campaigns have none',()=>{
 let s=createGame('career',7182,{schedule:'ppa'});pushNews(s,{title:'Тест',tone:'neutral',media:MEDIA[1]});s=roll(s,1);assert.equal(s.news.at(-1).title,'Тест');assert.doesNotThrow(()=>deserialize(serialize(s)));
 let l=createGame('career',7182);l=roll(l,1);assert.equal(l.news,undefined);
});
