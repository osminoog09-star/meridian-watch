import test from 'node:test';import assert from 'node:assert/strict';
import {createGame,spawnIncident,tick,serialize,deserialize,nextShift,unitReason,assign,HQ,districtTrust} from '../dist/sim.js';
import {custodyFor,CUSTODY,variantById,HANDOVER_TIME} from '../dist/calls.js';
import {NODES} from '../dist/geography.js';
// 0.7.0 v1: detention -> transport to station -> handover -> report.

test('custody rules reference real variants and only arrest-type decisions',()=>{
 for(const [id,decisions] of Object.entries(CUSTODY)){assert.ok(variantById(id),id);for(const d of decisions)assert.ok(variantById(id).type!==undefined&&typeof d==='string');}
 assert.equal(custodyFor('domestic','talk'),true);assert.equal(custodyFor('noise-flat','talk'),false);assert.equal(custodyFor('drunk-driver','observe'),false);
});

function solve(seedVariant){
 // Let an automatic crew resolve one call of the given variant; return state and incident.
 for(let seed=1;seed<60;seed++){const s=createGame();s.seed=seed;s.nextIncident=9000;const anchor=NODES[(seed*7)%NODES.length];
  const i=spawnIncident(s,null,{variant:seedVariant,point:{x:anchor.x,y:anchor.y}});
  for(let k=0;k<6000&&!['resolved','missed'].includes(i.state);k++)tick(s,.1);
  if(i.state==='resolved'&&custodyFor(i.variant,i.decision))return {s,i};}
 return null;
}

test('a resolved arrest call sends one crew to the station, hands over and returns with a report',()=>{
 const r=solve('street-fight');assert.ok(r,'some seed resolves the fight with an arrest decision');const {s,i}=r;
 const u=s.units.find(x=>x.transport?.from===i.id||x.status==='transporting'||x.status==='handover');assert.ok(u,'a crew took the detainee');
 for(let k=0;k<4000&&u.status!=='transporting';k++)tick(s,.1);assert.equal(u.status,'transporting');assert.match(unitReason(s,u),/Везём задержанного/);
 const trust=s.trust,districtId=u.transport.district,district=districtTrust(s,districtId),xp=s.xp;
 for(let k=0;k<8000&&u.status==='transporting';k++)tick(s,.1);assert.equal(u.status,'handover');assert.ok(Math.hypot(u.x-HQ.x,u.y-HQ.y)<.02);
 // A crew in custody duty is not dispatched elsewhere.
 const other=spawnIncident(s,4);assert.equal(assign(s,u.id,other.id,true),false);
 for(let k=0;k<HANDOVER_TIME*10+20&&u.status==='handover';k++)tick(s,.1);
 assert.equal(u.status,'patrol');assert.equal(u.transport,null);assert.ok(s.trust>=trust);assert.ok(districtTrust(s,districtId)>district||district>=100);assert.ok(s.xp>xp);
 assert.match(s.logs.map(l=>l.text).join('\n'),/рапорт по вызову №/);
});

test('custody state survives save/load and is closed at shift change',()=>{
 const r=solve('domestic');assert.ok(r);const {s}=r;const u=s.units.find(x=>x.transport);if(!u)return;
 for(let k=0;k<4000&&u.status!=='transporting';k++)tick(s,.1);
 const n=deserialize(serialize(s));const nu=n.units.find(x=>x.id===u.id);assert.equal(nu.status,u.status);assert.deepEqual(nu.transport,u.transport);
 s.ended=true;const next=nextShift(s);const after=next.units.find(x=>x.id===u.id);assert.equal(after.status,'patrol');assert.equal(after.transport,undefined);assert.ok(next.trust>=Math.min(100,s.trust+1)||s.trust>=100);
 const bad=JSON.parse(serialize(s));bad.units.find(x=>x.id===u.id).transport={from:'x'};assert.throws(()=>deserialize(JSON.stringify(bad)));
});
