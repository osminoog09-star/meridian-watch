import test from 'node:test';import assert from 'node:assert/strict';
import {createAudio} from '../dist/audio.js';
// A new radio line plays one squelch + roger beep, once, never replayed.
function fake(){let osc=0,src=0;const param=()=>({value:0,setTargetAtTime(v){this.value=v},setValueAtTime(v){this.value=v},linearRampToValueAtTime(v){this.value=v}});
 return {state:'suspended',currentTime:1,sampleRate:200,destination:{},get osc(){return osc},get src(){return src},
  createGain(){return {gain:param(),connect(){},disconnect(){}}},createOscillator(){osc++;return {frequency:param(),connect(){},disconnect(){},start(){},stop(){}}},
  createBuffer(c,n){return {getChannelData:()=>new Float32Array(n)}},createBufferSource(){src++;return {connect(){},disconnect(){},start(){},stop(){},loop:false}},
  createBiquadFilter(){return {type:'',frequency:param(),Q:param(),connect(){},disconnect(){}}},async resume(){this.state='running'},async suspend(){this.state='suspended'}};}
test('radio squelch plays once per new radio line',async()=>{
 const ctx=fake(),a=createAudio({preferences:{enabled:true},createContext:()=>ctx}),s={shift:1,mode:'career',resolved:0,incidents:[],units:[],radio:[]};
 await a.unlock();a.reset(s);a.update(s,1,true);const src=ctx.src,osc=ctx.osc;
 s.radio.unshift({time:1,from:'Меридиан-01',text:'Принял.'});a.update(s,1,true);assert.equal(ctx.src,src+1,'one squelch');assert.equal(ctx.osc,osc+1,'one roger beep');
 a.update(s,1,true);assert.equal(ctx.src,src+1,'not replayed');
});
