import test from 'node:test';import assert from 'node:assert/strict';
import {createGame,spawnIncident,tick,assign,setCustodyChoice,serialize,deserialize} from '../dist/sim.js';
import {custodyDecision,CUSTODY_FOLLOW_UP,canChooseCustody} from '../dist/calls.js';
import {NODES} from '../dist/geography.js';
// 0.7.0 step 2: arrest or release with a warning at the scene.
test('default follows the old rule; explicit choice overrides it',()=>{
 assert.equal(custodyDecision({variant:'domestic',decision:'talk'}),'arrest');assert.equal(custodyDecision({variant:'domestic',decision:'check'}),'warn');
 assert.equal(custodyDecision({variant:'domestic',decision:'talk',custodyChoice:'warn'}),'warn');assert.equal(custodyDecision({variant:'noise-flat',decision:'talk'}),null);
 assert.ok(CUSTODY_FOLLOW_UP.arrest<1&&CUSTODY_FOLLOW_UP.warn>1);assert.equal(canChooseCustody('crash'),false);
});
function manualAtScene(variant){for(let seed=1;seed<40;seed++){const s=createGame();s.seed=seed;s.nextIncident=9000;for(const u of s.units)u.auto=false;const n=NODES[(seed*11)%NODES.length];
 const i=spawnIncident(s,null,{variant,point:{x:n.x,y:n.y}}),u=s.units[0];if(!assign(s,u.id,i.id,true))continue;for(let k=0;k<3000&&!(u.status==='decision');k++)tick(s,.1);if(u.status==='decision')return {s,i,u};}return null;}
test('a manual crew at the scene can choose; the choice is validated, logged and saved',()=>{
 const r=manualAtScene('street-fight');assert.ok(r);const {s,i,u}=r;
 assert.equal(setCustodyChoice(s,u.id,'bribe'),false);assert.equal(setCustodyChoice(s,u.id,'warn'),true);assert.equal(i.custodyChoice,'warn');assert.match(s.logs[0].text,/предупреждением/);
 const n=deserialize(serialize(s));assert.equal(n.incidents.find(x=>x.id===i.id).custodyChoice,'warn');
 const bad=JSON.parse(serialize(s));bad.incidents.find(x=>x.id===i.id).custodyChoice='free';assert.throws(()=>deserialize(JSON.stringify(bad)));
});
test('release with a warning frees the crew without a station trip; arrest sends it to the station',()=>{
 for(const choice of ['warn','arrest']){const r=manualAtScene('domestic');assert.ok(r);const {s,i,u}=r;assert.equal(setCustodyChoice(s,u.id,choice),true);
  u.auto=true;for(let k=0;k<6000&&!['resolved','missed'].includes(i.state);k++)tick(s,.1);if(i.state!=='resolved')continue;
  if(choice==='warn'){assert.equal(u.transport??null,null);assert.match(s.logs.map(l=>l.text).join('\\n'),/отпустили с предупреждением/);}
  else assert.ok(u.transport||['transporting','handover'].includes(u.status)||/везём в участок|рапорт/.test(s.logs.map(l=>l.text).join('\\n')));}
});
test('a call without an arrest option cannot take a choice',()=>{const r=manualAtScene('noise-flat');assert.ok(r);assert.equal(setCustodyChoice(r.s,r.u.id,'arrest'),false);});
