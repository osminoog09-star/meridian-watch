import test from 'node:test';import assert from 'node:assert/strict';
import {createGame,tick,nextShift,serialize,deserialize,startFirstWeek,skipFirstWeek} from '../dist/sim.js';
import {WEEK,STORY,storyDay,storyPoint,dayResult,weekVerdict,validWeek,weekActive} from '../dist/firstweek.js';
import {a11yPreferences,a11yClasses,callSignal,TEXT_SIZES} from '../dist/accessibility.js';
import {MAP_METRES} from '../dist/world-scale.js';
import {HQ} from '../dist/sim.js';
// Release E (Claude's part) «Первая неделя службы» and accessibility (12.10.2026).
function playDay(s){let story=null;for(let k=0;k<2400&&!s.ended;k++){tick(s,.5);story=story??s.incidents.find(i=>i.story);if(story&&['resolved','missed'].includes(story.state)&&Number.isInteger(s.life.week.outcome))break;}return story;}

test('the week: seven story calls for the player crew, debrief every day, evaluation and reward at the end',()=>{
 let s=createGame('career',7182,{schedule:'ppa'});assert.equal(startFirstWeek(s),true);assert.equal(startFirstWeek(s),false,'once');const xp0=s.xp;
 for(let d=1;d<=WEEK.length;d++){assert.equal(storyDay(s).day,d);const i=playDay(s);assert.ok(i,`day ${d}: a story call`);assert.equal(i.variant,WEEK[d-1].variant);assert.ok(i.units.includes(1),'it is the player crew\'s call');
  s.ended=true;s=nextShift(s);assert.equal(s.life.week.results.length,d);assert.ok(s.life.week.last.length>10,'debrief');deserialize(serialize(s));}
 assert.equal(s.life.week.done,true);assert.equal(weekActive(s),false);const v=weekVerdict(s.life.week.results);assert.ok(v.passed,`auto crew follows the mentor: ${v.points}`);assert.ok(s.xp>=xp0+STORY.reward.xp);
 assert.ok(s.news.some(n=>/испытательную неделю/.test(n.title)));
});

test('the story call comes near the station; a skipped week stops the calls; chief and old campaigns have none',()=>{
 for(let d=1;d<=7;d++){const p=storyPoint(HQ,d),m=Math.hypot(p.x-HQ.x,p.y-HQ.y)*MAP_METRES;assert.ok(m>=STORY.radius[0]-1&&m<=STORY.radius[1]+1,String(m));}
 const s=createGame('career',7182,{schedule:'ppa'});startFirstWeek(s);assert.equal(skipFirstWeek(s).ok,true);for(let k=0;k<400;k++)tick(s,.5);assert.ok(!s.incidents.some(i=>i.story));assert.equal(skipFirstWeek(s).ok,false);
 assert.equal(startFirstWeek(createGame('chief',1,{schedule:'ppa'})),false);assert.equal(startFirstWeek(createGame('career',1)),false);
 const plain=createGame('career',7182,{schedule:'ppa'});for(let k=0;k<400;k++)tick(plain,.5);assert.ok(!plain.incidents.some(i=>i.story),'only when the week was started');
});

test('points: closed call and the mentor\'s key decision; the verdict and validation',()=>{
 const key={state:'resolved',talk:{choices:[{id:'polite'}]}};assert.equal(dayResult(1,key).points,2);assert.equal(dayResult(1,{...key,talk:{choices:[{id:'firm'}]}}).points,1);assert.equal(dayResult(1,{...key,state:'missed'}).points,0);assert.equal(dayResult(1,null).points,0);
 assert.equal(weekVerdict(WEEK.map(d=>({day:d.day,points:1}))).passed,false);assert.equal(weekVerdict(WEEK.map(d=>({day:d.day,points:2}))).passed,true);
 assert.ok(validWeek(undefined)&&validWeek({day:1,results:[]}));assert.equal(validWeek({day:9,results:[]}),false);assert.equal(validWeek({day:2,results:[{day:1,points:5}]}),false);
 const s=createGame('career',7182,{schedule:'ppa'});startFirstWeek(s);const bad=JSON.parse(serialize(s));bad.life.week.day=40;assert.throws(()=>deserialize(JSON.stringify(bad)));
});

test('accessibility: preferences are clamped, classes follow them, call signals only when asked',()=>{
 assert.deepEqual(a11yPreferences('{bad'),{text:'normal',contrast:false,calm:false,visual:false});assert.equal(a11yPreferences({text:'giant'}).text,'normal');
 assert.deepEqual(a11yClasses({text:'large',contrast:true,calm:true}),['a11y-text-large','a11y-contrast','a11y-calm']);assert.deepEqual(a11yClasses({}),[]);assert.ok(TEXT_SIZES.huge.zoom>TEXT_SIZES.large.zoom);
 assert.equal(callSignal({type:3},{}),null);assert.equal(callSignal({type:2},{visual:true}).flash,'urgent');assert.deepEqual(callSignal({type:3},{visual:true}).vibrate,[140]);
});
