import test from 'node:test';
import assert from 'node:assert/strict';
import data from '../dist/city-data.js';
import {createGame,tick,nextShift,serialize,deserialize} from '../dist/sim.js';
import {PLACES,RESIDENTS,populationSummary,tickPopulation,residentPosition,cityMinute} from '../dist/population.js';
import {WALK_STATUSES} from '../dist/visits.js';
import {onRoad} from '../dist/geography.js';
const advance=(s,seconds)=>{for(let k=0;k<seconds*10;k++)tick(s,.1);};
test('16 stable fictional identities have distinct real building homes and reachable work places',()=>{
 const s=createGame(),other=createGame('chief',99);assert.deepEqual(s.population,other.population);
 assert.equal(s.population.residents.length,16);assert.equal(new Set(RESIDENTS.map(r=>r.home)).size,16);
 for(const r of RESIDENTS){assert.notEqual(r.home,r.work);for(const key of ['home','work']){const p=PLACES.get(r[key]);assert.ok(data.buildings.some(b=>b.id===p.id));assert.ok(onRoad(p.access));}}
});
test('residents commute on directed roads, arrive at home, and return to work next day without commands',()=>{
 const s=createGame();for(let k=0;k<150;k++){tickPopulation(s,1);if(k%5===0){for(const r of s.population.residents)if(!WALK_STATUSES.includes(r.status))assert.ok(onRoad(r));assert.doesNotThrow(()=>deserialize(serialize(s)));}}
 assert.equal(populationSummary(s).home,16);assert.ok(s.population.residents.every(r=>r.journeys===1));
 for(let k=0;k<1200;k++)tickPopulation(s,1);
 assert.equal(populationSummary(s).work,16);assert.ok(s.population.residents.every(r=>r.journeys===2));
 for(const r of s.population.residents){assert.deepEqual({x:r.x,y:r.y},PLACES.get(RESIDENTS[r.id-1].work).access);assert.equal(residentPosition(r).id,RESIDENTS[r.id-1].work);}
});
test('mid-journey save has identical future, including clock and resident routes',()=>{
 const s=createGame();for(let k=0;k<300&&!s.population.residents.some(r=>r.route.length);k++)tick(s,.1);assert.ok(populationSummary(s).travelling>0);const n=deserialize(serialize(s));assert.deepEqual(n,s);advance(s,80);advance(n,80);assert.deepEqual(n,s);
});
test('shift transfer preserves travelling residents and city clock without shared references',()=>{
 const s=createGame();for(let k=0;k<300&&!s.population.residents.some(r=>r.route.length);k++)tick(s,.1);const before=structuredClone(s.population);s.time=480;s.ended=true;const n=nextShift(s);
 assert.deepEqual(n.population,before);assert.notEqual(n.population,s.population);assert.equal(cityMinute(n.population.elapsed),cityMinute(s.population.elapsed));advance(n,12);assert.deepEqual(s.population,before);assert.notDeepEqual(n.population,before);assert.doesNotThrow(()=>deserialize(serialize(n)));
});
test('old saves add population without changing finances, officers, calls or seed',()=>{
 const s=createGame();advance(s,100);delete s.population;for(const i of s.incidents)for(const a of i.scene.participants)delete a.residentId;const n=deserialize(serialize(s));const {population,...rest}=n;assert.deepEqual(rest,s);assert.equal(population.elapsed,s.time);assert.equal(population.residents.length,16);assert.doesNotThrow(()=>deserialize(serialize(n)));
});
test('corrupt resident identities, impossible routes and off-road positions are rejected',()=>{
 const s=createGame();for(let k=0;k<300&&!s.population.residents.some(r=>r.route.length);k++)tick(s,.1);const target=s.population.residents.find(r=>r.route.length);
 for(const change of [n=>{n.population.residents[1].id=1;},n=>{n.population=null;},n=>{n.population.elapsed=-1;},n=>{n.population.residents[0].status='flying';},n=>{n.population.residents.find(r=>r.id===target.id).route[0]={x:0,y:0};},n=>{n.population.residents.find(r=>r.id===target.id).x=0;},n=>{n.population.residents[0].journeys=.5;}]){const n=structuredClone(s);change(n);assert.throws(()=>deserialize(serialize(n)),/жителей/);}
});
test('chief setup and ended shifts freeze residents and city time',()=>{
 for(const s of [createGame('chief'),Object.assign(createGame(),{ended:true})]){const before=structuredClone(s.population);advance(s,60);assert.deepEqual(s.population,before);}
});
