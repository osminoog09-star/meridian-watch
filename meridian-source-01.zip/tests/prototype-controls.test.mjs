import test from 'node:test';import assert from 'node:assert/strict';
import {panGround,setupViewerControls} from '../dist/prototype-controls.js';
test('panning follows screen drag after camera rotation and clamps the quarter',()=>{
 const state={span:200,yaw:Math.PI/2,pitch:Math.PI/6,focus:[0,0]};
 const p=panGround(state,10,0,200);assert.ok(Math.abs(p[0])<1e-10);assert.equal(p[1],10);assert.deepEqual(state.focus,[0,0]);
 const q=panGround(state,0,10,200);assert.ok(Math.abs(q[0]-20)<1e-8);
 assert.deepEqual(panGround({...state,yaw:0},1e6,1e6,0),[-400,400]);
});
test('viewer offers direct phase and pan without campaign storage',()=>{
 const nodes={viewerPan:{setAttribute(k,v){this[k]=v}},viewerPhase:{value:'day'},viewerNotice:{}},events={};
 const doc={getElementById:id=>nodes[id],addEventListener:(n,f)=>events[n]=f};let phase;
 const control=setupViewerControls(doc,{draw(){},setPhase(v){phase=v}});assert.equal(control.panning,false);nodes.viewerPan.onclick();assert.equal(control.panning,true);assert.equal(nodes.viewerPan['aria-pressed'],'true');nodes.viewerPhase.value='night';nodes.viewerPhase.onchange();assert.equal(phase,'night');control.syncPhase('dawn');assert.equal(nodes.viewerPhase.value,'dawn');
});
import {zoomAtGround,pinchGround} from '../dist/prototype-controls.js';
test('zoom keeps the ground anchor stable across yaw and pitch',()=>{for(const yaw of [0,.7,-1.8])for(const pitch of [.4,.8,1.25]){const s={span:200,yaw,pitch,focus:[12,-9]},x=60,y=-40,h=500;const ground=state=>{const p=panGround({...state,focus:[0,0]},-x,-y,h);return [state.focus[0]+p[0],state.focus[1]+p[1]];};const q=zoomAtGround(s,.6,x,y,h);const a=ground(s),b=ground({...s,...q});for(let k=0;k<2;k++)assert.ok(Math.abs(a[k]-b[k])<1e-8);}});
test('pinch supports two finger translation and rejects collapsed fingers',()=>{const s={span:200,yaw:0,pitch:.8,focus:[0,0]},rect={left:0,top:0,width:400,height:500},before=[{x:100,y:200},{x:200,y:200}],after=[{x:120,y:220},{x:220,y:220}];const q=pinchGround(s,before,after,rect);assert.equal(q.span,200);assert.deepEqual(q.focus,panGround(s,20,20,500));assert.deepEqual(pinchGround(s,before,[{x:1,y:1},{x:1,y:1}],rect),{span:200,focus:[0,0]});assert.equal(zoomAtGround(s,1e9,0,0,500).span,1400);assert.equal(zoomAtGround(s,NaN,0,0,500).span,200);});
