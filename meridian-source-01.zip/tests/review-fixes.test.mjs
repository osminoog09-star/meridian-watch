import test from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs';
import FROZEN from '../dist/fiction-streets.js';import {streetName} from '../dist/fiction.js';import data from '../dist/city-data.js';
import {drawOccluded,MIN_OCCLUSION_FACTOR} from '../dist/city-depth.js';
// Fixes for Codex review of PR #5 (Claude, 11.10.2026).
test('street names are frozen: every current road has a fixed unique fictional name',()=>{
 const names=[...new Set(data.roads.map(r=>r.name).filter(Boolean))];assert.deepEqual(Object.keys(FROZEN).sort(),names.sort());
 assert.equal(new Set(Object.values(FROZEN)).size,names.length);for(const n of names)assert.equal(streetName(n),FROZEN[n]);
});
test('a shrunk snapshot skips the foreground search and draws the actor unmasked',()=>{let queried=false,drawn=false;const buildings={query(){queried=true;return [];}};
 assert.equal(drawOccluded({},buildings,{x:0,y:0},{x:0,y:0,scale:MIN_OCCLUSION_FACTOR/2},390,570,()=>{drawn=true;},12),false);assert.ok(drawn);assert.equal(queried,false);});
test('game UI has no links to developer pages with real place names',()=>{const app=fs.readFileSync(new URL('../dist/app.js',import.meta.url),'utf8');for(const page of ['prototype3d.html','police-prototype.html','cars-prototype.html','people-prototype.html','models.html','visual-audit.html','roadmap.html','QA.md'])assert.ok(!app.includes(`href="${page}`),page);});
