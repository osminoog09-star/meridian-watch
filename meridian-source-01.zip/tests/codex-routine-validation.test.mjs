import test from 'node:test';import assert from 'node:assert/strict';
import {createGame,serialize,deserialize,tick} from '../dist/sim.js';
const roster=()=>createGame('career',7182,{schedule:'ppa'});
test('routine timers and meal flags reject corrupt saves before they can strand a crew',()=>{
 for(const value of ['never',null,-1,1e20]){const s=roster();s.units[0].routineLeft=value;assert.throws(()=>deserialize(serialize(s)));}
 const s=roster();s.units[0].mealDone='false';assert.throws(()=>deserialize(serialize(s)));
});
test('briefing save resumes with identical simulation continuation',()=>{
 const a=roster();for(let i=0;i<70;i++)tick(a,.1);const b=deserialize(serialize(a));
 for(let i=0;i<200;i++){tick(a,.1);tick(b,.1);}assert.equal(serialize(a),serialize(b));
});
