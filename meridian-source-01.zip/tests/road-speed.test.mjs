import test from 'node:test';
import assert from 'node:assert/strict';
import {parseSpeed,roadSpeed} from '../dist/road-speed.js';
import {advanceRoute} from '../dist/transport.js';
import {MAP_METRES} from '../dist/world-scale.js';
import {ROAD_NODES,roadRoute,segmentSpeed} from '../dist/geography.js';
import data from '../dist/city-data.js';
test('numeric speed units, directional tags and unresolved conditions',()=>{
 assert.equal(parseSpeed('50'),50);assert.equal(parseSpeed('30 km/h'),30);assert.ok(Math.abs(parseSpeed('20 mph')-32.18688)<1e-8);
 for(const raw of ['EE:urban','none','249','0','-30','50;70','50 @ (wet)',null])assert.equal(parseSpeed(raw),null);
 const r={id:'test',kind:'service',speedTags:{maxspeed:'50','maxspeed:forward':'30','maxspeed:backward':'20 mph'}};
 assert.equal(roadSpeed(r).kmh,30);assert.ok(roadSpeed(r,false).kmh>32);assert.equal(roadSpeed(r).source,'osm');
 r.speedTags['maxspeed:conditional']='10 @ (wet)';assert.equal(roadSpeed(r).source,'game-default');assert.equal(roadSpeed(r).kmh,20);
 assert.equal(roadSpeed({kind:'residential'}).source,'game-default');
});
test('segment boundary consumes time at each limit instead of carrying old distance budget',()=>{
 const a={x:0,y:0,route:[{x:10/MAP_METRES,y:0,roadSpeed:{kmh:36,source:'osm'}},{x:100/MAP_METRES,y:0,roadSpeed:{kmh:18,source:'osm'}}]};
 advanceRoute(a,2/45,72);assert.ok(Math.abs(a.x*MAP_METRES-15)<1e-8);assert.equal(a.roadLimitKmh,18);
 const b={x:0,y:0,route:[{x:1,y:0,roadSpeed:{kmh:20,source:'osm'}}]};advanceRoute(b,1/45,60,{obeyLimits:false});assert.ok(Math.abs(b.x*MAP_METRES-60/3.6)<1e-8);
});
test('real directed graph, planned routes and legacy partial segments retain source limits',()=>{
 assert.equal(data.roads.filter(r=>r.speedTags&&Object.keys(r.speedTags).length).length,438);
 const a=ROAD_NODES.find(n=>n.edges.some(e=>e.speed.kmh===20)),e=a.edges.find(e=>e.speed.kmh===20),b=ROAD_NODES.find(n=>n.id===e.id);
 const mid={x:(a.x+b.x)/2,y:(a.y+b.y)/2};assert.equal(segmentSpeed(mid,b).kmh,20);
 const old={...mid,route:[{x:b.x,y:b.y}]};advanceRoute(old,.0001,30);assert.ok(old.currentSpeedKmh<=20+1e-7);
 const route=roadRoute(a,b);assert.ok(route.length);for(const p of route)assert.ok(p.roadSpeed?.kmh>0);
});
