import test from 'node:test';import assert from 'node:assert/strict';
import {routeWeight,roadRoute,NODES} from '../dist/geography.js';
import {streetStyle} from '../dist/street-art.js';
// Owner 11.10: patrol cars must look like they drive on roads; routes avoid yards and parking aisles.
test('routing prefers proper streets over service ways and living streets',()=>{
 assert.ok(routeWeight(1,20,'service')>routeWeight(1,20,'residential')*3);assert.ok(routeWeight(1,50,'secondary')<routeWeight(1,30,'residential'));
 const r=roadRoute(NODES[0],NODES.at(-1));assert.ok(r.length>2);
});
test('drivable ways always look like carriageways; footways are thin without a curb',()=>{
 const road=streetStyle({id:-1,drive:true,kind:'service'},1670,10),path=streetStyle({id:-2,drive:false,kind:'footway'},1670,10);
 assert.ok(road.edgeWidth>road.width,'curb line');assert.equal(path.edgeWidth,path.width,'no curb on footways');assert.ok(path.width<road.width);
});
