import test from 'node:test';import assert from 'node:assert/strict';
import {createGame,tick,nextShift,serialize,deserialize,spawnIncident,assign,startPatrolTask,shiftWeather,unitReason} from '../dist/sim.js';
import {TASKS,TASK_IDS,taskResult,taskReward,autoTaskFor,preventionMods,taskTicks} from '../dist/patrolwork.js';
import {VARIANTS,variantWeights,PROTOCOLS,weatherFor} from '../dist/calls.js';
import {NODES} from '../dist/geography.js';
// R13 «Новые вызовы и работа между вызовами» (Claude, 11.10.2026).
const share=(id,w,minute=12*60)=>{const ws=variantWeights(minute,w),k=VARIANTS.findIndex(v=>v.id===id);return ws[k]/ws.reduce((a,b)=>a+b,0);};

test('new calls appear only in roster campaigns, seasonal ones only in their season',()=>{
 const roster=VARIANTS.filter(v=>v.roster);assert.ok(roster.length>=8);for(const v of roster)assert.ok(PROTOCOLS[v.id]&&v.brief.length>40,v.id);
 const legacy=weatherFor(7182,3);for(const v of roster)assert.equal(share(v.id,legacy),0,'legacy mix unchanged: '+v.id);
 const autumn={kind:'rain',season:'autumn'},winter={kind:'snow',season:'winter'},summer={kind:'clear',season:'summer'};
 assert.ok(share('phone-scam',autumn)>0);assert.ok(share('restraining-order',autumn,20*60)>0);
 assert.equal(share('thin-ice',autumn),0);assert.ok(share('thin-ice',winter)>0);assert.equal(share('beach-party',winter,23*60),0);assert.ok(share('beach-party',summer,23*60)>0);
});

test('a roster shift really produces the new calls',()=>{
 const seen=new Set();for(const seed of [3,7,11]){const s=createGame('career',seed,{schedule:'ppa'});for(let k=0;k<2000&&!s.ended;k++){tick(s,.5);for(const i of s.incidents)seen.add(i.variant);}}
 assert.ok([...seen].some(v=>VARIANTS.find(x=>x.id===v)?.roster),[...seen].join(','));
});

function quiet(){const s=createGame('career',4411,{schedule:'ppa'});s.nextIncident=9000;for(const u of s.units)u.tasksToday=99;for(let k=0;k<200;k++)tick(s,.1);return s;}

test('the player orders a sobriety checkpoint: the crew drives to a road, works, reports and prevents',()=>{
 assert.equal(startPatrolTask(createGame(),1,'breath-check').ok,false,'old campaigns have no patrol work');
 const s=quiet(),u=s.units[0];assert.equal(startPatrolTask(s,1,'nope').ok,false);
 const trust=s.trust,xp=s.xp;assert.equal(startPatrolTask(s,1,'breath-check').ok,true);assert.equal(u.status,'proactive');assert.equal(u.task.phase,'moving');
 assert.match(unitReason(s,u),/Едем на место/);assert.equal(startPatrolTask(s,1,'speed-check').ok,false,'busy');
 assert.doesNotThrow(()=>deserialize(serialize(s)));
 for(let k=0;k<6000&&u.status==='proactive';k++)tick(s,.1);
 assert.equal(u.status,'patrol');assert.equal(s.tasksDone[0].task,'breath-check');assert.equal(s.tasksDone[0].done,true);assert.match(s.tasksDone[0].text,/проверено \d+ водителей/);
 assert.ok(s.trust>trust);assert.ok(s.xp>xp);assert.ok(preventionMods(s)['drunk-driver']<1);
 const w={...shiftWeather(s),prevention:preventionMods(s)};assert.ok(share('drunk-driver',w,23*60)<share('drunk-driver',shiftWeather(s),23*60));
 assert.doesNotThrow(()=>deserialize(serialize(s)));
 s.ended=true;const n=nextShift(s);assert.ok(n.units.every(x=>x.task===undefined&&x.status!=='proactive'));assert.equal(n.prevention,undefined);
});

test('a dispatcher order interrupts the task at once',()=>{
 const s=quiet(),u=s.units[0];startPatrolTask(s,1,'foot-patrol');for(let k=0;k<40;k++)tick(s,.1);
 const n=NODES[50],i=spawnIncident(s,null,{variant:'noise-flat',point:{x:n.x,y:n.y}});assert.equal(assign(s,1,i.id),true);
 assert.equal(u.status,'responding');assert.equal(u.task,undefined);assert.equal(s.tasksDone[0].done,false);assert.ok(s.logs.some(l=>/прерван/.test(l.text)));
});

test('auto crews work between calls on their own and drop it for a waiting call',()=>{
 const s=createGame('career',4411,{schedule:'ppa'});s.nextIncident=9000;let started=false;for(let k=0;k<6000&&!started;k++){tick(s,.25);started=s.units.some(u=>u.status==='proactive');}
 assert.ok(started,'a crew started patrol work in a quiet shift');const u=s.units.find(x=>x.status==='proactive');
 for(const o of s.units)if(o!==u&&['patrol','idle'].includes(o.status))o.auto=false;
 const n=NODES[80],i=spawnIncident(s,null,{variant:'noise-flat',point:{x:n.x,y:n.y}});for(let k=0;k<5;k++)tick(s,.25);
 assert.notEqual(u.status,'proactive');assert.ok(i.units.includes(u.id),'the crew took the call');
 const bad=JSON.parse(serialize(s));const b=bad.units.find(x=>x.id===u.id);b.status='proactive';assert.throws(()=>deserialize(JSON.stringify(bad)),'proactive needs a task');
});

test('results are deterministic; busy nights bring more drunk drivers; rewards follow results',()=>{
 for(const id of TASK_IDS){assert.ok(TASKS[id].about.length>40);assert.ok(taskTicks(id)>0);}
 assert.ok(taskTicks('breath-check',true)<taskTicks('breath-check'));
 assert.deepEqual(taskResult('breath-check',{seed:1,shift:2,unit:3,start:40}),taskResult('breath-check',{seed:1,shift:2,unit:3,start:40}));
 let quietN=0,busyN=0;for(let k=0;k<300;k++){quietN+=taskResult('breath-check',{seed:k,busy:.7}).found;busyN+=taskResult('breath-check',{seed:k,busy:1.6}).found;}assert.ok(busyN>quietN*1.5,`${busyN} vs ${quietN}`);
 assert.ok(taskReward('breath-check',{found:2}).xp>taskReward('breath-check',{found:0}).xp);assert.ok(taskReward('foot-patrol',{found:5}).district>taskReward('speed-check',{found:5}).district);
 assert.equal(autoTaskFor(23*60),'breath-check');assert.equal(autoTaskFor(8*60),'speed-check');assert.equal(autoTaskFor(19*60),'foot-patrol');
});

test('old campaigns never start patrol work',()=>{const s=createGame('career',4411);s.nextIncident=9000;for(let k=0;k<3000;k++)tick(s,.25);assert.ok(s.units.every(u=>u.task===undefined));assert.equal(s.tasksDone,undefined);});
