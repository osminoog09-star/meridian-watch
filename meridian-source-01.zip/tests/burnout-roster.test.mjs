import test from 'node:test';import assert from 'node:assert/strict';
import {createGame,tick,nextShift,serialize,deserialize,hireOfficer,createPatrol,grantLeave,reserveOfficers,shiftWages} from '../dist/sim.js';
import {performanceFactor,microsleep,BURNOUT} from '../dist/burnout.js';
import {ROSTER,rosterAfterShift,wagesFactor,startFatigueOf} from '../dist/roster.js';
import {applyPlan,validPlan,freeBlocks,ensureLife} from '../dist/life.js';
import {SHIFT_TICKS} from '../dist/schedule.js';
// R4 burnout and R5 chief roster.

test('stress slows work; night microsleep only when very tired',()=>{
 assert.equal(performanceFactor(50),1);assert.ok(performanceFactor(100)<performanceFactor(80));assert.ok(performanceFactor(100)>=1-BURNOUT.maxPenalty-1e-9);
 assert.equal(microsleep(1,5,95,14*60),null,'daytime: no microsleep');assert.equal(microsleep(1,5,60,4*60),null,'not tired enough');
 const hits=Array.from({length:400},(_,b)=>microsleep(1,b,95,4*60)).filter(Boolean);assert.ok(hits.length>50&&hits.every(h=>h==='crash'));
 assert.ok(Array.from({length:400},(_,b)=>microsleep(2,b,80,4*60)).filter(Boolean).every(h=>h==='nearMiss'));
});

test('a nodding driver pulls over at night and is explained',()=>{
 const s=createGame('career',7182,{schedule:'ppa'});s.nextIncident=9000;for(let k=0;k<300;k++)tick(s,.1);
 const now=s.population.elapsed;s.population.elapsed+=((4*60+1440-((17*60+now*45/60)%1440))%1440)*60/45;// jump to 04:00
 for(const o of s.officers)o.fatigue=97;let stopped=false;for(let k=0;k<3000&&!stopped;k++){tick(s,.1);for(const o of s.officers)o.fatigue=97;stopped=s.units.some(u=>u.pullover>0);}
 assert.ok(stopped,'someone nodded off');assert.ok(s.logs.some(l=>/задремал|чуть не заснул/.test(l.text)));assert.doesNotThrow(()=>deserialize(serialize(s)));
});

test('burnout: two stressed off periods → psychologist, forced rest, then relief',()=>{
 const life=JSON.parse(JSON.stringify(ensureLife(createGame('career',7182,{schedule:'ppa'}))));life.stress=95;
 applyPlan(life,[{activity:'overtime'},{activity:'overtime'},{activity:'rest'},{activity:'rest'}].slice(0,1),4);assert.equal(life.burnout,1);
 life.stress=95;const r=applyPlan(life,[{activity:'hobby'}],8);assert.equal(life.forcedRest,true);assert.match(r.lines.join(),/Психолог/);
 assert.equal(validPlan([{activity:'overtime'},{activity:'rest'},{activity:'rest'},{activity:'rest'}],freeBlocks(4),life),false,'no overtime while forced to rest');
 life.stress=90;applyPlan(life,[{activity:'rest'}],12);assert.equal(life.forcedRest,false);assert.ok(life.stress<90);
});

test('chief roster: night premium, sleep debt, leave',()=>{
 assert.ok(Math.abs(wagesFactor(true)-(1+.25*8/12))<1e-9);assert.equal(wagesFactor(false),1);
 const o={id:1};rosterAfterShift(o,{worked:true,night:true,restHours:12});assert.equal(o.sleepDebt,ROSTER.nightSleep+ROSTER.shortRest);assert.equal(o.nights,1);assert.ok(startFatigueOf({sleepDebt:80,stress:20})>0);
 let s=createGame('chief',7182,{schedule:'ppa'});s.budget+=5000;s.finance.opening+=5000;for(let k=1;k<=3;k++)assert.equal(hireOfficer(s,k).ok,true);
 assert.equal(createPatrol(s,s.officers[0].id,s.officers[1].id,1).ok,true);s.setupPending=false;const reserve=s.officers[2];
 assert.equal(grantLeave(s,s.officers[0].id).ok,false,'crew members must be moved to reserve first');assert.equal(grantLeave(s,reserve.id).ok,true);
 assert.equal(reserve.leave,ROSTER.leaveShifts);assert.ok(!reserveOfficers(s).includes(reserve));assert.equal(createPatrol(s,reserve.id,0,2).ok,false);
 for(let n=0;n<1;n++){for(let k=0;k<SHIFT_TICKS*10+10&&!s.ended;k++)tick(s,.1);s=nextShift(s);}
 const day=shiftWages(s);for(let k=0;k<SHIFT_TICKS*10+10&&!s.ended;k++)tick(s,.1);s=nextShift(s);assert.ok(shiftWages(s)>day,'night shift wages include the premium');
 const worker=s.officers[0];assert.ok(worker.shiftsWorked>=2);assert.ok(s.officers.find(o=>o.id===reserve.id).leave<ROSTER.leaveShifts);
 assert.doesNotThrow(()=>deserialize(serialize(s)));const bad=JSON.parse(serialize(s));bad.officers[0].leave=9;assert.throws(()=>deserialize(JSON.stringify(bad)));
});
