import test from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs';
import {NODES,ROAD_NODES} from '../dist/geography.js';
import {VISITS} from '../dist/visits.js';
import {PATROL_ZONES} from '../dist/patrol-planner.js';
import {streetName,CITY_NAME,LOCAL_STREET} from '../dist/fiction.js';
import data from '../dist/city-data.js';
// Owner decision 11.10.2026: fictional city «Меридиан», no real place names shown to players.
const real=/[A-Za-zÄÖÜÕäöüõŠšŽž]|Пярну|Эстони/;

test('every shown street, district, place and zone name is fictional',()=>{
 for(const n of [...NODES,...ROAD_NODES])assert.doesNotMatch(n.name,real,n.name);
 for(const v of VISITS){assert.doesNotMatch(v.name,real,v.name);assert.doesNotMatch(v.address,real,v.address);}
 for(const z of Object.values(PATROL_ZONES))assert.doesNotMatch(z,real,z);
});

test('street mapping is deterministic and unique per real road name',()=>{
 const names=[...new Set(data.roads.map(r=>r.name).filter(Boolean))],shown=names.map(streetName);
 assert.equal(new Set(shown).size,names.length);assert.equal(streetName(names[0]),shown[0]);assert.equal(streetName(null),LOCAL_STREET);assert.equal(CITY_NAME,'Меридиан');
});

test('main page and game texts carry no real city name or OSM mention outside the help credit',()=>{
 const html=fs.readFileSync(new URL('../dist/index.html',import.meta.url),'utf8');assert.doesNotMatch(html,/Пярну|Pärnu|PÄRNU|Эстони|ЭСТОНИ|OpenStreetMap|OSM/);
 for(const f of ['render.js','sim.js','patrol-planner.js']){const s=fs.readFileSync(new URL('../dist/'+f,import.meta.url),'utf8');assert.doesNotMatch(s,/Пярну|ПЯРНУ|Pärnu Muuseum/,f);}
 const app=fs.readFileSync(new URL('../dist/app.js',import.meta.url),'utf8');assert.doesNotMatch(app,/Пярну|ПЯРНУ|Rüütli|Malmö/);assert.equal((app.match(/openstreetmap\.org\/copyright/g)??[]).length,1);
});
