import test from 'node:test';import assert from 'node:assert/strict';
import {createGame,tick,spawnIncident,assign,chooseTalk,serialize,deserialize} from '../dist/sim.js';
import {SCRIPTS,TYPE_SCRIPTS,SCRIPTED,scriptFor,ensureTalk,applyChoice,autoOption,currentStage,optionOpen,talkDone,factsFor,talkComplaintFactor,validTalk} from '../dist/dialogues.js';
import {VARIANTS} from '../dist/calls.js';
import {NODES} from '../dist/geography.js';
// Release B «Глубина вызовов» (Claude, 12.10.2026).
test('every call has a three-step scene; dedicated scripts for the main calls',()=>{
 assert.ok(SCRIPTED.length>=13);for(const v of VARIANTS)assert.ok(scriptFor({variant:v.id,type:v.type}),v.id);
 for(const sc of [...Object.values(SCRIPTS),...TYPE_SCRIPTS]){assert.deepEqual(sc.map(x=>x.stage),['approach','inquiry','decision']);for(const st of sc){assert.ok(st.options.length>=1&&st.title);for(const o of st.options)assert.ok(o.id&&o.label.length>4);}
  assert.ok(sc[2].options.some(o=>!o.needs),'a decision without preconditions always exists');}
});
test('the inquiry reveals the facts; a careless choice costs; automatic play follows the standing order',()=>{
 const i={id:41,variant:'drunk-driver',type:5};ensureTalk(i);assert.equal(currentStage(i).stage,'approach');applyChoice(i,'safe');
 const law=()=>currentStage(i)?.options.find(o=>o.id==='law');const r=applyChoice(i,'breath');const f=factsFor(i);assert.match(r.line,f.refuses?/Отказывается/:/промилле/);
 assert.ok(optionOpen(i,law()));applyChoice(i,'law');assert.ok(talkDone(i));assert.equal(i.talk.sets.custody,f.promille>=1.5||f.refuses?'arrest':'warn');
 const j={id:41,variant:'drunk-driver',type:5};ensureTalk(j);applyChoice(j,'safe');applyChoice(j,'trust');assert.equal(optionOpen(j,currentStage(j).options.find(o=>o.id==='law')),false,'no test → no lawful decision');applyChoice(j,'release');assert.ok(j.talk.followUp>3,'he will drive drunk again');
 const k={id:5,variant:'domestic',type:4};ensureTalk(k);assert.equal(autoOption(k,'strict'),'firm');assert.equal(autoOption(k,'prevention'),'separate');assert.equal(autoOption(k,'balanced'),'separate');
 assert.ok(talkComplaintFactor({complaint:1,evidence:10,sets:{custody:'arrest'}})>talkComplaintFactor({complaint:1,evidence:60,sets:{custody:'arrest'}}),'evidence protects against complaints');
 assert.ok(validTalk(i.talk));assert.equal(validTalk({...i.talk,evidence:300}),false);
});
function manual(variant){for(let seed=1;seed<40;seed++){const s=createGame('career',seed,{schedule:'ppa'});s.nextIncident=9000;for(const u of s.units){u.auto=false;u.tasksToday=99;}for(let k=0;k<200;k++)tick(s,.1);const n=NODES[(seed*13)%NODES.length];
 const i=spawnIncident(s,null,{variant,point:{x:n.x,y:n.y}}),u=s.units[0];if(!assign(s,u.id,i.id))continue;for(let k=0;k<6000&&u.status!=='decision';k++)tick(s,.1);if(u.status==='decision')return {s,i,u};}return null;}
test('the player plays a shoplifting call through the card and the protocol follows the choices',()=>{
 const m=manual('shoplift');assert.ok(m);const {s,i,u}=m;assert.ok(i.talk);assert.equal(chooseTalk(s,u.id,'nope').ok,false);
 assert.equal(chooseTalk(s,u.id,'security').ok,true);assert.equal(u.status,'working');assert.equal(i.decision,'check');
 const law=currentStage(i).options;assert.ok(law.length>=2);assert.equal(chooseTalk(s,u.id,'camera').ok,true);
 assert.doesNotThrow(()=>deserialize(serialize(s)),'saves in the middle of a scene');
 assert.equal(chooseTalk(s,u.id,'law').ok,true);const f=factsFor(i);assert.equal(i.custodyChoice,f.value>200||f.repeat?'arrest':'warn');
 for(let k=0;k<20000&&!['resolved','missed'].includes(i.state);k++)tick(s,.1);assert.equal(i.state,'resolved');
 const c=s.cases.find(x=>x.id===i.id);assert.ok(c.talk.length===3);assert.match(c.protocol,new RegExp(String(f.value)));
});
test('automatic crews play the scene too; old campaigns keep the old cards',()=>{
 const s=createGame('career',4242,{schedule:'ppa'});for(let k=0;k<2200&&!s.ended;k++)tick(s,.5);const played=(s.cases??[]).filter(c=>c.talk?.length===3).length;assert.ok(played>=(s.cases??[]).filter(c=>c.success).length*.8,`${played}`);
 const l=createGame('career',4242);for(let k=0;k<1500;k++)tick(l,.5);assert.ok(l.incidents.every(i=>i.talk===undefined));assert.equal(chooseTalk(l,1,'calm').ok,false);
});
function manualWhere(variant,pred){for(let seed=1;seed<80;seed++){const s=createGame('career',seed,{schedule:'ppa'});s.nextIncident=9000;for(const u of s.units){u.auto=false;u.tasksToday=99;}for(let k=0;k<200;k++)tick(s,.1);const n=NODES[(seed*13)%NODES.length];
 const i=spawnIncident(s,null,{variant,point:{x:n.x,y:n.y}}),u=s.units[0];if(!pred(i)||!assign(s,u.id,i.id))continue;for(let k=0;k<6000&&u.status!=='decision';k++)tick(s,.1);if(u.status==='decision'&&!i.medical)return {s,i,u};}return null;}
test('a scene choice that finds an injury calls the ambulance (Release C fix)',()=>{
 const m=manualWhere('domestic',i=>factsFor(i).injured);assert.ok(m,'a domestic call with an injury');const {s,i,u}=m;
 for(let k=0;k<3&&currentStage(i);k++){const st=currentStage(i),o=st.options.find(x=>x.id==='injury')??st.options.find(x=>optionOpen(i,x)&&!x.needs)??st.options[0];chooseTalk(s,u.id,o.id);for(let t=0;t<40;t++)tick(s,.1);}
 assert.ok(i.talk.sets.ambulance,'the crew asked for an ambulance');assert.ok(i.medical,'the ambulance is on its way');
});
