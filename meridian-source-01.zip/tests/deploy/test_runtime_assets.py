"""APK runtime asset closure (Claude, 11.10.2026)."""
import importlib.util, re, tempfile, unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
spec = importlib.util.spec_from_file_location('runtime_assets', ROOT / 'android' / 'runtime_assets.py')
runtime = importlib.util.module_from_spec(spec); spec.loader.exec_module(runtime)


class RuntimeAssets(unittest.TestCase):
    def test_missing_import_stops_packaging(self):
        with tempfile.TemporaryDirectory() as folder:
            dist = Path(folder)
            (dist / 'index.html').write_text('<script type="module" src="app.js"></script>')
            (dist / 'app.js').write_text("import './missing.js';")
            with self.assertRaises(FileNotFoundError):
                runtime.closure(dist)

    def setUp(self):
        self.dist = ROOT / 'dist'
        self.names = runtime.closure(self.dist)

    def test_entry_points_and_core_modules_are_packaged(self):
        for name in ['index.html', 'style.css', 'boot.js', 'app.js', 'sim.js', 'render.js', 'city-data.js']:
            self.assertIn(name, self.names)

    def test_every_relative_import_of_a_packaged_module_is_packaged(self):
        pattern = re.compile(r'''(?:import|export)[^'"]*?from\s*['"]\./([^'"]+)['"]|import\(\s*['"]\./([^'"]+)['"]\s*\)''')
        for name in self.names:
            if name.endswith('.js'):
                for groups in pattern.findall((self.dist / name).read_text(encoding='utf-8')):
                    self.assertIn(next(g for g in groups if g), self.names, f'{name} imports a file outside the APK')

    def test_developer_pages_with_real_names_stay_out(self):
        for name in ['audit.html', 'map-notes.html', 'roadmap.html', 'prototype3d.html', 'police-prototype.html', 'cars-prototype.html', 'people-prototype.html', 'performance-audit.html', 'ktp-reference.html']:
            self.assertNotIn(name, self.names)
        for name in self.names:
            if name.endswith('.html'):
                self.assertNotRegex((self.dist / name).read_text(encoding='utf-8'), r'Pärnu|Пярну|OpenStreetMap')


if __name__ == '__main__':
    unittest.main()
