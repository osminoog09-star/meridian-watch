import hashlib,json,shutil,subprocess,tempfile,unittest,zipfile
from pathlib import Path

class SourceImportTests(unittest.TestCase):
    def test_old_archive_preserves_git_collaboration_documents(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d)
            shutil.copyfile(Path(__file__).parents[2]/'tools/collab-source-import.py',root/'source-import.py')
            protected=['AGENTS.md','CLAUDE.md','COLLAB_LOG.md','CLAUDE_HANDOFF.md']
            for name in protected:(root/name).write_text('current git '+name)
            archive=root/'old.zip'
            with zipfile.ZipFile(archive,'w') as z:
                for name in protected:z.writestr('./'+name,'stale archive')
                z.writestr('dist/test.js','new source')
            (root/'source-import-sha256.json').write_text(json.dumps({'old.zip':hashlib.sha256(archive.read_bytes()).hexdigest()}))
            subprocess.run(['python3',str(root/'source-import.py')],check=True,capture_output=True)
            for name in protected:self.assertEqual((root/name).read_text(),'current git '+name)
            self.assertEqual((root/'dist/test.js').read_text(),'new source')
