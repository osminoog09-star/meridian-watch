import hashlib, importlib.util, io, json, stat, tempfile, unittest, zipfile
from pathlib import Path
spec=importlib.util.spec_from_file_location('update',Path(__file__).parents[2]/'dist/deploy/update.py')
u=importlib.util.module_from_spec(spec);spec.loader.exec_module(u)

def archive(extra=None):
    output=io.BytesIO()
    with zipfile.ZipFile(output,'w') as z:
        for name in u.REQUIRED:
            z.writestr(name,'<html>game</html>' if name=='index.html' else '/* game */')
        for name,value in (extra or {}).items(): z.writestr(name,value)
    data=output.getvalue()
    return data,dict(version='0.4.1',archive='/downloads/meridian-watch-0.4.1-static.zip',sha256=hashlib.sha256(data).hexdigest(),bytes=len(data))

class DeploymentTests(unittest.TestCase):
    def test_first_repeat_and_rollback_targets(self):
        with tempfile.TemporaryDirectory() as d:
            base=Path(d);data,m=archive()
            self.assertTrue(u.activate(base,m,data))
            first=(base/'current').resolve()
            self.assertFalse(u.activate(base,m,data))
            data2,m2=archive({'extra.json':'{}'})
            self.assertTrue(u.activate(base,m2,data2))
            self.assertEqual((base/'previous-target.txt').read_text().strip(),str(first))
            self.assertTrue(first.exists())
    def test_bad_digest_preserves_current(self):
        with tempfile.TemporaryDirectory() as d:
            base=Path(d);data,m=archive();u.activate(base,m,data)
            first=(base/'current').resolve();m['sha256']='0'*64
            with self.assertRaises(ValueError):u.activate(base,m,data)
            self.assertEqual((base/'current').resolve(),first)
    def test_traversal_and_executable_rejected(self):
        for name in ['../escape','/absolute.js','nested/file.js','.env','run.py','x\\y.js']:
            with self.subTest(name=name):
                data,m=archive({name:'bad'})
                with self.assertRaises(ValueError):u.validate_zip(data,m)
    def test_symlink_rejected(self):
        output=io.BytesIO();info=zipfile.ZipInfo('evil.js');info.external_attr=(stat.S_IFLNK|0o777)<<16
        with zipfile.ZipFile(output,'w') as z:z.writestr(info,'/etc/passwd')
        data=output.getvalue();_,m=archive();m.update(sha256=hashlib.sha256(data).hexdigest(),bytes=len(data))
        with self.assertRaises(ValueError):u.validate_zip(data,m)
    def test_manifest_source_bound(self):
        _,m=archive()
        for path in ['/other.zip','https://example.org/release.zip','/downloads/../release.zip']:
            with self.assertRaises(ValueError):u.validate_manifest(dict(m,archive=path))
    def test_plain_directory_not_replaced(self):
        with tempfile.TemporaryDirectory() as d:
            base=Path(d);(base/'current').mkdir();(base/'current/keep').write_text('keep')
            data,m=archive()
            with self.assertRaises(ValueError):u.activate(base,m,data)
            self.assertEqual((base/'current/keep').read_text(),'keep')
    def test_real_release(self):
        root=Path(__file__).parents[2]
        m=json.loads((root/'dist/deploy/release.json').read_text())
        u.validate_manifest(m)
        with u.validate_zip((root/'dist'/m['archive'].lstrip('/')).read_bytes(),m) as z:
            self.assertIn('sim.js',z.namelist())
        with tempfile.TemporaryDirectory() as d:
            self.assertTrue(u.activate(Path(d),m,(root/'dist'/m['archive'].lstrip('/')).read_bytes()))

if __name__=='__main__':unittest.main()
