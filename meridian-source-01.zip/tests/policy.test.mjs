import test from 'node:test';import assert from 'node:assert/strict';
import {createGame,hireOfficer,createPatrol,tick,nextShift,shiftCost,serialize,deserialize,spawnIncident,setPolicy,setPriorityDistrict,districtOf,districtTrust} from '../dist/sim.js';
import {POLICIES,POLICY_IDS,PRIORITY_RULES,policyOf,priorityOf,policyCost} from '../dist/policy.js';
import {custodyDecision,DISTRICT_IDS} from '../dist/calls.js';
import {NODES} from '../dist/geography.js';
// 0.6.2 «Правила отделения»: standing order + priority district change real behaviour (chief only).

function hire(s,id){assert.equal(hireOfficer(s,id).ok,true);return s.officers.at(-1).id;}
function ready(){const s=createGame('chief');const a=hire(s,1),b=hire(s,2);assert.equal(createPatrol(s,a,b,1).ok,true);s.nextIncident=9000;return s;}

test('rules exist, are described and only the chief can change them',()=>{
 for(const id of POLICY_IDS){assert.ok(POLICIES[id].label&&POLICIES[id].about.length>40);}
 const career=createGame();assert.equal(setPolicy(career,'strict'),false);assert.equal(setPriorityDistrict(career,DISTRICT_IDS[0]),false);
 career.policy='strict';assert.equal(policyOf(career),POLICIES.balanced,'career ignores a stray policy');assert.equal(policyCost(career),0);
 const s=ready();assert.equal(setPolicy(s,'nope'),false);assert.equal(setPolicy(s,'balanced'),false,'already active');
 assert.equal(setPolicy(s,'strict'),true);assert.equal(s.policy,'strict');assert.match(s.logs[0].text,/Нулевая терпимость/);
});

test('rules change the shift cost and carry into the next shift',()=>{
 const s=ready(),base=shiftCost(s);setPolicy(s,'strict');assert.equal(shiftCost(s),base+POLICIES.strict.cost);
 setPriorityDistrict(s,DISTRICT_IDS[1]);assert.equal(shiftCost(s),base+POLICIES.strict.cost+PRIORITY_RULES.cost);
 setPriorityDistrict(s,'');assert.equal(priorityOf(s),null);assert.equal(shiftCost(s),base+POLICIES.strict.cost);
 setPriorityDistrict(s,DISTRICT_IDS[2]);s.ended=true;const n=nextShift(s);assert.equal(n.policy,'strict');assert.equal(n.priorityDistrict,DISTRICT_IDS[2]);
});

function resolve(policy,variant='noise-flat'){
 for(let seed=1;seed<60;seed++){const s=ready();s.seed=seed;if(policy)setPolicy(s,policy);const n=NODES[(seed*13)%NODES.length];
  const i=spawnIncident(s,null,{variant,point:{x:n.x,y:n.y}});for(let k=0;k<8000&&!['resolved','missed'].includes(i.state);k++)tick(s,.1);
  if(i.state==='resolved')return {s,i};}
 return null;
}

test('standing order decides detention when no explicit choice was made',()=>{
 const strict=resolve('strict','noise-venue');assert.ok(strict);assert.equal(custodyDecision(strict.i),'arrest');
 const soft=resolve('prevention','street-fight');assert.ok(soft);assert.equal(custodyDecision(soft.i),'warn');
 assert.ok(!soft.s.units.some(u=>u.transport),'warned participants are not transported');
});

test('prevention raises district trust on warnings; priority district gets crews first and extra trust',()=>{
 const run=(seed,policy)=>{const s=ready();s.seed=seed;setPolicy(s,policy);const n=NODES[(seed*13)%NODES.length];const i=spawnIncident(s,null,{variant:'shoplift',point:{x:n.x,y:n.y}});i.custodyChoice='warn';
  for(let k=0;k<8000&&!['resolved','missed'].includes(i.state);k++)tick(s,.1);return {s,i};};
 let checked=false;for(let seed=1;seed<40&&!checked;seed++){const a=run(seed,'balanced'),b=run(seed,'prevention');if(a.i.state!=='resolved'||b.i.state!=='resolved')continue;const d=districtOf(b.i);
  if(districtTrust(b.s,d)>=100)continue;assert.equal(districtTrust(b.s,d),Math.min(100,districtTrust(a.s,d)+POLICIES.prevention.warnDistrict));checked=true;}
 assert.ok(checked,'found a resolved warning to compare');
 // Dispatch preference: two equal calls, the one in the priority district is taken first.
 const s=ready();const u=s.units[0];const byDist=[...NODES].sort((x,y)=>Math.hypot(x.x-u.x,x.y-u.y)-Math.hypot(y.x-u.x,y.y-u.y));
 const i1=spawnIncident(s,null,{variant:'blocked-exit',point:byDist[0]}),i2=spawnIncident(s,null,{variant:'blocked-exit',point:byDist.at(-1)});
 assert.notEqual(districtOf(i1),districtOf(i2));setPriorityDistrict(s,districtOf(i2));
 for(let k=0;k<50&&u.incident==null;k++)tick(s,.1);assert.equal(u.incident,i2.id,'priority district first at equal severity');assert.notEqual(u.incident,i1.id);
});

test('rules survive save/load and broken values are rejected',()=>{
 const s=ready();setPolicy(s,'prevention');setPriorityDistrict(s,DISTRICT_IDS[0]);
 const n=deserialize(serialize(s));assert.equal(n.policy,'prevention');assert.equal(n.priorityDistrict,DISTRICT_IDS[0]);
 const bad=JSON.parse(serialize(s));bad.policy='martial';assert.throws(()=>deserialize(JSON.stringify(bad)));
 const bad2=JSON.parse(serialize(s));bad2.priorityDistrict='moon';assert.throws(()=>deserialize(JSON.stringify(bad2)));
 const old=JSON.parse(serialize(s));delete old.policy;delete old.priorityDistrict;assert.doesNotThrow(()=>deserialize(JSON.stringify(old)));
});
