import test from 'node:test';import assert from 'node:assert/strict';
import {loadFactor,weekdayOf,absoluteMinute} from '../dist/season.js';
import {shiftStartMinute} from '../dist/schedule.js';
import {createGame,loadNow,weekdayNow} from '../dist/sim.js';
// R9: call load by hour and weekday on the roster.
test('the roster starts on Monday; Friday/Saturday nights are the peak, early mornings the calmest',()=>{
 assert.equal(weekdayOf(shiftStartMinute(0)),1);const day=d=>(2+d)*1440;// d days after Monday 12.10
 const friNight=loadFactor(day(4)+23*60),tueNight=loadFactor(day(1)+23*60),earlyTue=loadFactor(day(1)+5*60),sunMorning=loadFactor(day(6)+9*60),satAfterMidnight=loadFactor(day(6)+1*60);
 assert.ok(friNight>tueNight*1.3);assert.ok(satAfterMidnight>loadFactor(day(2)+60)*1.3,'night after Saturday counts as weekend');assert.ok(earlyTue<.7);assert.ok(sunMorning<loadFactor(day(1)+9*60));
 const s=createGame('career',7182,{schedule:'ppa'});assert.equal(weekdayNow(s),'понедельник');assert.ok(loadNow(s)>0);assert.equal(loadNow(createGame()),1,'legacy unchanged');
 assert.equal(absoluteMinute(900),3360);
});
