import test from 'node:test';import assert from 'node:assert/strict';
import {createGame,hireOfficer,createPatrol,changeCrew,crewChangeReason,reserveOfficers,assign,spawnIncident,serialize,deserialize} from '../dist/sim.js';
// 0.6b reserve management: crew changes only while patrolling or in the station.
function hire(s,id){assert.equal(hireOfficer(s,id).ok,true);return s.officers.at(-1).id;}
function ready(){const s=createGame('chief');const a=hire(s,1),b=hire(s,2);assert.equal(createPatrol(s,a,b,1).ok,true);const c=hire(s,3);return {s,a,b,c,u:s.units[0]};}

test('reserve lists only officers outside crews',()=>{const {s,c}=ready();assert.deepEqual(reserveOfficers(s).map(o=>o.id),[c]);});

test('swap a crew member with a reserve officer; names, skill and fatigue follow the people',()=>{const {s,a,b,c,u}=ready();const fresh=s.officers.find(o=>o.id===c);fresh.fatigue=20;
 const r=changeCrew(s,u.id,b,c);assert.equal(r.ok,true);assert.deepEqual(u.officerIds,[a,c]);assert.equal(u.people[1],fresh.name);
 const left=s.officers.find(o=>o.id===a);assert.equal(u.skill,(left.skill+fresh.skill)/2);assert.equal(u.fatigue,(left.fatigue+20)/2);
 assert.deepEqual(reserveOfficers(s).map(o=>o.id),[b]);assert.match(s.logs[0].text,/резерв/);});

test('pair can drop to solo and solo can take a partner; solo cannot drop its only officer',()=>{const {s,a,b,c,u}=ready();
 assert.equal(changeCrew(s,u.id,b,null).ok,true);assert.deepEqual(u.officerIds,[a]);
 assert.equal(changeCrew(s,u.id,a,null).ok,false);assert.deepEqual(u.officerIds,[a]);
 assert.equal(changeCrew(s,u.id,null,c).ok,true);assert.deepEqual(u.officerIds,[a,c]);
 assert.equal(changeCrew(s,u.id,null,b).ok,false);});

test('busy, on-foot and returning crews are blocked with a clear reason and stay unchanged',()=>{const {s,b,c,u}=ready();const i=spawnIncident(s,0);s.nextIncident=999;assert.equal(assign(s,u.id,i.id),true);
 const before=[...u.officerIds],r=changeCrew(s,u.id,b,c);assert.equal(r.ok,false);assert.match(r.message,new RegExp('вызовом №'+i.id));assert.deepEqual(u.officerIds,before);
 u.status='returning';u.incident=null;assert.match(crewChangeReason(s,u),/участок/);
 u.status='patrol';u.foot={phase:'approach',actors:[]};assert.match(crewChangeReason(s,u),/вне машины/);
 u.foot=null;assert.equal(crewChangeReason(s,u),'');});

test('tired reserve, foreign or crewed officers and career mode are refused',()=>{const {s,a,b,c,u}=ready();s.officers.find(o=>o.id===c).fatigue=90;
 assert.equal(changeCrew(s,u.id,b,c).ok,false);assert.equal(changeCrew(s,u.id,b,a).ok,false);assert.equal(changeCrew(s,u.id,999,c).ok,false);assert.equal(changeCrew(s,u.id,null,null).ok,false);
 const career=createGame();assert.equal(changeCrew(career,career.units[0].id,career.units[0].officerIds?.[0]??1,null).ok,false);});

test('crew change survives save and load',()=>{const {s,a,c,u}=ready();assert.equal(changeCrew(s,u.id,u.officerIds[1],c).ok,true);const n=deserialize(serialize(s));assert.deepEqual(n.units[0].officerIds,[a,c]);assert.equal(n.units[0].people.length,2);});
