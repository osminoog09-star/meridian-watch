import test from 'node:test';
import assert from 'node:assert/strict';
import {createGame,spawnIncident,assign,decide,tick,nextShift,serialize,deserialize,TYPES} from '../dist/sim.js';
import {residentProfile,populationSummary} from '../dist/population.js';
const advance=(s,seconds)=>{for(let k=0;k<seconds*10;k++)tick(s,.1);};
function setup(type=0){const s=createGame();s.nextIncident=999;s.units.forEach(u=>u.auto=false);const i=spawnIncident(s,type),r=s.population.residents.find(r=>r.incidentId===i.id);return {s,i,r};}
function finish(success=true){const x=setup(),{s,i}=x;if(success){Object.assign(s.units[0],{x:i.x,y:i.y});assign(s,1,i.id);tick(s,.1);decide(s,1,'talk');while(i.state!=='resolved'&&i.state!=='missed')tick(s,.1);}else{i.age=TYPES[i.type].limit;tick(s,.1);}return x;}
test('stationary local calls reference one resident, stay at their road access and freeze their routine',()=>{
 for(const type of [0,3,4]){const {s,i,r}=setup(type),before={x:r.x,y:r.y};assert.equal(i.scene.participants[0].name,residentProfile(r.id).name);assert.equal(i.scene.participants[0].residentId,r.id);advance(s,20);assert.equal(r.status,'incident');assert.equal(r.journeys,0);assert.deepEqual({x:r.x,y:r.y},before);assert.equal(r.route.length,0);assert.doesNotThrow(()=>deserialize(serialize(s)));assert.equal(populationSummary(s).involved,1);}
});
test('busy residents cannot be claimed twice; unsupported calls remain independent actors',()=>{
 const s=createGame();for(let k=0;k<17;k++)spawnIncident(s,0);const linked=s.incidents.flatMap(i=>i.scene.participants).filter(a=>a.residentId);assert.equal(linked.length,16);assert.equal(new Set(linked.map(a=>a.residentId)).size,16);assert.doesNotThrow(()=>deserialize(serialize(s)));
 for(const type of [1,2,5]){const n=createGame();assert.ok(spawnIncident(n,type).scene.participants.every(a=>a.residentId===undefined));}
});
test('different outcomes produce stress and rest, followed by autonomous return home',()=>{
 const good=finish(),bad=finish(false);assert.equal(good.i.state,'resolved');assert.equal(bad.i.state,'missed');for(const x of [good,bad]){assert.equal(x.r.status,'recovering');assert.equal(x.r.incidentId,null);assert.equal(x.r.lastEvent.outcome,x.i.scene.outcome);assert.equal(x.r.lastEvent.success,x.i.state==='resolved');assert.doesNotThrow(()=>deserialize(serialize(x.s)));}
 assert.ok(bad.r.stress>good.r.stress);assert.ok(bad.r.recoveryUntil-bad.s.population.elapsed>good.r.recoveryUntil-good.s.population.elapsed);
 advance(good.s,140);assert.equal(good.r.status,'home');assert.equal(good.r.journeys,1);assert.equal(good.r.resumeStatus,null);assert.equal(good.s.incidents.length,0);assert.ok(good.r.lastEvent);assert.doesNotThrow(()=>deserialize(serialize(good.s)));
});
test('event and recovery saves continue identically; shift transfer preserves links and remaining rest',()=>{
 for(const x of [setup(),finish(false)]){const {s,r}=x;advance(s,2);const copy=deserialize(serialize(s));advance(s,3);advance(copy,3);assert.deepEqual(copy,s);const before=structuredClone(s);s.time=480;s.ended=true;const n=nextShift(s);assert.deepEqual(n.population,s.population);assert.notEqual(n.population,s.population);assert.doesNotThrow(()=>deserialize(serialize(n)));advance(n,1);assert.deepEqual(s.population,before.population);assert.equal(n.population.residents.find(a=>a.id===r.id).lastEvent?.incidentId,r.lastEvent?.incidentId);}
});
test('0.4.0 fields migrate without resetting routes, identity, money, calls or RNG',()=>{
 const s=createGame();s.nextIncident=999;advance(s,10);for(const r of s.population.residents)for(const k of ['incidentId','resumeStatus','recoveryUntil','stress','lastEvent'])delete r[k];const n=deserialize(serialize(s));const bare=structuredClone(n);for(const r of bare.population.residents)for(const k of ['incidentId','resumeStatus','recoveryUntil','stress','lastEvent'])delete r[k];assert.deepEqual(bare,s);assert.ok(n.population.residents.every(r=>r.incidentId===null&&r.stress===0));
});
test('dangling, duplicate, misplaced links and corrupt recovery fields reject damaged saves',()=>{
 const {s}=setup();for(const mutate of [n=>{n.population.residents[0].incidentId=999;},n=>{n.incidents[0].scene.participants[0].residentId=999;},n=>{n.incidents[0].scene.participants[0].x+=.01;},n=>{n.incidents[0].scene.participants[0].name='Other';},n=>{n.population.residents[0].route=[{x:0,y:0}];},n=>{n.population.residents[0].stress=101;},n=>{delete n.population.residents[0].resumeStatus;},n=>{delete n.incidents[0].scene.participants[0].residentId;}]){const n=structuredClone(s);mutate(n);assert.throws(()=>deserialize(serialize(n)));}
 const x=finish(false);x.r.lastEvent.elapsed=x.s.population.elapsed+1;assert.throws(()=>deserialize(serialize(x.s)));
});
test('autonomous patrol resolves a linked resident call without player commands',()=>{
 const {s,i,r}=setup();s.units[0].auto=true;advance(s,170);assert.equal(i.state,'resolved');assert.equal(r.lastEvent.success,true);assert.equal(r.status,'home');assert.equal(r.journeys,1);
});
