import test from 'node:test';import assert from 'node:assert/strict';
import {createGame,hireOfficer,createPatrol,tick,nextShift,shiftCost,serialize,deserialize,spawnIncident,buyUpgrade,setPolicy,districtTrust} from '../dist/sim.js';
import {UPGRADES,UPGRADE_IDS,UPGRADE_EFFECT,upgradesUpkeep,upgradeBonus,has,COMPLAINTS,complaintChance,complaintRolled,complaintCleared} from '../dist/upgrades.js';
import {NODES} from '../dist/geography.js';
// R10 «Развитие отделения» + R12 «Внутренний контроль» (Claude, 11.10.2026).

function hire(s,id){assert.equal(hireOfficer(s,id).ok,true);return s.officers.at(-1).id;}
function ready(opts){const s=createGame('chief',4411,opts);const a=hire(s,1),b=hire(s,2);assert.equal(createPatrol(s,a,b,1).ok,true);s.nextIncident=9000;s.budget+=10000;s.finance.opening+=10000;return s;}

test('every upgrade is described, priced and bought once by the chief only',()=>{
 for(const id of UPGRADE_IDS){const u=UPGRADES[id];assert.ok(u.label&&u.about.length>30&&u.price>0&&u.upkeep>=0);}
 const career=createGame();assert.equal(buyUpgrade(career,'bodycam').ok,false);career.upgrades=['drone'];assert.equal(has(career,'drone'),false,'career ignores a stray upgrade');
 const s=ready(),before=s.budget,cost=shiftCost(s);
 assert.equal(buyUpgrade(s,'nope').ok,false);assert.equal(buyUpgrade(s,'bodycam').ok,true);assert.equal(buyUpgrade(s,'bodycam').ok,false,'only once');
 assert.equal(s.budget,before-UPGRADES.bodycam.price);assert.equal(s.finance.entries.at(-1).category,'upgrade');
 assert.equal(shiftCost(s),cost+UPGRADES.bodycam.upkeep);assert.equal(upgradesUpkeep(s),UPGRADES.bodycam.upkeep);
 const poor=ready();poor.budget=100;poor.finance.opening=100-poor.finance.entries.reduce((n,e)=>n+e.amount,0);assert.match(buyUpgrade(poor,'drone').message,/Недостаточно/);
});

test('upkeep is charged at shift close, upgrades carry over and survive a save',()=>{
 const s=ready();buyUpgrade(s,'tablets');buyUpgrade(s,'training');s.ended=true;const n=nextShift(s);
 assert.deepEqual(n.upgrades,['tablets','training']);
 const r=deserialize(serialize(n));assert.deepEqual(r.upgrades,['tablets','training']);
 const bad=JSON.parse(serialize(n));bad.upgrades=['tablets','tablets'];assert.throws(()=>deserialize(JSON.stringify(bad)));
 bad.upgrades=['laser'];assert.throws(()=>deserialize(JSON.stringify(bad)));
 const up=n.previousReport.finance.entries.find(e=>e.category==='upkeep');assert.equal(up.amount,-(UPGRADES.tablets.upkeep+UPGRADES.training.upkeep));
});

test('training raises officers skill each shift up to the cap; others are untouched',()=>{
 const s=ready();const skills=s.officers.map(o=>o.skill);buyUpgrade(s,'training');s.ended=true;const n=nextShift(s);
 n.officers.forEach((o,k)=>assert.ok(Math.abs(o.skill-Math.min(UPGRADE_EFFECT.skillCap,skills[k]+UPGRADE_EFFECT.skill))<1e-9||skills[k]>=UPGRADE_EFFECT.skillCap));
 const t=ready();const before=t.officers.map(o=>o.skill);t.ended=true;assert.deepEqual(nextShift(t).officers.map(o=>o.skill),before);
 const c=ready();buyUpgrade(c,'training');c.officers[0].skill=.99;c.ended=true;assert.equal(nextShift(c).officers[0].skill,.99,'never lowered by the cap');
});

test('drone speeds up searches and breathalyzers speed up drunk calls',()=>{
 const s=ready();assert.equal(upgradeBonus(s,'missing-elder',2),1);buyUpgrade(s,'drone');buyUpgrade(s,'breath');
 assert.equal(upgradeBonus(s,'missing-elder',2),UPGRADE_EFFECT.search);assert.equal(upgradeBonus(s,'drunk-driver',5),UPGRADE_EFFECT.drunk);assert.equal(upgradeBonus(s,'noise-flat',0),1);
});

function waitTime(withTablets){const s=ready();if(withTablets)buyUpgrade(s,'tablets');s.units[0].auto=false;const n=NODES[40];const i=spawnIncident(s,null,{variant:'noise-flat',point:{x:n.x,y:n.y}});let t=0;while(i.state!=='missed'&&t<5000){tick(s,.5);t+=.5;}return t;}
test('tablets let an unanswered call wait longer before it is lost',()=>{
 const plain=waitTime(false),tab=waitTime(true);assert.ok(plain<5000);assert.ok(tab>plain*1.1,`${tab} vs ${plain}`);
});

test('restroom makes resting crews recover faster',()=>{
 const run=up=>{const s=ready();if(up)buyUpgrade(s,'restroom');const o=s.officers[0];o.fatigue=80;s.units[0].status='resting';s.units[0].auto=false;for(let k=0;k<40;k++){s.units[0].status='resting';tick(s,.25);}return o.fatigue;};
 assert.ok(run(true)<run(false));
});

test('complaint chance: arrests and failures, stress and strict order raise it, body cameras cut it',()=>{
 assert.equal(complaintChance({}),0);const a=complaintChance({arrest:true});assert.equal(a,COMPLAINTS.arrest);
 assert.ok(complaintChance({arrest:true,stress:80})>a);assert.ok(complaintChance({arrest:true,strict:true})>a);
 assert.ok(Math.abs(complaintChance({failed:true,bodycam:true})-COMPLAINTS.failed*UPGRADE_EFFECT.complaints)<1e-12);
 let hits=0,cleared=0,clearedCam=0;for(let id=1;id<=2000;id++){if(complaintRolled(5,id,.1))hits++;if(complaintCleared(5,id,false))cleared++;if(complaintCleared(5,id,true))clearedCam++;}
 assert.ok(hits>150&&hits<250,`${hits}`);assert.ok(cleared>1050&&cleared<1350);assert.ok(clearedCam>cleared);
 assert.equal(complaintRolled(5,17,.3),complaintRolled(5,17,.3),'deterministic');
});

test('roster complaints are reviewed after the shift: founded ones cost trust, cleared ones only get logged',()=>{
 const s=ready({schedule:'ppa'});const d=Object.keys(s.districts??{})[0];
 s.complaints=[];for(let id=1;id<=8;id++)s.complaints.push({incident:id,unit:s.units[0].id,reason:'Жалоба на задержание: «превышение полномочий»',status:'проверка',district:d});
 const founded=s.complaints.filter(c=>!complaintCleared(s.seed,c.incident,false)).length;assert.ok(founded>0&&founded<8);
 s.ended=true;const trust=s.trust;const n=nextShift(s);
 assert.equal(n.complaints.length,8);assert.equal(n.complaints.filter(c=>c.status==='обоснована').length,founded);
 assert.ok(n.trust<=trust-COMPLAINTS.foundedTrust*founded+1e-9||n.trust===0);assert.ok(n.logs.some(l=>/Внутренний контроль/.test(l.text)));
 const again=deserialize(serialize(n));assert.equal(again.complaints.length,8);
 n.ended=true;const m=nextShift(n);assert.equal(m.complaints,undefined,'reviewed complaints are not reviewed twice');
 const bad=JSON.parse(serialize(n));bad.complaints[0].status='ой';assert.throws(()=>deserialize(JSON.stringify(bad)));
});

test('legacy campaigns never collect complaints',()=>{
 const s=createGame('career',4411);for(let k=0;k<6000&&!s.ended;k++)tick(s,.2);assert.equal(s.complaints,undefined);
});

test('a roster chief campaign files complaints from real calls and stays valid',()=>{
 let filed=0;for(const seed of [3,8,21,34,55]){const s=createGame('chief',seed,{schedule:'ppa'});const a=hire(s,1),b=hire(s,2);createPatrol(s,a,b,1);setPolicy(s,'strict');
  for(let k=0;k<20000&&!s.ended;k++)tick(s,.5);filed+=(s.complaints??[]).length;deserialize(serialize(s));}
 assert.ok(filed>0,'complaints appear in a real roster shift');
});
