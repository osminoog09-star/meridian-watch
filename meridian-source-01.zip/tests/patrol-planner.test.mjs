import test from 'node:test';
import assert from 'node:assert/strict';
import {createGame,serialize,deserialize,shiftCost,tick} from '../dist/sim.js';
import {quotePatrol,confirmPatrol,patrolChoices} from '../dist/patrol-planner.js';
const draft=(extra={})=>({first:'candidate:1',second:'',vehicle:'vehicle:1',zone:'all',...extra});
test('quote is pure; solo confirmation charges hire once and starts autonomous patrol',()=>{
 const s=createGame('chief'),raw=serialize(s),q=quotePatrol(s,draft());assert.equal(serialize(s),raw);assert.equal(q.ok,true);assert.equal(q.initialCost,420);assert.equal(q.shiftDelta,55);assert.equal(q.totalShiftCost,115);assert.equal(q.balanceAfter,1980);
 assert.equal(confirmPatrol(s,draft(),q.token).ok,true);assert.equal(s.budget,1980);assert.deepEqual(s.units[0].officerIds,[1]);assert.equal(s.units[0].auto,true);assert.equal(s.setupPending,false);const done=serialize(s);assert.equal(confirmPatrol(s,draft(),q.token).ok,false);assert.equal(serialize(s),done);assert.ok(deserialize(done));
});
test('pair and purchased SUV reconcile fees, maintenance and salaries',()=>{
 const s=createGame('chief'),d=draft({second:'candidate:2',vehicle:'new:suv',zone:'east'}),q=quotePatrol(s,d);assert.equal(q.hireCost,720);assert.equal(q.purchaseCost,1200);assert.equal(q.initialCost,1920);assert.equal(q.shiftDelta,125);assert.equal(q.totalShiftCost,185);assert.equal(q.balanceAfterShift,295);assert.equal(confirmPatrol(s,d,q.token).ok,true);assert.equal(s.vehicles.length,3);assert.equal(s.units[0].vehicleId,3);assert.deepEqual(s.units[0].officerIds,[1,2]);assert.equal(shiftCost(s),q.totalShiftCost);assert.ok(deserialize(serialize(s)));
});
test('invalid or unaffordable plan leaves no partial hire or purchase',()=>{
 for(const d of [draft({second:'candidate:1'}),draft({zone:'tammiste'}),draft({vehicle:'new:boat'}),draft({first:'candidate:999'}),draft({vehicle:'new:suv',second:'candidate:2'})]){
 const s=createGame('chief');s.budget=700;const raw=serialize(s);assert.equal(quotePatrol(s,d).ok,false);assert.equal(confirmPatrol(s,d,'invalid').ok,false);assert.equal(serialize(s),raw);
 }
});
test('stale quote requires review after budget or salary changes',()=>{
 for(const mutate of [s=>s.budget+=10,s=>s.candidates[0].salary+=5]){const s=createGame('chief'),d=draft(),q=quotePatrol(s,d);mutate(s);const raw=serialize(s);assert.equal(confirmPatrol(s,d,q.token).ok,false);assert.equal(serialize(s),raw);const fresh=quotePatrol(s,d);assert.equal(confirmPatrol(s,d,fresh.token).ok,true);}
});
test('existing moving unit retains identity; reserves avoid recruitment fees',()=>{
 const s=createGame('chief'),d=draft(),q=quotePatrol(s,d);confirmPatrol(s,d,q.token);tick(s,1);const unit=s.units[0],officer=s.officers[0],car=s.vehicles[0],old=JSON.stringify(unit);
 const second=draft({first:'candidate:2',vehicle:'vehicle:2',zone:'west'}),sq=quotePatrol(s,second);assert.equal(JSON.stringify(unit),old);confirmPatrol(s,second,sq.token);assert.equal(s.units[0],unit);assert.equal(s.officers[0],officer);assert.equal(s.vehicles[0],car);assert.equal(JSON.stringify(unit),old);assert.ok(!patrolChoices(s).people.some(p=>p.key==='officer:1'));
 assert.equal(quotePatrol(s,draft({first:'officer:1',vehicle:'new:sedan'})).ok,false);assert.ok(deserialize(serialize(s)));
});
test('career and ended shifts refuse plans without mutation',()=>{for(const s of [createGame('career'),Object.assign(createGame('chief'),{ended:true})]){const raw=serialize(s);assert.equal(quotePatrol(s,draft()).ok,false);assert.equal(serialize(s),raw);}});
test('reserve officer and garage vehicle cost nothing up front and add no existing salary',async()=>{
 const {hireOfficer}=await import('../dist/sim.js');const s=createGame('chief');hireOfficer(s,1);const d=draft({first:'officer:1'}),raw=serialize(s),q=quotePatrol(s,d);assert.equal(q.initialCost,0);assert.equal(q.shiftDelta,0);assert.equal(serialize(s),raw);assert.equal(confirmPatrol(s,d,q.token).ok,true);assert.equal(s.budget,1980);assert.equal(s.officers.length,1);
});
