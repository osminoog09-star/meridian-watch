import test from 'node:test';import assert from 'node:assert/strict';
import {createGame,tick,nextShift,serialize,deserialize,offDuty,rankOf} from '../dist/sim.js';
import {PAY,shiftGross,shiftNet,freeBlocks,validPlan,applyPlan,ensureLife,courseValid,mandatoryOk,scheduledRank,RANK_XP,startFatigue,courseBonus,COURSES} from '../dist/life.js';
import {SHIFT_TICKS} from '../dist/schedule.js';
// R3 «Между сменами»: free time between realistic roster shifts in the career.

const career=()=>createGame('career',7182,{schedule:'ppa'});
function finish(s){for(let k=0;k<SHIFT_TICKS*10+10&&!s.ended;k++)tick(s,.1);return s;}

test('pay and free blocks follow the roster (12 h, 24 h, 4 days)',()=>{
 assert.equal(shiftGross(),Math.round(PAY.monthlyGross/PAY.shiftsPerMonth));assert.ok(shiftNet()>90&&shiftNet()<shiftGross());
 assert.deepEqual(freeBlocks(1),{days:1,rest:12,overtime:false,training:false});
 assert.deepEqual(freeBlocks(2),{days:1,rest:24,overtime:false,training:true});
 assert.deepEqual(freeBlocks(4),{days:4,rest:96,overtime:true,training:true});
 const four=freeBlocks(4),short=freeBlocks(1);
 assert.equal(validPlan([{activity:'overtime'}],short),false,'no overtime without 12 h rest on both sides');
 assert.equal(validPlan([{activity:'training',course:'firstaid'}],short),false);
 assert.equal(validPlan([{activity:'overtime'},{activity:'overtime'},{activity:'rest'},{activity:'rest'}],four),false,'one overtime per off period');
 assert.equal(validPlan([{activity:'training'},{activity:'rest'},{activity:'rest'},{activity:'rest'}],four),false,'training needs a course');
 assert.equal(validPlan([{activity:'overtime'},{activity:'training',course:'firstaid'},{activity:'sport'},{activity:'family'}],four),true);
});

test('activities change sleep, stress, fitness, money and courses',()=>{
 const s=career();const life=JSON.parse(JSON.stringify(ensureLife(s)));life.sleepDebt=60;life.stress=50;
 const r=applyPlan(life,[{activity:'overtime'},{activity:'training',course:'firstaid'},{activity:'training',course:'firstaid'},{activity:'sport'}],4);
 assert.equal(life.courses.firstaid,4);assert.ok(r.lines.some(x=>/Первая помощь: пройдено/.test(x)));assert.equal(r.xp,60);assert.ok(life.money>shiftNet());assert.equal(life.overtime,1);
 assert.ok(life.fitness>55);
 const unfit=JSON.parse(JSON.stringify(ensureLife(career())));unfit.fitness=20;const f=applyPlan(unfit,[{activity:'training',course:'fitness'}],5);assert.match(f.lines[0],/не сдан/);assert.equal(unfit.courses.fitness,1,'old pass kept');
 assert.ok(startFatigue({sleepDebt:80,stress:20})>startFatigue({sleepDebt:10,stress:20}));
 assert.equal(courseBonus({courses:{negotiation:3}},'domestic'),COURSES.negotiation.bonus);assert.equal(courseBonus({courses:{}},'domestic'),1);
});

test('promotion needs XP at a realistic pace and valid shooting/fitness checks',()=>{
 const s=career();assert.equal(s.rank,0);assert.ok(mandatoryOk(s.life,1),'academy graduates start with valid checks');
 s.xp=RANK_XP[1];assert.equal(rankOf(s),1);
 s.shift=40;assert.equal(courseValid(s.life,'firearms',40),false);s.rank=1;s.xp=RANK_XP[3];assert.equal(scheduledRank(s),1,'expired checks block promotion');
 s.life.courses={firearms:39,fitness:39};assert.equal(scheduledRank(s),3);
 const legacy=createGame();legacy.xp=300;assert.equal(rankOf(legacy),2,'legacy pace unchanged');
});

test('the planned free time is applied at the next shift, saved and validated',()=>{
 let s=career();assert.ok(offDuty(s));for(let k=0;k<3;k++){finish(s);s=nextShift(s);}
 finish(s);const xp=s.xp,money=s.life.money;assert.equal(offDuty(s).days,4);
 const plan=[{activity:'overtime'},{activity:'training',course:'negotiation'},{activity:'family'},{activity:'rest'}];
 const n=nextShift(s,{plan});assert.equal(n.xp,xp+60);assert.ok(n.life.money>money+shiftNet());assert.equal(n.life.progress.negotiation,1);assert.match(n.life.last.lines.join('\n'),/Доп\. смена/);
 assert.ok(n.logs.some(l=>/Между сменами/.test(l.text)));
 assert.doesNotThrow(()=>deserialize(serialize(n)));
 const bad=JSON.parse(serialize(n));bad.life.stress=140;assert.throws(()=>deserialize(JSON.stringify(bad)));
 const wrong=nextShift(s,{plan:[{activity:'overtime'}]});assert.equal(wrong.life.overtime,s.life.overtime,'invalid plan falls back to rest');
 const tired=JSON.parse(serialize(s));tired.life.sleepDebt=100;const t=nextShift(deserialize(JSON.stringify(tired)),{plan:[{activity:'overtime'},{activity:'overtime'},{activity:'overtime'},{activity:'overtime'}]});
 assert.ok(t.officers.find(o=>o.id===1).fatigue>=8);
 assert.equal(createGame().life,undefined,'legacy campaigns have no off-duty life');assert.equal(createGame('chief',7182,{schedule:'ppa'}).life,undefined);
});

test('a roster call gives a third of the XP of a legacy call',()=>{
 let s=career();finish(s);const perCall=s.resolved?s.xp/s.resolved:0;assert.ok(perCall<=15,`xp per call ${perCall}`);
});
