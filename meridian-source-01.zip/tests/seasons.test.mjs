import test from 'node:test';import assert from 'node:assert/strict';
import {createGame,tick,shiftWeather,shiftDateOf,sunOf} from '../dist/sim.js';
import {shiftDate,seasonOf,SUN,weatherSpeed} from '../dist/season.js';
import {cityLighting} from '../dist/lighting.js';
import {weatherFor,WEATHER} from '../dist/calls.js';
// Seasons, daylight and road weather on the roster calendar.

test('the roster calendar has real dates and seasons',()=>{
 assert.equal(shiftDate(0).label,'12.10');assert.equal(seasonOf(shiftDate(0).month),'autumn');
 let k=0;while(seasonOf(shiftDate(k).month)!=='winter')k++;assert.equal(shiftDate(k).month,11,'December comes first');
 const winter=new Set(Array.from({length:40},(_,n)=>weatherFor(7182,n,'winter').kind));assert.ok(winter.has('snow')&&winter.has('ice'));
 const summer=new Set(Array.from({length:40},(_,n)=>weatherFor(7182,n,'summer').kind));assert.ok(summer.has('heat')&&!summer.has('snow'));
 for(const kind of [...winter,...summer])assert.ok(WEATHER[kind],kind);
 assert.ok(weatherFor(7182,5,'winter').temp<=2);
 assert.deepEqual(weatherFor(7182,3),weatherFor(7182,3,null),'legacy weather unchanged');
 const s=createGame('career',7182,{schedule:'ppa'});assert.equal(shiftDateOf(s).label,'12.10');assert.deepEqual(sunOf(s),SUN[9]);assert.equal(shiftDateOf(createGame()),null);
});

test('daylight follows the month; legacy lighting unchanged',()=>{
 assert.equal(cityLighting(420).darkness,0);assert.equal(cityLighting(1260).darkness,.55);
 const dec=SUN[11],jun=SUN[5];assert.ok(cityLighting(8*60,dec).darkness>0,'dark at 08:00 in December');assert.equal(cityLighting(8*60,jun).darkness,0);
 assert.ok(cityLighting(21*60,jun).darkness===0||cityLighting(21*60,jun).darkness<.2,'light June evening');assert.equal(cityLighting(18*60,dec).darkness,.55);
});

test('snow and black ice slow every car',()=>{
 assert.ok(weatherSpeed('ice')<weatherSpeed('snow')&&weatherSpeed('snow')<1);assert.equal(weatherSpeed('clear'),1);
 const run=wantSnow=>{const s=createGame('career',7182,{schedule:'ppa'});s.nextIncident=9000;let n=1;while(n<400&&(shiftWeather({...s,shift:n}).kind==='snow')!==wantSnow)n++;s.shift=n;
  for(let k=0;k<30;k++)tick(s,.1);const u=s.units[1];let d=0,last={x:u.x,y:u.y};for(let k=0;k<300;k++){tick(s,.1);d+=Math.hypot(u.x-last.x,u.y-last.y);last={x:u.x,y:u.y};}return d;};
 assert.ok(run(true)<run(false),'patrol covers less ground in snow');
});
