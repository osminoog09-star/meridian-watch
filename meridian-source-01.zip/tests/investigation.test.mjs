import test from 'node:test';import assert from 'node:assert/strict';
import {createGame,spawnIncident,tick,serialize,deserialize} from '../dist/sim.js';
import {leadFor,LEAD_RULES,VARIANTS,pickVariant,custodyDecision} from '../dist/calls.js';
import {NODES} from '../dist/geography.js';
// 0.7.0 step 4 «Розыск»: unsolved thefts stay open; evidence raises the chance of a later lead.

test('lead rules: thefts only, evidence helps, deterministic, never random-picked',()=>{
 assert.equal(leadFor({variant:'noise-flat',id:1}),null);
 const plain=leadFor({variant:'shoplift',id:5,decision:null}),withEvidence=leadFor({variant:'shoplift',id:5,decision:'check'});
 assert.equal(plain.evidence,null);assert.match(withEvidence.evidence,/камер/);assert.ok(withEvidence.chance>plain.chance);
 assert.deepEqual(leadFor({variant:'bike-theft',id:9,decision:'talk'}),leadFor({variant:'bike-theft',id:9,decision:'talk'}));
 const found=Array.from({length:400},(_,k)=>leadFor({variant:'car-break',id:k+1,decision:'check'}).found).filter(Boolean).length/400;
 assert.ok(Math.abs(found-(LEAD_RULES.base+LEAD_RULES.evidence))<.1,`hash rate ${found}`);
 for(let r=0;r<1;r+=.01)assert.notEqual(pickVariant(r,600).id,'suspect-found');
 assert.equal(VARIANTS.find(v=>v.id==='suspect-found').w,0);
 assert.equal(custodyDecision({variant:'suspect-found',decision:'check'}),'arrest');
});

function missTheft(id,decision){
 // No crews: the call expires unanswered and is filed as unsolved.
 const s=createGame();s.nextIncident=9000;s.nextId=id;s.units=[];const n=NODES[40];
 const i=spawnIncident(s,null,{variant:'shoplift',point:{x:n.x,y:n.y}});i.decision=decision;
 for(let k=0;k<6000&&i.state!=='missed';k++)tick(s,.1);assert.equal(i.state,'missed');return {s,i};
}

test('a missed theft opens an investigation with evidence and, when found, a suspect call',()=>{
 let id=1;while(!leadFor({variant:'shoplift',id,decision:'check'}).found)id++;
 const {s,i}=missTheft(id,'check');const c=s.cases.find(x=>x.id===i.id);
 assert.equal(c.status,'Розыск: есть зацепка');assert.match(c.evidence,/камер/);
 const f=s.followUps.find(x=>x.from===i.id&&x.variant==='suspect-found');assert.ok(f);
 assert.match(s.logs.map(l=>l.text).join('\n'),/открыт розыск \(улики/);
 const n=deserialize(serialize(s));assert.deepEqual(n.cases,s.cases);assert.deepEqual(n.followUps,s.followUps);
 const bad=JSON.parse(serialize(s));bad.cases[0].evidence=7;assert.throws(()=>deserialize(JSON.stringify(bad)));
 // Lead released: the suspect call appears and is linked back to the case.
 for(let k=0;k<3000&&!s.incidents.some(x=>x.variant==='suspect-found');k++)tick(s,.1);
 const lead=s.incidents.find(x=>x.variant==='suspect-found');assert.ok(lead);assert.equal(lead.followUp.from,i.id);assert.match(s.logs[0].text+s.logs[1].text,/по делу №/);
});

test('without a lead the case stays in «Розыск» and no suspect call is planned',()=>{
 let id=1;while(leadFor({variant:'shoplift',id,decision:null}).found)id++;
 const {s,i}=missTheft(id,null);const c=s.cases.find(x=>x.id===i.id);assert.equal(c.status,'Розыск');assert.equal(c.evidence,null);
 assert.ok(!(s.followUps??[]).some(x=>x.from===i.id&&x.variant==='suspect-found'));
});

test('catching the suspect closes the original case',()=>{
 for(let seed=1;seed<60;seed++){const s=createGame();s.seed=seed;s.nextIncident=9000;
  s.cases=[{id:99,name:'Кража в магазине',district:'centre',time:0,success:false,decision:null,custody:null,medical:false,repeatOf:null,outcome:'Подозреваемый скрылся',status:'Розыск: есть зацепка',evidence:'записи камер и следы на месте'}];
  const n=NODES[(seed*17)%NODES.length];const i=spawnIncident(s,null,{variant:'suspect-found',point:{x:n.x,y:n.y},followUp:{from:99,reason:'по делу №99 замечен подозреваемый.'}});
  for(let k=0;k<8000&&!['resolved','missed'].includes(i.state);k++)tick(s,.1);
  const origin=s.cases.find(c=>c.id===99);
  if(i.state==='resolved'){assert.equal(origin.status,'Раскрыто: подозреваемый задержан');assert.equal(s.cases.find(c=>c.id===i.id).lead,true);return;}
  assert.equal(origin.status,'Розыск: подозреваемый снова скрылся');}
 assert.fail('no seed resolved the suspect call');
});

test('shift debrief counts solved and open investigations',async()=>{
 const {shiftDebrief}=await import('../dist/debrief.js');const s=createGame();
 s.cases=[{status:'Раскрыто: подозреваемый задержан'},{status:'Розыск'},{status:'Розыск: есть зацепка'},{status:'Закрыто на месте'}];
 const d=shiftDebrief(s);assert.ok(d.good.includes('Раскрыто по розыску: 1'));assert.ok(d.attention.includes('Дел в розыске: 2'));
});
