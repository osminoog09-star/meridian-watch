import test from 'node:test';
import assert from 'node:assert/strict';
import {advanceVehicle,motionTrace} from '../dist/transport.js';
import {advanceVisualPath} from '../dist/motion-visual.js';
import {MAP_METRES} from '../dist/world-scale.js';

test('visual interpolation follows crossed route vertices without changing simulation',()=>{
 const metres=m=>m/MAP_METRES,car={x:0,y:0,motionSpeedKmh:35,route:[{x:metres(20),y:0,roadSpeed:{kmh:50,source:'osm'}},{x:metres(20),y:metres(30),roadSpeed:{kmh:50,source:'osm'}}]};
 advanceVehicle(car,.1,50);const trace=motionTrace(car),before=JSON.stringify(car);assert.ok(trace.points.some(p=>Math.abs(p.x-metres(20))<1e-12&&p.y===0));
 let visual={x:0,y:0,path:[],revision:0};for(let k=0;k<90;k++){visual=advanceVisualPath(visual,car,motionTrace(car,visual.revision),1/60,1);if(visual.y>1e-12)assert.ok(Math.abs(visual.x-metres(20))<1e-10);}
 assert.equal(JSON.stringify(car),before);assert.ok(Math.hypot(visual.x-car.x,visual.y-car.y)<1e-8);
});

test('trace history joins several fixed steps for x4 rendering and stays bounded',()=>{
 const car={x:0,y:0,route:[{x:3,y:0,roadSpeed:{kmh:50,source:'osm'}}]};for(let k=0;k<20;k++)advanceVehicle(car,.1,50);
 const trace=motionTrace(car,0);assert.ok(trace.revision>=20);assert.ok(trace.points.length<=12);assert.equal(motionTrace(car,trace.revision),null);
});
test('real-time visual motion is capped by physical metres and pause holds queued positions',()=>{const car={x:1,y:0,route:[{x:2,y:0}],currentSpeedKmh:30};const v={x:0,y:0,path:[],revision:0};advanceVisualPath(v,car,null,.1,1/45);assert.ok(v.x*MAP_METRES<=30/3.6*.1+1e-8);const x=v.x;advanceVisualPath(v,car,null,.1,0);assert.equal(v.x,x);});

test('stalled frames up to half a second do not leave vehicles permanently behind',()=>{const car={x:0,y:0,currentSpeedKmh:50};let v=null,rev=0;for(let k=0;k<1800;k++){const real=k%30===0?.25:1/30;car.x+=50/3.6*real/MAP_METRES;rev++;v=advanceVisualPath(v,car,{revision:rev,points:[{x:car.x,y:0}]},real,1/45);}assert.ok(Math.abs(car.x-v.x)*MAP_METRES<1);});
