import test from 'node:test';import assert from 'node:assert/strict';
import {createGame,tick,nextShift,serialize,deserialize,shiftWeather,spawnIncident} from '../dist/sim.js';
import {LEAVE,canTakeVacation,validPlan,freeBlocks,newYear} from '../dist/life.js';
import {shiftEvent,HOLIDAYS,shiftDate} from '../dist/season.js';
import {protocolFor,PROTOCOLS,VARIANTS,weatherFactor} from '../dist/calls.js';
import {SHIFT_TICKS,shiftKind} from '../dist/schedule.js';
import {NODES} from '../dist/geography.js';
// Career leave and health days, holidays of the calendar, paperwork in case files.

const roster=()=>createGame('career',7182,{schedule:'ppa'});
const finish=s=>{for(let k=0;k<SHIFT_TICKS*10+10&&!s.ended;k++)tick(s,.1);return s;};

test('leave of one roster cycle: only after night shifts, uses 8 days, full rest and holiday pay',()=>{
 let s=roster();assert.equal(s.life.leaveDays,LEAVE.days);assert.equal(s.life.healthDays,LEAVE.health);
 assert.match(canTakeVacation(s.life,freeBlocks(1)),/после ночных/);
 for(let k=0;k<3;k++){finish(s);s=nextShift(s);}finish(s);s.life.stress=70;s.life.sleepDebt=60;const money=s.life.money;
 assert.equal(canTakeVacation(s.life,freeBlocks(s.shift)),null);
 const n=nextShift(s,{vacation:true});assert.equal(n.shift,s.shift+5,'four shifts skipped');assert.equal(n.life.leaveDays,LEAVE.days-LEAVE.cycleDays);
 assert.equal(n.life.sleepDebt>=0&&n.life.sleepDebt<=25,true);assert.ok(n.life.money>money);assert.match(n.life.last.lines.join(),/Отпуск/);
 assert.doesNotThrow(()=>deserialize(serialize(n)));
 const none=JSON.parse(serialize(s));none.life.leaveDays=4;const blocked=nextShift(deserialize(JSON.stringify(none)),{vacation:true});assert.equal(blocked.shift,s.shift+1,'no leave left');
});

test('health days: paid, five a year, renewed by the new year',()=>{
 const life={healthDays:1};assert.equal(validPlan([{activity:'health'},{activity:'rest'},{activity:'rest'},{activity:'rest'}],freeBlocks(4),life),true);
 assert.equal(validPlan([{activity:'health'},{activity:'health'},{activity:'rest'},{activity:'rest'}],freeBlocks(4),life),false);
 const l={leaveYear:2026,leaveDays:3,healthDays:0};assert.equal(newYear(l,2026),false);assert.equal(newYear(l,2027),true);assert.equal(l.leaveDays,LEAVE.days);assert.equal(l.healthDays,LEAVE.health);
});

test('holidays: Midsummer and New Year nights bring more calls of their kind',()=>{
 let mid=null,ny=null;for(let k=0;k<400&&(!mid||!ny);k++){const night=shiftKind(k)==='night',e=shiftEvent(k,night);if(e?.label.startsWith('Яанипяэв')&&!mid)mid=k;if(e?.label==='Новогодняя ночь'&&!ny)ny=k;}
 assert.ok(mid!==null&&ny!==null,'both found in the calendar');assert.equal(shiftDate(mid).month,5);
 const s=roster();s.shift=mid+1;const w=shiftWeather(s);assert.ok(w.event);assert.ok(weatherFactor(w,'drunk-person')>weatherFactor({kind:w.kind},'drunk-person'));
 assert.ok(HOLIDAYS.every(h=>h.intensity>=1&&h.label));
});

test('every closed call files realistic paperwork',()=>{
 for(const v of VARIANTS)assert.ok(PROTOCOLS[v.id],v.id);assert.match(protocolFor('drunk-driver',null),/Алкометр/);assert.match(protocolFor('domestic','arrest'),/соцработнику/);
 const s=roster();s.nextIncident=9000;for(let k=0;k<30;k++)tick(s,.1);const n=NODES[30];const i=spawnIncident(s,null,{variant:'noise-flat',point:{x:n.x,y:n.y}});
 for(let k=0;k<8000&&!['resolved','missed'].includes(i.state);k++)tick(s,.1);const c=s.cases.find(x=>x.id===i.id);if(i.state==='resolved')assert.match(c.protocol,/тишин|проступк/);
 const bad=JSON.parse(serialize(s));if(bad.cases?.[0]){bad.cases[0].protocol=5;assert.throws(()=>deserialize(JSON.stringify(bad)));}
});
