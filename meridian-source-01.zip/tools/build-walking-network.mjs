import {ROAD_NODES} from '../dist/geography.js';
import fs from 'node:fs';import city from '../dist/city-data.js';const raw=JSON.parse(fs.readFileSync(new URL('../data/walking-source.json',import.meta.url)));import {blocked,doorwaySegment} from './walking-geometry.mjs';
const box=p=>[Math.min(...p.map(v=>v[0])),Math.min(...p.map(v=>v[1])),Math.max(...p.map(v=>v[0])),Math.max(...p.map(v=>v[1]))];
const overlaps=(a,b)=>a[0]<=b[2]&&a[2]>=b[0]&&a[1]<=b[3]&&a[3]>=b[1];
const region=[1.19,2.315,1.89,3.015];
const obstacles=[...city.buildings,...city.areas.filter(a=>a.kind==='water')].map(f=>({...f,box:box(f.p)})).filter(f=>overlaps(f.box,region));
const safe=raw.segments.filter(s=>{const bounds=box(s.p);return !obstacles.some(f=>overlaps(f.box,bounds)&&blocked(...s.p,f.p)&&!raw.entrances.some(e=>e.building===f.id&&(e.id===s.a||e.id===s.b)&&doorwaySegment(...s.p,f.p,e.p)));});
const adj=new Map();for(const s of safe){for(const [a,b] of [[s.a,s.b],[s.b,s.a]]){if(!adj.has(a))adj.set(a,new Set());adj.get(a).add(b);}}
const seen=new Set(),components=[];for(const id of adj.keys()){if(seen.has(id))continue;const ids=[id];seen.add(id);for(let i=0;i<ids.length;i++)for(const n of adj.get(ids[i]))if(!seen.has(n)){seen.add(n);ids.push(n);}components.push(ids);}components.sort((a,b)=>b.length-a.length);
const keep=new Set(components[0]??[]),segments=safe.filter(s=>keep.has(s.a)),nodes={};for(const s of segments){nodes[s.a]=s.p[0];nodes[s.b]=s.p[1];}
const carIds=new Set(ROAD_NODES.map(n=>n.id));
function carAccess(start){const dist=new Map([[start,0]]),open=new Set([start]);while(open.size){let id=null;for(const n of open)if(id===null||dist.get(n)<dist.get(id))id=n;open.delete(id);if(carIds.has(id))return id;for(const next of adj.get(id)){const a=nodes[id],b=nodes[next];if(!b)continue;const d=dist.get(id)+Math.hypot(a[0]-b[0],a[1]-b[1]);if(d<(dist.get(next)??Infinity)){dist.set(next,d);open.add(next);}}}return null;}
const entrances=raw.entrances.filter(e=>keep.has(e.id)).map(e=>({...e,carAccess:carAccess(e.id)})).filter(e=>e.carAccess);
const result={entrances,source:raw.source,candidates:raw.segments.length,rejectedGeometry:raw.segments.length-safe.length,components:components.length,nodes,segments};
fs.writeFileSync('dist/walking-network.js','export default '+JSON.stringify(result)+';\n');console.log({nodes:keep.size,segments:segments.length,rejectedGeometry:result.rejectedGeometry,components:result.components});
