"""Shared source-space contract for every OSM extractor.

Keep the current origin and scale stable so existing campaigns remain valid
when adjacent Pärnumaa sectors are appended to the east or south.
"""
BBOX=(24.455,58.355,24.590,58.425)
SCALE=(35,65)

def project(lon,lat):
 return [round((lon-BBOX[0])*SCALE[0],6),round((BBOX[3]-lat)*SCALE[1],6)]

def inside(lon,lat,bbox=BBOX):
 return bbox[0]<=lon<=bbox[2] and bbox[1]<=lat<=bbox[3]

def world_bounds(bbox=BBOX):
 return [0,0,round((bbox[2]-bbox[0])*SCALE[0],6),round((bbox[3]-bbox[1])*SCALE[1],6)]
