// Reproducible route-planner CPU audit. No browser, rasterization or phone FPS.
import fs from 'node:fs';import {performance} from 'node:perf_hooks';
import {ROAD_NODES} from '../dist/geography.js';
import {walkingNodes} from '../dist/walking.js';
import {policeWalkPlan} from '../dist/police-walk.js';
const candidates=ROAD_NODES.filter(n=>walkingNodes.has(n.id)).map(n=>({...n,type:0}));
const start=performance.now(),plans=candidates.map(i=>policeWalkPlan(i)),coldMs=performance.now()-start;
const rounds=100000,warmStart=performance.now();for(let k=0;k<rounds;k++){const j=k%candidates.length;if(policeWalkPlan(candidates[j])!==plans[j])throw Error('Memoization lost');}
const result={version:JSON.parse(fs.readFileSync(new URL('../package.json',import.meta.url))).version,sharedRoadFootNodes:candidates.length,walkingAccesses:plans.filter(Boolean).length,maxPathNodes:Math.max(...plans.filter(Boolean).map(p=>p.ids.length)),walkingMetres:{min:Math.min(...plans.filter(Boolean).map(p=>p.metres)),max:Math.max(...plans.filter(Boolean).map(p=>p.metres))},coldMs,warmRequests:rounds,warmMs:performance.now()-warmStart,limits:'Node CPU only; cold search then reused immutable plans. No phone FPS, Canvas/GPU timings, audio or browser playtest.'};
fs.writeFileSync(new URL('../docs/police-walk-audit-053b.json',import.meta.url),JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify(result));
