export function inRing([x,y],ring){let inside=false;for(let i=0,j=ring.length-1;i<ring.length;j=i++){const [ax,ay]=ring[i],[bx,by]=ring[j];if((ay>y)!==(by>y)&&x<(bx-ax)*(y-ay)/(by-ay)+ax)inside=!inside;}return inside;}
const cross=(a,b,c)=>(b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0]);
function meets(a,b,c,d){const v=[cross(a,b,c),cross(a,b,d),cross(c,d,a),cross(c,d,b)];return v[0]*v[1]<=0&&v[2]*v[3]<=0&&Math.max(Math.min(a[0],b[0]),Math.min(c[0],d[0]))<=Math.min(Math.max(a[0],b[0]),Math.max(c[0],d[0]))&&Math.max(Math.min(a[1],b[1]),Math.min(c[1],d[1]))<=Math.min(Math.max(a[1],b[1]),Math.max(c[1],d[1]));}
export function blocked(a,b,ring){if(inRing(a,ring)||inRing(b,ring))return true;for(let i=0;i<ring.length;i++)if(meets(a,b,ring[i],ring[(i+1)%ring.length]))return true;return false;}

// Only an audited doorway may touch its own footprint at the final endpoint.
export function doorwaySegment(a,b,ring,door){
 const same=p=>Math.hypot(p[0]-door[0],p[1]-door[1])<1e-10;
 if(!same(a)&&!same(b))return false;
 const end=same(a)?a:b,other=same(a)?b:a;
 const onBoundary=ring.some((p,i)=>{const q=ring[(i+1)%ring.length];return Math.abs(cross(p,q,end))<1e-10&&end[0]>=Math.min(p[0],q[0])-1e-10&&end[0]<=Math.max(p[0],q[0])+1e-10&&end[1]>=Math.min(p[1],q[1])-1e-10&&end[1]<=Math.max(p[1],q[1])+1e-10;});
 if(!onBoundary)return false;
 const short=[end[0]+(other[0]-end[0])*1e-5,end[1]+(other[1]-end[1])*1e-5];
 return !blocked(other,short,ring);
}
