"""Build distributable OSM-derived city data. Source XML is downloaded separately.
Usage: python tools/build-city.py /path/to/osm/tiles
Output data licensed ODbL, © OpenStreetMap contributors.
"""
import sys,json,pathlib,xml.etree.ElementTree as E,collections
from city_projection import BBOX,project,inside
root=pathlib.Path(sys.argv[1]);nodes={};ways={};rels={}
for f in root.glob('*.osm'):
 for el in E.parse(f).getroot():
  if el.tag=='node':nodes[el.attrib['id']]=(float(el.attrib['lon']),float(el.attrib['lat']))
  elif el.tag=='way':ways[el.attrib['id']]={'ids':[x.attrib['ref'] for x in el.findall('nd')],'tags':{x.attrib['k']:x.attrib['v'] for x in el.findall('tag')}}
  elif el.tag=='relation':rels[el.attrib['id']]={'members':[x.attrib for x in el.findall('member')],'tags':{x.attrib['k']:x.attrib['v'] for x in el.findall('tag')}}
bbox=BBOX
def pt(p):return project(*p)
def visible_point(p):return inside(*p)
def geom(ids):return [pt(nodes[n]) for n in ids if n in nodes]
def visible(ids):return any(n in nodes and visible_point(nodes[n]) for n in ids)
roads=[];buildings=[];areas=[];coasts=[]
allowed={'motorway','trunk','primary','secondary','tertiary','unclassified','residential','living_street','service','motorway_link','trunk_link','primary_link','secondary_link','tertiary_link'}
for id,w in ways.items():
 t=w['tags'];ids=w['ids']
 if not visible(ids):continue
 g=geom(ids)
 if len(g)<2:continue
 if 'building' in t and len(g)>=4:
  try:h=min(12,max(1,float(t.get('building:levels','2'))))
  except:h=2
  buildings.append({'id':id,'p':g,'h':h,'kind':t['building']})
 if 'highway' in t:
  drive=t['highway'] in allowed and t.get('access') not in ['private','no'] and t.get('motor_vehicle') not in ['no','private']
  roads.append({'id':id,'p':g,'nodes':[n for n in ids if n in nodes],'name':t.get('name',''),'kind':t['highway'],'drive':drive,'bridge':t.get('bridge')=='yes','oneway':t.get('oneway','no'),'speedTags':{k:v for k,v in t.items() if k.startswith('maxspeed')}})
 if t.get('natural')=='coastline':coasts.append(g)
 if ids[0]==ids[-1] and ('landuse' in t or t.get('natural') in ['water','wood','beach','scrub'] or t.get('leisure') in ['park','garden','pitch']):areas.append({'p':g,'kind':t.get('natural',t.get('landuse',t.get('leisure')))})
# Stitch multipolygon outer rings, including river water and large park areas.
for r in rels.values():
 t=r['tags'];kind=t.get('natural',t.get('landuse',t.get('leisure')))
 if kind not in ['water','wood','forest','park','grass','beach']:continue
 segments=[ways[m['ref']]['ids'][:] for m in r['members'] if m['type']=='way' and m.get('role','') in ['outer',''] and m['ref'] in ways]
 while segments:
  ring=segments.pop();changed=True
  while changed and ring[0]!=ring[-1]:
   changed=False
   for k,seg in enumerate(segments):
    if ring[-1]==seg[0]:ring+=seg[1:]
    elif ring[-1]==seg[-1]:ring+=seg[-2::-1]
    elif ring[0]==seg[-1]:ring=seg[:-1]+ring
    elif ring[0]==seg[0]:ring=seg[:0:-1]+ring
    else:continue
    segments.pop(k);changed=True;break
  if ring[0]==ring[-1] and visible(ring) and all(n in nodes for n in ring):areas.append({'p':geom(ring),'kind':kind})
data={'source':'© OpenStreetMap contributors','date':'2026-10-07','bbox':bbox,'roads':roads,'buildings':buildings,'areas':areas,'coasts':coasts}
payload=json.dumps(data,ensure_ascii=False,separators=(',',':'))
# Large static data: avoid a multi-megabyte JavaScript object AST at startup.
pathlib.Path('dist/city-data.js').write_text('export default JSON.parse('+json.dumps(payload,ensure_ascii=False,separators=(',',':'))+');\n')
print({k:len(data[k]) for k in ['roads','buildings','areas','coasts']});print('bytes',pathlib.Path('dist/city-data.js').stat().st_size)
