# Headless Mesa EGL/GLES driver check, not browser or phone QA.
import ctypes as C,re,sys
W,H=(960,480) if "--landscape" in sys.argv else (390,570)
SUFFIX="-landscape" if W>H else ""
from pathlib import Path
E=C.CDLL('libEGL.so.1');E.eglGetProcAddress.argtypes=[C.c_char_p];E.eglGetProcAddress.restype=C.c_void_p
F=lambda n,ret,args:C.CFUNCTYPE(ret,*args)(E.eglGetProcAddress(n.encode()))
get=F('eglGetPlatformDisplayEXT',C.c_void_p,[C.c_uint,C.c_void_p,C.POINTER(C.c_int)])
d=get(0x31dd,None,None)
E.eglInitialize.argtypes=[C.c_void_p,C.POINTER(C.c_int),C.POINTER(C.c_int)];a=C.c_int();b=C.c_int();assert E.eglInitialize(d,C.byref(a),C.byref(b))
E.eglBindAPI(0x30a0)
attrs=(C.c_int*9)(0x3033,1,0x3040,4,0x3024,8,0x3025,16,0x3038);config=C.c_void_p();num=C.c_int()
E.eglChooseConfig.argtypes=[C.c_void_p,C.POINTER(C.c_int),C.POINTER(C.c_void_p),C.c_int,C.POINTER(C.c_int)];assert E.eglChooseConfig(d,attrs,C.byref(config),1,C.byref(num)) and num.value
E.eglCreateContext.argtypes=[C.c_void_p,C.c_void_p,C.c_void_p,C.POINTER(C.c_int)];E.eglCreateContext.restype=C.c_void_p
ctx=E.eglCreateContext(d,config,None,(C.c_int*3)(0x3098,2,0x3038));assert ctx
E.eglCreatePbufferSurface.argtypes=[C.c_void_p,C.c_void_p,C.POINTER(C.c_int)];E.eglCreatePbufferSurface.restype=C.c_void_p
surf=E.eglCreatePbufferSurface(d,config,(C.c_int*5)(0x3057,1,0x3056,1,0x3038));assert surf
E.eglMakeCurrent.argtypes=[C.c_void_p,C.c_void_p,C.c_void_p,C.c_void_p];assert E.eglMakeCurrent(d,surf,surf,ctx)
depth_bits=C.c_int();F('glGetIntegerv',None,[C.c_uint,C.POINTER(C.c_int)])(0x0d56,C.byref(depth_bits));assert depth_bits.value>=16
create=F('glCreateShader',C.c_uint,[C.c_uint]);source=F('glShaderSource',None,[C.c_uint,C.c_int,C.POINTER(C.c_char_p),C.c_void_p]);compile=F('glCompileShader',None,[C.c_uint]);getshader=F('glGetShaderiv',None,[C.c_uint,C.c_uint,C.POINTER(C.c_int)]);logshader=F('glGetShaderInfoLog',None,[C.c_uint,C.c_int,C.c_void_p,C.c_char_p])
s=Path('dist/prototype3d.js').read_text();sh=[]
def shader_text(name):
 text=re.search(r'const '+name+r'=`(.*?)`;',s,re.S).group(1)
 text=text.replace('${lightProjection}',re.search(r'const lightProjection=`(.*?)`;',s,re.S).group(1))
 if name in ['skyVert','skyFrag']:text=text.replace('precision mediump float','precision highp float').replace('mediump vec2 vUV','highp vec2 vUV')
 return text.encode()
for name,typ in [('vert',0x8b31),('frag',0x8b30)]:
 code=shader_text(name);q=create(typ);p=C.c_char_p(code);source(q,1,C.byref(p),None);compile(q);ok=C.c_int();getshader(q,0x8b81,C.byref(ok));buf=C.create_string_buffer(8192);logshader(q,8192,None,buf);print(name,ok.value,buf.value.decode());sh.append(q)
p=F('glCreateProgram',C.c_uint,[])();attach=F('glAttachShader',None,[C.c_uint,C.c_uint]);link=F('glLinkProgram',None,[C.c_uint]);getp=F('glGetProgramiv',None,[C.c_uint,C.c_uint,C.POINTER(C.c_int)]);logp=F('glGetProgramInfoLog',None,[C.c_uint,C.c_int,C.c_void_p,C.c_char_p])
psky=F('glCreateProgram',C.c_uint,[])()
for name,typ in [('skyVert',0x8b31),('skyFrag',0x8b30)]:
 q=create(typ);src=C.c_char_p(shader_text(name));source(q,1,C.byref(src),None);compile(q);ok=C.c_int();getshader(q,0x8b81,C.byref(ok));assert ok.value;attach(psky,q)
link(psky);getp(psky,0x8b82,C.byref(ok));assert ok.value
for q in sh:attach(p,q)
link(p);ok=C.c_int();getp(p,0x8b82,C.byref(ok));buf=C.create_string_buffer(8192);logp(p,8192,None,buf);print('LINK',ok.value,buf.value.decode());assert ok.value

# Execute the actual scene and shaders, then read the framebuffer.
import subprocess,base64
raw=base64.b64decode(subprocess.check_output(['node','--input-type=module','-e',"import {buildScene} from './dist/scene3d.js'; const v=buildScene().vertices;process.stdout.write(Buffer.from(v.buffer,v.byteOffset,v.byteLength).toString('base64')); "]))
# Resize the pbuffer to a phone-sized viewport.
surf=E.eglCreatePbufferSurface(d,config,(C.c_int*5)(0x3057,W,0x3056,H,0x3038));assert E.eglMakeCurrent(d,surf,surf,ctx)
sp=F('glCreateProgram',C.c_uint,[])()
for name,typ in [('shadowVert',0x8b31),('shadowFrag',0x8b30)]:
 q=create(typ);src=C.c_char_p(shader_text(name));source(q,1,C.byref(src),None);compile(q);ok=C.c_int();getshader(q,0x8b81,C.byref(ok));assert ok.value;attach(sp,q)
link(sp);getp(sp,0x8b82,C.byref(ok));assert ok.value
tex=C.c_uint();F('glGenTextures',None,[C.c_int,C.POINTER(C.c_uint)])(1,C.byref(tex));F('glBindTexture',None,[C.c_uint,C.c_uint])(0x0de1,tex)
F('glTexImage2D',None,[C.c_uint,C.c_int,C.c_int,C.c_int,C.c_int,C.c_int,C.c_uint,C.c_uint,C.c_void_p])(0x0de1,0,0x1908,1024,1024,0,0x1908,0x1401,None)
for key,val in [(0x2801,0x2600),(0x2800,0x2600),(0x2802,0x812f),(0x2803,0x812f)]:F('glTexParameteri',None,[C.c_uint,C.c_uint,C.c_int])(0x0de1,key,val)
fbo=C.c_uint();rb=C.c_uint();F('glGenFramebuffers',None,[C.c_int,C.POINTER(C.c_uint)])(1,C.byref(fbo));F('glBindFramebuffer',None,[C.c_uint,C.c_uint])(0x8d40,fbo)
F('glGenRenderbuffers',None,[C.c_int,C.POINTER(C.c_uint)])(1,C.byref(rb));F('glBindRenderbuffer',None,[C.c_uint,C.c_uint])(0x8d41,rb)
F('glRenderbufferStorage',None,[C.c_uint,C.c_uint,C.c_int,C.c_int])(0x8d41,0x81a5,1024,1024)
F('glFramebufferRenderbuffer',None,[C.c_uint]*4)(0x8d40,0x8d00,0x8d41,rb)
F('glFramebufferTexture2D',None,[C.c_uint,C.c_uint,C.c_uint,C.c_uint,C.c_int])(0x8d40,0x8ce0,0x0de1,tex,0)
assert F('glCheckFramebufferStatus',C.c_uint,[C.c_uint])(0x8d40)==0x8cd5
F('glUseProgram',None,[C.c_uint])(p)
bufid=C.c_uint();F('glGenBuffers',None,[C.c_int,C.POINTER(C.c_uint)])(1,C.byref(bufid));F('glBindBuffer',None,[C.c_uint,C.c_uint])(0x8892,bufid)
data=C.create_string_buffer(raw);F('glBufferData',None,[C.c_uint,C.c_ssize_t,C.c_void_p,C.c_uint])(0x8892,len(raw),data,0x88e4)
for name,offset in [('aPosition',0),('aNormal',12),('aColor',24)]:
 loc=F('glGetAttribLocation',C.c_int,[C.c_uint,C.c_char_p])(p,name.encode());assert loc>=0
 F('glEnableVertexAttribArray',None,[C.c_uint])(loc);F('glVertexAttribPointer',None,[C.c_uint,C.c_int,C.c_uint,C.c_ubyte,C.c_int,C.c_void_p])(loc,3,0x1406,0,36,C.c_void_p(offset))
F('glUseProgram',None,[C.c_uint])(sp)
F('glUniform3f',None,[C.c_int,C.c_float,C.c_float,C.c_float])(F('glGetUniformLocation',C.c_int,[C.c_uint,C.c_char_p])(sp,b'uLightDir'),-.35,.82,.44)
loc=F('glGetAttribLocation',C.c_int,[C.c_uint,C.c_char_p])(sp,b'aPosition');F('glEnableVertexAttribArray',None,[C.c_uint])(loc);F('glVertexAttribPointer',None,[C.c_uint,C.c_int,C.c_uint,C.c_ubyte,C.c_int,C.c_void_p])(loc,3,0x1406,0,36,None)
F('glViewport',None,[C.c_int]*4)(0,0,1024,1024);F('glEnable',None,[C.c_uint])(0x0b71);F('glDisable',None,[C.c_uint])(0x0bd0)
F('glClearColor',None,[C.c_float]*4)(1,0,0,1);F('glClear',None,[C.c_uint])(0x4000|0x100);F('glDrawArrays',None,[C.c_uint,C.c_int,C.c_int])(4,0,len(raw)//36)
F('glBindFramebuffer',None,[C.c_uint,C.c_uint])(0x8d40,0);F('glUseProgram',None,[C.c_uint])(p)
getloc=F('glGetUniformLocation',C.c_int,[C.c_uint,C.c_char_p]);F('glUniform3f',None,[C.c_int,C.c_float,C.c_float,C.c_float])(getloc(p,b'uLightDir'),-.35,.82,.44);F('glUniform4f',None,[C.c_int,C.c_float,C.c_float,C.c_float,C.c_float])(getloc(p,b'uCamera'),-.65,.8,680,0)
F('glUniform1f',None,[C.c_int,C.c_float])(getloc(p,b'uAspect'),W/H)
F('glUniform1f',None,[C.c_int,C.c_float])(getloc(p,b'uShadows'),1);F('glUniform1i',None,[C.c_int,C.c_int])(getloc(p,b'uShadowMap'),0)
F('glViewport',None,[C.c_int]*4)(0,0,W,H);F('glEnable',None,[C.c_uint])(0x0b71)
F('glClearColor',None,[C.c_float]*4)(.2,.32,.38,1);F('glClear',None,[C.c_uint])(0x4000|0x100)
F('glDrawArrays',None,[C.c_uint,C.c_int,C.c_int])(4,0,len(raw)//36)
pixels=(C.c_ubyte*(W*H*4))();F('glReadPixels',None,[C.c_int,C.c_int,C.c_int,C.c_int,C.c_uint,C.c_uint,C.c_void_p])(0,0,W,H,0x1908,0x1401,pixels)
error=F('glGetError',C.c_uint,[])();assert error==0,error
pixel_bytes=bytes(pixels);colors=set(pixel_bytes[i:i+3] for i in range(0,len(pixels),4));assert len(colors)>10,len(colors)
print(f'GLES framebuffer: {W}x{H},',len(colors),'distinct RGB colors, GL error 0')
from PIL import Image
Image.frombytes('RGBA',(W,H),bytes(pixels)).transpose(Image.Transpose.FLIP_TOP_BOTTOM).save('docs/visuals/prototype3d-gles-v'+__import__('json').loads(Path('package.json').read_text())['version'].replace('.','')+SUFFIX+'.png')

# Shadow pass must change the rendered pixels; a successful no-op is not enough.
before=bytes(pixels)
F('glUniform1f',None,[C.c_int,C.c_float])(getloc(p,b'uShadows'),0)
F('glClear',None,[C.c_uint])(0x4000|0x100);F('glDrawArrays',None,[C.c_uint,C.c_int,C.c_int])(4,0,len(raw)//36)
F('glReadPixels',None,[C.c_int,C.c_int,C.c_int,C.c_int,C.c_uint,C.c_uint,C.c_void_p])(0,0,W,H,0x1908,0x1401,pixels)
after=bytes(pixels);changed=sum(before[i:i+3]!=after[i:i+3] for i in range(0,len(pixels),4));assert changed>1000,changed
print('Shadows affect',changed,'pixels; fallback render also succeeds')
F('glUniform1f',None,[C.c_int,C.c_float])(getloc(p,b'uShadows'),1)
F('glUniform4f',None,[C.c_int,C.c_float,C.c_float,C.c_float,C.c_float])(getloc(p,b'uCamera'),-.65,.8,240,0)
F('glClear',None,[C.c_uint])(0x4000|0x100);F('glDrawArrays',None,[C.c_uint,C.c_int,C.c_int])(4,0,len(raw)//36)
F('glReadPixels',None,[C.c_int,C.c_int,C.c_int,C.c_int,C.c_uint,C.c_uint,C.c_void_p])(0,0,W,H,0x1908,0x1401,pixels)
Image.frombytes('RGBA',(W,H),bytes(pixels)).transpose(Image.Transpose.FLIP_TOP_BOTTOM).save('docs/visuals/prototype3d-detail-v'+__import__('json').loads(Path('package.json').read_text())['version'].replace('.','')+SUFFIX+'.png')

# Draw every artistic phase, including the actual procedural sky shader.
import json,struct
phases=json.loads(subprocess.check_output(['node','--input-type=module','-e',"import {PHASES} from './dist/prototype-light.js';process.stdout.write(JSON.stringify(PHASES))"]))
focus=json.loads(subprocess.check_output(['node','--input-type=module','-e',"import {buildScene} from './dist/scene3d.js';process.stdout.write(JSON.stringify(buildScene().stats.actorFocus))"]))
quadbuf=C.c_uint();F('glGenBuffers',None,[C.c_int,C.POINTER(C.c_uint)])(1,C.byref(quadbuf));F('glBindBuffer',None,[C.c_uint,C.c_uint])(0x8892,quadbuf)
quad=C.create_string_buffer(struct.pack('12f',-1,-1,1,-1,1,1,-1,-1,1,1,-1,1));F('glBufferData',None,[C.c_uint,C.c_ssize_t,C.c_void_p,C.c_uint])(0x8892,48,quad,0x88e4)
version=json.loads(Path('package.json').read_text())['version'].replace('.','')+SUFFIX
lights=json.loads(subprocess.check_output(['node','--input-type=module','-e',"import {buildScene} from './dist/scene3d.js';const s=buildScene();process.stdout.write(JSON.stringify({lights:s.localLights,directions:s.headDirections}));"]))
occlusion=base64.b64decode(subprocess.check_output(['node','--input-type=module','-e',"import {buildScene} from './dist/scene3d.js';process.stdout.write(Buffer.from(buildScene().lightOcclusion).toString('base64')); "]))
occ=C.c_uint();F('glGenTextures',None,[C.c_int,C.POINTER(C.c_uint)])(1,C.byref(occ));F('glActiveTexture',None,[C.c_uint])(0x84c1);F('glBindTexture',None,[C.c_uint,C.c_uint])(0x0de1,occ)
def upload_occ(data):
 F('glActiveTexture',None,[C.c_uint])(0x84c1);F('glBindTexture',None,[C.c_uint,C.c_uint])(0x0de1,occ);pixels_occ=C.create_string_buffer(data);F('glTexImage2D',None,[C.c_uint,C.c_int,C.c_int,C.c_int,C.c_int,C.c_int,C.c_uint,C.c_uint,C.c_void_p])(0x0de1,0,0x1908,512,7,0,0x1908,0x1401,pixels_occ)
 for key,val in [(0x2801,0x2600),(0x2800,0x2600),(0x2802,0x812f),(0x2803,0x812f)]:F('glTexParameteri',None,[C.c_uint,C.c_uint,C.c_int])(0x0de1,key,val)
 F('glUseProgram',None,[C.c_uint])(p);F('glUniform1i',None,[C.c_int,C.c_int])(getloc(p,b'uLightOcclusion'),1);F('glActiveTexture',None,[C.c_uint])(0x84c0)
upload_occ(occlusion)
def local_lights(enabled=True):
 F('glUseProgram',None,[C.c_uint])(p)
 for i,values in enumerate(lights['lights']):F('glUniform4f',None,[C.c_int,C.c_float,C.c_float,C.c_float,C.c_float])(getloc(p,f'uLocalLights[{i}]'.encode()),*(values if enabled else [0,0,0,0]))
 for i,values in enumerate(lights['directions']):F('glUniform2f',None,[C.c_int,C.c_float,C.c_float])(getloc(p,f'uHeadDirections[{i}]'.encode()),*values)
local_lights()
for phase_name,phase in phases.items():
 # Rebuild the cached depth map for the selected light direction.
 F('glBindFramebuffer',None,[C.c_uint,C.c_uint])(0x8d40,fbo);F('glUseProgram',None,[C.c_uint])(sp);F('glBindBuffer',None,[C.c_uint,C.c_uint])(0x8892,bufid)
 loc=F('glGetAttribLocation',C.c_int,[C.c_uint,C.c_char_p])(sp,b'aPosition');F('glVertexAttribPointer',None,[C.c_uint,C.c_int,C.c_uint,C.c_ubyte,C.c_int,C.c_void_p])(loc,3,0x1406,0,36,None)
 F('glUniform3f',None,[C.c_int,C.c_float,C.c_float,C.c_float])(getloc(sp,b'uLightDir'),*phase['sun']);F('glViewport',None,[C.c_int]*4)(0,0,1024,1024);F('glClearColor',None,[C.c_float]*4)(1,0,0,1);F('glClear',None,[C.c_uint])(0x4000|0x100);F('glDrawArrays',None,[C.c_uint,C.c_int,C.c_int])(4,0,len(raw)//36)
 F('glBindFramebuffer',None,[C.c_uint,C.c_uint])(0x8d40,0);F('glViewport',None,[C.c_int]*4)(0,0,W,H);F('glClear',None,[C.c_uint])(0x4000|0x100)
 F('glDisable',None,[C.c_uint])(0x0b71);F('glUseProgram',None,[C.c_uint])(psky);F('glBindBuffer',None,[C.c_uint,C.c_uint])(0x8892,quadbuf)
 loc=F('glGetAttribLocation',C.c_int,[C.c_uint,C.c_char_p])(psky,b'aSky');F('glEnableVertexAttribArray',None,[C.c_uint])(loc);F('glVertexAttribPointer',None,[C.c_uint,C.c_int,C.c_uint,C.c_ubyte,C.c_int,C.c_void_p])(loc,2,0x1406,0,0,None)
 for name,values in [('uSky',phase['sky']),('uHorizon',phase['horizon'])]:F('glUniform3f',None,[C.c_int,C.c_float,C.c_float,C.c_float])(getloc(psky,name.encode()),*values)
 F('glUniform4f',None,[C.c_int,C.c_float,C.c_float,C.c_float,C.c_float])(getloc(psky,b'uDisc'),*phase['disc'],0)
 F('glUniform1f',None,[C.c_int,C.c_float])(getloc(psky,b'uStars'),phase['star']);F('glUniform1f',None,[C.c_int,C.c_float])(getloc(psky,b'uPixelScale'),1);F('glUniform1f',None,[C.c_int,C.c_float])(getloc(psky,b'uAspect'),W/H);F('glDrawArrays',None,[C.c_uint,C.c_int,C.c_int])(4,0,6)
 F('glEnable',None,[C.c_uint])(0x0b71);F('glUseProgram',None,[C.c_uint])(p);F('glBindBuffer',None,[C.c_uint,C.c_uint])(0x8892,bufid)
 for name,offset in [('aPosition',0),('aNormal',12),('aColor',24)]:
  loc=F('glGetAttribLocation',C.c_int,[C.c_uint,C.c_char_p])(p,name.encode());F('glEnableVertexAttribArray',None,[C.c_uint])(loc);F('glVertexAttribPointer',None,[C.c_uint,C.c_int,C.c_uint,C.c_ubyte,C.c_int,C.c_void_p])(loc,3,0x1406,0,36,C.c_void_p(offset))
 F('glUniform3f',None,[C.c_int,C.c_float,C.c_float,C.c_float])(getloc(p,b'uLightDir'),*phase['sun']);F('glUniform4f',None,[C.c_int,C.c_float,C.c_float,C.c_float,C.c_float])(getloc(p,b'uCamera'),-.65,.8,(500 if W>H else 680),phase['night'])
 F('glUniform2f',None,[C.c_int,C.c_float,C.c_float])(getloc(p,b'uFocus'),0,0);F('glDrawArrays',None,[C.c_uint,C.c_int,C.c_int])(4,0,len(raw)//36)
 F('glReadPixels',None,[C.c_int,C.c_int,C.c_int,C.c_int,C.c_uint,C.c_uint,C.c_void_p])(0,0,W,H,0x1908,0x1401,pixels);assert F('glGetError',C.c_uint,[])()==0
 Image.frombytes('RGBA',(W,H),bytes(pixels)).transpose(Image.Transpose.FLIP_TOP_BOTTOM).save(f'docs/visuals/prototype3d-{phase_name}-v{version}.png')
 if phase_name=='day':
  F('glUniform2f',None,[C.c_int,C.c_float,C.c_float])(getloc(p,b'uFocus'),*focus);F('glUniform4f',None,[C.c_int,C.c_float,C.c_float,C.c_float,C.c_float])(getloc(p,b'uCamera'),-.65,1.1,45,0);F('glClear',None,[C.c_uint])(0x4000|0x100);F('glDrawArrays',None,[C.c_uint,C.c_int,C.c_int])(4,0,len(raw)//36);F('glReadPixels',None,[C.c_int,C.c_int,C.c_int,C.c_int,C.c_uint,C.c_uint,C.c_void_p])(0,0,W,H,0x1908,0x1401,pixels);Image.frombytes('RGBA',(W,H),bytes(pixels)).transpose(Image.Transpose.FLIP_TOP_BOTTOM).save(f'docs/visuals/prototype3d-crew-v{version}.png')
# Compare actual night pixels with local lights enabled/disabled, same camera.
F('glUniform2f',None,[C.c_int,C.c_float,C.c_float])(getloc(p,b'uFocus'),*focus);F('glUniform4f',None,[C.c_int,C.c_float,C.c_float,C.c_float,C.c_float])(getloc(p,b'uCamera'),-.65,1.1,65,1)
F('glClearColor',None,[C.c_float]*4)(.015,.035,.075,1)
local_pixels=[]
for enabled in [True,False]:
 local_lights(enabled);F('glClear',None,[C.c_uint])(0x4000|0x100);F('glDrawArrays',None,[C.c_uint,C.c_int,C.c_int])(4,0,len(raw)//36);F('glReadPixels',None,[C.c_int,C.c_int,C.c_int,C.c_int,C.c_uint,C.c_uint,C.c_void_p])(0,0,W,H,0x1908,0x1401,pixels);local_pixels.append(bytes(pixels))
 if enabled:Image.frombytes('RGBA',(W,H),bytes(pixels)).transpose(Image.Transpose.FLIP_TOP_BOTTOM).save(f'docs/visuals/prototype3d-local-night-v{version}.png')
changed=sum(local_pixels[0][k:k+3]!=local_pixels[1][k:k+3] for k in range(0,len(local_pixels[0]),4));assert changed>50,changed
local_lights(True)
wall_pixels=[]
for enabled in [True,False]:
 upload_occ(occlusion if enabled else bytes([255])*len(occlusion));F('glClear',None,[C.c_uint])(0x4000|0x100);F('glDrawArrays',None,[C.c_uint,C.c_int,C.c_int])(4,0,len(raw)//36);F('glReadPixels',None,[C.c_int,C.c_int,C.c_int,C.c_int,C.c_uint,C.c_uint,C.c_void_p])(0,0,W,H,0x1908,0x1401,pixels);wall_pixels.append(bytes(pixels))
 Image.frombytes('RGBA',(W,H),bytes(pixels)).transpose(Image.Transpose.FLIP_TOP_BOTTOM).save(f'docs/visuals/prototype3d-wall-mask-{enabled}-v{version}.png')
wall_changed=sum(wall_pixels[0][k:k+3]!=wall_pixels[1][k:k+3] for k in range(0,len(wall_pixels[0]),4));assert wall_changed>0,wall_changed
print(f'Building masks change {wall_changed} night pixels compared with unobstructed lighting')
upload_occ(occlusion)
local_lights(True);F('glUniform4f',None,[C.c_int,C.c_float,C.c_float,C.c_float,C.c_float])(getloc(p,b'uCamera'),-.65,1.1,18,1);F('glClear',None,[C.c_uint])(0x4000|0x100);F('glDrawArrays',None,[C.c_uint,C.c_int,C.c_int])(4,0,len(raw)//36);F('glReadPixels',None,[C.c_int,C.c_int,C.c_int,C.c_int,C.c_uint,C.c_uint,C.c_void_p])(0,0,W,H,0x1908,0x1401,pixels);Image.frombytes('RGBA',(W,H),bytes(pixels)).transpose(Image.Transpose.FLIP_TOP_BOTTOM).save(f'docs/visuals/prototype3d-paired-headlights-v{version}.png');F('glUniform4f',None,[C.c_int,C.c_float,C.c_float,C.c_float,C.c_float])(getloc(p,b'uCamera'),-.65,1.1,65,1)
local_lights(True);lamp=lights['lights'][0];F('glUniform2f',None,[C.c_int,C.c_float,C.c_float])(getloc(p,b'uFocus'),lamp[0],lamp[2]);F('glClear',None,[C.c_uint])(0x4000|0x100);F('glDrawArrays',None,[C.c_uint,C.c_int,C.c_int])(4,0,len(raw)//36);F('glReadPixels',None,[C.c_int,C.c_int,C.c_int,C.c_int,C.c_uint,C.c_uint,C.c_void_p])(0,0,W,H,0x1908,0x1401,pixels);Image.frombytes('RGBA',(W,H),bytes(pixels)).transpose(Image.Transpose.FLIP_TOP_BOTTOM).save(f'docs/visuals/prototype3d-lamp-night-v{version}.png');local_lights(False)
print(f'Local night lights affect {changed} pixels; disabled fallback works')
print('Four sky/light phases and crew focus rendered successfully, GL error 0')
# Standalone pages use these exact original figure meshes and joint-space poses.
for kind in ['officer','sedan','civilian']:
 info=json.loads(subprocess.check_output(['node','--input-type=module','-e',"import {buildModelScene} from './dist/model-scene.js';const s=buildModelScene(process.argv[1]);process.stdout.write(JSON.stringify({raw:Buffer.from(s.vertices.buffer).toString('base64'),view:s.view}));",kind]))
 figure=base64.b64decode(info['raw']);arr=C.create_string_buffer(figure);F('glBindBuffer',None,[C.c_uint,C.c_uint])(0x8892,bufid);F('glBufferData',None,[C.c_uint,C.c_ssize_t,C.c_void_p,C.c_uint])(0x8892,len(figure),arr,0x88e4)
 F('glBindFramebuffer',None,[C.c_uint,C.c_uint])(0x8d40,fbo);F('glUseProgram',None,[C.c_uint])(sp)
 loc=F('glGetAttribLocation',C.c_int,[C.c_uint,C.c_char_p])(sp,b'aPosition');F('glVertexAttribPointer',None,[C.c_uint,C.c_int,C.c_uint,C.c_ubyte,C.c_int,C.c_void_p])(loc,3,0x1406,0,36,None);F('glUniform3f',None,[C.c_int,C.c_float,C.c_float,C.c_float])(getloc(sp,b'uLightDir'),-.35,.82,.44)
 F('glViewport',None,[C.c_int]*4)(0,0,1024,1024);F('glClearColor',None,[C.c_float]*4)(1,0,0,1);F('glClear',None,[C.c_uint])(0x4000|0x100);F('glDrawArrays',None,[C.c_uint,C.c_int,C.c_int])(4,0,len(figure)//36)
 F('glBindFramebuffer',None,[C.c_uint,C.c_uint])(0x8d40,0);F('glUseProgram',None,[C.c_uint])(p)
 for name,offset in [('aPosition',0),('aNormal',12),('aColor',24)]:
  loc=F('glGetAttribLocation',C.c_int,[C.c_uint,C.c_char_p])(p,name.encode());F('glEnableVertexAttribArray',None,[C.c_uint])(loc);F('glVertexAttribPointer',None,[C.c_uint,C.c_int,C.c_uint,C.c_ubyte,C.c_int,C.c_void_p])(loc,3,0x1406,0,36,C.c_void_p(offset))
 F('glUniform3f',None,[C.c_int,C.c_float,C.c_float,C.c_float])(getloc(p,b'uLightDir'),-.35,.82,.44);F('glUniform2f',None,[C.c_int,C.c_float,C.c_float])(getloc(p,b'uFocus'),0,0);F('glUniform4f',None,[C.c_int,C.c_float,C.c_float,C.c_float,C.c_float])(getloc(p,b'uCamera'),info['view']['yaw'],info['view']['pitch'],info['view']['span'],0)
 F('glViewport',None,[C.c_int]*4)(0,0,W,H);F('glClearColor',None,[C.c_float]*4)(.18,.28,.36,1);F('glClear',None,[C.c_uint])(0x4000|0x100);F('glDrawArrays',None,[C.c_uint,C.c_int,C.c_int])(4,0,len(figure)//36)
 F('glReadPixels',None,[C.c_int,C.c_int,C.c_int,C.c_int,C.c_uint,C.c_uint,C.c_void_p])(0,0,W,H,0x1908,0x1401,pixels);assert F('glGetError',C.c_uint,[])()==0
 pixel_bytes=bytes(pixels);assert len(set(pixel_bytes[i:i+3] for i in range(0,len(pixels),4)))>10
 Image.frombytes('RGBA',(W,H),bytes(pixels)).transpose(Image.Transpose.FLIP_TOP_BOTTOM).save(f'docs/visuals/model-{kind}-v{version}.png')
print('Standalone police, car and person figures rendered, GL error 0')
