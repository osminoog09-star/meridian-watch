// CPU-only audit: exact road lookup, save validation and deterministic campaign continuation.
import fs from 'node:fs';import assert from 'node:assert/strict';import {performance} from 'node:perf_hooks';
import {ROAD_NODES,nearestRoad} from '../dist/geography.js';import {createNearestPoint} from '../dist/nearest-point.js';
import {createGame,tick,serialize,deserialize,nextShift} from '../dist/sim.js';import {saveGame} from '../dist/storage.js';
const median=a=>a.slice().sort((a,b)=>a-b)[Math.floor(a.length/2)];let seed=17;const rand=()=>((seed=Math.imul(seed,1664525)+1013904223>>>0)/2**32);
const points=Array.from({length:2000},()=>({x:rand()*4.725,y:rand()*4.55}));
const full=p=>ROAD_NODES.reduce((a,b)=>Math.hypot(p.x-b.x,p.y-b.y)<Math.hypot(p.x-a.x,p.y-a.y)?b:a);
for(const p of points)assert.equal(nearestRoad(p),full(p));
const lookup={nodes:ROAD_NODES.length,queries:points.length,exactMatches:points.length,baselineMs:[],indexedMs:[],buildMs:[]};
for(let r=0;r<5;r++){for(const [name,fn] of r%2?[['indexedMs',nearestRoad],['baselineMs',full]]:[['baselineMs',full],['indexedMs',nearestRoad]]){const start=performance.now();for(const p of points)fn(p);lookup[name].push(performance.now()-start);}const start=performance.now();createNearestPoint(ROAD_NODES);lookup.buildMs.push(performance.now()-start);}
for(const name of ['baselineMs','indexedMs','buildMs'])lookup[name+'Median']=median(lookup[name]);
const s=createGame();let steps=0;const started=performance.now();while(!s.ended&&steps<216100){tick(s,.1/45);steps++;}assert.ok(s.ended);
const loaded=deserialize(serialize(s)),continued=nextShift(loaded),memory=new Map(),storage={getItem:k=>memory.get(k)??null,setItem:(k,v)=>memory.set(k,v)},saveMs=[];
for(let k=0;k<30;k++){tick(continued,.1/45);const t=performance.now();assert.ok(saveGame(storage,continued).ok);saveMs.push(performance.now()-t);}
const raw=serialize(continued),copy=deserialize(raw);for(let k=0;k<1000;k++){tick(continued,.1/45);tick(copy,.1/45);}assert.equal(serialize(continued),serialize(copy));
const result={version:JSON.parse(fs.readFileSync('package.json')).version,lookup,shift:{steps,worldHours:s.time*45/3600,cpuMs:performance.now()-started,resolved:s.resolved,missed:s.missed,saveBytes:Buffer.byteLength(raw),continuationEqual:true,saveMsMedian:median(saveMs),saveMsMax:Math.max(...saveMs)},limits:'Node CPU only, no DOM/layout/raster/GPU/phone FPS. Save timing uses in-memory storage, excludes real localStorage I/O. Five alternating lookup runs; exact original road references preserved.'};
fs.writeFileSync(process.argv[2]??'docs/system-audit-053e9.json',JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify(result));
