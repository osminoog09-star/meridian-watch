// Long simulation soak at the new real-time quantum, without wall-clock waiting.
import fs from 'node:fs';import {performance} from 'node:perf_hooks';import {createGame,tick,serialize,deserialize,nextShift} from '../dist/sim.js';
const s=createGame(),start=performance.now();let steps=0;
while(!s.ended&&steps<216100){tick(s,.1/45);steps++;}
if(!s.ended)throw Error('Shift did not finish');const loaded=deserialize(serialize(s)),next=nextShift(loaded);for(let k=0;k<1000;k++){tick(next,.1/45);}
const raw=serialize(next),copy=deserialize(raw);for(let k=0;k<1000;k++){tick(next,.1/45);tick(copy,.1/45);}if(serialize(next)!==serialize(copy))throw Error('Continuation diverged');
const result={version:JSON.parse(fs.readFileSync('package.json')).version,steps,representedWorldHours:s.time*45/3600,cpuMs:performance.now()-start,resolved:s.resolved,missed:s.missed,saveBytes:Buffer.byteLength(raw),nextShift:next.shift,saveContinuationEqual:true,limits:'Accelerated CPU simulation of six world hours; not six hours of browser/phone play or a memory profile.'};fs.writeFileSync('docs/real-time-soak-053d.json',JSON.stringify(result,null,2)+'\n');console.log(result);
