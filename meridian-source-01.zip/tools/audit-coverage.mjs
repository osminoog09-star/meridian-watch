// Expansion-readiness audit for the current immutable Pärnu road snapshot.
// It identifies real directed boundary gateways; it does not invent county data.
import fs from 'node:fs';
import {ROAD_NODES,byId,roadRoute} from '../dist/geography.js';
import {WORLD_BOUNDS,coverageInfo,unprojectWorld} from '../dist/city-coverage.js';
import {MAP_METRES} from '../dist/world-scale.js';

const graph=new Map(ROAD_NODES.map(n=>[n.id,n])),centre=byId('centre'),margin=.08;
const definitions={
 east:n=>WORLD_BOUNDS.maxX-n.x<=margin,
 south:n=>WORLD_BOUNDS.maxY-n.y<=margin,
 west:n=>n.x-WORLD_BOUNDS.minX<=margin,
 north:n=>n.y-WORLD_BOUNDS.minY<=margin
};
const routeLength=(from,route)=>{let total=0,at=from;for(const p of route){total+=Math.hypot(p.x-at.x,p.y-at.y)*MAP_METRES;at=p;}return Math.round(total);};
const edges={};
for(const [edge,predicate] of Object.entries(definitions)){
 const nodes=ROAD_NODES.filter(predicate),named=[...new Set(nodes.map(n=>n.name).filter(n=>n&&n!=='Местная улица'))].sort();
 const groups=new Map();for(const node of nodes){const key=node.name||'Местная улица',list=groups.get(key)??[];list.push(node);groups.set(key,list);}
 const gateways=[];
 for(const [name,list] of groups){
  const rank=n=>edge==='east'?n.x:edge==='south'?n.y:edge==='west'?-n.x:-n.y;
  const node=list.slice().sort((a,b)=>rank(b)-rank(a)||String(a.id).localeCompare(String(b.id)))[0];
  const outward=node.edges.length>0,inward=ROAD_NODES.some(n=>n.edges.some(e=>e.id===node.id));
  if(!outward||!inward)continue;
  const outbound=roadRoute({...centre,route:[]},node),inbound=roadRoute({...node,route:[]},centre),geo=unprojectWorld(node.x,node.y);
  gateways.push({name,nodeId:node.id,world:{x:node.x,y:node.y},geo:{lon:+geo.lon.toFixed(6),lat:+geo.lat.toFixed(6)},outboundNodes:outbound.length,inboundNodes:inbound.length,outboundMetres:routeLength(centre,outbound),inboundMetres:routeLength(node,inbound)});
 }
 edges[edge]={candidateNodes:nodes.length,namedRoads:named,gateways:gateways.sort((a,b)=>a.name.localeCompare(b.name))};
}
const summary=Object.fromEntries(Object.entries(edges).map(([edge,value])=>[edge,{candidateNodes:value.candidateNodes,namedRoads:value.namedRoads.length,reachableGateways:value.gateways.length}]));
const result={version:JSON.parse(fs.readFileSync('package.json')).version,coverage:coverageInfo(),roadNodes:ROAD_NODES.length,summary,edges,preferredNextEdge:'east',preferredReason:'The current east edge has multiple bidirectionally reachable named gateways toward the Paikuse/Tammiste side. Exact adjacent content still requires a verified OSM snapshot.',limits:'Current bundled data only. Gateway means directed connection to the Pärnu core inside this snapshot, not proof that the next sector has been loaded, surveyed or accepted.'};
fs.writeFileSync(process.argv[2]??'docs/coverage-audit-053r1.json',JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify({roadNodes:result.roadNodes,edges:Object.fromEntries(Object.entries(edges).map(([k,v])=>[k,{candidateNodes:v.candidateNodes,gateways:v.gateways.length,namedRoads:v.namedRoads}]))},null,2));
