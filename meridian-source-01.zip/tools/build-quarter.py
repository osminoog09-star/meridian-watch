"""Bounded OSM street-detail snapshot; no invented object locations.
Usage: python tools/build-quarter.py /path/to/existing/osm/tiles
"""
import pathlib,sys,json,xml.etree.ElementTree as E
from city_projection import project
bounds=[1.4,2.42,1.70,2.62];nodes={};buildings=[];roads=[]
for f in sorted(pathlib.Path(sys.argv[1]).glob('*.osm')):
 for e in E.parse(f).getroot():
  t={v.attrib['k']:v.attrib['v'] for v in e.findall('tag')}
  if e.tag=='node':
   p=project(float(e.attrib['lon']),float(e.attrib['lat']))
   if bounds[0]<=p[0]<=bounds[2] and bounds[1]<=p[1]<=bounds[3]:
    kind='tree' if t.get('natural')=='tree' else 'lamp' if t.get('highway')=='street_lamp' else t.get('amenity') if t.get('amenity') in ['bench','fountain'] else None
    if kind:nodes[e.attrib['id']]={'id':e.attrib['id'],'p':p,'kind':kind}
  elif e.tag=='way' and t.get('highway'):
   roads.append({'id':e.attrib['id'],**{k:t[k] for k in ['surface','width','lanes','sidewalk','lit'] if k in t}})
  elif e.tag=='way' and t.get('building'):
   buildings.append({'id':e.attrib['id'],'address':' '.join(filter(None,[t.get('addr:street'),t.get('addr:housenumber')])),'name':t.get('name',''),'height':t.get('height'),'levels':t.get('building:levels')})
result={'bounds':bounds,'source':'Existing OpenStreetMap tiles retrieved 2026-10-07; snapshot, not field survey','nodes':list(nodes.values()),'roads':list({r['id']:r for r in roads}.values()),'buildings':list({b['id']:b for b in buildings if b['address'] or b['name']}.values())}
pathlib.Path('data/quarter-source.json').write_text(json.dumps(result,ensure_ascii=False,separators=(',',':')))
print(len(nodes),'tagged objects extracted')
