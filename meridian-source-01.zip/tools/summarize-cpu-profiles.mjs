// Sampling diagnostics for profile-focus.mjs. Never browser/GPU/phone FPS.
import fs from 'node:fs';import path from 'node:path';
const directory=process.argv[2],output=process.argv[3];if(!directory||!output)throw Error('Profile directory and output required');
const phases=new Map([['cachedBuildingLayout','layout'],['shadeMaterial','materials'],['drawBuildingSlices','facades'],['drawBuildingShadow','shadows'],['shadowHull','shadows'],['buildingOccluder','masks'],['createOccluderIndexSlices','maskIndex'],['visible','visibility'],['querySlices','selection'],['prep','preparation'],['build','preparation'],['createFeatureIndexSlices','preparation'],['createWallIndexSlices','preparation'],['sortSlices','sorting'],['base','otherBackground'],['draw','dynamicFrame']]);
const profiles=[];for(const file of fs.readdirSync(directory).filter(v=>v.endsWith('.cpuprofile')).sort()){
 const data=JSON.parse(fs.readFileSync(path.join(directory,file))),nodes=new Map(data.nodes.map(n=>[n.id,n])),parents=new Map();for(const n of data.nodes)for(const child of n.children??[])parents.set(child,n.id);
 const buckets={},self=new Map();for(let k=0;k<(data.samples?.length??0);k++){
  const id=data.samples[k],node=nodes.get(id),frame=node.callFrame,ms=(data.timeDeltas?.[k]??0)/1000;let stage=frame.functionName==='(garbage collector)'?'unattributedGC':null,at=id;
  while(stage===null&&at!==undefined){stage=phases.get(nodes.get(at).callFrame.functionName)??null;at=parents.get(at);}stage??='importOrOther';buckets[stage]=(buckets[stage]??0)+ms;
  const key=JSON.stringify([frame.functionName,path.basename(frame.url??''),frame.lineNumber+1]);self.set(key,(self.get(key)??0)+ms);
 }
 profiles.push({file,implementation:Number(file.split('-')[0])%2?'baseline':'current',focus:file.split('-').slice(1).join('-').replace('.cpuprofile',''),samples:data.samples.length,sampledMs:Object.values(buckets).reduce((a,b)=>a+b,0),phaseSampleMs:buckets,topSelf:[...self].sort((a,b)=>b[1]-a[1]).slice(0,20).map(([key,ms])=>({frame:JSON.parse(key),ms}))});
}
fs.writeFileSync(output,JSON.stringify({profiles,limits:'V8 statistical CPU samples from fresh Node processes with no-op Canvas. Categories use nearest recognised ancestor/function, not instrumented exact phase durations. Import/other and GC are retained separately; GC cannot be attributed reliably. Not rasterization, GPU, browser, loading latency or mobile FPS.'},null,2)+'\n');console.log('Summarized '+profiles.length+' profiles');
