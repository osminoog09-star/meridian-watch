// Node CPU/Canvas call adapters; never a browser/GPU/phone measurement.
import fs from 'node:fs';import {execFileSync} from 'node:child_process';import {performance} from 'node:perf_hooks';
import {createRenderer} from '../dist/render.js';import {createGame,tick} from '../dist/sim.js';import {clippedBeam} from '../dist/city-light-walls.js';
const baseline=process.argv[2];if(!/^[a-f0-9]{40}$/.test(baseline??''))throw Error('Full baseline commit required');
const get=path=>execFileSync('git',['show',baseline+':dist/'+path],{encoding:'utf8'}).replace(/from '(\.\/[^']+)'/g,(_,p)=>'from '+JSON.stringify(new URL('../dist/'+p.slice(2),import.meta.url).href));
const oldWalls=await import('data:text/javascript;base64,'+Buffer.from(get('city-light-walls.js')).toString('base64'));
const oldRender=await import('data:text/javascript;base64,'+Buffer.from(get('render.js')).toString('base64'));
let mainCalls=0,allCalls=0;
const canvas=(main=false)=>{const ctx=new Proxy({}, {get:(o,k)=>o[k]??(()=>{allCalls++;if(main)mainCalls++;}),set:(o,k,v)=>(o[k]=v,true)});return {width:390,height:570,getBoundingClientRect:()=>({width:390,height:570}),getContext:()=>ctx,addEventListener(){}};};
globalThis.document={createElement:()=>canvas()};globalThis.devicePixelRatio=2;globalThis.ResizeObserver=class{observe(){}};
const run=factory=>{const r=factory(canvas(true),()=>{}),s=createGame();s.population.elapsed=320;r.locate(s.units[0]);for(let k=0;k<3;k++)r.zoom(1);for(let k=0;k<30;k++)r.draw(s,1,null,null,1/30,1/45);mainCalls=0;allCalls=0;const t=performance.now();for(let k=0;k<180;k++)r.draw(s,1,null,null,1/30,1/45);return {ms:performance.now()-t,mainCanvasCalls:mainCalls,allCanvasCalls:allCalls,stats:r.stats?.()??null};};
const before=[],after=[];for(let k=0;k<3;k++){before.push(run(oldRender.createRenderer));after.push(run(createRenderer));}
const rings=[];for(let x=-10;x<=10;x++)for(let y=-10;y<=10;y++){if(x===0&&y===0)continue;const a=x*14,b=y*14;rings.push([[a,b],[a+8,b],[a+8,b+8],[a,b+8]]);}
let comparisons=0;for(let k=0;k<60;k++){const args=[[.13,.27],k*.17,70,.12,rings];const a=oldWalls.clippedBeam(...args),b=clippedBeam(...args);if(JSON.stringify(a)!==JSON.stringify(b))throw Error('Beam boundary changed at '+k);comparisons++;}
const timeBeam=fn=>{const t=performance.now();for(let k=0;k<120;k++)fn([.13,.27],k*.17,70,.12,rings);return performance.now()-t;};
const oldBeam=[],newBeam=[];for(let k=0;k<3;k++){oldBeam.push(timeBeam(oldWalls.clippedBeam));newBeam.push(timeBeam(clippedBeam));}
const sim=createGame(),t=performance.now();for(let k=0;k<600;k++)tick(sim,.1/45);const simulationMinuteMs=performance.now()-t;
const result={version:JSON.parse(fs.readFileSync('package.json')).version,baseline,frames:180,dpr:2,baselineRendering:before,optimizedRendering:after,beamBoundaryComparisons:comparisons,beamBaselineMs:oldBeam,beamOptimizedMs:newBeam,simulationRealMinuteMs:simulationMinuteMs,limits:'Node CPU and no-op Canvas method calls. Warm stationary close night scene; includes JS geometry, not rasterization/GPU/browser/phone FPS. Old render uses current dependencies; isolated beam comparison uses original wall clipping. Heading sprites quantized to one degree and actor lighting to two world minutes; no pixel equivalence claim.'};fs.writeFileSync('docs/performance-audit-053d.json',JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify(result,null,2));
