// CPU z-buffer render of mesh. NOT a WebGL screenshot or browser playtest.
import fs from 'node:fs';import {createRequire} from 'node:module';
import {buildScene,cameraProjection} from '../dist/scene3d.js';
const require=createRequire('/opt/codex/runtimes/codex-primary-runtime/dependencies/node/package.json'),sharp=require('sharp'),scene=buildScene(),v=scene.vertices,version=JSON.parse(fs.readFileSync('package.json')).version.replaceAll('.','');
for(const [name,w,h,span] of [['mobile',390,570,750],['desktop',1100,650,640]]){const rgba=new Uint8Array(w*h*4),depth=new Float32Array(w*h).fill(Infinity);for(let k=0;k<rgba.length;k+=4)rgba.set([51,82,97,255],k);
 for(let k=0;k<v.length;k+=27){const points=cameraProjection([0,9,18].map(i=>[v[k+i],v[k+i+1],v[k+i+2]]),{span,aspect:w/h}).map(p=>[(p[0]+1)*w/2,(1-p[1])*h/2,p[2]]),[a,b,c]=points,area=(b[1]-c[1])*(a[0]-c[0])+(c[0]-b[0])*(a[1]-c[1]);if(Math.abs(area)<1e-8)continue;
 const light=.48+.52*Math.max(0,(-.35*v[k+3]+.82*v[k+4]+.44*v[k+5])/Math.hypot(.35,.82,.44)),color=[6,7,8].map(i=>Math.round(v[k+i]*light*255)),minX=Math.max(0,Math.floor(Math.min(a[0],b[0],c[0]))),maxX=Math.min(w-1,Math.ceil(Math.max(a[0],b[0],c[0]))),minY=Math.max(0,Math.floor(Math.min(a[1],b[1],c[1]))),maxY=Math.min(h-1,Math.ceil(Math.max(a[1],b[1],c[1])));
 for(let y=minY;y<=maxY;y++)for(let x=minX;x<=maxX;x++){const px=x+.5,py=y+.5,u=((b[1]-c[1])*(px-c[0])+(c[0]-b[0])*(py-c[1]))/area,t=((c[1]-a[1])*(px-c[0])+(a[0]-c[0])*(py-c[1]))/area,z=1-u-t;if(u<0||t<0||z<0)continue;const d=u*a[2]+t*b[2]+z*c[2],index=y*w+x;if(d<depth[index]){depth[index]=d;rgba.set([...color,255],index*4);}}
 }await sharp(rgba,{raw:{width:w,height:h,channels:4}}).png().toFile(`docs/visuals/prototype3d-${name}-v${version}-static.png`);}
console.log(scene.stats);
