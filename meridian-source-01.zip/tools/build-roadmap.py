from pathlib import Path
import html,re,json,sys
full_audit='--full-audit' in sys.argv
audit='--audit' in sys.argv
reference='--reference' in sys.argv
source=Path('AUDIT.md' if full_audit else 'KTP_REFERENCE.md' if reference else 'VISUAL_AUDIT.md' if audit else 'PLAN.md').read_text()
lines=source.splitlines();out=[];toc=[];n=0;section=0
def fmt(s):
 text=re.sub(r'\*\*(.*?)\*\*',r'<strong>\1</strong>',html.escape(s))
 return re.sub(r'https?://[^\s<>;]+',lambda m:'<a href="'+m[0].rstrip('.,')+'" target="_blank" rel="noopener">'+m[0].rstrip('.,')+'</a>'+m[0][len(m[0].rstrip('.,')):],text)
while n<len(lines):
 line=lines[n]
 if not line.strip(): n+=1;continue
 if line.startswith('# '):out.append('<h1>'+fmt(line[2:])+'</h1>');n+=1;continue
 if line.startswith('## '):
  section+=1;title=line[3:];anchor='section-'+str(section);toc.append((anchor,title));out.append(f'<h2 id="{anchor}">'+fmt(title)+'</h2>');n+=1;continue
 if line.startswith('|'):
  rows=[]
  while n<len(lines) and lines[n].startswith('|'):
   row=lines[n];n+=1
   if re.fullmatch(r'\|[-| :]+\|',row):continue
   rows.append([cell.strip() for cell in row.strip('|').split('|')])
  headers=rows[0];out.append('<div class="table-scroll"><table><thead><tr>'+''.join('<th scope="col">'+fmt(h)+'</th>' for h in headers)+'</tr></thead><tbody>')
  for row in rows[1:]:out.append('<tr>'+''.join('<td data-label="'+html.escape(headers[k],quote=True)+'">'+fmt(cell)+'</td>' for k,cell in enumerate(row))+'</tr>')
  out.append('</tbody></table></div>');continue
 if re.match(r'^\d+\. ',line):
  out.append('<ol>')
  while n<len(lines) and re.match(r'^\d+\. ',lines[n]):out.append('<li>'+fmt(re.sub(r'^\d+\. ','',lines[n]))+'</li>');n+=1
  out.append('</ol>');continue
 out.append('<p>'+fmt(line)+'</p>');n+=1
head='''<!doctype html><html lang="ru"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Дорожная карта до 1.0 — Mercury Response</title><link rel="stylesheet" href="style.css"><style>
body{display:block;overflow:auto;padding:24px 16px 60px}article{max-width:1050px;margin:auto}nav{display:flex;gap:20px;flex-wrap:wrap}h1{font-size:34px;line-height:1.2;margin:28px 0}h2{font-size:23px;margin:38px 0 12px;scroll-margin-top:20px}p,li{line-height:1.8;color:#bdd1cf}li{margin:10px 0}.table-scroll{border:1px solid #385049;border-radius:10px;overflow:auto}table{border-collapse:collapse;width:100%;font-size:13px}td,th{padding:14px;border-bottom:1px solid #385049;vertical-align:top;line-height:1.7;text-align:left}th{background:#264338;color:#a5e0c6}tr:nth-child(even){background:#182d29}strong{color:#a3e4ce}.contents{margin:22px 0;padding:16px;border:1px solid #385049;border-radius:10px}.contents summary{cursor:pointer;font-size:17px;min-height:44px}.contents a{display:block;padding:8px 0}.top-link{display:block;min-height:44px;padding:14px 0}
@media(max-width:650px){h1{font-size:27px}h2{font-size:21px}.table-scroll{overflow:visible;border:0}table,tbody,tr,td{display:block;width:100%}thead{position:absolute;clip-path:inset(100%);width:1px;height:1px;overflow:hidden}tr{border:1px solid #385049;border-radius:10px;margin:12px 0;padding:7px 13px;background:#182d29}td{padding:8px 0;border:0;font-size:14px}td::before{content:attr(data-label);display:block;font-size:10px;text-transform:uppercase;letter-spacing:1px;color:#89afa0;margin-bottom:3px}td:first-child{color:#a3e4ce;font-weight:600}}
</style></head><body><article id="top"><nav aria-label="Документы проекта"><a href="./">← В игру</a><a href="map-notes.html">Карта и источники</a><a href="QA.md">Проверки</a><a href="audit.html">Аудит</a><a href="roadmap.html">План</a><a href="research.html">Исследование</a><a href="PLAN.md">Исходный план</a><a href="HOSTING.md">Свой хостинг</a><a href="downloads/meridian-watch-0.4.1-static.zip" download>Скачать сборку 0.4.1</a></nav>'''
if full_audit:head=head.replace('Дорожная карта до 1.0 — Mercury Response','Полный аудит — Mercury Response')
if reference:head=head.replace('Дорожная карта до 1.0 — Mercury Response','Keep the Peace — разбор и план Mercury Response')
version=json.loads(Path('package.json').read_text())['version']
delivery_version=version.split('-',1)[0]
head=head.replace('downloads/meridian-watch-0.4.1-static.zip','https://meridian-watch.osminoog09.chatgpt.site/downloads/meridian-watch-'+delivery_version+'-static.zip').replace('Скачать сборку 0.4.1','Скачать сборку '+version)
contents='<details class="contents"><summary>Оглавление · системы, графика, проверки</summary><nav aria-label="Оглавление" style="display:block">'+''.join(f'<a href="#{anchor}">{fmt(title)}</a>' for anchor,title in toc)+'</nav></details>'
# Keep the title and introductory release paragraph above navigation.
out.insert(2,contents)
if audit:
 head=head.replace('Дорожная карта до 1.0 — Mercury Response','Аудит графики — Mercury Response')
 refs=[('https://media.moddb.com/images/articles/1/253/252096/pt10cand00890_indieDBcrop.jpg','Патрульные машины'),('https://media.indiedb.com/images/articles/1/292/291901/newUI.jpg','Город и интерфейс'),('https://media.moddb.com/images/articles/1/263/262247/VideoThumbnail.PNG','Остановка и погоня')]
 out.insert(2,'<section><h2>Изображения для сравнения — Keep the Peace</h2><p>Материалы разработчика, открываются с внешнего источника. Это не графика Mercury Response.</p>'+''.join('<figure style="margin:24px 0"><a href="'+url+'" target="_blank" rel="noopener"><img src="'+url+'" alt="'+label+' в Keep the Peace" loading="lazy" referrerpolicy="no-referrer" style="width:100%;height:auto;border-radius:12px"></a><figcaption>'+label+' · Deliberative Entertainment / IndieDB / ModDB</figcaption></figure>' for url,label in refs)+'</section>')
Path('dist/audit.html' if full_audit else 'dist/ktp-reference.html' if reference else 'dist/visual-audit.html' if audit else 'dist/roadmap.html').write_text(head+''.join(out)+'<a class="top-link" href="#top">↑ К началу</a></article></body></html>')
Path('dist/AUDIT.md' if full_audit else 'dist/KTP_REFERENCE.md' if reference else 'dist/VISUAL_AUDIT.md' if audit else 'dist/PLAN.md').write_text(source)
