"""Export only public deployable assets, never repository metadata or credentials."""
from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED,ZipInfo
import hashlib,json,re
root=Path(__file__).resolve().parent.parent
version=json.loads((root/'package.json').read_text())['version']
# The installed VPS updater accepts numeric versions only. The checksum still
# identifies each exact build, including successive e-series optimizations.
match=re.fullmatch(r'(\d+\.\d+\.\d+)(?:-[A-Za-z0-9][A-Za-z0-9.-]*)?',version)
if not match:
 raise ValueError('Unsupported build version')
delivery_version=match.group(1)
output=root/'dist'/'downloads';output.mkdir(exist_ok=True)
archive=output/f'meridian-watch-{delivery_version}-static.zip'
files=sorted(p for p in (root/'dist').rglob('*') if p.is_file() and not {'downloads','deploy'}.intersection(p.relative_to(root/'dist').parts))
with ZipFile(archive,'w',compression=ZIP_DEFLATED,compresslevel=9) as z:
 for p in files:
  info=ZipInfo(p.relative_to(root/'dist').as_posix(),date_time=(2026,10,8,0,0,0));info.compress_type=ZIP_DEFLATED;info.external_attr=0o644<<16;z.writestr(info,p.read_bytes())
with ZipFile(archive) as z:
 assert z.testzip() is None
 assert all(z.read(p.relative_to(root/'dist').as_posix())==p.read_bytes() for p in files)
 assert 'index.html' in z.namelist() and 'city-data.js' in z.namelist()
 assert not any(name.startswith('.') or '..' in Path(name).parts for name in z.namelist())
sha=hashlib.sha256(archive.read_bytes()).hexdigest()
(archive.with_suffix('.sha256')).write_text(sha+'  '+archive.name+'\n')
print(f'{archive.name}: {len(files)} files, {archive.stat().st_size} bytes, SHA256 {sha}')
# Publishing this manifest explicitly approves this exact archive for the VPS.
deploy=root/'dist'/'deploy';deploy.mkdir(exist_ok=True)
(deploy/'release.json').write_text(json.dumps({'version':delivery_version,'build_version':version,'archive':'/downloads/'+archive.name,'sha256':sha,'bytes':archive.stat().st_size},indent=2)+'\n')
