// Fresh-process CPU profile of completed background jobs with a no-op Canvas.
// This deliberately excludes browser rasterization, GPU, RAF pacing and phone FPS.
import fs from 'node:fs';
import {execFileSync} from 'node:child_process';
import path from 'node:path';
import {baselineModules} from './baseline-modules.mjs';

const baseline=process.argv[2],output=process.argv[3]??'docs/focus-audit.json';
const profileDir=process.argv[4]?path.resolve(process.argv[4]):null;
if(profileDir)fs.mkdirSync(profileDir,{recursive:true});
if(!/^[a-f0-9]{40}$/.test(baseline??''))throw Error('Full baseline commit required');
const snapshot=baselineModules(baseline),currentRender=new URL('../dist/render.js',import.meta.url).href,currentSim=new URL('../dist/sim.js',import.meta.url).href;
const code=(render,sim,focus)=>`import {performance} from 'node:perf_hooks';
const graphStart=performance.now(),{createRenderer}=await import(${JSON.stringify(render)}),{createGame}=await import(${JSON.stringify(sim)}),graphMs=performance.now()-graphStart;
const ctx=new Proxy({}, {get:(o,k)=>o[k]??(()=>{}),set:(o,k,v)=>(o[k]=v,true)}),canvas=()=>({width:390,height:570,getContext:()=>ctx,getBoundingClientRect:()=>({width:390,height:570,left:0,top:0}),addEventListener(){}});
globalThis.document={createElement:canvas};globalThis.ResizeObserver=class{observe(){}};globalThis.devicePixelRatio=2;
const r=createRenderer(canvas(),()=>{}),s=createGame();${focus==='wholeCity'?'r.reset();':focus==='quarter'?'r.quarter();':focus==='patrol'?'r.locate(s.units[0]);':''}
const frames=[];for(let k=0;k<3000;k++){const start=performance.now();r.draw(s,1,null,null,1/30,1/45);frames.push(performance.now()-start);if(!r.stats().backgroundPending)break;}if(r.stats().backgroundPending)throw Error('Background did not complete');
const ordered=frames.slice().sort((a,b)=>a-b);console.log(JSON.stringify({graphMs,frames:frames.length,totalMs:frames.reduce((a,b)=>a+b,0),firstMs:frames[0],p95Ms:ordered[Math.ceil(ordered.length*.95)-1],maxMs:Math.max(...frames),heapUsed:process.memoryUsage().heapUsed,stats:r.stats()}));`;
let profileNumber=0;
const run=(render,sim,focus)=>JSON.parse(execFileSync(process.execPath,[...(profileDir?['--cpu-prof','--cpu-prof-dir='+profileDir,'--cpu-prof-name='+String(++profileNumber).padStart(2,'0')+'-'+focus+'.cpuprofile']:[]),'--input-type=module','-e',code(render,sim,focus)],{encoding:'utf8',maxBuffer:8e6}));
const scenarios=[];for(const focus of ['first','wholeCity','quarter','patrol']){const before=[],after=[];for(let k=0;k<3;k++){before.push(run(snapshot.url('render.js'),snapshot.url('sim.js'),focus));after.push(run(currentRender,currentSim,focus));}scenarios.push({focus,baseline:before,current:after});}
const result={version:JSON.parse(fs.readFileSync('package.json')).version,baselineCommit:baseline,baselineGraphModules:snapshot.files,cpuProfilerEnabled:!!profileDir,scenarios,limits:'Three fresh Node processes per implementation and focus. No-op Canvas; no command recording, Path2D, rasterization, GPU, browser, phone, network, RAF pacing or simulation advance. OS file cache is not cleared. CPU and heapUsed are process-local diagnostics, not mobile FPS or total browser memory.'};
fs.writeFileSync(output,JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify(result,null,2));
