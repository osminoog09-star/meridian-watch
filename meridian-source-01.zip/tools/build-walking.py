"""Extract conservative central footpaths from the same OSM tiles as city-data.
Usage: python tools/build-walking.py /path/to/osm/tiles
No private/unknown-access paths, barriers, indoor paths or inferred connections.
"""
import pathlib,sys,json,xml.etree.ElementTree as E
from city_projection import project
nodes={};ways={};barriers=set();node_tags={}
for f in sorted(pathlib.Path(sys.argv[1]).glob('*.osm')):
 for el in E.parse(f).getroot():
  tags={t.attrib['k']:t.attrib['v'] for t in el.findall('tag')}
  if el.tag=='node':
   node_tags[el.attrib['id']]=tags
   nodes[el.attrib['id']]=project(float(el.attrib['lon']),float(el.attrib['lat']))
   if 'barrier' in tags:barriers.add(el.attrib['id'])
  elif el.tag=='way':ways[el.attrib['id']]=([n.attrib['ref'] for n in el.findall('nd')],tags)
segments=[];excluded=0
cx,cy=project(24.499,58.384)
for wid,(ids,t) in sorted(ways.items()):
 if t.get('highway') not in ('footway','pedestrian'):continue
 if t.get('access','yes') not in ('yes','public','permissive') or t.get('foot','yes') not in ('yes','designated','permissive') or t.get('indoor')=='yes' or t.get('tunnel') in ('yes','building_passage') or t.get('bridge')=='yes' or t.get('construction') or t.get('area')=='yes':
  excluded+=1;continue
 for a,b in zip(ids,ids[1:]):
  if a not in nodes or b not in nodes or a in barriers or b in barriers:continue
  if any((x-cx)**2+(y-cy)**2>.35**2 for x,y in (nodes[a],nodes[b])):continue
  segments.append({'way':wid,'a':a,'b':b,'p':[nodes[a],nodes[b]],'name':t.get('name',''),'kind':t['highway']})
entrances=[]
# One audited public point of interest; no automatic admission of residential doors.
for wid,(ids,t) in sorted(ways.items()):
 if wid!='65399842' or t.get('tourism')!='museum' or t.get('access','yes') not in ('yes','public','permissive'):continue
 for nid in ids:
  nt=node_tags.get(nid,{})
  if nt.get('entrance') not in ('yes','main') or nt.get('access','yes') not in ('yes','public','permissive') or nid in barriers:continue
  entrances.append({'id':nid,'building':wid,'p':nodes[nid],'name':t.get('name','Музей'),'address':t.get('addr:street','')+' '+t.get('addr:housenumber',''),'entrance':nt['entrance']})
out={'entrances':entrances,'source':'OpenStreetMap tiles used for city-data, 2026-10-07','excludedWays':excluded,'segments':segments}
pathlib.Path('data/walking-source.json').write_text(json.dumps(out,ensure_ascii=False,separators=(',',':'))+'\n')
print(f'{len(segments)} central candidate segments; {excluded} ways excluded by tags')
